import unittest
from eidolang.reliability import *

def manifest(nanchors=20,maxr=0.05,alpha=.05,drift_alpha=.01):
    return ReliabilityManifest(
        study_id="S",protocol_hash="P",manifest_version="v1",
        observer_ids=("O1","O2"),anchor_ids=tuple(f"A{i}" for i in range(nanchors)),
        metric_keys=("focus","noise"),repeats_per_anchor=2,
        alpha_repeatability=alpha,alpha_drift=drift_alpha,
        max_repeatability_radius={"focus":maxr,"noise":maxr},
        quantization_step={"focus":.01,"noise":.01},
    )

def stable_obs(m,observer,noise=.004,drift=0.0):
    out=[]
    for i,aid in enumerate(m.anchor_ids):
        base=-.2 + .4*i/max(1,len(m.anchor_ids)-1)
        # deterministic alternating small discrepancy so no sign drift
        e=noise*(1 if i%2==0 else -1)
        d0={"focus":base,"noise":-base}
        d1={"focus":base+e+drift,"noise":-base-e+drift}
        out += [
          RepeatObservation(observer,aid,0,d0,f"{observer}-{aid}-0","P","fid"),
          RepeatObservation(observer,aid,1,d1,f"{observer}-{aid}-1","P","fid"),
        ]
    return out

class R410Tests(unittest.TestCase):
    def test_stable_repeatability_passes(self):
        m=manifest()
        obs=stable_obs(m,"O1")+stable_obs(m,"O2")
        g=reliability_gate(m,obs)
        self.assertEqual(g.status,"PASS")
        self.assertGreaterEqual(g.common_resolution_floor["focus"],.01)

    def test_insufficient_pairs_unresolved_at_95pct(self):
        m=manifest(nanchors=10)
        c=certify_observer_reliability(m,"O1",stable_obs(m,"O1"))
        self.assertEqual(c.status,"UNRESOLVED")
        self.assertTrue(any(r.status=="UNRESOLVED" for r in c.metric_results))

    def test_noisy_metric_fails(self):
        m=manifest(maxr=.02)
        c=certify_observer_reliability(m,"O1",stable_obs(m,"O1",noise=.04))
        self.assertEqual(c.status,"FAIL")
        self.assertTrue(any("exceeds" in x for r in c.metric_results for x in r.reasons))

    def test_systematic_drift_fails(self):
        m=manifest(nanchors=20,maxr=.2,drift_alpha=.01)
        c=certify_observer_reliability(m,"O1",stable_obs(m,"O1",noise=0.0,drift=.03))
        self.assertEqual(c.status,"FAIL")
        self.assertTrue(any("drift" in x for r in c.metric_results for x in r.reasons))

    def test_quantization_is_resolution_floor(self):
        m=manifest()
        obs=stable_obs(m,"O1",noise=0.0)
        c=certify_observer_reliability(m,"O1",obs)
        rs=c.radius_by_metric()
        self.assertEqual(rs["focus"],.01)

    def test_equivalence_margin_below_floor_invalid(self):
        m=manifest()
        obs=stable_obs(m,"O1")+stable_obs(m,"O2")
        g=reliability_gate(m,obs)
        r=validate_equivalence_margins({"focus":.005,"noise":.02},g)
        self.assertEqual(r.status,"INVALID")

    def test_equivalence_margin_at_or_above_floor_passes(self):
        m=manifest()
        obs=stable_obs(m,"O1")+stable_obs(m,"O2")
        g=reliability_gate(m,obs)
        margins={k:v for k,v in g.common_resolution_floor.items()}
        r=validate_equivalence_margins(margins,g)
        self.assertEqual(r.status,"PASS")

if __name__=="__main__":
    unittest.main()
