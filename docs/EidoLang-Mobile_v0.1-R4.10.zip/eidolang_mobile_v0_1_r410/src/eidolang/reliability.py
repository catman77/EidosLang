from __future__ import annotations

from dataclasses import dataclass, field, asdict
from math import ceil, comb
from typing import Any, Iterable, Optional
import hashlib
import json

from .acquisition import sha256_object


@dataclass(frozen=True)
class ReliabilityManifest:
    study_id: str
    protocol_hash: str
    manifest_version: str
    observer_ids: tuple[str, ...]
    anchor_ids: tuple[str, ...]
    metric_keys: tuple[str, ...]
    repeats_per_anchor: int
    alpha_repeatability: float
    alpha_drift: float
    max_repeatability_radius: dict[str, float]
    quantization_step: dict[str, float]
    pairing_policy: str = "ADJACENT_DISJOINT"
    unreliable_metric_policy: str = "FAIL_WHOLE_GATE"
    external_commit_ref: Optional[str] = None

    def __post_init__(self):
        if not (0 < self.alpha_repeatability < 1):
            raise ValueError("alpha_repeatability must be in (0,1)")
        if not (0 < self.alpha_drift < 1):
            raise ValueError("alpha_drift must be in (0,1)")
        if self.repeats_per_anchor < 2:
            raise ValueError("repeats_per_anchor must be >=2")
        if self.pairing_policy != "ADJACENT_DISJOINT":
            raise ValueError("only ADJACENT_DISJOINT is admitted in R4.10")
        if self.unreliable_metric_policy != "FAIL_WHOLE_GATE":
            raise ValueError("R4.10 admits only FAIL_WHOLE_GATE")
        if not self.observer_ids or not self.anchor_ids or not self.metric_keys:
            raise ValueError("observer_ids, anchor_ids and metric_keys must be non-empty")
        if set(self.max_repeatability_radius) != set(self.metric_keys):
            raise ValueError("max_repeatability_radius keys must equal metric_keys")
        if set(self.quantization_step) != set(self.metric_keys):
            raise ValueError("quantization_step keys must equal metric_keys")
        if any(v < 0 for v in self.max_repeatability_radius.values()):
            raise ValueError("negative max_repeatability_radius")
        if any(v < 0 for v in self.quantization_step.values()):
            raise ValueError("negative quantization_step")

    @property
    def manifest_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class RepeatObservation:
    observer_id: str
    anchor_id: str
    repeat_index: int
    delta: dict[str, float]
    session_id: str
    protocol_hash: str
    fidelity_certificate_ref: Optional[str] = None


@dataclass(frozen=True)
class RepeatPair:
    observer_id: str
    anchor_id: str
    repeat_index_a: int
    repeat_index_b: int
    session_id_a: str
    session_id_b: str
    signed_difference: dict[str, float]


@dataclass(frozen=True)
class MetricRepeatability:
    metric: str
    pair_count: int
    conformal_rank: Optional[int]
    empirical_abs_differences: tuple[float, ...]
    empirical_signed_differences: tuple[float, ...]
    conformal_radius: Optional[float]
    quantization_floor: float
    effective_radius: Optional[float]
    max_allowed_radius: float
    drift_nonzero_count: int
    drift_positive_count: int
    drift_negative_count: int
    exact_sign_p: Optional[float]
    dynamic_range: Optional[float]
    dynamic_range_to_radius: Optional[float]
    status: str
    reasons: tuple[str, ...]


@dataclass(frozen=True)
class ObserverReliabilityCertificate:
    observer_id: str
    manifest_hash: str
    protocol_hash: str
    metric_results: tuple[MetricRepeatability, ...]
    status: str
    reasons: tuple[str, ...]

    @property
    def certificate_hash(self) -> str:
        return sha256_object(self)

    def radius_by_metric(self) -> dict[str, float]:
        out={}
        for r in self.metric_results:
            if r.effective_radius is not None:
                out[r.metric]=r.effective_radius
        return out


@dataclass(frozen=True)
class ReliabilityGateResult:
    status: str
    observer_certificates: tuple[ObserverReliabilityCertificate, ...]
    common_resolution_floor: dict[str, float]
    reasons: tuple[str, ...]


@dataclass(frozen=True)
class MarginResolutionResult:
    status: str
    reasons: tuple[str, ...]


def _exact_two_sided_sign_p(values: list[float]) -> tuple[Optional[float], int, int, int]:
    nz=[v for v in values if abs(v) > 1e-15]
    n=len(nz)
    pos=sum(v>0 for v in nz)
    neg=n-pos
    if n == 0:
        return 1.0, 0, 0, 0
    k=min(pos,neg)
    tail=sum(comb(n,j) for j in range(0,k+1)) / (2**n)
    return min(1.0,2*tail), n, pos, neg


def _conformal_upper_radius(abs_errors: list[float], alpha: float) -> tuple[Optional[int], Optional[float], Optional[str]]:
    # Split-conformal style finite-sample upper quantile for a future exchangeable
    # absolute repeat discrepancy. Need ceil((n+1)(1-alpha)) <= n.
    n=len(abs_errors)
    if n == 0:
        return None,None,"no repeat pairs"
    k=ceil((n+1)*(1-alpha))
    if k > n:
        return k,None,f"insufficient pairs for finite-sample alpha={alpha:g}; need at least {ceil(1/alpha)-1}"
    xs=sorted(abs_errors)
    return k,xs[k-1],None


def _disjoint_pairs(obs: list[RepeatObservation]) -> list[RepeatPair]:
    grouped={}
    for o in obs:
        grouped.setdefault(o.anchor_id,[]).append(o)
    pairs=[]
    for aid, rows in sorted(grouped.items()):
        rows=sorted(rows,key=lambda x:(x.repeat_index,x.session_id))
        for i in range(0,len(rows)-1,2):
            a,b=rows[i],rows[i+1]
            keys=set(a.delta)&set(b.delta)
            pairs.append(RepeatPair(
                observer_id=a.observer_id,
                anchor_id=aid,
                repeat_index_a=a.repeat_index,
                repeat_index_b=b.repeat_index,
                session_id_a=a.session_id,
                session_id_b=b.session_id,
                signed_difference={k:b.delta[k]-a.delta[k] for k in keys},
            ))
    return pairs


def _dynamic_range(obs: list[RepeatObservation], metric: str) -> Optional[float]:
    by={}
    for o in obs:
        if metric in o.delta:
            by.setdefault(o.anchor_id,[]).append(o.delta[metric])
    med=[]
    for aid, vals in by.items():
        if vals:
            vals=sorted(vals)
            n=len(vals)
            m=vals[n//2] if n%2 else 0.5*(vals[n//2-1]+vals[n//2])
            med.append(m)
    if len(med)<2:
        return None
    return max(med)-min(med)


def certify_observer_reliability(
    manifest: ReliabilityManifest,
    observer_id: str,
    observations: Iterable[RepeatObservation],
) -> ObserverReliabilityCertificate:
    rows=[o for o in observations if o.observer_id==observer_id]
    global_reasons=[]
    if observer_id not in manifest.observer_ids:
        global_reasons.append("observer not declared in reliability manifest")
    if any(o.protocol_hash != manifest.protocol_hash for o in rows):
        global_reasons.append("protocol_hash mismatch in repeat observations")
    undeclared={o.anchor_id for o in rows}-set(manifest.anchor_ids)
    if undeclared:
        global_reasons.append("undeclared anchors present: "+",".join(sorted(undeclared)))
    # Exact schema: every admitted repeat observation must carry all and only frozen metrics.
    required=set(manifest.metric_keys)
    for o in rows:
        if set(o.delta)!=required:
            global_reasons.append(f"metric schema mismatch in {o.session_id}")
    pairs=_disjoint_pairs(rows)
    results=[]
    for metric in manifest.metric_keys:
        signed=[p.signed_difference[metric] for p in pairs if metric in p.signed_difference]
        absd=[abs(x) for x in signed]
        k,radius,err=_conformal_upper_radius(absd,manifest.alpha_repeatability)
        qfloor=manifest.quantization_step[metric]
        effective=None if radius is None else max(radius,qfloor)
        sign_p,nz,pos,neg=_exact_two_sided_sign_p(signed)
        dr=_dynamic_range(rows,metric)
        ratio=None
        if dr is not None and effective is not None:
            ratio=float("inf") if effective<=1e-15 and dr>0 else (0.0 if effective<=1e-15 else dr/effective)
        reasons=[]
        status="PASS"
        if err is not None:
            status="UNRESOLVED"; reasons.append(err)
        elif effective is not None and effective > manifest.max_repeatability_radius[metric] + 1e-15:
            status="FAIL"; reasons.append("repeatability radius exceeds preregistered maximum")
        if sign_p is not None and sign_p < manifest.alpha_drift:
            status="FAIL"; reasons.append("systematic repeat-order drift detected by exact sign test")
        results.append(MetricRepeatability(
            metric=metric,
            pair_count=len(signed),
            conformal_rank=k,
            empirical_abs_differences=tuple(absd),
            empirical_signed_differences=tuple(signed),
            conformal_radius=radius,
            quantization_floor=qfloor,
            effective_radius=effective,
            max_allowed_radius=manifest.max_repeatability_radius[metric],
            drift_nonzero_count=nz,
            drift_positive_count=pos,
            drift_negative_count=neg,
            exact_sign_p=sign_p,
            dynamic_range=dr,
            dynamic_range_to_radius=ratio,
            status=status,
            reasons=tuple(reasons),
        ))
    if any(r.status=="FAIL" for r in results):
        global_reasons.append("one or more required metrics failed repeatability")
    elif any(r.status=="UNRESOLVED" for r in results):
        global_reasons.append("one or more required metrics unresolved")
    status="FAIL" if any(r.status=="FAIL" for r in results) or global_reasons and any("mismatch" in x or "undeclared" in x or "not declared" in x for x in global_reasons) else (
        "UNRESOLVED" if any(r.status=="UNRESOLVED" for r in results) else "PASS"
    )
    if global_reasons and status=="PASS":
        status="FAIL"
    return ObserverReliabilityCertificate(
        observer_id=observer_id,
        manifest_hash=manifest.manifest_hash,
        protocol_hash=manifest.protocol_hash,
        metric_results=tuple(results),
        status=status,
        reasons=tuple(global_reasons),
    )


def reliability_gate(
    manifest: ReliabilityManifest,
    observations: Iterable[RepeatObservation],
) -> ReliabilityGateResult:
    obs=list(observations)
    certs=tuple(certify_observer_reliability(manifest,o,obs) for o in manifest.observer_ids)
    reasons=[]
    if any(c.status=="FAIL" for c in certs):
        reasons.append("at least one observer failed required measurement repeatability")
        status="FAIL"
    elif any(c.status=="UNRESOLVED" for c in certs):
        reasons.append("at least one observer measurement repeatability is unresolved")
        status="UNRESOLVED"
    else:
        status="PASS"
    floors={}
    if certs:
        for metric in manifest.metric_keys:
            vals=[]
            for c in certs:
                r=c.radius_by_metric().get(metric)
                if r is not None:
                    vals.append(r)
            if len(vals)==len(certs):
                floors[metric]=max(vals)
    return ReliabilityGateResult(status,certs,floors,tuple(reasons))


def validate_equivalence_margins(
    margins: dict[str,float],
    reliability: ReliabilityGateResult,
) -> MarginResolutionResult:
    reasons=[]
    if reliability.status!="PASS":
        reasons.append("measurement reliability gate is not PASS")
        return MarginResolutionResult("INVALID",tuple(reasons))
    for metric,floor in reliability.common_resolution_floor.items():
        if metric not in margins:
            reasons.append(f"missing equivalence margin for {metric}")
        elif margins[metric] + 1e-15 < floor:
            reasons.append(
                f"equivalence margin for {metric} ({margins[metric]:g}) is below empirical repeatability floor ({floor:g})"
            )
    return MarginResolutionResult("PASS" if not reasons else "INVALID",tuple(reasons))
