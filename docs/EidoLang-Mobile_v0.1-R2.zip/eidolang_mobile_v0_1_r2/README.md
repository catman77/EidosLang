# EidoLang-Mobile v0.1-R1

Минимальное детерминированное ядро для исследования эйдографического языка как языка **операторов состояния**, а не словаря заранее назначенных символов.

## Инварианты R1

1. Raw-first/event-sourced: первичен поток `RawEvent`; финальное изображение — производное представление.
2. Никакой заданной семантики форм: в ядре нет правил вроде «круг = покой».
3. Сегмент = физический stroke: R1 не вводит эвристическую субсегментацию.
4. Токены структурные: форма кодируется канонической геометрической сигнатурой; отношения — числовыми дескрипторами.
5. Операторы открываются по эффекту: `EidoOperator` — повторяющийся n-граммный паттерн, связанный с наблюдаемым переходом состояния.
6. Evidence-carrying: сохраняются support, evidence и counterexamples.
7. Recommender не рисует за пользователя: он возвращает ссылку на прототип следующего структурного действия.
8. Все derived-артефакты версионируются; raw-данные неизменяемы.

## Pipeline

```text
smartphone pointer/media events
        -> RawEvent stream (append-only)
        -> StrokeSegmenter v1
        -> shape signatures + relation descriptors
        -> token trajectory
        -> OperatorMiner
        -> EidoOperator + evidence + counterexamples
        -> DeterministicRecommender
        -> next-action prototype reference
```

Состояние субъекта хранится независимо:

```text
latent state m_t --unknown--> StateObservation o_t = proxy(m_t)
```

Никакая шкала состояния не считается фундаментальной.

## Запуск

```bash
python -m pip install -e .
python -m unittest discover -s tests -v
```

CLI:

```bash
eidolang analyze examples/sample_session.json
```

## Gate R1

R1 считается содержательно успешным только если на корпусе появляются паттерны `w`, для которых наблюдаемый переход состояния воспроизводимо отличается от baseline и сохраняется на отложенных сессиях.

# R2 — персональный алфавит и эффект-грамматика

R2 добавляет автоматический discovery-проход, который **не присваивает значения формам вручную**.

## Alphabet gate

Исходные stroke signatures рассматриваются как технические токены. Два токена допускается
слить в один `AlphabetSymbol` только если pooled effect predictor на holdout не хуже, чем два
раздельных predictors. Символ сохраняется только если его predictor на holdout лучше глобального
baseline состояния.

```text
raw stroke tokens
   -> train effect estimates
   -> deterministic agglomerative merge
   -> holdout non-inferiority gate
   -> predictive-vs-global-baseline gate
   -> AlphabetSymbol
```

## Grammar gate

После factorization stroke token -> alphabet symbol сессия кодируется как:

```text
A:symbol, R:relation, A:symbol, R:relation, ...
```

Паттерн порядка >=2 становится `EffectGrammarRule`, только если на holdout его transition predictor
строго лучше predictor-а собственного suffix. Это проверяет наличие **контекстного эффекта**, а не
просто частоты последовательности.

## Negative controls

И alphabet, и grammar повторно строятся на детерминированных permutations `session -> state_delta`,
которые сохраняют распределение эффектов, но разрушают связь формы с переходом состояния.
Discovery gate проходит только если реальный holdout gain выше максимального gain предзаданных
controls.

Это сильный, намеренно консервативный gate; `negative_controls` — вычислительный budget протокола,
а не семантический порог.

## Важное ограничение R2

State delta пока относится к сессии целиком. Поэтому найденная буква/грамматическое правило означает
`predictive association with session transition`, а не доказанную причинность отдельного штриха.
Чтобы перейти к причинному оператору, следующая версия должна вводить промежуточные state probes или
рандомизированное/контрбалансированное воспроизведение уже найденных macro-operators.
