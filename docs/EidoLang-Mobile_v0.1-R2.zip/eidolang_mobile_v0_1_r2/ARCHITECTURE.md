# EidoLang-Mobile v0.1-R1 — архитектура

## 1. Мобильный слой

Capture UI обязан сохранять pointer events, monotonic timestamps, нормированные координаты, optional pressure/contact/tilt и media feedback log. Exported session bundle неизменяем.

## 2. Python core

- `schema.py` — контракты данных.
- `geometry.py` — структурные дескрипторы.
- `segmenter.py` — stroke segmentation и tokenization.
- `state.py` — операции над proxy-state.
- `operators.py` — evidence-carrying n-gram miner.
- `recommender.py` — детерминированный next-action recommender.
- `store.py` — append-only store.
- `utc_adapter.py` — связь с внешним UTC/mem-object.
- `latent.py` — только интерфейсы latent bridge; без зависимости от конкретной модели.

## 3. Каноническая цепочка

```text
RawEvent* -> StrokeSegment* -> RelationDescriptor* -> token* -> EidoOperator* -> MacroName*
```

## 4. Почему R1 не делает «умную» сегментацию

Любая субсегментация по curvature/speed потребовала бы порогов, не выведенных из корпуса. Поэтому первичная сегментация совпадает с физическим stroke `START..END`. Более тонкие границы разрешены только если они улучшают out-of-sample prediction переходов состояния.

## 5. Rotation

Перенос и масштаб нормализуются, поворот — нет. Если корпус покажет операторную эквивалентность вращённых форм, rotation-invariant quotient можно ввести как выведенную эквивалентность.

## 6. Gate для алфавита второго уровня

`segment_a ~ segment_b` допустимо только если замена `a` на `b` не меняет предсказанный state transition в пределах допуска. До этого shape signature — технический идентификатор, не «буква».

## 7. Gate для MacroName

`MacroName` возникает только после проверки `T_w1 ≈ T_w2 ≈ ...` на общей области начальных состояний и на отложенных сессиях.

## 8. Gate для AI

AI допускается только после фиксации deterministic baseline; режим `NONE` остаётся контролем; raw events отделены от model-derived artifacts; модель не назначает семантические ярлыки без отдельного evidence layer.

# R2 language discovery layer

```text
                   session-level state delta
                             |
Raw stroke token ------------+----> train effect estimates
      |                              |
      |                              v
      |                      exclusive-support gate
      |                              |
      +----------------------> holdout merge test
                                     |
                                     v
                               AlphabetSymbol
                                     |
            relation token ----------+
                                     |
                                     v
                         alternating symbolic sequence
                                     |
                                     v
                         context-vs-suffix holdout test
                                     |
                                     v
                            EffectGrammarRule
```

Both layers are rerun against deterministic label-permutation controls. The real pipeline is marked as discovered
only when its total holdout gain exceeds every configured control run.
