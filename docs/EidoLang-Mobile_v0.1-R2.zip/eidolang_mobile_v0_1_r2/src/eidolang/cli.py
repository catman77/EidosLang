from __future__ import annotations
import argparse,json
from pathlib import Path
from dataclasses import asdict
from enum import Enum
from .schema import EidoSession
from .segmenter import StrokeSegmenter
from .state import state_delta
from .discovery import LanguageDiscovery

def jsonable(x):
    if isinstance(x,Enum): return x.value
    if isinstance(x,tuple): return [jsonable(v) for v in x]
    if isinstance(x,list): return [jsonable(v) for v in x]
    if isinstance(x,dict): return {k:jsonable(v) for k,v in x.items()}
    return x

def load_session(p): return EidoSession.from_dict(json.loads(Path(p).read_text(encoding='utf-8')))

def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    a=sub.add_parser('analyze'); a.add_argument('session_json')
    d=sub.add_parser('discover'); d.add_argument('session_json',nargs='+')
    ns=ap.parse_args()
    if ns.cmd=='analyze':
        s=load_session(ns.session_json); toks,segs=StrokeSegmenter().tokens(s)
        print(json.dumps({'session_id':s.session_id,'segments':len(segs),'tokens':toks,'state_delta':state_delta(s)},ensure_ascii=False,indent=2))
    else:
        report=LanguageDiscovery().fit([load_session(p) for p in ns.session_json])
        print(json.dumps(jsonable(asdict(report)),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
