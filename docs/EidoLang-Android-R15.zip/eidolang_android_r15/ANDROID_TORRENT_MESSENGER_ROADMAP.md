# Android eidogram messenger roadmap after R15

## R14 / R14.1 — Eidogram editor — COMPLETE AT SOURCE LEVEL
113-glyph editor, exact geometry hit testing, grouping, canonical persistence/import/export.

## R15 — Identity + encrypted/signed message envelope — CURRENT / COMPLETE
- root P-256 user identity;
- root-certified device signing/encryption keys;
- AndroidKeyStore adapter;
- conversation descriptor;
- AES-256-GCM eidogram payload;
- RSA-OAEP per-device key boxes;
- signed immutable message DAG node;
- strict canonical parsers;
- fixed cryptographic golden vector.

## R16 — Torrent Archive Model — NEXT
- immutable `ConversationSegmentV1`;
- deterministic segment manifest;
- message-envelope files addressed by their message IDs;
- segment content hash;
- BitTorrent-v2 file-tree mapping;
- mutable signed `ConversationHeadV1`;
- no network engine yet.

## R17 — Android P2P / Torrent engine
- native/JNI torrent core;
- DHT;
- download/verify/seed;
- conversation-head publication/lookup;
- quotas and Android background policy.

## R18 — Messenger UX + local repository
- contact import;
- conversation list;
- signed message DAG repository;
- compose/send/receive;
- replay/sequence enforcement;
- sync state.

## R19 — Archive / Recovery
- local content index;
- pin/unpin;
- archive browser;
- full restore after deleting local database.

## R20 — Multi-device
- root-authorized additional device certificates;
- device revocation;
- concurrent conversation heads;
- deterministic DAG merge.

## R20.1 — Forward-secrecy session layer
- evaluate/introduce per-contact ratcheting without changing `EidogramDocumentV1`;
- historical-key erasure;
- migration of recipient-key boxes to ratcheted session secrets.

## R21 — Security / Fuzzing
- malformed canonical objects;
- signature/key-box attacks;
- replay;
- forged/stale heads;
- poisoned torrents;
- parser/JNI fuzzing.

## R22 — Android 1.0 acceptance
Two ordinary Android devices with no application server can create identities, exchange
encrypted signed eidograms, synchronize the same signed message DAG over BitTorrent/DHT,
archive it, and restore it from the P2P network.
