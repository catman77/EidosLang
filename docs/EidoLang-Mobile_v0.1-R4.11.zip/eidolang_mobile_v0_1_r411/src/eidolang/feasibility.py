from __future__ import annotations

from dataclasses import dataclass, asdict
from math import comb, factorial, ceil
from typing import Optional

from .acquisition import sha256_object


@dataclass(frozen=True)
class FeasibilityManifest:
    study_id: str
    protocol_hash: str
    manifest_version: str = "finite-sample-feasibility-v1"

    # R3 causal replay family
    r3_alpha_familywise: float = 0.05
    r3_operator_hypotheses: int = 2
    r3_endpoint_metric_hypotheses: int = 2
    r3_alternative: str = "one-sided"
    r3_min_per_arm: int = 4
    r3_exact_cap: int = 200_000

    # R4 substitution family
    r4_alpha_familywise: float = 0.05
    r4_macro_operator_count: int = 3
    r4_strata: int = 1
    r4_endpoint_metric_count: int = 2
    r4_trajectory_metric_count: int = 2
    r4_probe_phase_count: int = 2
    r4_min_per_arm_per_stratum: int = 4
    r4_exact_cap: int = 200_000

    # R4.7 alignment family
    observer_count: int = 6
    state_dimension: int = 6
    r47_alpha_familywise: float = 0.05
    r47_holdout_anchor_count: int = 3
    r47_permutation_cap: int = 100_000

    # R4.10 repeatability calibration
    r410_alpha_marginal: float = 0.05
    r410_metric_count: int = 6

    # Planned R5 primary representation-transport test
    r5_alpha_familywise: float = 0.05
    r5_primary_hypothesis_count: int = 1
    r5_binary_observer_label_flip: bool = True
    r5_exact_cap: int = 100_000

    def __post_init__(self):
        alphas = [
            self.r3_alpha_familywise, self.r4_alpha_familywise,
            self.r47_alpha_familywise, self.r410_alpha_marginal,
            self.r5_alpha_familywise,
        ]
        if any(not (0 < a < 1) for a in alphas):
            raise ValueError("all alpha values must be in (0,1)")
        ints = [
            self.r3_operator_hypotheses, self.r3_endpoint_metric_hypotheses,
            self.r3_min_per_arm, self.r4_macro_operator_count, self.r4_strata,
            self.r4_endpoint_metric_count, self.r4_trajectory_metric_count,
            self.r4_probe_phase_count, self.r4_min_per_arm_per_stratum,
            self.observer_count, self.state_dimension, self.r47_holdout_anchor_count,
            self.r410_metric_count, self.r5_primary_hypothesis_count,
        ]
        if any(x < 1 for x in ints):
            raise ValueError("count parameters must be >=1")
        if self.observer_count < 2:
            raise ValueError("observer_count must be >=2")
        if self.r4_macro_operator_count < 2:
            raise ValueError("r4_macro_operator_count must be >=2")
        if self.r3_alternative not in {"one-sided", "two-sided-balanced"}:
            raise ValueError("r3_alternative must be one-sided|two-sided-balanced")

    @property
    def manifest_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class ExactResolution:
    test_id: str
    alpha_local: float
    exact_outcomes: int
    p_floor: float
    exact_cap: int
    status: str
    reason: str


@dataclass(frozen=True)
class R3Feasibility:
    family_hypotheses: int
    alpha_local: float
    minimum_total_trials_per_operator: Optional[int]
    minimum_per_arm: Optional[int]
    exact_allocations: Optional[int]
    p_floor: Optional[float]
    status: str
    reason: str


@dataclass(frozen=True)
class R4Feasibility:
    pair_hypotheses: int
    checks_per_pair: int
    alpha_pair: float
    alpha_local_boundary: float
    minimum_trials_per_arm_per_stratum: Optional[int]
    total_trials_per_pair_per_stratum: Optional[int]
    exact_allocations_per_boundary: Optional[int]
    p_floor: Optional[float]
    status: str
    reason: str


@dataclass(frozen=True)
class R47Feasibility:
    nonreference_observers: int
    alpha_per_observer: float
    minimum_fit_anchors: Optional[int]
    exact_permutations: Optional[int]
    p_floor: Optional[float]
    holdout_anchor_count: int
    status: str
    reason: str


@dataclass(frozen=True)
class R410Feasibility:
    alpha_marginal: float
    marginal_min_disjoint_pairs: int
    marginal_min_repeat_sessions_per_observer: int
    observer_metric_channels: int
    bonferroni_simultaneous_alpha: float
    bonferroni_simultaneous_min_pairs: int
    semantics: str


@dataclass(frozen=True)
class R5Feasibility:
    primary_hypotheses: int
    alpha_local: float
    minimum_observers: Optional[int]
    exact_label_conventions: Optional[int]
    p_floor: Optional[float]
    configured_observers: int
    configured_exact_conventions: Optional[int]
    configured_p_floor: Optional[float]
    status: str
    reason: str


@dataclass(frozen=True)
class CorpusLowerBound:
    observer_count: int
    distinct_alignment_anchor_sessions_per_observer: int
    marginal_reliability_repeat_sessions_per_observer: int
    conservative_anchor_sessions_per_observer_no_reuse: int
    conservative_anchor_sessions_total_no_reuse: int
    notes: tuple[str, ...]


@dataclass(frozen=True)
class FeasibilityReport:
    manifest_hash: str
    r3: R3Feasibility
    r4: R4Feasibility
    r47: R47Feasibility
    r410: R410Feasibility
    r5: R5Feasibility
    corpus_lower_bound: CorpusLowerBound
    status: str
    reasons: tuple[str, ...]


def balanced_allocations(total_trials: int) -> tuple[int, int, int]:
    if total_trials < 2:
        raise ValueError("total_trials must be >=2")
    n_a = total_trials // 2
    n_b = total_trials - n_a
    return n_a, n_b, comb(total_trials, n_a)


def best_case_p_floor(exact_outcomes: int, multiplicity: int = 1) -> float:
    if exact_outcomes < 1 or multiplicity < 1:
        raise ValueError("positive exact_outcomes and multiplicity required")
    return min(1.0, multiplicity / exact_outcomes)


def minimum_balanced_trials(
    alpha_local: float,
    min_per_arm: int,
    exact_cap: int,
    two_sided_balanced: bool = False,
) -> tuple[Optional[int], Optional[int], Optional[float], str]:
    """
    Necessary arithmetic feasibility, not power.
    For a one-sided exact randomization test the best-case p resolution is >=1/C(n,n_a).
    For an even balanced two-sided test, complement symmetry gives a conservative
    best-case floor >=2/C(n,n/2).
    """
    for n in range(2*min_per_arm, 10_000):
        if n % 2:
            continue
        a,b,alloc = balanced_allocations(n)
        if a < min_per_arm or b < min_per_arm:
            continue
        if alloc > exact_cap:
            return None, alloc, None, (
                f"allocation cap reached before alpha resolution: C({n},{a})={alloc} > {exact_cap}"
            )
        mult = 2 if two_sided_balanced else 1
        floor = best_case_p_floor(alloc, mult)
        if floor <= alpha_local:
            return n, alloc, floor, "PASS"
    return None, None, None, "search bound exhausted"


def minimum_equal_arm_trials(
    alpha_local: float,
    min_per_arm: int,
    exact_cap: int,
) -> tuple[Optional[int], Optional[int], Optional[float], str]:
    for m in range(min_per_arm, 10_000):
        alloc = comb(2*m, m)
        if alloc > exact_cap:
            return None, alloc, None, (
                f"allocation cap reached before alpha resolution: C({2*m},{m})={alloc} > {exact_cap}"
            )
        floor = 1.0/alloc
        if floor <= alpha_local:
            return m, alloc, floor, "PASS"
    return None,None,None,"search bound exhausted"


def minimum_fit_anchors(
    alpha_per_observer: float,
    state_dimension: int,
    exact_cap: int,
) -> tuple[Optional[int], Optional[int], Optional[float], str]:
    k=max(2,state_dimension)
    while k < 100:
        n=factorial(k)
        if n > exact_cap:
            return None,n,None,f"{k}!={n} exceeds exact permutation cap {exact_cap} before required p resolution"
        floor=1.0/n
        if floor <= alpha_per_observer:
            return k,n,floor,"PASS"
        k+=1
    return None,None,None,"search bound exhausted"


def conformal_min_pairs(alpha: float) -> int:
    # ceil((n+1)(1-alpha)) <= n  <=>  n >= 1/alpha - 1.
    return max(1, ceil(1.0/alpha) - 1)


def binary_observer_label_conventions(observer_count: int) -> int:
    """
    Binary observer-wise label-convention flips, quotienting the irrelevant global swap:
        2^O / 2 = 2^(O-1).
    This is the planned exact R5 null family, not the old sampled R4.6 controls.
    """
    if observer_count < 2:
        raise ValueError("need >=2 observers")
    return 2 ** (observer_count-1)


def minimum_observers_for_binary_flip(alpha_local: float, exact_cap: int) -> tuple[Optional[int], Optional[int], Optional[float], str]:
    for o in range(2,100):
        n=binary_observer_label_conventions(o)
        if n > exact_cap:
            return None,n,None,f"observer-label exact space {n} exceeds cap {exact_cap} before required p resolution"
        floor=1.0/n
        if floor <= alpha_local:
            return o,n,floor,"PASS"
    return None,None,None,"search bound exhausted"


def analyze_feasibility(m: FeasibilityManifest) -> FeasibilityReport:
    reasons=[]

    # R3: family over preregistered operator x endpoint metric claims.
    r3h=m.r3_operator_hypotheses*m.r3_endpoint_metric_hypotheses
    r3alpha=m.r3_alpha_familywise/r3h
    n3,alloc3,p3,msg3=minimum_balanced_trials(
        r3alpha,m.r3_min_per_arm,m.r3_exact_cap,
        two_sided_balanced=(m.r3_alternative=="two-sided-balanced"),
    )
    r3status="PASS" if n3 is not None else "IMPOSSIBLE"
    r3=R3Feasibility(
        r3h,r3alpha,n3,(n3//2 if n3 is not None else None),
        alloc3,p3,r3status,
        msg3 if r3status!="PASS" else
        f"set CausalAnalyzer.alpha <= {r3alpha:.8g}; {n3} balanced trials/operator gives p-floor {p3:.8g}",
    )
    if r3status!="PASS": reasons.append("R3 exact causal family cannot attain preregistered alpha under cap")

    # R4: all pairwise comparisons for one planned clique, then all endpoint/trajectory checks.
    pair_h=comb(m.r4_macro_operator_count,2)
    checks=m.r4_strata*(m.r4_endpoint_metric_count + m.r4_trajectory_metric_count*m.r4_probe_phase_count)
    alpha_pair=m.r4_alpha_familywise/pair_h
    alpha_boundary=alpha_pair/checks
    m4,alloc4,p4,msg4=minimum_equal_arm_trials(
        alpha_boundary,m.r4_min_per_arm_per_stratum,m.r4_exact_cap
    )
    r4status="PASS" if m4 is not None else "IMPOSSIBLE"
    r4=R4Feasibility(
        pair_h,checks,alpha_pair,alpha_boundary,m4,(2*m4 if m4 is not None else None),
        alloc4,p4,r4status,
        msg4 if r4status!="PASS" else
        f"set SubstitutionPolicy.alpha_familywise <= {alpha_pair:.8g}; analyzer then uses local alpha {alpha_boundary:.8g}",
    )
    if r4status!="PASS": reasons.append("R4 exact substitution family cannot attain preregistered alpha under cap")

    # R4.7: built-in familywise correction over non-reference observers.
    nonref=m.observer_count-1
    alpha_obs=m.r47_alpha_familywise/nonref
    k47,nperm,p47,msg47=minimum_fit_anchors(alpha_obs,m.state_dimension,m.r47_permutation_cap)
    configured_ok=False
    if k47 is not None:
        configured_ok=True
    r47status="PASS" if configured_ok else "IMPOSSIBLE"
    r47=R47Feasibility(
        nonref,alpha_obs,k47,nperm,p47,m.r47_holdout_anchor_count,r47status,
        msg47 if r47status!="PASS" else
        f"{k47} fit anchors are the minimum under rank={m.state_dimension}, adjusted alpha={alpha_obs:.8g}, cap={m.r47_permutation_cap}",
    )
    if r47status!="PASS": reasons.append("R4.7 exact anchor-permutation alignment cannot attain preregistered alpha under cap")

    # R4.10: report both current marginal semantics and the cost of a stronger simultaneous Bonferroni claim.
    marginal_pairs=conformal_min_pairs(m.r410_alpha_marginal)
    channels=m.observer_count*m.r410_metric_count
    simultaneous_alpha=m.r410_alpha_marginal/channels
    simultaneous_pairs=conformal_min_pairs(simultaneous_alpha)
    r410=R410Feasibility(
        m.r410_alpha_marginal,
        marginal_pairs,2*marginal_pairs,
        channels,simultaneous_alpha,simultaneous_pairs,
        "R4.10 currently certifies marginal per-observer/per-metric repeatability. "
        "The Bonferroni simultaneous figure is reported as a stronger optional claim, not silently imposed.",
    )

    # Planned R5 exact observer-convention permutation.
    alpha5=m.r5_alpha_familywise/m.r5_primary_hypothesis_count
    if not m.r5_binary_observer_label_flip:
        o5=n5=p5=None; msg5="non-binary/general R5 exact null not specified"; r5status="UNRESOLVED"
        cfg_n=cfg_p=None
    else:
        o5,n5,p5,msg5=minimum_observers_for_binary_flip(alpha5,m.r5_exact_cap)
        cfg_n=binary_observer_label_conventions(m.observer_count)
        cfg_p=1.0/cfg_n
        cfg_feasible=(cfg_n<=m.r5_exact_cap and cfg_p<=alpha5)
        r5status="PASS" if (o5 is not None and cfg_feasible) else "IMPOSSIBLE"
        if o5 is not None and not cfg_feasible:
            msg5=(
                f"minimum is {o5} observers, but configured observer_count={m.observer_count} "
                f"gives exact p-floor {cfg_p:.8g} at alpha {alpha5:.8g}"
            )
        elif r5status=="PASS":
            msg5=(
                f"configured {m.observer_count} observers gives {cfg_n} exact binary convention assignments, "
                f"p-floor={cfg_p:.8g} <= alpha={alpha5:.8g}"
            )
    r5=R5Feasibility(
        m.r5_primary_hypothesis_count,alpha5,o5,n5,p5,m.observer_count,cfg_n,cfg_p,r5status,msg5
    )
    if r5status!="PASS": reasons.append("planned R5 exact observer-label transport test is not arithmetically feasible")

    # Conservative pre-R3 anchor-session lower bound, intentionally no data reuse.
    align_sessions=(k47 or 0)+m.r47_holdout_anchor_count
    rel_sessions=2*marginal_pairs
    per_obs=align_sessions+rel_sessions
    corpus=CorpusLowerBound(
        observer_count=m.observer_count,
        distinct_alignment_anchor_sessions_per_observer=align_sessions,
        marginal_reliability_repeat_sessions_per_observer=rel_sessions,
        conservative_anchor_sessions_per_observer_no_reuse=per_obs,
        conservative_anchor_sessions_total_no_reuse=per_obs*m.observer_count,
        notes=(
            "This is a lower bound only for alignment + marginal repeatability anchors.",
            "It excludes R3/R4 causal replay/substitution sessions and free EidoLang discovery sessions.",
            "No reuse between reliability and alignment anchors is assumed; a future theorem may license reuse.",
        ),
    )

    status="PASS" if not reasons else "BLOCKED"
    return FeasibilityReport(
        m.manifest_hash,r3,r4,r47,r410,r5,corpus,status,tuple(reasons)
    )
