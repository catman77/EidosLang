# R11 checkpoint

Status: IMPLEMENTED / JOINT R10 REFINEMENT ADMITTED ON FULL SYNTHETIC REPLAY

Admitted R10 spec:
- local `shape_signature(12,9)` probe inside the one certified collision cell;
- one promoted existing base-token coverage atom;
- no other representational additions.

Compilation semantics:
- representation support is raw-program based;
- causal operator support is effect-bearing-session based;
- the complete refined address is one canonical causal cell;
- no redundant base+probe operator duplication.

Repair replay:
- collision case: R9 `INADEQUATE -> PASS`;
- 2/2 collision obligations separated;
- 1/1 protected causal equivalence preserved;
- refined partition: 10 cells;
- refined causal operators: 10.

Coverage replay:
- unrepresented case: R9 `INADEQUATE -> PASS`;
- 1/1 unrepresented raw program now has a representation address;
- representation cells: 10;
- causal operators remain 9 because the orphan still has no discovery state-delta support.

Protected six-observer replay:
- all six refined R8 closures PASS;
- all six refined R9 adequacy certificates PASS;
- candidate MacroNames remain exactly 3/observer;
- R7 PASS;
- R6 PASS;
- R5 PASS;
- R5 statistic unchanged: 0.7508845597283931;
- exact p unchanged: 1/32 = 0.03125.

Final status: `ADMITTED`.
