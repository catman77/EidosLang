# R13 checkpoint

Status: IMPLEMENTED / FORMAT + GOLDEN VECTORS

Frozen wire components:
- `eidogram-document-v1`
- `eidogram-canonical-json-v1`
- normalized integer canvas `1_000_000 x 1_000_000`
- `ShapeLibraryV1`: POINT, LINE, TRIANGLE, RECTANGLE, ELLIPSE
- `PaletteV1`: 16 indexed sRGB colors
- construction action log
- derived scene `snapshot_hash`
- full document `content_hash`
- R12 `ANDROID_DOCUMENT` lineage binding

No float, SVG path, bitmap, custom RGB or freehand geometry is accepted in v1.

Android conformance artifacts:
- canonical JSON golden documents;
- expected byte lengths;
- snapshot SHA-256;
- content SHA-256;
- PaletteV1 table/hash;
- ShapeLibraryV1 table/hash.
