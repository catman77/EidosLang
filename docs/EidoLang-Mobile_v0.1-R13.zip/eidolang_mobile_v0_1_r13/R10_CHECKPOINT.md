# R10 checkpoint

Status: IMPLEMENTED / SYNTHETIC NECESSITY-CONSTRAINED SYNTHESIS

## Source obligations

R10 replays every supplied R9 certificate from its frozen ledger before accepting its
witnesses.

Positive-control collision cell contains three exact raw programs:

- exact diagonal;
- translated diagonal with the same normalized geometry;
- slightly bent diagonal.

R9 dispositions inside the same old grammar cell:

- diagonal ~ translated: substitution PASS (protected equivalence);
- diagonal vs bent: substitution FAIL;
- translated vs bent: substitution FAIL.

Thus the refinement must satisfy two separation obligations and one anti-splitting
obligation simultaneously.

## Collision-only synthesis

Frozen search family:

- base `(resample_n,bins)=(12,8)` retained;
- additive `shape_signature(n,bins)` probes only;
- `n in [12,16]`, `bins in [8,16]`;
- at most one added probe;
- probe is enabled only inside R9-proved collision cells.

Complete candidate count: 45 (identity + 44 probes).
Valid candidates: 24.

Canonical minimum:

```text
probe: shape_signature(resample_n=12, bins=9)
target old cell: (op:2d3d8f0e020f,)
coverage atoms: none
```

Measured refinement cost:

```text
empirical partition increase  1
added atom count              2
new rule count                1
probe capacity bits           76.0782000346
parameter displacement        1
```

It separates both FAIL pairs and preserves the certified equivalent diagonal pair.
No strictly better valid candidate exists in the frozen exhaustive search.

## Unrepresented-only synthesis

The R9 causal-PASS orphan is not used to justify a new geometric observable.

Canonical minimum:

```text
new geometric probes: none
promote one already-existing raw-supported base token pattern
```

Measured cost:

```text
empirical partition increase  0
added atom count              1
new rule count                1
```

This is the structural separation of representational existence from causal-effect evidence.

## Joint synthesis over all known obligations

Cases:

- six unchanged R8/R9 PASS corpora;
- protected collision corpus;
- unrepresented-program corpus.

Complete frozen search: 90 candidate specs.
Valid: 24.

Canonical minimum contains exactly two forced repairs:

1. cell-local additive `(12,9)` shape probe;
2. one promotion of the existing orphan base-token pattern.

All six previously adequate corpora remain valid; the protected equivalence remains unsplit;
both collision obligations are separated; the unrepresented program receives an address.

## Non-admission boundary

R10 emits a `RefinedGrammarSpec` and a minimality certificate only.
It does **not** mutate the production `StrokeSegmenter` or `OperatorMiner`.
The new spec must be recompiled through R8/R9 and the downstream R7/R6/R5 chain before it
can become a confirmatory grammar revision.
