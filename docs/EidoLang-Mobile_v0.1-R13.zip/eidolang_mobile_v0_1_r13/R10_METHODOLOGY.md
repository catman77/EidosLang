# R10 — Necessity-Constrained Grammar Refinement Synthesis

## 1. Input is an obligation set, not a feature menu

R9 can produce two residual types.

Collision:

\[
G(x)=G(y)\neq\varnothing,
\qquad
x\not\simeq_{causal}y.
\]

Coverage failure:

\[
G(x)=\varnothing,
\qquad
Causal(x)=PASS.
\]

R10 is forbidden to add an intuitive semantic feature merely because it appears useful.
It may search only a frozen refinement family generated from machinery already present in the
current grammar.

The first admitted family is:

1. preserve the entire old address verbatim;
2. optionally append another `shape_signature(resample_n,bins)` probe from the **same**
   canonicalization function already used by `StrokeSegmenter`;
3. optionally promote an already-existing base token pattern to a representational atom when
   raw support exists but effect-bearing `OperatorMiner` support does not.

No curvature, pressure, color, topology or learned embedding is introduced by R10.

---

## 2. Refinement is additive

The old grammar address is retained:

\[
A_{G'}(x)=A_G(x)\cup A_{new}(x).
\]

Therefore an existing distinction can never be merged by construction.

This avoids the false move of replacing 8-bin quantization by an unrelated 9-bin partition.
The extra 9-bin signature is appended as a probe; the old 8-bin token remains part of the
address.

---

## 3. Protected causal equivalences

Every R9 raw-program pair whose exact substitution certificate is `PASS` becomes a hard
negative constraint on refinement:

\[
x\simeq_{causal}y
\Longrightarrow
A_{G'}(x)=A_{G'}(y).
\]

A candidate that solves a collision by splitting a previously certified equivalent pair is
inadmissible.

The R10 positive-control corpus includes three exact raw programs in one old grammar cell:

- exact diagonal;
- translated/scaled diagonal with the same normalized shape;
- slightly bent diagonal.

The first two are certified substitution-equivalent; the bent program is substitution-FAIL
against both. A valid refinement must therefore split exactly the bent member while keeping
both diagonals together.

---

## 4. Unrepresented programs do not automatically justify a new sensor

If an R9 causal-PASS raw program has no current address because `OperatorMiner` requires
state-delta support, R10 first tries the weakest structural repair:

> promote a raw-supported pattern that already exists in the current token language to a
> representational atom, without assigning it a causal effect.

This separates **representation existence** from **causal operator evidence**.

It is strictly weaker than inventing a new geometric observable.

Promotion is pattern-based and symmetric: every raw-supported program containing that same
pattern receives the same atom. Witness IDs are never used as features.

---

## 5. Exact finite search

Let the current shape grammar be:

\[
(n_0,b_0)=(12,8).
\]

The frozen R10 search enumerates candidate probes

\[
(n,b),
\quad
n_0\le n\le n_0+\Delta n,
\quad
b_0\le b\le b_0+\Delta b,
\]

excluding the original pair, plus witness-derived promotions of existing base patterns.

All combinations up to the frozen probe/promotion caps are evaluated.

If the complete search space exceeds the computational cap, R10 returns `UNRESOLVED` before
sampling it. If no valid candidate exists inside the completely enumerated frozen family,
R10 also returns `UNRESOLVED`; it does **not** claim universal impossibility.

---

## 6. Minimality objective

For every candidate R10 computes, in this order:

1. empirical partition increase on all causal-PASS raw programs;
2. size of the newly admitted atom alphabet;
3. number of added refinement rules;
4. maximum-code description capacity of added probes/patterns;
5. parameter displacement from the existing grammar.

Thus the primary quantity is literally the number of additional distinctions introduced on
the frozen evidence, not an aesthetic preference for a feature.

The selected candidate is the canonical minimum under this frozen lexicographic objective. R10 certifies that no strictly better valid candidate exists in the exhaustively enumerated family; exact-cost ties, if any, are resolved deterministically by `spec_hash`.

Minimality is claimed **only inside the frozen existing-family search space**.

---

## 7. Admission conditions

A candidate is valid iff simultaneously:

\[
A_{G'}(x)\ne A_{G'}(y)
\]

for every R9 collision obligation,

\[
A_{G'}(u)\ne\varnothing
\]

for every R9 unrepresented causal program, and

\[
A_{G'}(p)=A_{G'}(q)
\]

for every protected causal-equivalence pair.

R10 only emits a `RefinedGrammarSpec` and its minimality certificate. It does not silently
replace the production grammar. The entire R8/R9/R7/R6/R5 chain must be recompiled and
revalidated under the new spec before confirmatory use.

## 8. Necessity locality

The shape probe is not enabled globally. Its domain is frozen to the old grammar cells that
actually contain R9 collision obligations:

\[
Cell_{probe}=\{A_G(x):(x,y)\in W_{collision}\}.
\]

Outside those cells:

\[
A_{G'}(z)=A_G(z)
\]

except for separately forced unrepresented-program coverage atoms. This is stronger than a
global re-quantization: a counterexample licenses extra resolution only where the old quotient
has been proved non-homogeneous.
