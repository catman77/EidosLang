from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from eidolang.eidogram_document import parse_document, document_content_hash, replay_actions, canonical_json_bytes

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('command',choices=('verify','hash','replay'))
    ap.add_argument('document')
    ns=ap.parse_args()
    data=Path(ns.document).read_bytes()
    doc=parse_document(data)
    if ns.command=='verify':
        print(json.dumps({'status':'PASS','content_hash':document_content_hash(doc),'snapshot_hash':doc['snapshot_hash']},indent=2))
    elif ns.command=='hash':
        print(document_content_hash(doc))
    else:
        sys.stdout.buffer.write(canonical_json_bytes(replay_actions(doc['actions']))+b'\n')
if __name__=='__main__': main()
