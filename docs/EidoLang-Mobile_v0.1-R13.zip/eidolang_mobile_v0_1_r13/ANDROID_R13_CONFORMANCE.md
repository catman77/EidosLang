# Android conformance for EidogramDocumentV1

The Kotlin implementation must not rely on ordinary JSON serialization order.
It must implement the canonical writer literally:

1. reject floating-point values;
2. escape strings as JSON;
3. sort object keys lexicographically by their Unicode/ASCII key strings;
4. emit no insignificant whitespace;
5. use UTF-8 bytes;
6. emit arrays in stored order;
7. use lowercase SHA-256 hex.

Coordinates and transforms are `Long`/`Int`, never `Float`/`Double` in the content model.
Compose may convert fixed-point values to floating pixels only in the rendering layer.
Those render floats must never be serialized back as source-of-truth geometry.

Conformance gate for every file in `golden_vectors/r13_android/`:

- input raw bytes equal Kotlin canonical reserialization;
- Kotlin SHA-256 equals `content_hash`;
- replayed scene SHA-256 equals `snapshot_hash`;
- PaletteV1 hash and ShapeLibraryV1 hash match the manifest.

A file that parses but reserializes differently is invalid canonical content.
