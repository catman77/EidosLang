# R12 — Production Grammar Promotion / Root-Protocol Rebinding

## Necessity

R11 proved that one concrete refinement is admissible, but the old root protocol still allowed a new study to be compiled without naming that grammar. Therefore an admitted grammar could remain merely an artifact rather than the production language.

R12 closes that gap by making the production grammar lineage part of the root preregistration hash.

The production root is now:

\[
M_2 = (M_1, H_G, H_B, V_L),
\]

where:

- \(H_G\) is the admitted grammar-spec hash;
- \(H_B\) is the production grammar-binding hash;
- \(V_L\) is the lineage protocol version.

Therefore:

\[
H(M_2) \ne H(M_1).
\]

All child protocol hashes that bind the master root change automatically.

## Promotion rule

Only an R11 certificate satisfying:

\[
status=ADMITTED \land admitted=true
\]

may create `ProductionGrammarBinding`.

The binding checks:

\[
H(GrammarSpec)=R11.refined\_spec\_hash,
\]

and binds both the source R10 synthesis certificate and the R11 admission certificate.

A rejected or locally repaired-but-not-admitted refinement cannot become production grammar.

## Root protocol version

`master-prereg-v1` is retained only for historical/replay compatibility.

The new production protocol is:

`master-prereg-v2`.

A v2 manifest is invalid unless all three fields are present:

- `production_grammar_spec_hash`;
- `production_grammar_binding_hash`;
- `production_grammar_lineage_version`.

Conversely a v1 manifest may not claim those fields.

## Production compiler

`ProductionProtocolCompiler` requires simultaneously:

1. a v2 master manifest;
2. the exact `ProductionGrammarBinding` named by the root;
3. the exact R11 ADMITTED certificate named by the binding.

Any mismatch is `ProtocolCompileError`.

The legacy `ProtocolCompiler` remains available for historical unit tests and reproducibility, but its output is explicitly non-production. `ProductionRuntime` and `require_production_bundle()` reject a legacy bundle.

## Stage lineage slots

R12 creates a deterministic lineage slot for every research and product stage:

`R3, R4, R4.7, R4.8, R4.9, R4.10, R4.11, R4.12, R5, R6, R7, R8, R9, R10, R11, R12, ANDROID_DOCUMENT, ANDROID_MESSAGE, TORRENT_ARCHIVE`.

For stage \(S\):

\[
L_S = H(S, H_{master}, H_G, H_B, V_L).
\]

Any later evidence object is wrapped as:

\[
E_S=(S,H(E),H_{master},H_G,H_B,L_S).
\]

Thus Android documents and torrent archive manifests inherit the same production grammar lineage as the research certificates.

## Status semantics

R12 does not prove a new scientific invariant. It proves deployment provenance:

> the protocol and every production evidence/product object can be traced to exactly the grammar admitted by R11.

After promotion, an old grammar or unbound legacy protocol is not acceptable production evidence.

## Reproducibility audit at promotion boundary

Promotion is also an artifact-consistency boundary. R12 discovered that the inherited R11 archive's generated report/summary named an older R10/R11 certificate hash than the certificate reproduced by the source code in the same archive. The selected grammar spec hash remained identical and the current source replay still returned `ADMITTED`.

The current R11 certificate hash was reproduced in independent processes under two different `PYTHONHASHSEED` values. R12 therefore binds the replayed certificate object and emits an explicit audit record rather than silently trusting the stale generated metadata.

This becomes a permanent rule for production promotion:

\[
\text{generated summary metadata} \not\Rightarrow \text{promotion authority}.
\]

Only a reproducible certificate object plus its admitted spec may promote a grammar.
