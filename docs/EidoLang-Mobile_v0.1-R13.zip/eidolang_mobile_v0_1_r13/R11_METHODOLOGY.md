# R11 — Refinement Admission / Full Recompile and Non-Regression Replay

## 1. Why R10 is not yet a production grammar

R10 proves only that a `RefinedGrammarSpec` satisfies the frozen necessity obligations inside
its completely enumerated refinement family. It deliberately does not mutate the production
grammar.

A local repair can still create global side effects:

- new causal operator candidates;
- extra R4 cliques and therefore extra R7 candidates;
- destruction of a protected causal equivalence;
- loss of candidate-universe closure;
- a changed confirmation class selection;
- degradation of the final exact R5 statistic.

Therefore R10 acceptance is necessary but not sufficient.

R11 requires the actual compilation and replay:

\[
G'\rightarrow R8'\rightarrow R9'\rightarrow R7'\rightarrow R6'\rightarrow R5'.
\]

Only after this replay may the refinement be marked `ADMITTED`.

---

## 2. A new distinction forced by the R10 coverage witness

The R10 `UNREPRESENTED` witness revealed that the old implementation conflated two questions:

1. does a raw intervention have a representational address?;
2. does that address already have enough effect-bearing observations to be a causal candidate?

These are not equivalent.

R11 therefore compiles two linked layers.

### Representation layer

A raw-supported program may receive an address even when its source sessions have no
`StateObservation` delta:

\[
A_{G'}(x)\ne\varnothing.
\]

### Causal-candidate layer

A causal operator is emitted only when the exact refined cell has at least the frozen
`min_support` effect-bearing sessions.

Thus:

\[
A_{G'}(x)\ne\varnothing
\not\Rightarrow
x\in Operators_{causal}.
\]

This prevents a coverage repair from fabricating causal evidence.

---

## 3. Compilation of the R10 specification

The admitted R10 joint spec is:

- base segmenter: `(12,8,8)`;
- one local probe: `shape_signature(12,9)`;
- probe domain: the certified collision cell `('op:2d3d8f0e020f',)`;
- one promoted already-existing base-token pattern;
- raw support minimum: 3;
- `max_ngram=1`.

R11 v1 refuses to extrapolate this proof to `max_ngram>1`. Such a generalization would be a
new design choice rather than an implication of R10.

For each frozen raw program:

\[
A_{G'}(x)
=
A_G(x)
\cup
ProbeAtoms(x)
\cup
CoverageAtoms(x).
\]

Probe atoms are observable only in the R10-certified target cell. Coverage promotion is
symmetric over every raw-supported program containing the same existing pattern.

---

## 4. Canonical refined causal cells

A naive implementation would emit both the old base operator and every new probe atom as
separate causal operators. This would create redundant operators and gratuitously multiply
R4 MacroNames.

That is not what R10 proved.

R11 instead treats the complete refined address as the canonical causal token:

\[
Cell_{G'}(x)=A_{G'}(x).
\]

All effect-bearing sessions with the same complete address contribute to one new causal
candidate. Therefore refinement *splits a cell* rather than adding a redundant parallel
operator.

This preserves the old partition wherever the refinement adds no new distinction.

---

## 5. Fresh R8' is mandatory

R11 does not reuse the old R8 candidate certificate.

For every refined causal operator it requires one fresh R3 disposition, and for every pair
of R3-PASS refined operators one fresh R4 disposition:

\[
Registry_{R3}'=Operators_{G'},
\]

\[
Registry_{R4}'={Operators_{G'}^{PASS}\choose2}.
\]

All fixed clique combinations are enumerated again.

The synthetic dry run generates these fresh registries from its known test mechanism. In a
real experiment they must be produced by the ordinary locked R3/R4 acquisition/replay path;
R11 does not infer a causal PASS merely because R10 created a representation feature.

---

## 6. Fresh R9' uses the compiled representation

R9' no longer defines representation by the old `OperatorMiner` incidence address. It uses
the actually compiled R11 representation address.

Two causal-PASS raw programs require a substitution disposition iff:

\[
A_{G'}(x)=A_{G'}(y)\ne\varnothing.
\]

The registry is again exact and complete for that set.

The R10 repair is admitted only if:

\[
A_{G'}(x)\ne A_{G'}(y)
\]

for every collision obligation,

\[
A_{G'}(x)=A_{G'}(y)
\]

for every protected equivalence, and every former unrepresented witness satisfies

\[
A_{G'}(x)\ne\varnothing.
\]

In addition the new R9 certificate itself must be `PASS`.

---

## 7. Full protected-confirmation replay

The six original R8/R9-PASS confirmation corpora are recompiled under the same joint R10
spec.

R11 requires:

- R8' candidate closure `PASS` for every observer;
- R9' adequacy `PASS` for every observer;
- no increase of the protected synthetic candidate count;
- R7 `PASS` using the complete new candidate set;
- R6 `PASS`;
- R5 `PASS`.

For the primary R5 result R11 freezes a stronger non-regression condition in this version:

\[
|S_{R5}'-S_{R5}|\le10^{-12}
\]

and

\[
p_{R5}'\le p_{R5}.
\]

A locally correct grammar repair is rejected if it changes the protected confirmatory result.

---

## 8. Admission semantics

R11 returns:

- `ADMITTED` — every R10 obligation is repaired and the complete downstream replay passes;
- `REJECTED` — local repair exists but causes any downstream/protected regression;
- `UNRESOLVED` — an exact enumeration/replay cap prevents the decision;
- `INVALID` — provenance or registry completeness is broken.

`ADMITTED` does not establish universal grammar adequacy. It establishes that the particular
R10 necessity-constrained refinement can safely replace the frozen grammar on the replayed
scope without invalidating the already certified experiment.
