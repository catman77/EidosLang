# R13 — Eidogram Document Format v1

## 1. Product object, not research observation

R13 defines the immutable content object that the Android messenger will exchange.
It deliberately does not reuse `EidoSession` as a message format. `EidoSession` is an
experimental measurement object; `EidogramDocumentV1` is an authored artifact.

Every document is root-bound to R12 through:

\[
L_D=(H_{master},H_G,H_B,H_{ANDROID\_DOCUMENT}).
\]

A document from another grammar lineage is not silently upgraded.

## 2. No arbitrary geometry in v1

`ShapeLibraryV1` contains exactly:

- POINT;
- LINE;
- TRIANGLE;
- RECTANGLE;
- ELLIPSE.

Square and circle are the equal-scale special cases of rectangle and ellipse.
Custom paths, SVG path strings, Bezier points, bitmap payloads and freehand strokes are
not part of R13.

This is a product constraint, not a claim that these shapes are the complete eidographic
alphabet. The library may change only by a future version/hash.

## 3. Fixed-point geometry

The logical canvas is exactly:

\[
10^6\times10^6
\]

integer units.

`TransformV1` is:

\[
(c_x,c_y,s_x,s_y,\theta_{mdeg})\in\mathbb Z^5.
\]

No IEEE float occurs in the wire format. Rotation is canonicalized to:

\[
-180000\le\theta_{mdeg}<180000.
\]

This removes Python/JVM floating serialization differences from document identity.

## 4. PaletteV1

There are exactly 16 sRGB render tokens. Documents store only palette index `0..15`.
No arbitrary RGB, alpha, gradient or color profile is accepted.

The palette is bound by:

\[
H_P=SHA256(CanonicalJSON(PaletteV1)).
\]

Color names and hues carry no built-in semantic interpretation.

## 5. Construction history is part of content

A document contains an append-only committed action sequence with contiguous `seq`:

- ADD;
- SET_TRANSFORM;
- SET_COLOR;
- SET_PAINT;
- MOVE_Z;
- REMOVE;
- GROUP;
- UNGROUP.

The current scene is deterministically replayed from the history.

Two histories may satisfy:

\[
Scene(A)=Scene(B)
\]

while:

\[
Hash(Document(A))\ne Hash(Document(B)).
\]

This is intentional. The construction trajectory is retained as eidographic data.

`GROUP` is editor structure only in v1: it does not alter rendering and nested/overlapping
groups are forbidden.

## 6. Snapshot hash and content hash

Replay produces:

\[
S=\{ordered\ nodes,sorted\ groups\}.
\]

The document stores:

\[
H_S=SHA256(CanonicalJSON(S)).
\]

and validation recomputes it.

The transport content identity is:

\[
H_D=SHA256(CanonicalJSON(Document)).
\]

`H_D` will become the object reference used by the R15 message envelope and R16 torrent
archive.

## 7. Canonical JSON

`eidogram-canonical-json-v1` permits only:

- object with string keys;
- arrays;
- strings;
- integers;
- booleans/null where a future schema permits them.

R13 itself currently uses no floats. Object keys are lexicographically sorted, separators
are `,` and `:`, UTF-8 is used and non-ASCII is JSON-escaped. Duplicate keys are invalid.
A parser rejects semantically equivalent but noncanonical JSON bytes.

Therefore Android conformance is a byte-level test, not a semantic-JSON test.

## 8. Undo/redo

The canonical format does not contain a mutable editor cursor. Android undo/redo is
implemented by appending the inverse committed action or by editing a local uncommitted
history before finalization. Sent content is immutable.

## 9. Explicit exclusions from v1

Not present:

- text labels;
- arbitrary RGB;
- transparency;
- gradients;
- custom paths/freehand;
- audio/haptics/video;
- signatures/encryption;
- timestamps/sender/conversation ID;
- torrent metadata.

The latter belong to R15/R16 rather than the eidogram content object.
