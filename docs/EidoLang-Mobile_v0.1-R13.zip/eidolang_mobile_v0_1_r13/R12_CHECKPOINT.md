# R12 checkpoint

Status: IMPLEMENTED / PRODUCTION ROOT REBOUND

## Production grammar

Admitted grammar spec hash:

`d5afb09e6ecdcff8a4b2c9758af83f215059d1b5bc4ad32da3fb8dd191b69b19`

Reproduced current R11 admission hash:

`4c1ec5947583c786987a54d2e5994dd8db0386f01d3fc76b0745abe22b08bd38`

Production grammar binding hash:

`130eed81541292dfc8ccfd48ba01a28c374cd8fa96285c51fb3ea978d530944a`

Legacy root master hash:

`123bb308f0d094f887e45e45c4f8b27c7796caef3e2415e2db4569b97092e464`

Production root master hash:

`4667dcd42dec6e14aed1311525488370d141758ca8795aeb2ddfe8aecde57fd3`

Production bundle hash:

`d922f2347b13c349bc9edd7ea59a29f14159d5a2282c955d676553d9a5325ac8`

## Implemented

- `ProductionGrammarBinding`;
- `master-prereg-v2` grammar fields;
- `ProductionProtocolCompiler`;
- `ProductionProtocolBundle`;
- `ProductionRuntime`;
- 19 deterministic stage-lineage slots;
- grammar-bound evidence envelopes;
- legacy protocol rejection in production runtime;
- wrong/old grammar hash rejection;
- rejected R11 admission rejection;
- reserved product lineage slots: `ANDROID_DOCUMENT`, `ANDROID_MESSAGE`, `TORRENT_ARCHIVE`.

The grammar binding changes the root master hash and consequently rebinds acquisition/reliability protocol hashes and the runtime lock.

## R11 reproducibility audit found during promotion

The inherited R11 archive contained generated metadata with an older R10/R11 certificate hash while the source code in that same archive reproducibly generated a newer certificate. The admitted grammar spec hash itself is unchanged.

R12 therefore does **not** trust the stale generated metadata. It replays the current source certificate, verifies `ADMITTED`, verifies the same admitted grammar spec, and binds the reproducible current certificate object.

See `R12_R11_REPRODUCIBILITY_AUDIT.json` and `R12_REPRODUCED_R11_ADMISSION.json`.
