from __future__ import annotations

from dataclasses import dataclass, asdict, replace
from typing import Iterable, Optional

from .acquisition import sha256_object
from .grammar_refinement import RefinedGrammarSpec
from .refinement_admission import R11AdmissionCertificate
from .protocol_compiler import (
    MasterStudyManifest, CompiledProtocolBundle, ProtocolCompiler,
    ProtocolCompileError, ConfirmatoryRuntime,
)


@dataclass(frozen=True)
class ProductionGrammarBinding:
    grammar_spec_hash: str
    grammar_spec: RefinedGrammarSpec
    source_r10_certificate_hash: str
    r11_admission_certificate_hash: str
    previous_grammar_hash: str
    lineage_version: str = 'production-grammar-lineage-v1'
    promotion_policy: str = 'ONLY_R11_ADMITTED_SPEC_V1'

    def __post_init__(self):
        if self.grammar_spec.spec_hash != self.grammar_spec_hash:
            raise ValueError('grammar spec hash mismatch')
        if self.lineage_version != 'production-grammar-lineage-v1':
            raise ValueError('unsupported grammar lineage version')
        if self.promotion_policy != 'ONLY_R11_ADMITTED_SPEC_V1':
            raise ValueError('unsupported production promotion policy')

    @property
    def binding_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class StageLineageSlot:
    stage: str
    root_master_hash: str
    grammar_spec_hash: str
    grammar_binding_hash: str
    slot_hash: str


@dataclass(frozen=True)
class GrammarBoundEvidence:
    stage: str
    evidence_hash: str
    root_master_hash: str
    grammar_spec_hash: str
    grammar_binding_hash: str
    lineage_slot_hash: str

    @property
    def envelope_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class ProductionProtocolBundle:
    base_bundle: CompiledProtocolBundle
    grammar_binding: ProductionGrammarBinding
    lineage_slots: tuple[StageLineageSlot, ...]
    source_r11_certificate_hash: str
    source_r11_status: str
    production_ready: bool
    protocol_version: str = 'root-grammar-rebinding-v1'

    @property
    def master_hash(self) -> str:
        return self.base_bundle.master_hash

    @property
    def production_bundle_hash(self) -> str:
        return sha256_object({
            'base_bundle_hash': self.base_bundle.bundle_hash,
            'grammar_binding_hash': self.grammar_binding.binding_hash,
            'lineage_slots': self.lineage_slots,
            'r11': self.source_r11_certificate_hash,
            'production_ready': self.production_ready,
            'protocol_version': self.protocol_version,
        })

    def slot(self, stage: str) -> StageLineageSlot:
        found=[x for x in self.lineage_slots if x.stage==stage]
        if len(found)!=1:
            raise KeyError(stage)
        return found[0]

    def bind_evidence(self, stage: str, evidence_hash: str) -> GrammarBoundEvidence:
        s=self.slot(stage)
        return GrammarBoundEvidence(
            stage=stage,
            evidence_hash=evidence_hash,
            root_master_hash=self.master_hash,
            grammar_spec_hash=self.grammar_binding.grammar_spec_hash,
            grammar_binding_hash=self.grammar_binding.binding_hash,
            lineage_slot_hash=s.slot_hash,
        )


PRODUCTION_LINEAGE_STAGES=(
    'R3','R4','R4.7','R4.8','R4.9','R4.10','R4.11','R4.12',
    'R5','R6','R7','R8','R9','R10','R11','R12',
    'ANDROID_DOCUMENT','ANDROID_MESSAGE','TORRENT_ARCHIVE',
)


def baseline_grammar_hash(spec: RefinedGrammarSpec) -> str:
    return sha256_object({
        'segmenter_version':spec.base_segmenter_version,
        'resample_n':spec.base_resample_n,
        'quantization_bins':spec.base_quantization_bins,
        'relation_bins':spec.base_relation_bins,
        'max_ngram':spec.max_ngram,
        'representation':'pre-R10-base-grammar',
    })


def binding_from_admission(
    admission: R11AdmissionCertificate,
    spec: RefinedGrammarSpec,
) -> ProductionGrammarBinding:
    if admission.status!='ADMITTED' or not admission.admitted:
        raise ProtocolCompileError('only an R11 ADMITTED refinement can become production grammar')
    if admission.refined_spec_hash!=spec.spec_hash:
        raise ProtocolCompileError('R11 admitted spec hash differs from supplied grammar spec')
    return ProductionGrammarBinding(
        grammar_spec_hash=spec.spec_hash,
        grammar_spec=spec,
        source_r10_certificate_hash=admission.source_r10_certificate_hash,
        r11_admission_certificate_hash=admission.certificate_hash,
        previous_grammar_hash=baseline_grammar_hash(spec),
    )


def promote_master_manifest(
    legacy: MasterStudyManifest,
    binding: ProductionGrammarBinding,
) -> MasterStudyManifest:
    if legacy.manifest_version!='master-prereg-v1':
        raise ProtocolCompileError('R12 promotion source must be master-prereg-v1')
    return replace(
        legacy,
        manifest_version='master-prereg-v2',
        production_grammar_spec_hash=binding.grammar_spec_hash,
        production_grammar_binding_hash=binding.binding_hash,
        production_grammar_lineage_version=binding.lineage_version,
    )


def _slots(master_hash: str, binding: ProductionGrammarBinding) -> tuple[StageLineageSlot,...]:
    out=[]
    for stage in PRODUCTION_LINEAGE_STAGES:
        sh=sha256_object({
            'stage':stage,
            'root_master_hash':master_hash,
            'grammar_spec_hash':binding.grammar_spec_hash,
            'grammar_binding_hash':binding.binding_hash,
            'lineage_version':binding.lineage_version,
        })
        out.append(StageLineageSlot(stage,master_hash,binding.grammar_spec_hash,binding.binding_hash,sh))
    return tuple(out)


class ProductionProtocolCompiler:
    compiler_version='production-protocol-compiler-v1'

    def compile(
        self,
        master: MasterStudyManifest,
        binding: ProductionGrammarBinding,
        admission: R11AdmissionCertificate,
    ) -> ProductionProtocolBundle:
        reasons=[]
        if master.manifest_version!='master-prereg-v2':
            reasons.append('production protocol requires master-prereg-v2')
        if admission.status!='ADMITTED' or not admission.admitted:
            reasons.append('R11 admission is not ADMITTED')
        if admission.certificate_hash!=binding.r11_admission_certificate_hash:
            reasons.append('grammar binding does not bind supplied R11 certificate')
        if admission.source_r10_certificate_hash!=binding.source_r10_certificate_hash:
            reasons.append('R10 lineage mismatch')
        if admission.refined_spec_hash!=binding.grammar_spec_hash:
            reasons.append('R11 admitted grammar hash mismatch')
        if master.production_grammar_spec_hash!=binding.grammar_spec_hash:
            reasons.append('root master grammar spec hash mismatch')
        if master.production_grammar_binding_hash!=binding.binding_hash:
            reasons.append('root master grammar binding hash mismatch')
        if master.production_grammar_lineage_version!=binding.lineage_version:
            reasons.append('root master grammar lineage version mismatch')
        if reasons:
            raise ProtocolCompileError('; '.join(reasons))

        base=ProtocolCompiler().compile(master)
        slots=_slots(base.master_hash,binding)
        return ProductionProtocolBundle(
            base_bundle=base,
            grammar_binding=binding,
            lineage_slots=slots,
            source_r11_certificate_hash=admission.certificate_hash,
            source_r11_status=admission.status,
            production_ready=True,
        )


class ProductionRuntime:
    def __init__(self, bundle: ProductionProtocolBundle):
        if not isinstance(bundle,ProductionProtocolBundle) or not bundle.production_ready:
            raise ProtocolCompileError('production runtime requires R12 production bundle')
        self.bundle=bundle
        self.confirmatory=ConfirmatoryRuntime(bundle.base_bundle)

    def assert_evidence(self, envelope: GrammarBoundEvidence) -> None:
        slot=self.bundle.slot(envelope.stage)
        if envelope.root_master_hash!=self.bundle.master_hash:
            raise ProtocolCompileError('evidence root master hash mismatch')
        if envelope.grammar_spec_hash!=self.bundle.grammar_binding.grammar_spec_hash:
            raise ProtocolCompileError('evidence grammar spec hash mismatch')
        if envelope.grammar_binding_hash!=self.bundle.grammar_binding.binding_hash:
            raise ProtocolCompileError('evidence grammar binding hash mismatch')
        if envelope.lineage_slot_hash!=slot.slot_hash:
            raise ProtocolCompileError('evidence lineage slot mismatch')


def require_production_bundle(bundle) -> ProductionProtocolBundle:
    if not isinstance(bundle,ProductionProtocolBundle) or not bundle.production_ready:
        raise ProtocolCompileError('legacy/non-production protocol is forbidden after R12 promotion')
    return bundle
