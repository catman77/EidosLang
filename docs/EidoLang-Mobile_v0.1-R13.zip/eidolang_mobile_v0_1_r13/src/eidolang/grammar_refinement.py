from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from math import log2
from typing import Iterable, Optional

from .acquisition import AcquisitionLedger, DataFreezeCertificate, sha256_object
from .schema import EidoSession
from .operators import OperatorMiner
from .segmenter import StrokeSegmenter, SegmenterConfig
from .geometry import shape_signature
from .candidate_universe import CandidateUniverseCertificate
from .grammar_adequacy import (
    GrammarAdequacyConfig, GrammarAdequacyCertificate, GrammarAdequacyAnalyzer,
    RawProgram, RawProgramCausalDisposition, RawProgramPairDisposition,
    _extract_raw_programs, _contains_pattern,
)


@dataclass(frozen=True)
class ShapeRefinementProbe:
    resample_n: int
    quantization_bins: int

    def __post_init__(self):
        if self.resample_n < 2 or self.quantization_bins < 2:
            raise ValueError('invalid shape probe')

    @property
    def probe_id(self) -> str:
        return f'shape:n={self.resample_n}:b={self.quantization_bins}'

    @property
    def max_code_bits(self) -> float:
        # Capacity of the 2*n quantized coordinates. Used only after empirical
        # partition/atom costs, as a deterministic minimal-description tie break.
        return 2.0*self.resample_n*log2(self.quantization_bins)


@dataclass(frozen=True)
class CoverageAtom:
    pattern: tuple[str,...]

    def __post_init__(self):
        if not self.pattern:
            raise ValueError('empty coverage atom')

    @property
    def atom_id(self) -> str:
        return 'coverage:'+sha256_object(self.pattern)[:16]


@dataclass(frozen=True)
class RefinedGrammarSpec:
    base_segmenter_version: str
    base_resample_n: int
    base_quantization_bins: int
    base_relation_bins: int
    probes: tuple[ShapeRefinementProbe,...]
    probe_target_addresses: tuple[tuple[str,...],...]
    coverage_atoms: tuple[CoverageAtom,...]
    raw_support_min: int
    max_ngram: int
    address_version: str='necessity-refined-address-v1'

    @property
    def spec_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class GrammarRefinementSearchConfig:
    base_segmenter_version: str='stroke-v1'
    base_resample_n: int=12
    base_quantization_bins: int=8
    base_relation_bins: int=8
    max_resample_increment: int=4
    max_bin_increment: int=8
    max_probes: int=2
    max_coverage_atoms: int=3
    max_candidate_specs: int=50_000
    search_family: str='AUGMENT_EXISTING_SHAPE_SIGNATURE_AND_PROMOTE_BASE_PATTERNS_V1'

    def __post_init__(self):
        if min(self.base_resample_n,self.base_quantization_bins,self.base_relation_bins) < 2:
            raise ValueError('invalid base segmenter parameters')
        if min(self.max_resample_increment,self.max_bin_increment) < 0:
            raise ValueError('negative search increment')
        if min(self.max_probes,self.max_coverage_atoms,self.max_candidate_specs) < 0:
            raise ValueError('negative search cap')
        if self.search_family!='AUGMENT_EXISTING_SHAPE_SIGNATURE_AND_PROMOTE_BASE_PATTERNS_V1':
            raise ValueError('unsupported refinement search family')

    @property
    def config_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class CertifiedRefinementCase:
    case_id: str
    observer_id: str
    source_r9_certificate_hash: str
    source_r9_status: str
    raw_program_min_support: int
    max_ngram: int
    programs: tuple[RawProgram,...]
    causal_pass_program_ids: tuple[str,...]
    protected_equivalence_pairs: tuple[tuple[str,str],...]
    collision_obligations: tuple[tuple[str,str],...]
    unrepresented_obligations: tuple[str,...]
    representative_sessions: tuple[tuple[str,EidoSession],...]

    @property
    def case_hash(self) -> str:
        return sha256_object({
            'case_id':self.case_id,
            'observer_id':self.observer_id,
            'r9':self.source_r9_certificate_hash,
            'programs':[(p.program_id,p.program_hash,p.grammar_address,p.support_count) for p in self.programs],
            'pass':self.causal_pass_program_ids,
            'protected':self.protected_equivalence_pairs,
            'collision':self.collision_obligations,
            'unrepresented':self.unrepresented_obligations,
            'sessions':[(pid,sha256_object(s)) for pid,s in self.representative_sessions],
        })


@dataclass(frozen=True)
class RefinementCaseValidation:
    case_id: str
    base_partition_count: int
    refined_partition_count: int
    partition_increase: int
    added_atom_count: int
    collisions_separated: int
    protected_pairs_preserved: int
    unrepresented_covered: int
    status: str
    reasons: tuple[str,...]


@dataclass(frozen=True)
class GrammarRefinementSynthesisCertificate:
    certificate_id: str
    search_config_hash: str
    case_hashes: tuple[tuple[str,str],...]
    status: str  # IDENTITY | REFINED | UNRESOLVED | INVALID
    selected_spec: Optional[RefinedGrammarSpec]
    selected_cost: Optional[tuple[float,...]]
    search_space_size: int
    evaluated_candidate_count: int
    valid_candidate_count: int
    strictly_better_valid_candidate_count: int
    validations: tuple[RefinementCaseValidation,...]
    separation_obligations: tuple[tuple[str,str],...]
    protected_equivalence_pairs: tuple[tuple[str,str],...]
    covered_unrepresented_programs: tuple[str,...]
    reasons: tuple[str,...]
    scope_statement: str

    @property
    def certificate_hash(self) -> str:
        return sha256_object(self)


def certify_refinement_case(
    case_id:str,
    config:GrammarAdequacyConfig,
    ledger:AcquisitionLedger,
    freeze:DataFreezeCertificate,
    sessions_by_id:dict[str,EidoSession],
    r8_certificate:CandidateUniverseCertificate,
    causal_dispositions:Iterable[RawProgramCausalDisposition],
    pair_dispositions:Iterable[RawProgramPairDisposition],
    r9_certificate:GrammarAdequacyCertificate,
) -> CertifiedRefinementCase:
    # Re-run R9 from the frozen source: R10 never trusts a detached witness list.
    rerun=GrammarAdequacyAnalyzer(config).certify(
        ledger,freeze,sessions_by_id,r8_certificate,causal_dispositions,pair_dispositions
    )
    if rerun.certificate_hash!=r9_certificate.certificate_hash:
        raise ValueError('supplied R9 certificate does not reproduce from frozen source')
    if rerun.status in {'INVALID','UNRESOLVED'}:
        raise ValueError('R10 cannot synthesize from invalid/unresolved R9 source')
    excluded=set(freeze.excluded_session_ids)
    ids=[e.session_id for e in ledger.entries if e.session_id not in excluded]
    source=[sessions_by_id[x] for x in ids]
    mined=sorted(OperatorMiner(config=config.miner_config()).mine(source),key=lambda x:x.operator_id)
    programs=_extract_raw_programs(source,mined,config.raw_program_min_support)
    causal=list(causal_dispositions); cmap={d.program_id:d for d in causal}
    pass_ids=tuple(sorted(pid for pid,d in cmap.items() if d.status=='PASS'))
    pairs=list(pair_dispositions)
    protected=tuple(sorted((d.left_program_id,d.right_program_id) for d in pairs if d.status=='PASS'))
    collisions=tuple(sorted(r9_certificate.separation_obligations))
    unrepresented=tuple(sorted(w.left_program_id for w in r9_certificate.unrepresented_witnesses))
    # One representative exact program is sufficient: all sessions in a raw-program hash group
    # have exactly the same intervention events by construction.
    reps=[]
    for p in programs:
        if not p.source_session_ids:
            raise ValueError('raw program without source session')
        reps.append((p.program_id,sessions_by_id[p.source_session_ids[0]]))
    return CertifiedRefinementCase(
        case_id,config.observer_id,r9_certificate.certificate_hash,r9_certificate.status,
        config.raw_program_min_support,config.miner_max_ngram,tuple(programs),pass_ids,
        protected,collisions,unrepresented,tuple(reps)
    )


def _patterns(tokens:tuple[str,...],max_ngram:int):
    for n in range(1,max_ngram+1):
        for i in range(len(tokens)-n+1):
            yield tuple(tokens[i:i+n])


def _probe_tokens(session:EidoSession, probe:ShapeRefinementProbe, cfg:GrammarRefinementSearchConfig)->tuple[str,...]:
    base=StrokeSegmenter(SegmenterConfig(
        version=cfg.base_segmenter_version,
        resample_n=cfg.base_resample_n,
        quantization_bins=cfg.base_quantization_bins,
        relation_bins=cfg.base_relation_bins,
    ))
    segs=base.segment(session); rels=base.relations(segs); out=[]
    for i,s in enumerate(segs):
        sig,_=shape_signature(list(s.points),probe.resample_n,probe.quantization_bins)
        out.append(sig if i==0 else rels[i-1].signature+'|'+sig)
    return tuple(out)


def _probe_atom_maps(case:CertifiedRefinementCase, probe:ShapeRefinementProbe, cfg:GrammarRefinementSearchConfig):
    reps=dict(case.representative_sessions); pmap={p.program_id:p for p in case.programs}
    toks={pid:_probe_tokens(reps[pid],probe,cfg) for pid in pmap}
    support={}
    for pid,ts in toks.items():
        seen=set(_patterns(ts,case.max_ngram))
        for pat in seen:
            support[pat]=support.get(pat,0)+pmap[pid].support_count
    admitted={pat for pat,n in support.items() if n>=case.raw_program_min_support}
    atoms={}
    for pid,ts in toks.items():
        xs=[]
        for pat in sorted(set(_patterns(ts,case.max_ngram)) & admitted):
            xs.append('probe:'+probe.probe_id+':'+sha256_object(pat)[:16])
        atoms[pid]=tuple(sorted(xs))
    return atoms


def _coverage_atom_candidates(cases:tuple[CertifiedRefinementCase,...])->tuple[CoverageAtom,...]:
    out=set()
    for case in cases:
        pmap={p.program_id:p for p in case.programs}
        for pid in case.unrepresented_obligations:
            p=pmap[pid]
            for pat in _patterns(p.grammar_tokens,case.max_ngram):
                out.add(tuple(pat))
    return tuple(CoverageAtom(x) for x in sorted(out))


def _coverage_atoms_for_case(case:CertifiedRefinementCase, atoms:tuple[CoverageAtom,...]):
    pmap={p.program_id:p for p in case.programs}
    out={pid:[] for pid in pmap}
    for atom in atoms:
        # Promotion is symmetric: the atom applies to every raw-supported program containing
        # the same existing base-grammar pattern, never to a witness by ID.
        support=sum(p.support_count for p in case.programs if _contains_pattern(p.grammar_tokens,atom.pattern))
        if support<case.raw_program_min_support:
            continue
        for pid,p in pmap.items():
            if _contains_pattern(p.grammar_tokens,atom.pattern): out[pid].append(atom.atom_id)
    return {pid:tuple(sorted(xs)) for pid,xs in out.items()}


def _addresses(case:CertifiedRefinementCase,spec:RefinedGrammarSpec,cfg:GrammarRefinementSearchConfig):
    pmap={p.program_id:p for p in case.programs}
    extra={pid:[] for pid in pmap}
    for probe in spec.probes:
        amap=_probe_atom_maps(case,probe,cfg)
        for pid,xs in amap.items():
            # Necessity locality: a new probe is observable only inside old grammar cells
            # that contain a certified R9 collision. Outside those cells the old grammar
            # is retained literally, so no gratuitous new alphabet is introduced.
            if pmap[pid].grammar_address in set(spec.probe_target_addresses):
                extra[pid].extend(xs)
    cmap=_coverage_atoms_for_case(case,spec.coverage_atoms)
    out={}
    for pid,p in pmap.items():
        base=['base:'+x for x in p.grammar_address]
        out[pid]=tuple(sorted(base+extra[pid]+list(cmap[pid])))
    return out


def _validate_case(case:CertifiedRefinementCase,spec:RefinedGrammarSpec,cfg:GrammarRefinementSearchConfig):
    a=_addresses(case,spec,cfg); reasons=[]
    for x,y in case.collision_obligations:
        if a[x]==a[y]: reasons.append(f'collision obligation not separated: {x}::{y}')
    for x,y in case.protected_equivalence_pairs:
        if a[x]!=a[y]: reasons.append(f'protected causal equivalence split: {x}::{y}')
    for x in case.unrepresented_obligations:
        if not a[x]: reasons.append(f'unrepresented witness remains without address: {x}')
    pass_ids=case.causal_pass_program_ids
    base={pid:tuple('base:'+x for x in next(p.grammar_address for p in case.programs if p.program_id==pid)) for pid in pass_ids}
    base_parts=len(set(base.values())) if pass_ids else 0
    refined_parts=len(set(a[pid] for pid in pass_ids)) if pass_ids else 0
    added=set()
    for pid in pass_ids:
        added.update(x for x in a[pid] if not x.startswith('base:'))
    return RefinementCaseValidation(
        case.case_id,base_parts,refined_parts,refined_parts-base_parts,len(added),
        sum(a[x]!=a[y] for x,y in case.collision_obligations),
        sum(a[x]==a[y] for x,y in case.protected_equivalence_pairs),
        sum(bool(a[x]) for x in case.unrepresented_obligations),
        'PASS' if not reasons else 'FAIL',tuple(reasons)
    )


def _cost(spec:RefinedGrammarSpec,validations:tuple[RefinementCaseValidation,...])->tuple[float,...]:
    # Primary objective = actual refinement of the empirical partition, i.e. additional
    # distinguishable cells. Then minimize admitted new atom alphabet, rule count, and
    # maximum-code description length. The final numeric tuple is a deterministic tie break.
    partition=sum(v.partition_increase for v in validations)
    atoms=sum(v.added_atom_count for v in validations)
    items=len(spec.probes)+len(spec.coverage_atoms)
    bits=sum(p.max_code_bits for p in spec.probes)
    cov_size=sum(len(a.pattern) for a in spec.coverage_atoms)
    displacement=sum((p.resample_n-12)+(p.quantization_bins-8) for p in spec.probes)
    return (float(partition),float(atoms),float(items),float(bits+cov_size),float(displacement))


class NecessityConstrainedGrammarRefinementSynthesizer:
    def __init__(self,config:GrammarRefinementSearchConfig=GrammarRefinementSearchConfig()):
        self.config=config

    def _probe_candidates(self):
        c=self.config; out=[]
        for dn in range(c.max_resample_increment+1):
            for db in range(c.max_bin_increment+1):
                if dn==0 and db==0: continue
                out.append(ShapeRefinementProbe(c.base_resample_n+dn,c.base_quantization_bins+db))
        return tuple(sorted(out,key=lambda p:(p.max_code_bits,(p.resample_n-c.base_resample_n)+(p.quantization_bins-c.base_quantization_bins),p.resample_n,p.quantization_bins)))

    def synthesize(self,cases:Iterable[CertifiedRefinementCase])->GrammarRefinementSynthesisCertificate:
        cases=tuple(cases); c=self.config
        if not cases:
            return self._result('INVALID',cases,None,None,0,0,0,(),('no certified refinement cases',))
        # Only R9 PASS/INADEQUATE are admissible. PASS cases contribute protected/no-regression scope.
        bad=[x.case_id for x in cases if x.source_r9_status not in {'PASS','INADEQUATE'}]
        if bad:
            return self._result('INVALID',cases,None,None,0,0,0,(),('invalid/unresolved source case: '+','.join(bad),))
        obligations=sum(len(x.collision_obligations)+len(x.unrepresented_obligations) for x in cases)
        target_cells=tuple(sorted(set(
            next(p.grammar_address for p in case.programs if p.program_id==a)
            for case in cases for a,b in case.collision_obligations
        )))
        if obligations==0:
            spec=RefinedGrammarSpec(c.base_segmenter_version,c.base_resample_n,c.base_quantization_bins,c.base_relation_bins,(),(),(),min(x.raw_program_min_support for x in cases),max(x.max_ngram for x in cases))
            vals=tuple(_validate_case(x,spec,c) for x in cases)
            return self._result('IDENTITY',cases,spec,_cost(spec,vals),1,1,1,vals,())

        probes=self._probe_candidates()
        cov=_coverage_atom_candidates(cases)
        probe_sets=[()]
        for k in range(1,c.max_probes+1): probe_sets.extend(combinations(probes,k))
        cov_sets=[()]
        for k in range(1,min(c.max_coverage_atoms,len(cov))+1): cov_sets.extend(combinations(cov,k))
        total=len(probe_sets)*len(cov_sets)
        if total>c.max_candidate_specs:
            return self._result('UNRESOLVED',cases,None,None,total,0,0,(),(f'frozen refinement search space {total} exceeds cap {c.max_candidate_specs}',))
        valid=[]; evaluated=0
        for ps in probe_sets:
            for cs in cov_sets:
                evaluated+=1
                spec=RefinedGrammarSpec(c.base_segmenter_version,c.base_resample_n,c.base_quantization_bins,c.base_relation_bins,tuple(ps),target_cells,tuple(cs),min(x.raw_program_min_support for x in cases),max(x.max_ngram for x in cases))
                vals=tuple(_validate_case(x,spec,c) for x in cases)
                if all(v.status=='PASS' for v in vals):
                    valid.append((_cost(spec,vals),spec,vals))
        if not valid:
            return self._result('UNRESOLVED',cases,None,None,total,evaluated,0,(),('no admissible refinement found inside the frozen existing-family search space',))
        valid.sort(key=lambda x:(x[0],x[1].spec_hash))
        best_cost,best_spec,best_vals=valid[0]
        better=sum(1 for cost,_,__ in valid if cost<best_cost)
        return self._result('REFINED',cases,best_spec,best_cost,total,evaluated,len(valid),best_vals,(),better)

    def _result(self,status,cases,spec,cost,total,evaluated,valid,vals,reasons,better=0):
        sep=tuple(sorted(set(p for x in cases for p in x.collision_obligations)))
        prot=tuple(sorted(set(p for x in cases for p in x.protected_equivalence_pairs)))
        unr=tuple(sorted(set(p for x in cases for p in x.unrepresented_obligations)))
        cid='r10:'+sha256_object({
            'search':self.config.config_hash,'cases':[(x.case_id,x.case_hash) for x in cases],
            'status':status,'spec':None if spec is None else spec.spec_hash,'cost':cost,
        })[:16]
        scope=(
            'minimal only inside the frozen refinement family generated from the existing shape_signature '
            'parameterization plus witness-derived promotion of already-existing base token patterns; '
            'R10 does not establish global minimality over arbitrary future representations'
        )
        return GrammarRefinementSynthesisCertificate(
            cid,self.config.config_hash,tuple(sorted((x.case_id,x.case_hash) for x in cases)),status,spec,cost,
            total,evaluated,valid,better,tuple(vals),sep,prot,unr,tuple(reasons),scope
        )
