from __future__ import annotations

from itertools import combinations
from dataclasses import replace

from .r8_synthetic import candidate_source_sessions, _session
from .r9_synthetic import run_r9_dryrun, unrepresented_universe, make_adequacy_registry
from .operators import OperatorMiner, MinerConfig
from .candidate_universe import (
    R3Disposition,R4PairDisposition,CandidateUniverseConfig,
    ExhaustiveCandidateUniverseEnumerator,freeze_generic_candidate_ledger,
)
from .grammar_adequacy import GrammarAdequacyConfig, GrammarAdequacyAnalyzer, raw_program_hash, raw_program_id
from .grammar_refinement import (
    GrammarRefinementSearchConfig, certify_refinement_case,
    NecessityConstrainedGrammarRefinementSynthesizer,
)
from .acquisition import AcquisitionLedger, sha256_object


def collision_with_protected_equivalence(observer='R10COLL',root='r10-root',policy_hash='policy'):
    sessions=candidate_source_sessions(observer)
    bent=((.10,.10),(.50,.52),(.90,.90))
    shifted=((.13,.12),(.53,.52),(.93,.92))  # same normalized shape as exact diagonal
    sessions += [_session(observer,'g0_diag_bent',bent,r) for r in range(3)]
    sessions += [_session(observer,'g0_diag_shifted',shifted,r) for r in range(3)]
    byid={s.session_id:s for s in sessions}; ledger=AcquisitionLedger(root)
    for s in sessions: ledger.append(s)
    freeze=freeze_generic_candidate_ledger('r10-collision-protected',root,observer,ledger,byid)
    mined=OperatorMiner(config=MinerConfig(3,1,'operator-miner-v1')).mine(sessions)
    r3=[R3Disposition(o.operator_id,sha256_object(o),f'r3:{observer}:{o.operator_id}','PASS','domain:shared','probe:2phase','causal-replay-v3') for o in mined]
    r3m={x.operator_id:x for x in r3}; r4=[]
    for a,b in combinations(sorted(r3m),2):
        r4.append(R4PairDisposition(f'{a}::{b}',a,b,r3m[a].causal_certificate_id,r3m[b].causal_certificate_id,
            f'subst:{observer}:{a}:{b}','FAIL','domain:shared','probe:2phase',policy_hash,'causal-substitution-v4'))
    cfg8=CandidateUniverseConfig(observer,freeze.freeze_hash,3,1,'operator-miner-v1','domain:shared','probe:2phase','causal-replay-v3',policy_hash,'causal-substitution-v4',3,100,1000,1000)
    r8=ExhaustiveCandidateUniverseEnumerator(cfg8).certify(ledger,freeze,byid,r3,r4)
    if r8.status!='PASS': raise RuntimeError(r8)
    cfg=GrammarAdequacyConfig(observer,r8.certificate_hash,freeze.freeze_hash,3,1,'operator-miner-v1',3,'domain:shared','probe:2phase','raw-program-causal-replay-v1',policy_hash,'raw-program-substitution-v1',100,1000)
    # Map exact programs by label hashes.
    diag_h=raw_program_hash(_session(observer,'tmp',((.10,.10),(.50,.50),(.90,.90)),0))
    bent_h=raw_program_hash(_session(observer,'tmp',bent,0))
    shift_h=raw_program_hash(_session(observer,'tmp',shifted,0))
    diag,bentp,shift=raw_program_id(diag_h),raw_program_id(bent_h),raw_program_id(shift_h)
    ids=sorted((diag,bentp,shift))
    pair_status={}
    for a,b in combinations(ids,2):
        pair_status[f'{a}::{b}']='PASS' if set((a,b))==set((diag,shift)) else 'FAIL'
    effects={
        diag:{'focus':.45,'noise':-.45},shift:{'focus':.45,'noise':-.45},
        bentp:{'focus':-.30,'noise':.30},
    }
    causal,pairs,progs=make_adequacy_registry(cfg,ledger,freeze,byid,r8,pair_status,effects)
    cert=GrammarAdequacyAnalyzer(cfg).certify(ledger,freeze,byid,r8,causal,pairs)
    if cert.status!='INADEQUATE': raise RuntimeError(cert)
    case=certify_refinement_case('collision-protected',cfg,ledger,freeze,byid,r8,causal,pairs,cert)
    return cfg8,ledger,freeze,byid,tuple(r3),tuple(r4),r8,cfg,causal,pairs,progs,cert,case,(diag,bentp,shift)


def case_from_unrepresented(policy_hash='policy'):
    x=unrepresented_universe(policy_hash=policy_hash)
    cfg8,ledger,freeze,byid,r3,r4,r8,cfg,causal,pairs,progs,cert=x
    case=certify_refinement_case('unrepresented',cfg,ledger,freeze,byid,r8,causal,pairs,cert)
    return x,case


def standard_cases_from_r9(data):
    # run_r9_dryrun returns each R8 source plus its reproduced R9 PASS registry.
    r8data,adeq,regs,r9,collision,unrep=data
    vals,dsa,csa,dsel,rule,csel,cclasses,pkg,universes,sources,r8confirm=r8data
    out=[]
    for oid in sorted(sources):
        cfg,causal,pairs,cert=regs[oid]
        cfg8,ledger,freeze,byid,r3,r4,r8,mg=sources[oid]
        out.append(certify_refinement_case('standard:'+oid,cfg,ledger,freeze,byid,r8,causal,pairs,cert))
    return tuple(out)


def run_r10_dryrun():
    r9=run_r9_dryrun()
    policy=r9[0][0][1].r4.as_substitution_policy().policy_hash()  # master bundle through R8/R9 chain
    coll=collision_with_protected_equivalence(policy_hash=policy)
    unrep,ucase=case_from_unrepresented(policy)
    std=standard_cases_from_r9(r9)
    ccase=coll[-2]
    search=GrammarRefinementSearchConfig(max_resample_increment=4,max_bin_increment=8,max_probes=1,max_coverage_atoms=2,max_candidate_specs=5000)
    syn=NecessityConstrainedGrammarRefinementSynthesizer(search)
    collision_only=syn.synthesize((ccase,))
    unrepresented_only=syn.synthesize((ucase,))
    joint=syn.synthesize(std+(ccase,ucase))
    identity=syn.synthesize(std)
    return r9,coll,unrep,std,search,collision_only,unrepresented_only,joint,identity
