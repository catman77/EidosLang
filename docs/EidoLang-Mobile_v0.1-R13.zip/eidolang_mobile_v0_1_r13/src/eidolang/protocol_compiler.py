from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Optional
from pathlib import Path
import json

from .acquisition import (
    AnchorDefinition, AnalysisLock, AcquisitionManifest, sha256_object
)
from .causal import CausalAnalyzer
from .substitution import SubstitutionPolicy, CausalSubstitutionAnalyzer
from .effect_alignment import AlignmentConfig, CrossObserverEffectAligner
from .reliability import ReliabilityManifest
from .fidelity import (
    FidelityScope, StimulusKind, StimulusStep, AnchorExecutionPlan
)
from .feasibility import FeasibilityManifest, FeasibilityReport, analyze_feasibility
from .cross_observer_transport import R5TransportConfig, R5CrossObserverTransportAnalyzer
from .reliability import ReliabilityGateResult
from .effect_alignment import EffectAlignmentReport


class ProtocolCompileError(ValueError):
    pass


@dataclass(frozen=True)
class MasterAnchorSpec:
    anchor_id: str
    family: str                  # ALIGNMENT | RELIABILITY
    instruction: str
    duration_s: float
    repeats: int
    synthetic_only: bool = False

    def __post_init__(self):
        if self.family not in {"ALIGNMENT","RELIABILITY"}:
            raise ValueError("anchor family must be ALIGNMENT|RELIABILITY")
        if self.duration_s <= 0:
            raise ValueError("anchor duration must be positive")
        if self.repeats < 1:
            raise ValueError("anchor repeats must be >=1")


@dataclass(frozen=True)
class MasterStudyManifest:
    study_id: str
    manifest_version: str
    mode: str                    # DRY_RUN | REAL
    observer_ids: tuple[str, ...]
    reference_observer_id: str
    state_metric_keys: tuple[str, ...]
    primary_endpoint_alternatives: tuple[tuple[str,str], ...]
    topology_representation: str
    topology_extractor_version: str
    alignment_holdout_rmse_margin: float
    alignment_split_seed: str
    alignment_anchor_specs: tuple[MasterAnchorSpec, ...]
    reliability_anchor_specs: tuple[MasterAnchorSpec, ...]
    quantization_step: dict[str,float]
    max_repeatability_radius: dict[str,float]
    repeatability_alpha: float
    repeat_order_drift_alpha: float
    causal_class_count: int
    operator_realizations_per_class: int
    r3_alpha_familywise: float
    r3_exact_cap: int
    r4_alpha_familywise: float
    r4_endpoint_margins: dict[str,float]
    r4_trajectory_margins: dict[str,float]
    r4_probe_phase_count: int
    r4_strata: int
    r4_exact_cap: int
    r47_alpha_familywise: float
    r47_permutation_cap: int
    r5_alpha_familywise: float
    r5_primary_hypothesis_count: int
    r5_exact_cap: int
    production_grammar_spec_hash: Optional[str] = None
    production_grammar_binding_hash: Optional[str] = None
    production_grammar_lineage_version: Optional[str] = None
    fidelity_scope: str = "DIGITAL_EXECUTION"
    recommendation_mode: str = "NONE"
    external_commit_ref: Optional[str] = None

    def __post_init__(self):
        if self.mode not in {"DRY_RUN","REAL"}:
            raise ValueError("mode must be DRY_RUN|REAL")
        prod=(self.production_grammar_spec_hash,self.production_grammar_binding_hash,self.production_grammar_lineage_version)
        if self.manifest_version=="master-prereg-v2":
            if any(x is None or x=="" for x in prod):
                raise ValueError("master-prereg-v2 requires complete production grammar binding")
        elif any(x is not None for x in prod):
            raise ValueError("production grammar binding requires manifest_version=master-prereg-v2")
        if len(self.observer_ids) < 2:
            raise ValueError("need at least two observers")
        if self.reference_observer_id not in self.observer_ids:
            raise ValueError("reference observer missing")
        if not self.state_metric_keys:
            raise ValueError("state_metric_keys cannot be empty")
        if self.causal_class_count < 2:
            raise ValueError("confirmatory R5 needs at least two causal classes")
        if self.operator_realizations_per_class < 2:
            raise ValueError("each causal MacroName needs >=2 distinct realizations")
        endpoint_keys={k for k,_ in self.primary_endpoint_alternatives}
        if not endpoint_keys:
            raise ValueError("primary endpoint set cannot be empty")
        if not endpoint_keys <= set(self.state_metric_keys):
            raise ValueError("primary endpoints must be state metrics")
        if set(self.r4_endpoint_margins) != endpoint_keys:
            raise ValueError("R4 endpoint margins must equal primary endpoint metric set")
        if set(self.r4_trajectory_margins) != endpoint_keys:
            raise ValueError("R4 trajectory margins must equal primary endpoint metric set")
        if set(self.quantization_step) != set(self.state_metric_keys):
            raise ValueError("quantization_step schema mismatch")
        if set(self.max_repeatability_radius) != set(self.state_metric_keys):
            raise ValueError("max_repeatability_radius schema mismatch")
        if self.mode=="REAL":
            bad=[a.anchor_id for a in self.alignment_anchor_specs+self.reliability_anchor_specs
                 if a.synthetic_only or "SYNTHETIC" in a.instruction.upper() or "REPLACE" in a.instruction.upper()]
            if bad:
                raise ValueError("REAL manifest contains synthetic/placeholder anchors: "+",".join(bad))
        if any(a.family!="ALIGNMENT" for a in self.alignment_anchor_specs):
            raise ValueError("alignment_anchor_specs contains wrong family")
        if any(a.family!="RELIABILITY" for a in self.reliability_anchor_specs):
            raise ValueError("reliability_anchor_specs contains wrong family")
        ids=[a.anchor_id for a in self.alignment_anchor_specs+self.reliability_anchor_specs]
        if len(ids)!=len(set(ids)):
            raise ValueError("anchor ids must be globally unique")

    @property
    def master_hash(self) -> str:
        return sha256_object(self)

    @property
    def r3_operator_count(self) -> int:
        # Distinct realizations are required for each class in the confirmatory design.
        return self.causal_class_count*self.operator_realizations_per_class

    @property
    def primary_endpoint_count(self) -> int:
        return len(self.primary_endpoint_alternatives)


@dataclass(frozen=True)
class CompiledR3Policy:
    alpha_local: float
    max_exact_allocations: int
    minimum_total_trials_per_operator: int
    minimum_per_arm: int
    operator_count_per_observer: int
    primary_endpoint_alternatives: tuple[tuple[str,str], ...]
    protocol_version: str = "causal-replay-v3"


@dataclass(frozen=True)
class CompiledR4Policy:
    alpha_familywise_per_pair: float
    endpoint_margins: dict[str,float]
    trajectory_margins: dict[str,float]
    min_trials_per_arm_per_stratum: int
    total_pair_certificates_per_observer: int
    probe_phase_count: int
    strata: int
    max_exact_allocations: int
    protocol_version: str = "causal-substitution-v4"

    def as_substitution_policy(self) -> SubstitutionPolicy:
        return SubstitutionPolicy(
            endpoint_margins=dict(self.endpoint_margins),
            trajectory_margins=dict(self.trajectory_margins),
            alpha_familywise=self.alpha_familywise_per_pair,
            min_trials_per_arm_per_stratum=self.min_trials_per_arm_per_stratum,
            max_exact_allocations=self.max_exact_allocations,
            protocol_version=self.protocol_version,
        )


@dataclass(frozen=True)
class SessionBudget:
    observers: int
    alignment_sessions_per_observer: int
    reliability_sessions_per_observer: int
    r3_sessions_per_observer: int
    r4_sessions_per_observer: int
    confirmatory_sessions_per_observer_before_discovery: int
    confirmatory_sessions_total_before_discovery: int
    excluded_from_count: tuple[str,...]


@dataclass(frozen=True)
class CompiledProtocolBundle:
    compiler_version: str
    master_hash: str
    feasibility: FeasibilityReport
    alignment_acquisition: AcquisitionManifest
    reliability: ReliabilityManifest
    r3: CompiledR3Policy
    r4: CompiledR4Policy
    r47: AlignmentConfig
    r5: R5TransportConfig
    anchor_execution_plans: tuple[AnchorExecutionPlan,...]
    session_budget: SessionBudget
    runtime_lock_hash: str
    child_hashes: tuple[tuple[str,str],...]

    @property
    def bundle_hash(self) -> str:
        return sha256_object(self)


class ProtocolCompiler:
    compiler_version="protocol-compiler-v1"

    def compile(self, m: MasterStudyManifest) -> CompiledProtocolBundle:
        endpoint_count=m.primary_endpoint_count
        operator_count=m.r3_operator_count

        # Alignment anchors must be exactly the number that will be frozen into R4.7.
        # The fit lower bound is solved by R4.11; holdout count is whatever remains.
        # For the first design, all declared ALIGNMENT anchors are used.
        if len(m.alignment_anchor_specs) < len(m.state_metric_keys)+1:
            raise ProtocolCompileError("alignment anchors cannot satisfy rank + holdout requirement")

        # Reliability sessions are deliberately separate: no silent cross-use theorem.
        if any(a.repeats != 2 for a in m.reliability_anchor_specs):
            raise ProtocolCompileError("R4.10 compiler currently requires exactly 2 repeats/reliability anchor")

        # First compute feasibility with all cross-stage multiplicities included.
        fit_guess=len(m.state_metric_keys)
        holdout_count=len(m.alignment_anchor_specs)-fit_guess
        if holdout_count < 1:
            raise ProtocolCompileError("need at least one alignment holdout anchor")

        fm=FeasibilityManifest(
            study_id=m.study_id,
            protocol_hash=m.master_hash,
            r3_alpha_familywise=m.r3_alpha_familywise,
            r3_operator_hypotheses=operator_count,
            r3_endpoint_metric_hypotheses=endpoint_count,
            r3_alternative="one-sided",
            r3_min_per_arm=4,
            r3_exact_cap=m.r3_exact_cap,
            r4_alpha_familywise=m.r4_alpha_familywise,
            r4_macro_operator_count=m.operator_realizations_per_class,
            r4_macro_name_hypotheses=m.causal_class_count,
            r4_strata=m.r4_strata,
            r4_endpoint_metric_count=len(m.r4_endpoint_margins),
            r4_trajectory_metric_count=len(m.r4_trajectory_margins),
            r4_probe_phase_count=m.r4_probe_phase_count,
            r4_min_per_arm_per_stratum=4,
            r4_exact_cap=m.r4_exact_cap,
            observer_count=len(m.observer_ids),
            state_dimension=len(m.state_metric_keys),
            r47_alpha_familywise=m.r47_alpha_familywise,
            r47_holdout_anchor_count=holdout_count,
            r47_permutation_cap=m.r47_permutation_cap,
            r410_alpha_marginal=m.repeatability_alpha,
            r410_metric_count=len(m.state_metric_keys),
            r5_alpha_familywise=m.r5_alpha_familywise,
            r5_primary_hypothesis_count=m.r5_primary_hypothesis_count,
            r5_binary_observer_label_flip=(m.causal_class_count==2),
            r5_exact_cap=m.r5_exact_cap,
        )
        fr=analyze_feasibility(fm)
        if fr.status!="PASS":
            raise ProtocolCompileError("finite-sample feasibility BLOCKED: "+"; ".join(fr.reasons))

        fit_count=fr.r47.minimum_fit_anchors
        if fit_count is None:
            raise ProtocolCompileError("R4.7 fit anchor count unresolved")
        if len(m.alignment_anchor_specs) != fit_count + fr.r47.holdout_anchor_count:
            raise ProtocolCompileError(
                f"declared alignment anchors={len(m.alignment_anchor_specs)} but compiled design requires "
                f"{fit_count}+{fr.r47.holdout_anchor_count}"
            )

        # R4.10 exact finite-sample count: one pair per reliability anchor.
        if len(m.reliability_anchor_specs) < fr.r410.marginal_min_disjoint_pairs:
            raise ProtocolCompileError(
                f"reliability anchors={len(m.reliability_anchor_specs)} < exact minimum {fr.r410.marginal_min_disjoint_pairs}"
            )

        # R4 margins cannot be finer even than the digital quantization floor before data.
        for k in m.r4_endpoint_margins:
            if m.r4_endpoint_margins[k] < m.quantization_step[k]:
                raise ProtocolCompileError(f"R4 endpoint margin for {k} below quantization floor")
            if m.r4_trajectory_margins[k] < m.quantization_step[k]:
                raise ProtocolCompileError(f"R4 trajectory margin for {k} below quantization floor")

        al_anchors=tuple(
            AnchorDefinition(a.anchor_id,a.instruction,a.duration_s,a.repeats)
            for a in m.alignment_anchor_specs
        )
        acquisition=AcquisitionManifest(
            study_id=m.study_id+":alignment",
            protocol_version="acquisition-v1",
            anchors=al_anchors,
            fit_anchor_count=fit_count,
            split_seed=m.alignment_split_seed,
            planned_observer_count=len(m.observer_ids),
            state_metric_keys=m.state_metric_keys,
            exclusion_rules=(
                "technical capture failure declared before outcome inspection",
                "missing required pre/post observation",
                "protocol-hash mismatch",
                "session not in deterministic schedule",
                "R4.9 fidelity certificate not PASS",
            ),
            analysis_lock=AnalysisLock(
                topology_representation=m.topology_representation,
                topology_extractor_version=m.topology_extractor_version,
                state_metric_keys=m.state_metric_keys,
                alignment_transport_family="zero_similarity",
                causal_label_policy="ALL_R4_PASSING_AT_CUTOFF",
                cross_observer_policy="LEAVE_ONE_OBSERVER_OUT",
                notes="compiled from master "+m.master_hash,
            ),
            recommendation_mode=m.recommendation_mode,
            target_state_allowed_for_anchors=False,
            external_commit_ref=m.external_commit_ref or ("master:"+m.master_hash),
        )
        split=acquisition.anchor_split()

        reliability=ReliabilityManifest(
            study_id=m.study_id+":reliability",
            protocol_hash=m.master_hash,
            manifest_version="reliability-v1",
            observer_ids=m.observer_ids,
            anchor_ids=tuple(a.anchor_id for a in m.reliability_anchor_specs),
            metric_keys=m.state_metric_keys,
            repeats_per_anchor=2,
            alpha_repeatability=m.repeatability_alpha,
            alpha_drift=m.repeat_order_drift_alpha,
            max_repeatability_radius=dict(m.max_repeatability_radius),
            quantization_step=dict(m.quantization_step),
            pairing_policy="ADJACENT_DISJOINT",
            unreliable_metric_policy="FAIL_WHOLE_GATE",
            external_commit_ref=m.external_commit_ref or ("master:"+m.master_hash),
        )

        r3=CompiledR3Policy(
            alpha_local=fr.r3.alpha_local,
            max_exact_allocations=m.r3_exact_cap,
            minimum_total_trials_per_operator=fr.r3.minimum_total_trials_per_operator,
            minimum_per_arm=fr.r3.minimum_per_arm,
            operator_count_per_observer=operator_count,
            primary_endpoint_alternatives=m.primary_endpoint_alternatives,
        )

        r4=CompiledR4Policy(
            alpha_familywise_per_pair=fr.r4.alpha_pair,
            endpoint_margins=dict(m.r4_endpoint_margins),
            trajectory_margins=dict(m.r4_trajectory_margins),
            min_trials_per_arm_per_stratum=fr.r4.minimum_trials_per_arm_per_stratum,
            total_pair_certificates_per_observer=fr.r4.pair_hypotheses,
            probe_phase_count=m.r4_probe_phase_count,
            strata=m.r4_strata,
            max_exact_allocations=m.r4_exact_cap,
        )

        r47=AlignmentConfig(
            fit_anchor_ids=split.fit_anchor_ids,
            holdout_anchor_ids=split.holdout_anchor_ids,
            holdout_rmse_margin=m.alignment_holdout_rmse_margin,
            alpha_familywise=m.r47_alpha_familywise,
            min_rank=len(m.state_metric_keys),
            permutation_cap=m.r47_permutation_cap,
            protocol_version="effect-alignment-v1",
        )

        r5=R5TransportConfig(
            observer_ids=m.observer_ids,
            reference_observer_id=m.reference_observer_id,
            causal_class_count=m.causal_class_count,
            realizations_per_class=m.operator_realizations_per_class,
            effect_metric_keys=tuple(k for k,_ in m.primary_endpoint_alternatives),
            alpha_local=m.r5_alpha_familywise/m.r5_primary_hypothesis_count,
            exact_cap=m.r5_exact_cap,
            topology_representation=m.topology_representation,
            topology_extractor_version=m.topology_extractor_version,
            statistic_version="pairing-orientation-product-v1",
            protocol_version="cross-observer-transport-v1",
        )

        scope=FidelityScope(m.fidelity_scope)
        plans=[]
        for a in m.alignment_anchor_specs+m.reliability_anchor_specs:
            # Compiler freezes *execution mechanics*. The content itself came from MasterAnchorSpec.
            steps=(
                StimulusStep(
                    step_id="prompt", kind=StimulusKind.PROMPT,
                    offset_ms=0, duration_ms=1000,
                    params={"text":a.instruction},
                    required=True,start_tolerance_ms=100,duration_tolerance_ms=150,
                ),
                StimulusStep(
                    step_id="exposure", kind=StimulusKind.WAIT,
                    offset_ms=1000, duration_ms=max(1,int(a.duration_s*1000)-1000),
                    params={"anchor_id":a.anchor_id},
                    required=True,start_tolerance_ms=150,duration_tolerance_ms=250,
                ),
            )
            plans.append(AnchorExecutionPlan(
                anchor_id=a.anchor_id,plan_version="compiled-anchor-v1",
                steps=steps,required_fidelity_scope=scope
            ))

        align_sessions=len(m.alignment_anchor_specs)
        rel_sessions=sum(a.repeats for a in m.reliability_anchor_specs)
        r3_sessions=operator_count*fr.r3.minimum_total_trials_per_operator
        # pair hypotheses already includes causal-class multiplicity.
        r4_sessions=fr.r4.pair_hypotheses*fr.r4.total_trials_per_pair_per_stratum*m.r4_strata
        per_obs=align_sessions+rel_sessions+r3_sessions+r4_sessions
        budget=SessionBudget(
            observers=len(m.observer_ids),
            alignment_sessions_per_observer=align_sessions,
            reliability_sessions_per_observer=rel_sessions,
            r3_sessions_per_observer=r3_sessions,
            r4_sessions_per_observer=r4_sessions,
            confirmatory_sessions_per_observer_before_discovery=per_obs,
            confirmatory_sessions_total_before_discovery=per_obs*len(m.observer_ids),
            excluded_from_count=(
                "FREE/CAPTURE discovery sessions",
                "failed sessions retained in ledger",
                "additional trials required for statistical power",
            ),
        )

        child_hashes=(
            ("alignment_acquisition",acquisition.protocol_hash),
            ("reliability",reliability.manifest_hash),
            ("r3",sha256_object(r3)),
            ("r4",sha256_object(r4)),
            ("r47",sha256_object(r47)),
            ("r5",sha256_object(r5)),
            ("feasibility",sha256_object(fr)),
            ("execution_plans",sha256_object(tuple(plans))),
            ("session_budget",sha256_object(budget)),
        )
        lock_hash=sha256_object({
            "compiler_version":self.compiler_version,
            "master_hash":m.master_hash,
            "children":child_hashes,
        })
        return CompiledProtocolBundle(
            compiler_version=self.compiler_version,
            master_hash=m.master_hash,
            feasibility=fr,
            alignment_acquisition=acquisition,
            reliability=reliability,
            r3=r3,r4=r4,r47=r47,r5=r5,
            anchor_execution_plans=tuple(plans),
            session_budget=budget,
            runtime_lock_hash=lock_hash,
            child_hashes=child_hashes,
        )

    def write_bundle(self, bundle: CompiledProtocolBundle, directory: str|Path) -> Path:
        d=Path(directory); d.mkdir(parents=True,exist_ok=True)
        def dump(name,obj):
            p=d/name
            payload=asdict(obj) if hasattr(obj,"__dataclass_fields__") else obj
            p.write_text(json.dumps(payload,ensure_ascii=False,indent=2,default=str),encoding="utf-8")
            return p
        dump("compiled_bundle.json",bundle)
        dump("feasibility.json",bundle.feasibility)
        dump("alignment_acquisition.json",bundle.alignment_acquisition)
        dump("reliability.json",bundle.reliability)
        dump("r3_policy.json",bundle.r3)
        dump("r4_policy.json",bundle.r4)
        dump("r47_config.json",bundle.r47)
        dump("r5_config.json",bundle.r5)
        dump("anchor_execution_plans.json",{"plans":[asdict(x) for x in bundle.anchor_execution_plans]})
        dump("session_budget.json",bundle.session_budget)
        (d/"RUNTIME_LOCK.txt").write_text(bundle.runtime_lock_hash+"\n",encoding="utf-8")
        return d


class ConfirmatoryRuntime:
    """
    Confirmatory factories. Raw constructors remain available for exploratory/backward-compatible
    code, but certificates emitted outside this runtime are not compiler-locked evidence.
    """
    def __init__(self,bundle:CompiledProtocolBundle):
        self.bundle=bundle

    def causal_analyzer(self) -> CausalAnalyzer:
        r=self.bundle.r3
        return CausalAnalyzer(
            alpha=r.alpha_local,
            max_exact_allocations=r.max_exact_allocations,
            protocol_version=r.protocol_version,
        )

    def substitution_policy(self) -> SubstitutionPolicy:
        return self.bundle.r4.as_substitution_policy()

    def substitution_analyzer(self) -> CausalSubstitutionAnalyzer:
        return CausalSubstitutionAnalyzer(self.substitution_policy())

    def effect_aligner(self) -> CrossObserverEffectAligner:
        return CrossObserverEffectAligner(self.bundle.r47)

    def r5_analyzer(self, alignment_report:EffectAlignmentReport, reliability:ReliabilityGateResult) -> R5CrossObserverTransportAnalyzer:
        return R5CrossObserverTransportAnalyzer(self.bundle.r5,alignment_report,reliability)

    def assert_r5_config(self,c:R5TransportConfig) -> None:
        if sha256_object(c)!=sha256_object(self.bundle.r5):
            raise ProtocolCompileError("R5TransportConfig differs from compiled preregistration")

    def assert_causal_analyzer(self,a:CausalAnalyzer) -> None:
        r=self.bundle.r3
        if (
            abs(a.alpha-r.alpha_local)>1e-15 or
            a.max_exact_allocations!=r.max_exact_allocations or
            a.protocol_version!=r.protocol_version
        ):
            raise ProtocolCompileError("CausalAnalyzer configuration differs from compiled preregistration")

    def assert_substitution_policy(self,p:SubstitutionPolicy) -> None:
        expected=self.substitution_policy()
        if p.policy_hash()!=expected.policy_hash():
            raise ProtocolCompileError("SubstitutionPolicy differs from compiled preregistration")

    def assert_alignment_config(self,c:AlignmentConfig) -> None:
        if sha256_object(c)!=sha256_object(self.bundle.r47):
            raise ProtocolCompileError("AlignmentConfig differs from compiled preregistration")

    def evidence_envelope(self, stage:str, evidence_ref:str) -> dict[str,str]:
        return {
            "stage":stage,
            "evidence_ref":evidence_ref,
            "master_hash":self.bundle.master_hash,
            "runtime_lock_hash":self.bundle.runtime_lock_hash,
            "bundle_hash":self.bundle.bundle_hash,
        }
