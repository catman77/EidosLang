from __future__ import annotations

from dataclasses import replace
from itertools import combinations

from .r10_synthetic import run_r10_dryrun, case_from_unrepresented
from .grammar_refinement import certify_refinement_case
from .refinement_admission import (
    RefinedGrammarCompiler, RefinedCandidateUniverseConfig,
    ExhaustiveRefinedCandidateUniverseEnumerator, RefinedGrammarAdequacyConfig,
    RefinedGrammarAdequacyAnalyzer, filter_refined_raw_pairs,
    verify_r10_source, make_case_replay, R11DownstreamReplay, admit_refinement,
)
from .candidate_universe import R3Disposition, R4PairDisposition
from .acquisition import sha256_object
from .r9_confirmation import R9AdequacyGatedConfirmationAnalyzer


def _synthetic_group_for_program(program,byid):
    groups=set()
    for sid in program.source_session_ids:
        parts=sid.split(':')
        label=next((x for x in parts if x.startswith('g') and '_' in x),None)
        if label is not None and len(label)>=2 and label[1].isdigit(): groups.add(int(label[1]))
    if len(groups)!=1:
        return None
    return next(iter(groups))


def _standard_fresh_registries(compiled,byid,policy_hash):
    pmap={p.program_id:p for p in compiled.raw_programs}
    group_by_op={}
    for o in compiled.causal_operators:
        pids=tuple(o.metadata.get('raw_program_ids',()))
        gs={_synthetic_group_for_program(pmap[p],byid) for p in pids}
        if len(gs)!=1 or None in gs:
            raise RuntimeError(f'cannot identify synthetic causal group for {o.operator_id}: {gs}')
        group_by_op[o.operator_id]=next(iter(gs))
    r3=tuple(R3Disposition(o.operator_id,sha256_object(o),f'r11:r3:{compiled.observer_id}:{o.operator_id}','PASS',
        'domain:shared','probe:2phase','causal-replay-v3') for o in compiled.causal_operators)
    r3m={x.operator_id:x for x in r3}; r4=[]
    for a,b in combinations(sorted(r3m),2):
        st='PASS' if group_by_op[a]==group_by_op[b] else 'FAIL'
        r4.append(R4PairDisposition(f'{a}::{b}',a,b,r3m[a].causal_certificate_id,r3m[b].causal_certificate_id,
            f'r11:subst:{compiled.observer_id}:{a}:{b}',st,'domain:shared','probe:2phase',policy_hash,'causal-substitution-v4'))
    return r3,tuple(r4),group_by_op


def _all_fail_fresh_registries(compiled,policy_hash):
    r3=tuple(R3Disposition(o.operator_id,sha256_object(o),f'r11:r3:{compiled.observer_id}:{o.operator_id}','PASS',
        'domain:shared','probe:2phase','causal-replay-v3') for o in compiled.causal_operators)
    r3m={x.operator_id:x for x in r3}; r4=[]
    for a,b in combinations(sorted(r3m),2):
        r4.append(R4PairDisposition(f'{a}::{b}',a,b,r3m[a].causal_certificate_id,r3m[b].causal_certificate_id,
            f'r11:subst:{compiled.observer_id}:{a}:{b}','FAIL','domain:shared','probe:2phase',policy_hash,'causal-substitution-v4'))
    return r3,tuple(r4)


def _enumerate(compiled,freeze,r3,r4,policy_hash,macro_size=3):
    cfg=RefinedCandidateUniverseConfig(compiled.observer_id,compiled.certificate_hash,freeze.freeze_hash,
        'domain:shared','probe:2phase','causal-replay-v3',policy_hash,'causal-substitution-v4',macro_size,100,5000,5000)
    return ExhaustiveRefinedCandidateUniverseEnumerator(cfg).certify(compiled,freeze,r3,r4)


def _adequacy(compiled,freeze,r8,causal,old_pairs,policy_hash):
    fresh_pairs=filter_refined_raw_pairs(compiled,old_pairs)
    cfg=RefinedGrammarAdequacyConfig(compiled.observer_id,compiled.certificate_hash,r8.certificate_hash,freeze.freeze_hash,
        'domain:shared','probe:2phase','raw-program-causal-replay-v1',policy_hash,'raw-program-substitution-v1',5000)
    return RefinedGrammarAdequacyAnalyzer(cfg).certify(compiled,r8,causal,fresh_pairs),fresh_pairs


def run_r11_dryrun():
    r10=run_r10_dryrun()
    r9data,coll,unrep,std,search,collision_only,unrepresented_only,joint,identity=r10
    spec=joint.selected_spec
    if spec is None: raise RuntimeError('joint R10 has no selected spec')
    policy=r9data[0][0][1].r4.as_substitution_policy().policy_hash()

    # Reconstruct the unrepresented certified case so source hashes are checked literally.
    cfg8u,ledgeru,freezeu,byidu,r3u,r4u,r8u,cfgu,causalu,pairsu,progsu,certu=unrep
    ucase=certify_refinement_case('unrepresented',cfgu,ledgeru,freezeu,byidu,r8u,causalu,pairsu,certu)
    ccase=coll[-2]
    all_cases=std+(ccase,ucase)
    source_check=verify_r10_source(joint,spec,all_cases)
    if source_check: raise RuntimeError(source_check)

    compiler=RefinedGrammarCompiler(spec)
    replays=[]

    # Collision repair replay.
    cfg8c,ledgerc,freezec,byidc,r3c,r4c,r8c,cfgc,causalc,pairsc,progsc,certc,casec,ids=coll
    cc=compiler.compile(cfgc.observer_id,ledgerc,freezec,byidc)
    nr3,nr4=_all_fail_fresh_registries(cc,policy)
    cr8=_enumerate(cc,freezec,nr3,nr4,policy)
    cr9,cpairs=_adequacy(cc,freezec,cr8,causalc,pairsc,policy)
    replays.append(make_case_replay(ccase,cc,cr8,cr9))

    # Unrepresented coverage replay.
    uc=compiler.compile(cfgu.observer_id,ledgeru,freezeu,byidu)
    ur3,ur4=_all_fail_fresh_registries(uc,policy)
    ur8=_enumerate(uc,freezeu,ur3,ur4,policy)
    ur9,upairs=_adequacy(uc,freezeu,ur8,causalu,pairsu,policy)
    replays.append(make_case_replay(ucase,uc,ur8,ur9))

    # Six original confirmation sources: full G' -> R8' -> R9' replay.
    r8data=r9data[0]
    vals,dsa,csa,dsel,rule,csel,cclasses,pkg,old_universes,sources,old_r8confirm=r8data
    m,b,split,ald,rgd,dclasses,dcert,hyp,alc,rgc,oldc,oldpkg,oldr6=vals
    old_registries=r9data[2]
    new_universes=[]; new_adequacy=[]; new_groupmap={}; compiles={}
    stdmap={c.observer_id:c for c in std}
    for oid in split.confirmation_observers():
        cfg8,ledger,freeze,byid,oldr3,oldr4,oldcert,oldmg=sources[oid]
        comp=compiler.compile(oid,ledger,freeze,byid); compiles[oid]=comp
        rr3,rr4,gmap=_standard_fresh_registries(comp,byid,policy)
        rr8=_enumerate(comp,freeze,rr3,rr4,policy)
        oldcfg,rawcausal,rawpairs,oldr9=old_registries[oid]
        rr9,rpairs=_adequacy(comp,freeze,rr8,rawcausal,rawpairs,policy)
        new_universes.append(rr8); new_adequacy.append(rr9)
        replays.append(make_case_replay(stdmap[oid],comp,rr8,rr9))
        mg={}
        for mc in rr8.eligible_macro_names:
            gs={gmap[o] for o in mc.macro_name.operator_ids}
            if len(gs)!=1: raise RuntimeError('refined standard clique crosses synthetic causal groups')
            g=next(iter(gs))
            if g in mg: raise RuntimeError(f'refinement created multiple MacroNames in group {g} for {oid}')
            mg[g]=mc.macro_name_id
        if set(mg)!={0,1,2}: raise RuntimeError(f'refined closure did not preserve three group candidates for {oid}: {mg}')
        new_groupmap[oid]=mg

    old_groupmap={oid:sources[oid][-1] for oid in sources}
    old_reverse={oid:{mid:g for g,mid in gm.items()} for oid,gm in old_groupmap.items()}
    csel2=[]
    for x in csel:
        g=old_reverse[x.observer_id][x.macro_name_id]
        csel2.append(replace(x,macro_name_id=new_groupmap[x.observer_id][g]))
    cclasses2=[]
    for x in cclasses:
        g=old_reverse[x.observer_id][x.macro_name_id]
        cclasses2.append(replace(x,macro_name_id=new_groupmap[x.observer_id][g]))
    pkg2=replace(pkg,confirmation_class_refs=tuple(sorted(x.macro_name_id for x in cclasses2)))
    newconfirm=R9AdequacyGatedConfirmationAnalyzer(split,hyp,pkg2,rule,csa,alc,rgc,new_universes,new_adequacy).certify(
        dclasses,csel2,cclasses2)

    oldr5=r9data[3].r8.r7.r6.r5_certificate
    newr5=newconfirm.r8.r7.r6.r5_certificate
    oldcounts=tuple(sorted((c.observer_id,len(c.eligible_macro_names)) for c in old_universes))
    newcounts=tuple(sorted((c.observer_id,len(c.eligible_macro_names)) for c in new_universes))
    reasons=[]
    countok=oldcounts==newcounts
    if not countok: reasons.append('refined candidate count changed on protected confirmation sources')
    statok=abs(float(newr5.observed_statistic)-float(oldr5.observed_statistic))<=1e-12
    if not statok: reasons.append('R5 primary statistic changed under admitted refinement')
    pok=float(newr5.exact_p_value)<=float(oldr5.exact_p_value)+1e-15
    if not pok: reasons.append('R5 exact p-value worsened')
    if newconfirm.status!='PASS': reasons.append('new R9-gated confirmation did not PASS')
    ds=R11DownstreamReplay(len(split.confirmation_observers()),oldcounts,newcounts,countok,
        float(oldr5.observed_statistic),float(newr5.observed_statistic),float(oldr5.exact_p_value),float(newr5.exact_p_value),
        newconfirm.status,newconfirm.r8.status,newconfirm.r8.r7.status,newconfirm.r8.r7.r6.status,newr5.status,statok,pok,
        'PASS' if not reasons else 'FAIL',tuple(reasons))
    admission=admit_refinement(joint,tuple(replays),ds)
    return r10,tuple(replays),ds,admission,cc,cr8,cr9,uc,ur8,ur9,tuple(new_universes),tuple(new_adequacy),newconfirm,new_groupmap
