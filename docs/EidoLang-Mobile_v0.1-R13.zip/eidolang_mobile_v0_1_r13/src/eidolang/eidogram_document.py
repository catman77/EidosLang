from __future__ import annotations

from copy import deepcopy
from hashlib import sha256
from typing import Any, Iterable
import json
import re

FORMAT_V1='eidogram-document-v1'
CANONICAL_JSON_V1='eidogram-canonical-json-v1'
PALETTE_ID_V1='PaletteV1'
SHAPE_LIBRARY_ID_V1='ShapeLibraryV1'
UNIT=1_000_000

_HEX64=re.compile(r'^[0-9a-f]{64}$')
_HEX32=re.compile(r'^[0-9a-f]{32}$')

# Color indices are transport/render tokens only. R13 assigns no semantics to hue.
PALETTE_V1=(
    {'index':0,'name':'black',      'srgb':'#000000'},
    {'index':1,'name':'white',      'srgb':'#ffffff'},
    {'index':2,'name':'red',        'srgb':'#e53935'},
    {'index':3,'name':'orange',     'srgb':'#fb8c00'},
    {'index':4,'name':'yellow',     'srgb':'#fdd835'},
    {'index':5,'name':'green',      'srgb':'#43a047'},
    {'index':6,'name':'cyan',       'srgb':'#00acc1'},
    {'index':7,'name':'blue',       'srgb':'#1e88e5'},
    {'index':8,'name':'indigo',     'srgb':'#3949ab'},
    {'index':9,'name':'violet',     'srgb':'#8e24aa'},
    {'index':10,'name':'magenta',   'srgb':'#d81b60'},
    {'index':11,'name':'brown',     'srgb':'#6d4c41'},
    {'index':12,'name':'gray',      'srgb':'#757575'},
    {'index':13,'name':'light_gray','srgb':'#bdbdbd'},
    {'index':14,'name':'teal',      'srgb':'#00897b'},
    {'index':15,'name':'pink',      'srgb':'#ec407a'},
)

# Geometry is normalized local integer geometry. Android renders these definitions,
# then applies TransformV1. No custom path data is admitted in v1.
SHAPE_LIBRARY_V1=(
    {'id':'POINT','geometry':'ELLIPSE','local_bbox_u':[-500_000,-500_000,500_000,500_000],
     'paint_modes':['FILL']},
    {'id':'LINE','geometry':'POLYLINE','points_u':[[-500_000,0],[500_000,0]],
     'paint_modes':['STROKE']},
    {'id':'TRIANGLE','geometry':'POLYGON','points_u':[[0,-500_000],[-500_000,500_000],[500_000,500_000]],
     'paint_modes':['FILL','STROKE']},
    {'id':'RECTANGLE','geometry':'POLYGON','points_u':[[-500_000,-500_000],[500_000,-500_000],[500_000,500_000],[-500_000,500_000]],
     'paint_modes':['FILL','STROKE']},
    {'id':'ELLIPSE','geometry':'ELLIPSE','local_bbox_u':[-500_000,-500_000,500_000,500_000],
     'paint_modes':['FILL','STROKE']},
)

PRIMITIVES=tuple(x['id'] for x in SHAPE_LIBRARY_V1)
_PAINT_BY_PRIMITIVE={x['id']:set(x['paint_modes']) for x in SHAPE_LIBRARY_V1}
OPS=('ADD','SET_TRANSFORM','SET_COLOR','SET_PAINT','MOVE_Z','REMOVE','GROUP','UNGROUP')


def _assert_json_domain(x:Any,path:str='$')->None:
    if x is None or isinstance(x,(bool,int,str)):
        return
    if isinstance(x,float):
        raise ValueError(f'float forbidden in canonical JSON at {path}')
    if isinstance(x,list) or isinstance(x,tuple):
        for i,v in enumerate(x): _assert_json_domain(v,f'{path}[{i}]')
        return
    if isinstance(x,dict):
        for k,v in x.items():
            if not isinstance(k,str): raise ValueError(f'non-string key at {path}')
            _assert_json_domain(v,f'{path}.{k}')
        return
    raise ValueError(f'unsupported canonical JSON type {type(x).__name__} at {path}')


def canonical_json_bytes(x:Any)->bytes:
    _assert_json_domain(x)
    # ensure_ascii=True deliberately makes bytes independent of source Unicode encoding quirks.
    return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode('utf-8')


def sha256_hex(x:Any)->str:
    return sha256(canonical_json_bytes(x)).hexdigest()

PALETTE_V1_HASH=sha256_hex({'id':PALETTE_ID_V1,'entries':list(PALETTE_V1)})
SHAPE_LIBRARY_V1_HASH=sha256_hex({'id':SHAPE_LIBRARY_ID_V1,'primitives':list(SHAPE_LIBRARY_V1)})


def _reject_constant(s:str):
    raise ValueError(f'non-integer JSON number forbidden: {s}')


def parse_canonical_json(data:bytes)->Any:
    try:
        text=data.decode('utf-8')
    except UnicodeDecodeError as e:
        raise ValueError('document is not UTF-8') from e
    def hook(pairs):
        d={}
        for k,v in pairs:
            if k in d: raise ValueError(f'duplicate JSON key: {k}')
            d[k]=v
        return d
    try:
        x=json.loads(text,object_pairs_hook=hook,parse_float=_reject_constant,
                     parse_constant=_reject_constant)
    except (json.JSONDecodeError,ValueError) as e:
        raise ValueError(f'invalid canonical JSON: {e}') from e
    if canonical_json_bytes(x)!=data:
        raise ValueError('JSON bytes are valid but not canonical eidogram-canonical-json-v1')
    return x


def _hex64(x,name):
    if not isinstance(x,str) or not _HEX64.fullmatch(x): raise ValueError(f'{name} must be 64 lowercase hex chars')


def _hex32(x,name):
    if not isinstance(x,str) or not _HEX32.fullmatch(x): raise ValueError(f'{name} must be 32 lowercase hex chars')


def make_lineage(root_master_hash:str,grammar_spec_hash:str,grammar_binding_hash:str,
                 android_document_slot_hash:str)->dict:
    for x,n in ((root_master_hash,'root_master_hash'),(grammar_spec_hash,'grammar_spec_hash'),
                (grammar_binding_hash,'grammar_binding_hash'),(android_document_slot_hash,'android_document_slot_hash')):
        _hex64(x,n)
    return {
        'root_master_hash':root_master_hash,
        'grammar_spec_hash':grammar_spec_hash,
        'grammar_binding_hash':grammar_binding_hash,
        'android_document_slot_hash':android_document_slot_hash,
    }


def lineage_from_production_bundle(bundle)->dict:
    slot=bundle.slot('ANDROID_DOCUMENT')
    return make_lineage(bundle.master_hash,bundle.grammar_binding.grammar_spec_hash,
                        bundle.grammar_binding.binding_hash,slot.slot_hash)


def transform(cx_u:int,cy_u:int,sx_u:int,sy_u:int,rotation_mdeg:int=0)->dict:
    t={'cx_u':cx_u,'cy_u':cy_u,'sx_u':sx_u,'sy_u':sy_u,'rotation_mdeg':rotation_mdeg}
    _validate_transform(t)
    return t


def _validate_transform(t):
    if set(t)!={'cx_u','cy_u','sx_u','sy_u','rotation_mdeg'}: raise ValueError('TransformV1 schema mismatch')
    if any(isinstance(t[k],bool) or not isinstance(t[k],int) for k in t): raise ValueError('TransformV1 uses integers only')
    if not (0<=t['cx_u']<=UNIT and 0<=t['cy_u']<=UNIT): raise ValueError('center outside normalized canvas')
    if not (1<=t['sx_u']<=4*UNIT and 1<=t['sy_u']<=4*UNIT): raise ValueError('scale outside v1 bounds')
    if not (-180_000<=t['rotation_mdeg']<180_000): raise ValueError('rotation must be canonical [-180000,180000)')


def node(node_id:str,primitive:str,t:dict,color:int,paint:str)->dict:
    n={'id':node_id,'primitive':primitive,'transform':deepcopy(t),'color':color,'paint':paint}
    _validate_node(n)
    return n


def _validate_node(n):
    if set(n)!={'id','primitive','transform','color','paint'}: raise ValueError('NodeV1 schema mismatch')
    _hex32(n['id'],'node id')
    if n['primitive'] not in PRIMITIVES: raise ValueError('unknown primitive/custom geometry forbidden')
    _validate_transform(n['transform'])
    if isinstance(n['color'],bool) or not isinstance(n['color'],int) or not 0<=n['color']<len(PALETTE_V1):
        raise ValueError('color must be PaletteV1 index')
    if n['paint'] not in _PAINT_BY_PRIMITIVE[n['primitive']]: raise ValueError('paint mode invalid for primitive')


def _validate_group(g):
    if set(g)!={'id','members'}: raise ValueError('GroupV1 schema mismatch')
    _hex32(g['id'],'group id')
    if not isinstance(g['members'],list) or len(g['members'])<2: raise ValueError('group needs >=2 members')
    for m in g['members']: _hex32(m,'group member id')
    if len(g['members'])!=len(set(g['members'])): raise ValueError('duplicate group member')


def _validate_action_shape(a):
    if not isinstance(a,dict): raise ValueError('action must be object')
    if 'seq' not in a or 'op' not in a: raise ValueError('action missing seq/op')
    if isinstance(a['seq'],bool) or not isinstance(a['seq'],int) or a['seq']<0: raise ValueError('invalid action seq')
    if a['op'] not in OPS: raise ValueError('unknown action op')
    op=a['op']
    req={
      'ADD':{'seq','op','node'},
      'SET_TRANSFORM':{'seq','op','node_id','transform'},
      'SET_COLOR':{'seq','op','node_id','color'},
      'SET_PAINT':{'seq','op','node_id','paint'},
      'MOVE_Z':{'seq','op','node_id','index'},
      'REMOVE':{'seq','op','node_id'},
      'GROUP':{'seq','op','group'},
      'UNGROUP':{'seq','op','group_id'},
    }[op]
    if set(a)!=req: raise ValueError(f'{op} action schema mismatch')
    if op=='ADD': _validate_node(a['node'])
    elif op=='SET_TRANSFORM': _hex32(a['node_id'],'node id'); _validate_transform(a['transform'])
    elif op=='SET_COLOR':
        _hex32(a['node_id'],'node id')
        if isinstance(a['color'],bool) or not isinstance(a['color'],int) or not 0<=a['color']<len(PALETTE_V1): raise ValueError('invalid PaletteV1 color')
    elif op=='SET_PAINT': _hex32(a['node_id'],'node id');
    elif op=='MOVE_Z':
        _hex32(a['node_id'],'node id')
        if isinstance(a['index'],bool) or not isinstance(a['index'],int) or a['index']<0: raise ValueError('invalid z index')
    elif op=='REMOVE': _hex32(a['node_id'],'node id')
    elif op=='GROUP': _validate_group(a['group'])
    elif op=='UNGROUP': _hex32(a['group_id'],'group id')


def replay_actions(actions:Iterable[dict])->dict:
    actions=list(actions)
    nodes={}; order=[]; groups={}; membership={}
    for expected,a in enumerate(actions):
        _validate_action_shape(a)
        if a['seq']!=expected: raise ValueError('action seq must be contiguous from 0')
        op=a['op']
        if op=='ADD':
            n=deepcopy(a['node']); nid=n['id']
            if nid in nodes: raise ValueError('ADD duplicate live node id')
            nodes[nid]=n; order.append(nid)
        elif op=='SET_TRANSFORM':
            nid=a['node_id'];
            if nid not in nodes: raise ValueError('SET_TRANSFORM unknown node')
            nodes[nid]['transform']=deepcopy(a['transform'])
        elif op=='SET_COLOR':
            nid=a['node_id'];
            if nid not in nodes: raise ValueError('SET_COLOR unknown node')
            nodes[nid]['color']=a['color']; _validate_node(nodes[nid])
        elif op=='SET_PAINT':
            nid=a['node_id'];
            if nid not in nodes: raise ValueError('SET_PAINT unknown node')
            nodes[nid]['paint']=a['paint']; _validate_node(nodes[nid])
        elif op=='MOVE_Z':
            nid=a['node_id']; idx=a['index']
            if nid not in nodes: raise ValueError('MOVE_Z unknown node')
            if idx>=len(order): raise ValueError('MOVE_Z index outside live z-stack')
            order.remove(nid); order.insert(idx,nid)
        elif op=='REMOVE':
            nid=a['node_id']
            if nid not in nodes: raise ValueError('REMOVE unknown node')
            if nid in membership: raise ValueError('remove group member only after UNGROUP')
            del nodes[nid]; order.remove(nid)
        elif op=='GROUP':
            g=deepcopy(a['group']); gid=g['id']
            if gid in groups: raise ValueError('duplicate group id')
            for nid in g['members']:
                if nid not in nodes: raise ValueError('GROUP unknown node')
                if nid in membership: raise ValueError('nested/overlapping groups forbidden in v1')
            groups[gid]=g
            for nid in g['members']: membership[nid]=gid
        elif op=='UNGROUP':
            gid=a['group_id']
            if gid not in groups: raise ValueError('UNGROUP unknown group')
            for nid in groups[gid]['members']: membership.pop(nid,None)
            del groups[gid]
    # Rendering order is node-list order. Groups are editor structure only in v1.
    return {'nodes':[deepcopy(nodes[nid]) for nid in order],
            'groups':[deepcopy(groups[k]) for k in sorted(groups)]}


def scene_hash(actions:Iterable[dict])->str:
    return sha256_hex(replay_actions(actions))


def make_document(lineage:dict,actions:Iterable[dict],background_color:int=1)->dict:
    actions=[deepcopy(x) for x in actions]
    if isinstance(background_color,bool) or not isinstance(background_color,int) or not 0<=background_color<len(PALETTE_V1):
        raise ValueError('background_color must be PaletteV1 index')
    _validate_lineage(lineage)
    snap=scene_hash(actions)
    doc={
        'format':FORMAT_V1,
        'canonical_json':CANONICAL_JSON_V1,
        'lineage':deepcopy(lineage),
        'canvas':{'width_u':UNIT,'height_u':UNIT,'background_color':background_color},
        'palette':{'id':PALETTE_ID_V1,'hash':PALETTE_V1_HASH},
        'shape_library':{'id':SHAPE_LIBRARY_ID_V1,'hash':SHAPE_LIBRARY_V1_HASH},
        'actions':actions,
        'snapshot_hash':snap,
    }
    validate_document(doc)
    return doc


def _validate_lineage(x):
    if set(x)!={'root_master_hash','grammar_spec_hash','grammar_binding_hash','android_document_slot_hash'}:
        raise ValueError('document lineage schema mismatch')
    for k,v in x.items(): _hex64(v,k)


def validate_document(doc:dict)->None:
    if not isinstance(doc,dict): raise ValueError('document must be object')
    req={'format','canonical_json','lineage','canvas','palette','shape_library','actions','snapshot_hash'}
    if set(doc)!=req: raise ValueError('EidogramDocumentV1 schema mismatch')
    if doc['format']!=FORMAT_V1: raise ValueError('unsupported eidogram document version')
    if doc['canonical_json']!=CANONICAL_JSON_V1: raise ValueError('unsupported canonical JSON version')
    _validate_lineage(doc['lineage'])
    c=doc['canvas']
    if c!={'width_u':UNIT,'height_u':UNIT,'background_color':c.get('background_color')}:
        raise ValueError('v1 canvas is normalized 1e6 x 1e6')
    if isinstance(c['background_color'],bool) or not isinstance(c['background_color'],int) or not 0<=c['background_color']<len(PALETTE_V1): raise ValueError('invalid background color')
    if doc['palette']!={'id':PALETTE_ID_V1,'hash':PALETTE_V1_HASH}: raise ValueError('PaletteV1 binding mismatch')
    if doc['shape_library']!={'id':SHAPE_LIBRARY_ID_V1,'hash':SHAPE_LIBRARY_V1_HASH}: raise ValueError('ShapeLibraryV1 binding mismatch')
    if not isinstance(doc['actions'],list): raise ValueError('actions must be array')
    _hex64(doc['snapshot_hash'],'snapshot_hash')
    actual=scene_hash(doc['actions'])
    if actual!=doc['snapshot_hash']: raise ValueError('snapshot_hash does not match action replay')


def document_bytes(doc:dict)->bytes:
    validate_document(doc)
    return canonical_json_bytes(doc)


def document_content_hash(doc:dict)->str:
    return sha256(document_bytes(doc)).hexdigest()


def parse_document(data:bytes)->dict:
    x=parse_canonical_json(data)
    validate_document(x)
    return x


def assert_lineage(doc:dict,lineage:dict)->None:
    validate_document(doc); _validate_lineage(lineage)
    if doc['lineage']!=lineage: raise ValueError('document production grammar lineage mismatch')


def android_document_evidence(bundle,doc:dict):
    lineage=lineage_from_production_bundle(bundle)
    assert_lineage(doc,lineage)
    return bundle.bind_evidence('ANDROID_DOCUMENT',document_content_hash(doc))

# Action constructors keep Android/Python object creation schemas identical.
def add(seq:int,n:dict)->dict: return {'seq':seq,'op':'ADD','node':deepcopy(n)}
def set_transform(seq:int,node_id:str,t:dict)->dict: return {'seq':seq,'op':'SET_TRANSFORM','node_id':node_id,'transform':deepcopy(t)}
def set_color(seq:int,node_id:str,color:int)->dict: return {'seq':seq,'op':'SET_COLOR','node_id':node_id,'color':color}
def set_paint(seq:int,node_id:str,paint:str)->dict: return {'seq':seq,'op':'SET_PAINT','node_id':node_id,'paint':paint}
def move_z(seq:int,node_id:str,index:int)->dict: return {'seq':seq,'op':'MOVE_Z','node_id':node_id,'index':index}
def remove(seq:int,node_id:str)->dict: return {'seq':seq,'op':'REMOVE','node_id':node_id}
def group(seq:int,group_id:str,members:Iterable[str])->dict: return {'seq':seq,'op':'GROUP','group':{'id':group_id,'members':list(members)}}
def ungroup(seq:int,group_id:str)->dict: return {'seq':seq,'op':'UNGROUP','group_id':group_id}
