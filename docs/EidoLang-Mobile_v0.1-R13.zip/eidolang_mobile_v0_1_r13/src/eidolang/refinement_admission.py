from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from collections import defaultdict
from typing import Iterable, Optional
import hashlib

from .acquisition import AcquisitionLedger, DataFreezeCertificate, sha256_object
from .schema import EidoSession, EidoOperator
from .segmenter import StrokeSegmenter, SegmenterConfig
from .geometry import shape_signature
from .operators import OperatorMiner, MinerConfig, mean_dict, stderr_dict
from .state import state_delta
from .grammar_adequacy import (
    RawProgramCausalDisposition, RawProgramPairDisposition, GrammarAdequacyCertificate,
    raw_program_hash, raw_program_id, _contains_pattern,
)
from .grammar_refinement import (
    RefinedGrammarSpec, ShapeRefinementProbe, CoverageAtom,
    GrammarRefinementSynthesisCertificate, CertifiedRefinementCase,
)
from .candidate_universe import (
    R3Disposition, R4PairDisposition, CandidateUniverseCertificate, MacroCandidate,
)
from .substitution import (
    CertifiedOperatorRef, SubstitutionCertificate, EquivalenceStatus, CausalMacroNameBuilder,
)


@dataclass(frozen=True)
class CompiledRefinedProgram:
    program_id: str
    program_hash: str
    source_session_ids: tuple[str,...]
    support_count: int
    base_tokens: tuple[str,...]
    base_address: tuple[str,...]
    added_atoms: tuple[str,...]
    refined_address: tuple[str,...]


@dataclass(frozen=True)
class RefinedGrammarCompileCertificate:
    certificate_id: str
    spec_hash: str
    observer_id: str
    source_data_freeze_hash: str
    source_ledger_root: str
    source_session_root: str
    raw_programs: tuple[CompiledRefinedProgram,...]
    causal_operators: tuple[EidoOperator,...]
    representation_partition_count: int
    causal_operator_count: int
    status: str
    reasons: tuple[str,...]
    compiler_version: str='necessity-refined-grammar-compiler-v1'

    @property
    def certificate_hash(self): return sha256_object(self)


@dataclass(frozen=True)
class RefinedCandidateUniverseConfig:
    observer_id: str
    grammar_compile_hash: str
    data_freeze_hash: str
    domain_id: str
    probe_schedule_id: str
    causal_protocol_version: str
    substitution_policy_hash: str
    substitution_protocol_version: str
    macro_size: int
    max_operator_candidates: int=10_000
    max_pair_dispositions: int=200_000
    max_clique_combinations: int=1_000_000
    enumeration_version: str='refined-candidate-universe-v1'

    @property
    def config_hash(self): return sha256_object(self)


@dataclass(frozen=True)
class RefinedGrammarAdequacyConfig:
    observer_id: str
    grammar_compile_hash: str
    source_r8_certificate_hash: str
    source_data_freeze_hash: str
    domain_id: str
    probe_schedule_id: str
    raw_causal_protocol_version: str
    raw_pair_policy_hash: str
    raw_pair_protocol_version: str
    max_indistinguishable_pairs: int=200_000
    adequacy_version: str='refined-grammar-adequacy-v1'

    @property
    def config_hash(self): return sha256_object(self)


@dataclass(frozen=True)
class R11CaseReplay:
    case_id: str
    source_r9_status: str
    compile_hash: str
    old_program_count: int
    refined_partition_count: int
    refined_operator_count: int
    refined_r8_status: str
    refined_r9_status: str
    collision_obligations_repaired: int
    collision_obligation_count: int
    protected_pairs_preserved: int
    protected_pair_count: int
    unrepresented_covered: int
    unrepresented_count: int
    status: str
    reasons: tuple[str,...]


@dataclass(frozen=True)
class R11DownstreamReplay:
    observer_count: int
    old_candidate_counts: tuple[tuple[str,int],...]
    new_candidate_counts: tuple[tuple[str,int],...]
    candidate_counts_preserved: bool
    old_r5_statistic: float
    new_r5_statistic: float
    old_r5_p: float
    new_r5_p: float
    r9_confirmation_status: str
    r8_status: str
    r7_status: str
    r6_status: str
    r5_status: str
    statistic_preserved: bool
    p_value_not_worse: bool
    status: str
    reasons: tuple[str,...]


@dataclass(frozen=True)
class R11AdmissionCertificate:
    certificate_id: str
    source_r10_certificate_hash: str
    refined_spec_hash: str
    case_replays: tuple[R11CaseReplay,...]
    downstream: R11DownstreamReplay
    status: str  # ADMITTED | REJECTED | UNRESOLVED | INVALID
    admitted: bool
    reasons: tuple[str,...]
    protocol_version: str='refinement-admission-v1'

    @property
    def certificate_hash(self): return sha256_object(self)


def _source_root(sessions):
    return sha256_object(tuple(sorted((s.session_id,sha256_object(s)) for s in sessions)))


def _patterns(tokens,max_ngram):
    for n in range(1,max_ngram+1):
        for i in range(len(tokens)-n+1):
            yield tuple(tokens[i:i+n])


class RefinedGrammarCompiler:
    """
    Compile an R10 spec into two linked objects:
      * representation address: raw-support based and may exist without state delta;
      * causal candidate operator: exact refined cell with sufficient effect-bearing support.

    R11 v1 admits the actually synthesized R10 regime max_ngram=1. General multi-token
    refinement is intentionally not guessed here.
    """
    def __init__(self,spec:RefinedGrammarSpec,base_miner_protocol='operator-miner-v1'):
        self.spec=spec; self.base_miner_protocol=base_miner_protocol

    def _segmenter(self):
        s=self.spec
        return StrokeSegmenter(SegmenterConfig(
            version=s.base_segmenter_version,resample_n=s.base_resample_n,
            quantization_bins=s.base_quantization_bins,relation_bins=s.base_relation_bins,
        ))

    def compile(self,observer_id,ledger,freeze,sessions_by_id):
        sp=self.spec; reasons=[]
        if sp.max_ngram!=1:
            reasons.append('R11 v1 only admits the currently synthesized max_ngram=1 grammar')
        if freeze.data_root!=ledger.data_root:
            reasons.append('data freeze does not bind supplied ledger')
        ok,why=ledger.verify(sessions_by_id)
        if not ok: reasons.append('ledger verification failed: '+why)
        ledger_ids=tuple(e.session_id for e in ledger.entries)
        if set(ledger_ids)!=set(sessions_by_id): reasons.append('sessions_by_id must equal complete ledger')
        if reasons:
            return RefinedGrammarCompileCertificate('r11compile:invalid',sp.spec_hash,observer_id,freeze.freeze_hash,
                ledger.data_root,'',(),(),0,0,'INVALID',tuple(reasons))

        excluded=set(freeze.excluded_session_ids)
        source=[sessions_by_id[x] for x in ledger_ids if x not in excluded]
        sroot=_source_root(source)
        seg=self._segmenter()
        bminer=OperatorMiner(segmenter=seg,config=MinerConfig(sp.raw_support_min,sp.max_ngram,self.base_miner_protocol))
        base_ops=sorted(bminer.mine(source),key=lambda x:x.operator_id)

        groups=defaultdict(list)
        for s in source: groups[raw_program_hash(s)].append(s)
        raw=[]
        for h,rows in sorted(groups.items()):
            if len(rows)<sp.raw_support_min: continue
            token_sets=[tuple(seg.tokens(s)[0]) for s in rows]
            if len(set(token_sets))!=1: raise ValueError('identical raw program gave different base tokens')
            toks=token_sets[0]
            addr=tuple(sorted(o.operator_id for o in base_ops if _contains_pattern(toks,tuple(o.pattern))))
            raw.append([raw_program_id(h),h,tuple(sorted(s.session_id for s in rows)),len(rows),toks,addr,[]])

        # Probe atoms are admitted by raw support, not effect-bearing support.
        target=set(sp.probe_target_addresses)
        for probe in sp.probes:
            ptoks={}
            support=defaultdict(int)
            for r in raw:
                pid,h,sids,n,toks,addr,extra=r
                ss=sessions_by_id[sids[0]]; segs=seg.segment(ss); rels=seg.relations(segs); out=[]
                for i,sg in enumerate(segs):
                    sig,_=shape_signature(list(sg.points),probe.resample_n,probe.quantization_bins)
                    out.append(sig if i==0 else rels[i-1].signature+'|'+sig)
                ts=tuple(out); ptoks[pid]=ts
                for pat in set(_patterns(ts,sp.max_ngram)): support[pat]+=n
            admitted={pat for pat,n in support.items() if n>=sp.raw_support_min}
            for r in raw:
                pid,h,sids,n,toks,addr,extra=r
                if addr not in target: continue
                for pat in sorted(set(_patterns(ptoks[pid],sp.max_ngram)) & admitted):
                    extra.append('probe:'+probe.probe_id+':'+sha256_object(pat)[:16])

        # Coverage promotion is symmetric over every raw-supported program containing pattern.
        for atom in sp.coverage_atoms:
            support=sum(r[3] for r in raw if _contains_pattern(r[4],atom.pattern))
            if support<sp.raw_support_min: continue
            for r in raw:
                if _contains_pattern(r[4],atom.pattern): r[6].append(atom.atom_id)

        programs=[]
        for pid,h,sids,n,toks,addr,extra in raw:
            refined=tuple(sorted(['base:'+x for x in addr]+extra))
            programs.append(CompiledRefinedProgram(pid,h,sids,n,toks,addr,tuple(sorted(extra)),refined))
        programs=tuple(sorted(programs,key=lambda x:x.program_id))

        # Causal candidate mining uses the complete refined cell as one canonical token.
        # This refines a base cell instead of creating redundant base+probe operators.
        effect_sessions=[]
        pid_by_sid={sid:p for p in programs for sid in p.source_session_ids}
        cell=defaultdict(list)
        for s in source:
            d=state_delta(s)
            p=pid_by_sid.get(s.session_id)
            if d and p is not None and p.refined_address:
                cell[p.refined_address].append((s,d,p.program_id))
                effect_sessions.append((s,d))
        baseline=mean_dict([d for s,d in effect_sessions])
        operators=[]
        for addr,rows in sorted(cell.items()):
            if len(rows)<sp.raw_support_min: continue
            ds=[d for s,d,pid in rows]; mean=mean_dict(ds); se=stderr_dict(ds,mean)
            direction={k:mean.get(k,0)-baseline.get(k,0) for k in set(mean)|set(baseline)}
            counter=[]
            for s,d,pid in rows:
                centered={k:d.get(k,0)-baseline.get(k,0) for k in direction}
                if sum(centered.get(k,0)*direction.get(k,0) for k in direction)<=0: counter.append(s.session_id)
            digest=hashlib.sha1(('\n'.join(addr)).encode()).hexdigest()[:12]
            # pattern is the exact refined address token tuple for object hashing/provenance.
            operators.append(EidoOperator(
                'rop:'+digest,tuple(addr),len(rows),mean,se,baseline,
                [s.session_id for s,d,pid in rows],counter,[],
                'necessity-refined-operator-miner-v1',
                {'refined_address':addr,'raw_program_ids':tuple(sorted({pid for s,d,pid in rows}))}
            ))
        operators=tuple(sorted(operators,key=lambda x:x.operator_id))
        cid='r11compile:'+sha256_object({'spec':sp.spec_hash,'source':sroot,'ops':[o.operator_id for o in operators]})[:16]
        return RefinedGrammarCompileCertificate(cid,sp.spec_hash,observer_id,freeze.freeze_hash,ledger.data_root,sroot,
            programs,operators,len(set(p.refined_address for p in programs if p.refined_address)),len(operators),'PASS',())


class ExhaustiveRefinedCandidateUniverseEnumerator:
    def __init__(self,config:RefinedCandidateUniverseConfig): self.config=config

    def certify(self,compiled:RefinedGrammarCompileCertificate,freeze:DataFreezeCertificate,
                r3_dispositions:Iterable[R3Disposition],r4_dispositions:Iterable[R4PairDisposition]):
        c=self.config; reasons=[]
        if compiled.certificate_hash!=c.grammar_compile_hash: reasons.append('config does not bind grammar compile')
        if compiled.status!='PASS': reasons.append('refined grammar compile not PASS')
        if freeze.freeze_hash!=c.data_freeze_hash or compiled.source_data_freeze_hash!=freeze.freeze_hash:
            reasons.append('data freeze binding mismatch')
        ops={o.operator_id:o for o in compiled.causal_operators}
        if len(ops)>c.max_operator_candidates:
            return self._fail('UNRESOLVED',[f'operator count {len(ops)} exceeds cap'],compiled,freeze)
        r3=list(r3_dispositions); r3m={x.operator_id:x for x in r3}
        if len(r3m)!=len(r3): reasons.append('duplicate R3 disposition')
        if set(r3m)!=set(ops): reasons.append('R3 registry must equal refined operator universe')
        for oid in set(r3m)&set(ops):
            if r3m[oid].operator_object_hash!=sha256_object(ops[oid]): reasons.append(f'R3 operator hash mismatch: {oid}')
            if r3m[oid].causal_protocol_version!=c.causal_protocol_version: reasons.append(f'R3 protocol mismatch: {oid}')
        if reasons: return self._fail('INVALID',reasons,compiled,freeze)
        epass={oid:d for oid,d in r3m.items() if d.status=='PASS' and d.domain_id==c.domain_id and d.probe_schedule_id==c.probe_schedule_id}
        expected={f'{a}::{b}' for a,b in combinations(sorted(epass),2)}
        if len(expected)>c.max_pair_dispositions:
            return self._fail('UNRESOLVED',[f'pair count {len(expected)} exceeds cap'],compiled,freeze,r3pass=len(epass),expected=len(expected))
        r4=list(r4_dispositions); r4m={x.pair_id:x for x in r4}
        if len(r4m)!=len(r4): reasons.append('duplicate R4 disposition')
        if set(r4m)!=expected: reasons.append('R4 registry must equal all compatible refined-operator pairs')
        for pid in expected & set(r4m):
            d=r4m[pid]; a,b=pid.split('::',1)
            if d.left_causal_certificate_id!=epass[a].causal_certificate_id or d.right_causal_certificate_id!=epass[b].causal_certificate_id:
                reasons.append(f'R4 causal refs mismatch: {pid}')
            if d.policy_hash!=c.substitution_policy_hash or d.protocol_version!=c.substitution_protocol_version:
                reasons.append(f'R4 policy/protocol mismatch: {pid}')
            if d.domain_id!=c.domain_id or d.probe_schedule_id!=c.probe_schedule_id: reasons.append(f'R4 domain mismatch: {pid}')
        if reasons: return self._fail('INVALID',reasons,compiled,freeze,r3pass=len(epass),expected=len(expected),registered=len(r4))
        from math import comb
        combos=comb(len(epass),c.macro_size) if len(epass)>=c.macro_size else 0
        if combos>c.max_clique_combinations:
            return self._fail('UNRESOLVED',[f'clique count {combos} exceeds cap'],compiled,freeze,r3pass=len(epass),expected=len(expected),registered=len(r4))
        builder=CausalMacroNameBuilder(); macros=[]
        for subset in combinations(sorted(epass),c.macro_size):
            pids=[f'{a}::{b}' for a,b in combinations(subset,2)]; edges=[r4m[x] for x in pids]
            if not all(e.status=='PASS' for e in edges): continue
            refs=[CertifiedOperatorRef(o,epass[o].causal_certificate_id,True,c.domain_id,c.probe_schedule_id,c.causal_protocol_version) for o in subset]
            certs=[SubstitutionCertificate(e.substitution_certificate_id,e.pair_id,e.left_operator_id,e.right_operator_id,
                e.left_causal_certificate_id,e.right_causal_certificate_id,e.domain_id,e.probe_schedule_id,e.policy_hash,(),True,
                EquivalenceStatus.PASS,e.protocol_version,('R11 registry stub',)) for e in edges]
            macro=builder.build(refs,certs)
            macros.append(MacroCandidate(macro,tuple(sha256_object(ops[o]) for o in macro.operator_ids)))
        macros=tuple(sorted(macros,key=lambda x:x.macro_name_id)); root=sha256_object(tuple((m.macro_name_id,m.macro_name.operator_ids) for m in macros))
        cid='r8refined:'+sha256_object({'config':c.config_hash,'compile':compiled.certificate_hash,'root':root})[:16]
        return CandidateUniverseCertificate(cid,c.config_hash,c.observer_id,freeze.freeze_hash,compiled.source_ledger_root,
            tuple(sid for p in compiled.raw_programs for sid in p.source_session_ids),compiled.source_session_root,len(ops),tuple(sorted(ops)),len(epass),
            len(expected),len(r4),combos,macros,root,'PASS',True,(),
            'complete relative to admitted refined grammar, fresh R3/R4 registry and fixed MacroName size')

    def _fail(self,status,reasons,compiled,freeze,r3pass=0,expected=0,registered=0):
        return CandidateUniverseCertificate('r8refined:'+sha256_object((status,tuple(reasons)))[:16],self.config.config_hash,self.config.observer_id,
            freeze.freeze_hash,compiled.source_ledger_root,(),compiled.source_session_root,len(compiled.causal_operators),tuple(o.operator_id for o in compiled.causal_operators),
            r3pass,expected,registered,0,(),sha256_object(()),status,False,tuple(reasons),'closure not established')


class RefinedGrammarAdequacyAnalyzer:
    def __init__(self,config:RefinedGrammarAdequacyConfig): self.config=config

    def certify(self,compiled:RefinedGrammarCompileCertificate,r8:CandidateUniverseCertificate,
                causal_dispositions:Iterable[RawProgramCausalDisposition],pair_dispositions:Iterable[RawProgramPairDisposition]):
        c=self.config; reasons=[]
        if compiled.certificate_hash!=c.grammar_compile_hash: reasons.append('config does not bind grammar compile')
        if r8.certificate_hash!=c.source_r8_certificate_hash: reasons.append('config does not bind refined R8')
        if compiled.source_data_freeze_hash!=c.source_data_freeze_hash or r8.source_data_freeze_hash!=c.source_data_freeze_hash:
            reasons.append('freeze binding mismatch')
        if r8.status!='PASS' or not r8.complete: reasons.append('refined R8 not PASS/complete')
        pmap={p.program_id:p for p in compiled.raw_programs}
        causal=list(causal_dispositions); cmap={d.program_id:d for d in causal}
        if len(cmap)!=len(causal): reasons.append('duplicate raw causal dispositions')
        if set(cmap)!=set(pmap): reasons.append('raw causal registry must equal refined raw-program universe')
        for pid in set(cmap)&set(pmap):
            d=cmap[pid]; p=pmap[pid]
            if d.program_hash!=p.program_hash: reasons.append(f'raw causal hash mismatch: {pid}')
            if d.causal_protocol_version!=c.raw_causal_protocol_version: reasons.append(f'raw causal protocol mismatch: {pid}')
            if d.domain_id!=c.domain_id or d.probe_schedule_id!=c.probe_schedule_id: reasons.append(f'raw causal domain mismatch: {pid}')
        if reasons: return self._result('INVALID',reasons,compiled,r8,(),(),0,0)
        cpass={pid:d for pid,d in cmap.items() if d.status=='PASS'}
        unrep=[pid for pid in cpass if not pmap[pid].refined_address]
        groups=defaultdict(list)
        for pid in cpass:
            if pmap[pid].refined_address: groups[pmap[pid].refined_address].append(pid)
        expected=[]
        for addr,pids in groups.items():
            for a,b in combinations(sorted(pids),2): expected.append((a,b,addr))
        if len(expected)>c.max_indistinguishable_pairs:
            return self._result('UNRESOLVED',[f'indistinguishable pair count {len(expected)} exceeds cap'],compiled,r8,(),(),len(cpass),len(cpass)-len(unrep))
        pairs=list(pair_dispositions); dmap={d.pair_id:d for d in pairs}; expids={f'{a}::{b}' for a,b,_ in expected}
        if len(dmap)!=len(pairs): reasons.append('duplicate raw pair dispositions')
        if set(dmap)!=expids: reasons.append('raw pair registry must equal refined-indistinguishable pair universe')
        for pid in expids & set(dmap):
            d=dmap[pid]; a,b=pid.split('::',1)
            if d.left_causal_certificate_id!=cpass[a].causal_certificate_id or d.right_causal_certificate_id!=cpass[b].causal_certificate_id:
                reasons.append(f'raw pair causal refs mismatch: {pid}')
            if d.policy_hash!=c.raw_pair_policy_hash or d.protocol_version!=c.raw_pair_protocol_version: reasons.append(f'raw pair policy mismatch: {pid}')
            if d.domain_id!=c.domain_id or d.probe_schedule_id!=c.probe_schedule_id: reasons.append(f'raw pair domain mismatch: {pid}')
        if reasons: return self._result('INVALID',reasons,compiled,r8,expected,pairs,len(cpass),len(cpass)-len(unrep))
        collisions=[]; unresolved=[]; invalid=[]
        from .grammar_adequacy import GrammarResidualWitness
        for a,b,addr in expected:
            d=dmap[f'{a}::{b}']
            if d.status=='FAIL': collisions.append(GrammarResidualWitness('COLLISION',a,b,addr,pmap[a].program_hash,pmap[b].program_hash,
                dict(cpass[a].effect_vector),dict(cpass[b].effect_vector),d.substitution_certificate_id,f'refined grammar still merges {a} and {b}'))
            elif d.status=='UNRESOLVED': unresolved.append(d.pair_id)
            elif d.status=='INVALID': invalid.append(d.pair_id)
        if invalid: return self._result('INVALID',['invalid raw pair dispositions: '+','.join(invalid)],compiled,r8,expected,pairs,len(cpass),len(cpass)-len(unrep),collisions,unrep)
        if unresolved: return self._result('UNRESOLVED',['unresolved raw pair dispositions: '+','.join(unresolved)],compiled,r8,expected,pairs,len(cpass),len(cpass)-len(unrep),collisions,unrep)
        if collisions or unrep: return self._result('INADEQUATE',[f'{len(collisions)} collision(s), {len(unrep)} unrepresented'],compiled,r8,expected,pairs,len(cpass),len(cpass)-len(unrep),collisions,unrep)
        return self._result('PASS',[],compiled,r8,expected,pairs,len(cpass),len(cpass),(),())

    def _result(self,status,reasons,compiled,r8,expected,pairs,cpass,represented,collisions=(),unrep=()):
        from .grammar_adequacy import GrammarResidualWitness
        pmap={p.program_id:p for p in compiled.raw_programs}; cmap=[]
        un_w=[]
        for pid in unrep:
            p=pmap[pid]
            un_w.append(GrammarResidualWitness('UNREPRESENTED',pid,None,p.refined_address,p.program_hash,None,{},None,None,
                f'refined grammar must represent {pid}'))
        obligations=tuple(sorted((x.left_program_id,x.right_program_id) for x in collisions if x.right_program_id))
        cid='r9refined:'+sha256_object({'config':self.config.config_hash,'r8':r8.certificate_hash,'status':status,'obligations':obligations,'unrep':tuple(unrep)})[:16]
        return GrammarAdequacyCertificate(cid,self.config.config_hash,self.config.observer_id,r8.certificate_hash,self.config.source_data_freeze_hash,
            len(compiled.raw_programs),cpass,represented,len(unrep),len(expected),len(pairs),tuple(collisions),tuple(un_w),obligations,
            status,status=='PASS',tuple(reasons),'adequate relative to admitted refined grammar and complete fresh raw causal/substitution registry')


def filter_refined_raw_pairs(compiled,old_pairs:Iterable[RawProgramPairDisposition]):
    """Keep exactly the pair dispositions that remain indistinguishable after refinement."""
    pmap={p.program_id:p for p in compiled.raw_programs}; groups=defaultdict(list)
    for pid,p in pmap.items():
        if p.refined_address: groups[p.refined_address].append(pid)
    need={f'{a}::{b}' for ids in groups.values() for a,b in combinations(sorted(ids),2)}
    dmap={d.pair_id:d for d in old_pairs}
    missing=need-set(dmap)
    if missing: raise ValueError('fresh adequacy requires raw pair evidence not present upstream: '+','.join(sorted(missing)))
    return tuple(dmap[x] for x in sorted(need))


def verify_r10_source(cert:GrammarRefinementSynthesisCertificate,spec:RefinedGrammarSpec,cases:Iterable[CertifiedRefinementCase]):
    reasons=[]; cases=tuple(cases)
    if cert.status!='REFINED': reasons.append('R10 source is not REFINED')
    if cert.selected_spec is None or cert.selected_spec.spec_hash!=spec.spec_hash: reasons.append('selected spec mismatch')
    if cert.strictly_better_valid_candidate_count!=0: reasons.append('R10 selected refinement is not minimal in frozen family')
    expected=dict(cert.case_hashes); actual={c.case_id:c.case_hash for c in cases}
    if expected!=actual: reasons.append('R10 source case set/hash mismatch')
    return tuple(reasons)


def make_case_replay(case,compiled,r8,r9):
    pmap={p.program_id:p for p in compiled.raw_programs}; reasons=[]
    repaired=sum(pmap[a].refined_address!=pmap[b].refined_address for a,b in case.collision_obligations)
    protected=sum(pmap[a].refined_address==pmap[b].refined_address for a,b in case.protected_equivalence_pairs)
    covered=sum(bool(pmap[x].refined_address) for x in case.unrepresented_obligations)
    if repaired!=len(case.collision_obligations): reasons.append('not all R9 collision obligations repaired')
    if protected!=len(case.protected_equivalence_pairs): reasons.append('protected causal equivalence was split')
    if covered!=len(case.unrepresented_obligations): reasons.append('unrepresented obligation remains')
    if r8.status!='PASS' or not r8.complete: reasons.append('refined R8 not PASS/complete')
    if r9.status!='PASS' or not r9.adequate: reasons.append('refined R9 not PASS')
    return R11CaseReplay(case.case_id,case.source_r9_status,compiled.certificate_hash,len(case.programs),compiled.representation_partition_count,
        compiled.causal_operator_count,r8.status,r9.status,repaired,len(case.collision_obligations),protected,len(case.protected_equivalence_pairs),
        covered,len(case.unrepresented_obligations),'PASS' if not reasons else 'FAIL',tuple(reasons))


def admit_refinement(source_r10,case_replays,downstream):
    reasons=[]
    if any(x.status!='PASS' for x in case_replays): reasons.append('one or more refinement replay cases failed')
    if downstream.status!='PASS': reasons.append('full downstream non-regression replay failed')
    status='ADMITTED' if not reasons else 'REJECTED'
    cid='r11:'+sha256_object({'r10':source_r10.certificate_hash,'cases':[x for x in case_replays],'downstream':downstream})[:16]
    return R11AdmissionCertificate(cid,source_r10.certificate_hash,source_r10.selected_spec.spec_hash,tuple(case_replays),downstream,status,status=='ADMITTED',tuple(reasons))
