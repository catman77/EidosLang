from __future__ import annotations

from dataclasses import replace, asdict

from .r412_dryrun import dryrun_master
from .r11_synthetic import run_r11_dryrun
from .production_promotion import (
    binding_from_admission, promote_master_manifest, ProductionProtocolCompiler,
    ProductionRuntime, require_production_bundle,
)
from .protocol_compiler import ProtocolCompiler, ProtocolCompileError


def run_r12_dryrun():
    r11=run_r11_dryrun()
    r10,replays,downstream,admission,*_=r11
    joint=r10[7]
    spec=joint.selected_spec
    if spec is None:
        raise RuntimeError('R10 joint synthesis has no selected spec')

    legacy_master=dryrun_master()
    legacy_bundle=ProtocolCompiler().compile(legacy_master)
    binding=binding_from_admission(admission,spec)
    production_master=promote_master_manifest(legacy_master,binding)
    production=ProductionProtocolCompiler().compile(production_master,binding,admission)
    runtime=ProductionRuntime(production)

    # Bind representative stage evidence to the same production grammar lineage.
    r11_env=production.bind_evidence('R11',admission.certificate_hash)
    r5_env=production.bind_evidence('R5','synthetic:future-r5-evidence')
    android_env=production.bind_evidence('ANDROID_DOCUMENT','synthetic:android-document-schema-v0')
    torrent_env=production.bind_evidence('TORRENT_ARCHIVE','synthetic:torrent-archive-schema-v0')
    for e in (r11_env,r5_env,android_env,torrent_env):
        runtime.assert_evidence(e)

    legacy_rejected=False
    try:
        require_production_bundle(legacy_bundle)
    except ProtocolCompileError:
        legacy_rejected=True

    wrong_hash_rejected=False
    try:
        bad=replace(production_master,production_grammar_spec_hash=binding.previous_grammar_hash)
        ProductionProtocolCompiler().compile(bad,binding,admission)
    except (ProtocolCompileError,ValueError):
        wrong_hash_rejected=True

    root_changed=legacy_master.master_hash!=production_master.master_hash
    acquisition_rebound=legacy_bundle.alignment_acquisition.protocol_hash!=production.base_bundle.alignment_acquisition.protocol_hash
    reliability_rebound=legacy_bundle.reliability.protocol_hash!=production.base_bundle.reliability.protocol_hash
    runtime_lock_changed=legacy_bundle.runtime_lock_hash!=production.base_bundle.runtime_lock_hash

    return {
        'legacy_master_hash':legacy_master.master_hash,
        'production_master_hash':production_master.master_hash,
        'root_changed':root_changed,
        'grammar_spec_hash':binding.grammar_spec_hash,
        'grammar_binding_hash':binding.binding_hash,
        'previous_grammar_hash':binding.previous_grammar_hash,
        'r11_admission_hash':admission.certificate_hash,
        'production_bundle_hash':production.production_bundle_hash,
        'production_ready':production.production_ready,
        'lineage_slot_count':len(production.lineage_slots),
        'lineage_stages':tuple(x.stage for x in production.lineage_slots),
        'alignment_protocol_rebound':acquisition_rebound,
        'reliability_protocol_rebound':reliability_rebound,
        'runtime_lock_changed':runtime_lock_changed,
        'legacy_bundle_rejected_by_production_runtime':legacy_rejected,
        'wrong_grammar_hash_rejected':wrong_hash_rejected,
        'production_master':asdict(production_master),
        'grammar_binding':asdict(binding),
        'lineage_slots':[asdict(x) for x in production.lineage_slots],
        'sample_evidence_envelopes':[asdict(x) for x in (r11_env,r5_env,android_env,torrent_env)],
    }, production, admission, binding
