import copy, json, unittest
from dataclasses import replace
from pathlib import Path

from eidolang.eidogram_document import *

ROOT='4667dcd42dec6e14aed1311525488370d141758ca8795aeb2ddfe8aecde57fd3'
GRAM='d5afb09e6ecdcff8a4b2c9758af83f215059d1b5bc4ad32da3fb8dd191b69b19'
BIND='130eed81541292dfc8ccfd48ba01a28c374cd8fa96285c51fb3ea978d530944a'
SLOT='134bf5f9957b0f5e40a004983d2d441b9c324654149709a33dc825e90b3bfd52'
L=make_lineage(ROOT,GRAM,BIND,SLOT)
N1='00000000000000000000000000000001'
N2='00000000000000000000000000000002'
N3='00000000000000000000000000000003'
G1='10000000000000000000000000000001'

class R13Tests(unittest.TestCase):
    def test_palette_and_shape_hashes_are_stable(self):
        self.assertEqual(len(PALETTE_V1),16)
        self.assertEqual(set(PRIMITIVES),{'POINT','LINE','TRIANGLE','RECTANGLE','ELLIPSE'})
        self.assertEqual(len(PALETTE_V1_HASH),64)
        self.assertEqual(len(SHAPE_LIBRARY_V1_HASH),64)

    def test_single_triangle_roundtrip_is_byte_exact(self):
        a=[add(0,node(N1,'TRIANGLE',transform(500000,500000,300000,300000),2,'FILL'))]
        d=make_document(L,a)
        b=document_bytes(d)
        self.assertEqual(document_bytes(parse_document(b)),b)
        self.assertEqual(len(document_content_hash(d)),64)

    def test_float_is_forbidden_even_if_json_can_encode_it(self):
        with self.assertRaises(ValueError): canonical_json_bytes({'x':0.5})

    def test_noncanonical_json_bytes_are_rejected(self):
        d=make_document(L,[])
        pretty=json.dumps(d,indent=2,sort_keys=True).encode()
        with self.assertRaises(ValueError): parse_document(pretty)

    def test_custom_geometry_and_arbitrary_color_are_rejected(self):
        with self.assertRaises(ValueError): node(N1,'BEZIER',transform(1,1,1,1),2,'STROKE')
        with self.assertRaises(ValueError): node(N1,'TRIANGLE',transform(1,1,1,1),16,'FILL')

    def test_action_replay_z_order_group_and_removal(self):
        a=[
          add(0,node(N1,'TRIANGLE',transform(300000,300000,200000,200000),2,'FILL')),
          add(1,node(N2,'ELLIPSE',transform(700000,300000,180000,180000),7,'STROKE')),
          group(2,G1,[N1,N2]),
          ungroup(3,G1),
          move_z(4,N2,0),
          remove(5,N1),
        ]
        s=replay_actions(a)
        self.assertEqual([x['id'] for x in s['nodes']],[N2])
        self.assertEqual(s['groups'],[])

    def test_same_final_scene_different_history_has_different_content_hash(self):
        a1=[add(0,node(N1,'TRIANGLE',transform(500000,500000,200000,200000),2,'FILL')),
            set_color(1,N1,7),set_color(2,N1,2)]
        a2=[add(0,node(N1,'TRIANGLE',transform(500000,500000,200000,200000),2,'FILL'))]
        d1=make_document(L,a1); d2=make_document(L,a2)
        self.assertEqual(d1['snapshot_hash'],d2['snapshot_hash'])
        self.assertNotEqual(document_content_hash(d1),document_content_hash(d2))

    def test_snapshot_tamper_is_rejected(self):
        d=make_document(L,[]); d['snapshot_hash']='0'*64
        with self.assertRaises(ValueError): validate_document(d)

    def test_lineage_tamper_is_rejected_by_expected_lineage(self):
        d=make_document(L,[])
        bad=copy.deepcopy(d); bad['lineage']['grammar_spec_hash']='1'*64
        validate_document(bad)
        with self.assertRaises(ValueError): assert_lineage(bad,L)

    def test_invalid_paint_for_line_is_rejected(self):
        with self.assertRaises(ValueError): node(N1,'LINE',transform(500000,500000,100000,100000),0,'FILL')

    def test_contiguous_action_sequence_required(self):
        a=[add(1,node(N1,'POINT',transform(500000,500000,20000,20000),0,'FILL'))]
        with self.assertRaises(ValueError): make_document(L,a)

    def test_nested_or_overlapping_groups_forbidden(self):
        a=[add(0,node(N1,'POINT',transform(1,1,1,1),0,'FILL')),
           add(1,node(N2,'POINT',transform(2,2,1,1),0,'FILL')),
           add(2,node(N3,'POINT',transform(3,3,1,1),0,'FILL')),
           group(3,G1,[N1,N2]),
           group(4,'20000000000000000000000000000001',[N2,N3])]
        with self.assertRaises(ValueError): make_document(L,a)

if __name__=='__main__': unittest.main()
