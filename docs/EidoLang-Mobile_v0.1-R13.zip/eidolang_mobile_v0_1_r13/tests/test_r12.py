import unittest
from dataclasses import replace

from eidolang.r12_synthetic import run_r12_dryrun
from eidolang.r412_dryrun import dryrun_master
from eidolang.r11_synthetic import run_r11_dryrun
from eidolang.production_promotion import (
    binding_from_admission, promote_master_manifest, ProductionProtocolCompiler,
    ProductionRuntime, require_production_bundle,
)
from eidolang.protocol_compiler import ProtocolCompiler, ProtocolCompileError


class R12Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report,cls.production,cls.admission,cls.binding=run_r12_dryrun()

    def test_admitted_grammar_is_root_bound(self):
        r=self.report
        self.assertTrue(r['production_ready'])
        self.assertTrue(r['root_changed'])
        self.assertEqual(r['grammar_spec_hash'],r['production_master']['production_grammar_spec_hash'])
        self.assertEqual(r['grammar_binding_hash'],r['production_master']['production_grammar_binding_hash'])

    def test_child_protocols_and_runtime_lock_are_rebound(self):
        r=self.report
        self.assertTrue(r['alignment_protocol_rebound'])
        self.assertTrue(r['reliability_protocol_rebound'])
        self.assertTrue(r['runtime_lock_changed'])

    def test_old_legacy_bundle_is_not_production_evidence(self):
        self.assertTrue(self.report['legacy_bundle_rejected_by_production_runtime'])
        with self.assertRaises(ProtocolCompileError):
            require_production_bundle(ProtocolCompiler().compile(dryrun_master()))

    def test_old_grammar_hash_after_promotion_is_rejected(self):
        self.assertTrue(self.report['wrong_grammar_hash_rejected'])
        m=self.production.base_bundle
        # covered end-to-end by the dry run; production compiler must have exact binding
        self.assertNotEqual(self.binding.previous_grammar_hash,self.binding.grammar_spec_hash)

    def test_rejected_r11_cannot_be_promoted(self):
        bad=replace(self.admission,status='REJECTED',admitted=False,reasons=('synthetic rejection',))
        with self.assertRaises(ProtocolCompileError):
            binding_from_admission(bad,self.binding.grammar_spec)

    def test_v2_manifest_requires_complete_grammar_binding(self):
        with self.assertRaises(ValueError):
            replace(dryrun_master(),manifest_version='master-prereg-v2')

    def test_every_research_and_product_stage_has_lineage_slot(self):
        stages=set(self.report['lineage_stages'])
        for x in ('R3','R4','R5','R6','R7','R8','R9','R10','R11','R12',
                  'ANDROID_DOCUMENT','ANDROID_MESSAGE','TORRENT_ARCHIVE'):
            self.assertIn(x,stages)

    def test_evidence_envelope_tamper_is_rejected(self):
        runtime=ProductionRuntime(self.production)
        env=self.production.bind_evidence('R5','evidence:1')
        runtime.assert_evidence(env)
        bad=replace(env,grammar_spec_hash=self.binding.previous_grammar_hash)
        with self.assertRaises(ProtocolCompileError):
            runtime.assert_evidence(bad)


if __name__=='__main__': unittest.main()
