import unittest
from dataclasses import replace

from eidolang.r11_synthetic import run_r11_dryrun
from eidolang.refinement_admission import (
    verify_r10_source, admit_refinement, RefinedGrammarCompiler,
    RefinedCandidateUniverseConfig, ExhaustiveRefinedCandidateUniverseEnumerator,
)
from eidolang.grammar_refinement import RefinedGrammarSpec


class R11Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data=run_r11_dryrun()

    def test_joint_refinement_is_admitted_only_after_full_replay(self):
        admission=self.data[3]
        self.assertTrue(admission.admitted,admission)
        self.assertEqual(admission.status,'ADMITTED')
        self.assertTrue(all(x.status=='PASS' for x in admission.case_replays))
        self.assertEqual(admission.downstream.status,'PASS')

    def test_collision_is_repaired_and_protected_equivalence_preserved(self):
        r=next(x for x in self.data[1] if x.case_id=='collision-protected')
        self.assertEqual(r.refined_r9_status,'PASS')
        self.assertEqual(r.collision_obligations_repaired,2)
        self.assertEqual(r.protected_pairs_preserved,1)
        self.assertEqual(r.refined_partition_count,10)
        self.assertEqual(r.refined_operator_count,10)

    def test_unrepresented_program_gets_representation_without_fake_causal_operator(self):
        r=next(x for x in self.data[1] if x.case_id=='unrepresented')
        self.assertEqual(r.unrepresented_covered,1)
        self.assertEqual(r.refined_r9_status,'PASS')
        # Ten raw representational cells exist, but the orphan still has no state-delta
        # support, so only nine causal candidate operators are mined.
        self.assertEqual(r.refined_partition_count,10)
        self.assertEqual(r.refined_operator_count,9)

    def test_protected_confirmation_candidate_universe_is_not_expanded(self):
        d=self.data[2]
        self.assertTrue(d.candidate_counts_preserved)
        self.assertTrue(all(n==3 for _,n in d.new_candidate_counts))

    def test_primary_r5_is_bitwise_semantically_preserved(self):
        d=self.data[2]
        self.assertTrue(d.statistic_preserved)
        self.assertTrue(d.p_value_not_worse)
        self.assertAlmostEqual(d.old_r5_statistic,d.new_r5_statistic,places=15)
        self.assertAlmostEqual(d.old_r5_p,d.new_r5_p,places=15)
        self.assertEqual(d.r5_status,'PASS')

    def test_r10_case_hash_tamper_is_rejected(self):
        r10=self.data[0]
        joint=r10[7]
        cases=list(r10[3])
        bad=replace(cases[0],case_id=cases[0].case_id+':tampered')
        reasons=verify_r10_source(joint,joint.selected_spec,(bad,)+tuple(cases[1:])+(r10[1][-2],))
        self.assertTrue(reasons)

    def test_downstream_failure_rejects_local_repair(self):
        r10=self.data[0]; replays=self.data[1]; d=self.data[2]
        bad=replace(d,status='FAIL',reasons=('synthetic downstream regression',))
        cert=admit_refinement(r10[7],replays,bad)
        self.assertFalse(cert.admitted)
        self.assertEqual(cert.status,'REJECTED')

    def test_compiler_refuses_unproved_multi_ngram_generalization(self):
        r10=self.data[0]; spec=r10[7].selected_spec
        bad=replace(spec,max_ngram=2)
        coll=r10[1]
        cfg8,ledger,freeze,byid,*_=coll
        c=RefinedGrammarCompiler(bad).compile('X',ledger,freeze,byid)
        self.assertEqual(c.status,'INVALID')

if __name__=='__main__': unittest.main()
