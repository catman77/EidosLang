import unittest
from dataclasses import replace

from eidolang.r10_synthetic import run_r10_dryrun
from eidolang.grammar_refinement import (
    GrammarRefinementSearchConfig,NecessityConstrainedGrammarRefinementSynthesizer,
)

class R10Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.data=run_r10_dryrun()

    def test_standard_r9_pass_cases_require_identity_only(self):
        *_,identity=self.data
        self.assertEqual(identity.status,'IDENTITY')
        self.assertEqual(identity.selected_spec.probes,())
        self.assertEqual(identity.selected_spec.coverage_atoms,())

    def test_collision_synthesis_separates_bent_and_preserves_equivalent_diagonals(self):
        collision_only=self.data[5]
        self.assertEqual(collision_only.status,'REFINED')
        self.assertEqual(len(collision_only.selected_spec.probes),1)
        self.assertEqual(len(collision_only.protected_equivalence_pairs),1)
        v=collision_only.validations[0]
        self.assertEqual(v.status,'PASS')
        self.assertEqual(v.collisions_separated,2)
        self.assertEqual(v.protected_pairs_preserved,1)

    def test_minimal_collision_probe_is_same_family_12_by_9(self):
        c=self.data[5]
        p=c.selected_spec.probes[0]
        self.assertEqual((p.resample_n,p.quantization_bins),(12,9))
        self.assertEqual(c.strictly_better_valid_candidate_count,0)

    def test_unrepresented_only_prefers_base_pattern_promotion_over_new_probe(self):
        c=self.data[6]
        self.assertEqual(c.status,'REFINED')
        self.assertEqual(c.selected_spec.probes,())
        self.assertGreaterEqual(len(c.selected_spec.coverage_atoms),1)
        self.assertEqual(c.validations[0].unrepresented_covered,1)

    def test_joint_known_residuals_have_one_valid_minimal_refinement(self):
        c=self.data[7]
        self.assertEqual(c.status,'REFINED')
        self.assertEqual(c.strictly_better_valid_candidate_count,0)
        self.assertTrue(all(v.status=='PASS' for v in c.validations))
        self.assertEqual((c.selected_spec.probes[0].resample_n,c.selected_spec.probes[0].quantization_bins),(12,9))
        self.assertGreaterEqual(len(c.selected_spec.coverage_atoms),1)
        self.assertTrue(c.selected_spec.probe_target_addresses)

    def test_search_cap_does_not_sample(self):
        r9,coll,unrep,std,search,*_=self.data
        ccase=coll[-2]
        tiny=GrammarRefinementSearchConfig(max_resample_increment=4,max_bin_increment=8,max_probes=2,max_coverage_atoms=2,max_candidate_specs=2)
        cert=NecessityConstrainedGrammarRefinementSynthesizer(tiny).synthesize((ccase,))
        self.assertEqual(cert.status,'UNRESOLVED')
        self.assertEqual(cert.evaluated_candidate_count,0)

    def test_source_r9_witness_is_reproduced_before_synthesis(self):
        coll=self.data[1]
        case=coll[-2]
        self.assertEqual(case.source_r9_status,'INADEQUATE')
        self.assertEqual(len(case.collision_obligations),2)
        self.assertEqual(len(case.protected_equivalence_pairs),1)

if __name__=='__main__': unittest.main()
