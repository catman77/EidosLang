# Android eidogram messenger roadmap after R14.1

## R14 / R14.1 — Editor — COMPLETE AT SOURCE LEVEL
- frozen 113-glyph catalog;
- Compose renderer/picker/editor;
- geometry-aware hit testing;
- multi-select and group/ungroup;
- deterministic undo/redo;
- canonical draft persistence;
- canonical import/export;
- Android instrumentation test source;
- pure-Kotlin conformance.

Remaining environmental gate before release:
- build/install/run on Android SDK/emulator/device.

## R15 — Identity + Message Envelope — NEXT
- root user identity and per-device key material;
- `ConversationId`;
- immutable `EidogramMessageV1`;
- signature over canonical envelope;
- encrypted eidogram payload;
- reply/reference graph;
- strict lineage/content-hash binding;
- golden cryptographic vectors.

## R16 — Torrent Archive Model
- immutable `ConversationSegment`;
- deterministic manifest;
- content hashes for messages/documents;
- torrent-v2 archive object;
- signed mutable conversation head.

## R17 — Android P2P/Torrent Engine
- native torrent core through NDK/JNI;
- DHT discovery;
- download/verify/seed;
- quota and storage policy;
- WorkManager sync plus explicit continuous-seeding mode.

## R18 — Messenger UX
- contacts;
- conversations;
- eidogram timeline;
- compose/send/receive;
- delivery/sync state.

## R19 — Archive / Recovery
- local index;
- pin/unpin;
- archive browser;
- recovery after deleting local database.

## R20 — Multi-device
- device subkeys;
- concurrent conversation heads;
- deterministic DAG merge;
- revocation and replay protection.

## R21 — Security / Fuzzing
- malformed canonical documents and envelopes;
- malicious dimensions;
- forged/stale heads;
- poisoned torrents;
- oversized segments;
- parser/JNI fuzzing.

## R22 — Android 1.0 acceptance
Two ordinary Android devices with no application server can create identities, compose
eidograms from the frozen glyph catalog, exchange them, converge on the same signed timeline,
seed/archive history through BitTorrent, and restore the history from the P2P archive.
