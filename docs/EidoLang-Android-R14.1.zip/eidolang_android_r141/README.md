# EidoLang Android — R14 Editor MVP Scaffold

This is the first Android source tree for the eidogram messenger/editor.

## Frozen content vocabulary
- `EidoGlyphCatalogV1`
- 113 glyphs
- catalog hash: `da2d3b72ff8d41abb8c293ce1deca44e99cb1d1a696e9834997395c6f6218005`
- production grammar hash: `d5afb09e6ecdcff8a4b2c9758af83f215059d1b5bc4ad32da3fb8dd191b69b19`

## Modules
- `app`
- `core-model`
- `core-canonical`
- `core-render`
- `feature-library`
- `feature-editor`

## Current editor capabilities
- browse the four glyph families
- add a glyph at canvas center
- select by tapping near an element
- drag / pinch-scale / rotate selected glyph
- ±45° rotation controls
- z-order controls
- delete
- deterministic action log
- undo / redo in the draft editor engine

The wire model uses integer fixed-point coordinates. No arbitrary RGB, freehand path, bitmap glyph, or float-valued wire geometry is admitted.

## Build environment pinned
- compileSdk / targetSdk: 37
- AGP: 9.3.0
- Gradle: 9.5.0
- Kotlin / Compose compiler plugin: 2.3.21
- Compose BOM: 2026.06.00
- minSdk: 26
- Java target: 17

See `R14_VALIDATION.md` for what was and was not executable in the artifact container.


## R14.1
Editor completion adds geometry-aware selection, multi-selection/group UX, strict canonical import/export, and canonical draft persistence. See `R14_1_CHECKPOINT.md`.


## Current status — R14.1

The editor-local completion gate is now implemented:
- geometry-aware hit testing;
- multi-select + group/ungroup;
- strict canonical import/export;
- canonical draft persistence;
- pure-Kotlin conformance PASS.

Next: R15 identity and signed/encrypted message envelope.
