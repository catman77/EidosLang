pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "EidoLangAndroid"
include(
    ":app",
    ":core-model",
    ":core-canonical",
    ":core-render",
    ":feature-library",
    ":feature-editor",
)
