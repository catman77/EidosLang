import unittest
from dataclasses import replace

from eidolang.protocol_compiler import *
from eidolang.r412_dryrun import dryrun_master, run_dryrun
from eidolang.causal import CausalAnalyzer

class R412Tests(unittest.TestCase):
    def test_cross_stage_operator_count_is_six(self):
        m=dryrun_master()
        self.assertEqual(m.causal_class_count,2)
        self.assertEqual(m.operator_realizations_per_class,3)
        self.assertEqual(m.r3_operator_count,6)

    def test_compiler_corrects_r3_multiplicity(self):
        b=ProtocolCompiler().compile(dryrun_master())
        self.assertEqual(b.r3.operator_count_per_observer,6)
        self.assertAlmostEqual(b.r3.alpha_local,.05/12)
        self.assertEqual(b.r3.minimum_total_trials_per_operator,10)

    def test_compiler_corrects_r4_multiplicity_across_two_classes(self):
        b=ProtocolCompiler().compile(dryrun_master())
        self.assertEqual(b.r4.total_pair_certificates_per_observer,6)
        self.assertAlmostEqual(b.r4.alpha_familywise_per_pair,.05/6)
        self.assertEqual(b.r4.min_trials_per_arm_per_stratum,6)

    def test_session_budget_is_1074(self):
        b=ProtocolCompiler().compile(dryrun_master())
        self.assertEqual(b.session_budget.confirmatory_sessions_per_observer_before_discovery,179)
        self.assertEqual(b.session_budget.confirmatory_sessions_total_before_discovery,1074)

    def test_runtime_rejects_manual_alpha(self):
        b=ProtocolCompiler().compile(dryrun_master())
        rt=ConfirmatoryRuntime(b)
        with self.assertRaises(ProtocolCompileError):
            rt.assert_causal_analyzer(CausalAnalyzer(alpha=.05))

    def test_real_mode_rejects_placeholder_anchors(self):
        m=dryrun_master()
        a=list(m.alignment_anchor_specs)
        a[0]=MasterAnchorSpec(a[0].anchor_id,"ALIGNMENT","REPLACE WITH REAL",4,1,False)
        with self.assertRaises(ValueError):
            replace(m,mode="REAL",alignment_anchor_specs=tuple(a))

    def test_too_few_reliability_anchors_rejected(self):
        m=dryrun_master()
        with self.assertRaises(ProtocolCompileError):
            ProtocolCompiler().compile(replace(m,reliability_anchor_specs=m.reliability_anchor_specs[:10]))

    def test_margin_below_quantization_rejected(self):
        m=dryrun_master()
        with self.assertRaises(ProtocolCompileError):
            ProtocolCompiler().compile(replace(
                m,r4_endpoint_margins={"focus":.005,"noise":.08}
            ))

    def test_full_compiled_dryrun(self):
        m,b,r=run_dryrun()
        self.assertTrue(r["overall_pass"],r)

if __name__=="__main__":
    unittest.main()
