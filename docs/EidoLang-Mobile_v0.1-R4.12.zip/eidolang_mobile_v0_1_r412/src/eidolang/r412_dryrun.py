from __future__ import annotations

from dataclasses import asdict
import math
import random
import numpy as np

from .protocol_compiler import (
    MasterAnchorSpec, MasterStudyManifest, ProtocolCompiler, ConfirmatoryRuntime,
    ProtocolCompileError,
)
from .r3_synthetic import make_trials
from .r4_synthetic import make_substitution_trials
from .causal import CausalAnalyzer
from .substitution import CertifiedOperatorRef, DomainSpec, CausalMacroNameBuilder
from .effect_alignment import AnchorObservation
from .reliability import RepeatObservation, reliability_gate, validate_equivalence_margins
from .fidelity import (
    DeviceCapabilityProfile, StepExecution, ExecutionTrace, certify_execution
)
from .schema import StateObservation


def dryrun_master() -> MasterStudyManifest:
    metrics=("activation","valence","clarity","noise","imagery","focus")
    alignment=tuple(
        MasterAnchorSpec(
            f"ALN{i:02d}","ALIGNMENT",
            f"SYNTHETIC DRY-RUN alignment anchor {i:02d}",
            4.0,1,True
        ) for i in range(1,10)
    )
    reliability=tuple(
        MasterAnchorSpec(
            f"REL{i:02d}","RELIABILITY",
            f"SYNTHETIC DRY-RUN reliability anchor {i:02d}",
            4.0,2,True
        ) for i in range(1,20)
    )
    return MasterStudyManifest(
        study_id="eidolang-r412-dryrun",
        manifest_version="master-prereg-v1",
        mode="DRY_RUN",
        observer_ids=tuple(f"O{i}" for i in range(6)),
        reference_observer_id="O0",
        state_metric_keys=metrics,
        primary_endpoint_alternatives=(("focus","greater"),("noise","less")),
        topology_representation="T3",
        topology_extractor_version="multilayer-topology-v1",
        alignment_holdout_rmse_margin=.02,
        alignment_split_seed="r412-frozen-split",
        alignment_anchor_specs=alignment,
        reliability_anchor_specs=reliability,
        quantization_step={k:.01 for k in metrics},
        max_repeatability_radius={k:.05 for k in metrics},
        repeatability_alpha=.05,
        repeat_order_drift_alpha=.01,
        causal_class_count=2,
        operator_realizations_per_class=3,
        r3_alpha_familywise=.05,
        r3_exact_cap=200_000,
        r4_alpha_familywise=.05,
        r4_endpoint_margins={"focus":.08,"noise":.08},
        r4_trajectory_margins={"focus":.08,"noise":.08},
        r4_probe_phase_count=2,
        r4_strata=1,
        r4_exact_cap=200_000,
        r47_alpha_familywise=.05,
        r47_permutation_cap=100_000,
        r5_alpha_familywise=.05,
        r5_primary_hypothesis_count=1,
        r5_exact_cap=100_000,
        fidelity_scope="DIGITAL_EXECUTION",
    )


def _alignment_observations(bundle):
    fit=bundle.r47.fit_anchor_ids
    hold=bundle.r47.holdout_anchor_ids
    aids=fit+hold
    d=6
    # Six fit anchors form a full-rank canonical basis-like matrix.
    canon={}
    for i,a in enumerate(fit):
        v=np.zeros(d); v[i]=0.8; v[(i+1)%d]=0.15
        canon[a]=v
    canon[hold[0]]=np.array([.3,.2,.1,-.2,.15,.4])
    canon[hold[1]]=np.array([-.2,.35,.25,.1,-.3,.2])
    canon[hold[2]]=np.array([.4,-.1,.3,-.25,.2,.15])
    keys=("activation","valence","clarity","inner_noise","imagery","focus")
    rows=[]
    rng=random.Random(412)
    for oi in range(6):
        # Signed permutation is exactly orthogonal; scale differs by observer.
        perm=list(range(d))
        shift=oi%d
        perm=perm[shift:]+perm[:shift]
        signs=np.array([(-1 if (j+oi)%3==0 else 1) for j in range(d)])
        P=np.zeros((d,d))
        for j,pj in enumerate(perm):
            P[j,pj]=signs[j]
        scale=.8+.07*oi
        for aid in aids:
            local=(canon[aid]@P.T)/scale
            local += np.array([rng.uniform(-.0004,.0004) for _ in range(d)])
            rows.append(AnchorObservation(
                f"O{oi}",aid,{k:float(v) for k,v in zip(keys,local)},
                f"O{oi}:{aid}","compiled-anchor-v1"
            ))
    return rows


def _reliability_observations(master,bundle):
    rows=[]
    for oi,o in enumerate(master.observer_ids):
        for ai,aid in enumerate(bundle.reliability.anchor_ids):
            base=(ai-(len(bundle.reliability.anchor_ids)-1)/2)/50.0
            d0={}
            d1={}
            for mi,k in enumerate(master.state_metric_keys):
                v=base*(1+mi*.07)
                e=.004*(1 if (ai+mi+oi)%2==0 else -1)
                d0[k]=v
                d1[k]=v+e
            rows.append(RepeatObservation(o,aid,0,d0,f"{o}:{aid}:0",master.master_hash,"fid"))
            rows.append(RepeatObservation(o,aid,1,d1,f"{o}:{aid}:1",master.master_hash,"fid"))
    return rows


def run_dryrun():
    master=dryrun_master()
    compiler=ProtocolCompiler()
    bundle=compiler.compile(master)
    runtime=ConfirmatoryRuntime(bundle)

    out={
        "compile":{
            "master_hash":bundle.master_hash,
            "runtime_lock_hash":bundle.runtime_lock_hash,
            "bundle_hash":bundle.bundle_hash,
            "feasibility":bundle.feasibility.status,
            "session_budget":asdict(bundle.session_budget),
        }
    }

    # Runtime lock negative control.
    try:
        runtime.assert_causal_analyzer(CausalAnalyzer(alpha=.05))
        tamper="FAIL_NOT_DETECTED"
    except ProtocolCompileError:
        tamper="PASS_REJECTED"
    out["runtime_lock_negative_control"]=tamper

    # R3: all six confirmatory realizations, at compiler-minimal n.
    analyzer=runtime.causal_analyzer()
    r3=[]
    for ci in range(master.causal_class_count):
        for oi in range(master.operator_realizations_per_class):
            op=f"class{ci}:op{oi}"
            trials=make_trials(op,n=bundle.r3.minimum_total_trials_per_operator,seed=731+ci*10+oi,
                               treatment_effect=.50+.01*oi,control_effect=.00)
            cert=analyzer.certify(trials,op,dict(bundle.r3.primary_endpoint_alternatives))
            r3.append({"operator":op,"passed":cert.passed,
                       "p":[e.exact_p_value for e in cert.estimates]})
    out["r3"]={"all_pass":all(x["passed"] for x in r3),"operators":r3}

    # R4: two all-pairs 3-operator MacroNames using compiler-minimal 12 trials/pair.
    sub=runtime.substitution_analyzer()
    names=[]
    for ci in range(master.causal_class_count):
        ops=[f"class{ci}:op{i}" for i in range(master.operator_realizations_per_class)]
        refs=[CertifiedOperatorRef(o,f"causal:{o}",True,"domain:shared","probe:2phase") for o in ops]
        domain=DomainSpec("domain:shared",{"focus":(-1,2),"noise":(-1,2)},("focus","noise"))
        certs=[]
        for i in range(len(ops)):
            for j in range(i+1,len(ops)):
                trials=make_substitution_trials(
                    ops[i],ops[j],
                    n=bundle.r4.min_trials_per_arm_per_stratum*2,
                    seed=404+ci*20+i*5+j,
                    left_effect=.45+.003*i,right_effect=.45+.003*j,
                    left_probe=(.14+.002*i,.31-.001*i),
                    right_probe=(.14+.002*j,.31-.001*j),
                    domain_id="domain:shared",probe_schedule_id="probe:2phase",
                )
                certs.append(sub.certify(trials,refs[i],refs[j],domain))
        name=CausalMacroNameBuilder().build(refs,certs)
        names.append({
            "name_id":name.name_id,
            "operators":name.operator_ids,
            "pair_certificates":len(name.pair_certificate_ids),
            "all_pair_pass":all(c.passed for c in certs)
        })
    out["r4"]={"all_names_built":len(names)==2 and all(x["all_pair_pass"] for x in names),"names":names}

    # R4.7: 6D, six observers, exact 6!=720 fit-anchor permutations.
    al=runtime.effect_aligner().align(_alignment_observations(bundle),master.reference_observer_id)
    out["r47"]={
        "passed":al.passed,
        "aligned":al.aligned_observers,
        "p_values":[r.permutation_p for r in al.results],
        "holdout_rmse":[r.holdout_rmse for r in al.results],
    }

    # R4.10: compiler-minimal 19 disjoint pairs/observer.
    rg=reliability_gate(bundle.reliability,_reliability_observations(master,bundle))
    margin_check=validate_equivalence_margins(master.r4_endpoint_margins,rg)
    out["r410"]={
        "status":rg.status,
        "common_resolution_floor":rg.common_resolution_floor,
        "r4_margin_compatibility":asdict(margin_check),
    }

    # R4.9: verify every compiled anchor plan under ideal digital trace on one device.
    prof=DeviceCapabilityProfile(
        "D1","dry-v1","synthetic","synthetic",1080,2400,3.0,
        True,True,True,48000.0,{"dry_run":True}
    )
    fidelity=[]
    for p in bundle.anchor_execution_plans:
        steps=[]
        for s in p.steps:
            steps.append(StepExecution(
                s.step_id,s.kind,float(s.offset_ms),float(s.offset_ms+5),
                float(s.offset_ms+5+s.duration_ms),True,{},None
            ))
        tr=ExecutionTrace(p.anchor_id,p.plan_hash,prof.profile_hash,
                          "dry:"+p.anchor_id,"dry-trace-v1",tuple(steps))
        c=certify_execution(p,tr,prof)
        fidelity.append(c.status=="PASS")
    out["r49"]={"plans":len(fidelity),"all_digital_fidelity_pass":all(fidelity)}

    # R4.11 arithmetic itself.
    out["r411"]={
        "status":bundle.feasibility.status,
        "r3_local_alpha":bundle.r3.alpha_local,
        "r4_pair_alpha":bundle.r4.alpha_familywise_per_pair,
        "r5_p_floor":bundle.feasibility.r5.configured_p_floor,
    }

    out["overall_pass"]=all([
        out["compile"]["feasibility"]=="PASS",
        tamper=="PASS_REJECTED",
        out["r3"]["all_pass"],
        out["r4"]["all_names_built"],
        out["r47"]["passed"],
        out["r410"]["status"]=="PASS",
        out["r410"]["r4_margin_compatibility"]["status"]=="PASS",
        out["r49"]["all_digital_fidelity_pass"],
        out["r411"]["status"]=="PASS",
    ])
    return master,bundle,out
