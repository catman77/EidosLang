# Android eidogram messenger roadmap after R20

## R14–R19 — COMPLETE AT SOURCE/PROTOCOL LEVEL
Editor, identities, encrypted message envelopes, torrent archive format, transport admission,
messenger repository/UX, archive and destructive recovery are implemented and regression-
protected.

## R20 — Multi-device — COMPLETE AT CORE/PROTOCOL LEVEL
- root-authorized secondary devices;
- signing-key possession enrollment proof;
- root-signed device roster chain;
- prospective revocation;
- multiple certified devices per contact;
- all active local/remote devices receive new message key boxes;
- per-device sender sequences;
- concurrent same-user DAG branches;
- deterministic head convergence/merge;
- historical message-key grants without changing MessageId;
- second-device R19 recovery through migration capsule;
- AndroidKeyStore primary/secondary onboarding adapters.

Remaining UI-only multi-device work:
- polished first-launch secondary-device onboarding;
- QR presentation/scanning;
- device naming and revocation confirmation UX.

## R20.1 — Forward secrecy — NEXT
The current static RSA device decryption model and R20 historical grants intentionally preserve
long-term decryptability. Next introduce a ratcheted session layer:
- per-contact/per-device session state;
- chain-key advancement;
- skipped-message key handling;
- bounded out-of-order receive;
- historical key erasure;
- multi-device session fan-out;
- archive/recovery rules for ratchet state;
- migration without changing `EidogramDocumentV1`.

## R21 — Security / fuzzing / local hardening
- encrypted at-rest repository/drafts/archive;
- malicious enrollment/roster/revocation corpus;
- grant forgery/substitution;
- parser fuzzing;
- archive poisoning;
- SQLite corruption/recovery;
- JNI/native boundary fuzzing.

## R22 — Product completion
- first-launch identity/device onboarding UX;
- profile/settings/device management;
- notifications;
- archive policy UX;
- Android build/install/device admission;
- finally connect the real R17 BitTorrent/DHT backend.

Final acceptance remains two ordinary Android phones exchanging, converging, archiving and
recovering encrypted eidogram conversations without an application server.
