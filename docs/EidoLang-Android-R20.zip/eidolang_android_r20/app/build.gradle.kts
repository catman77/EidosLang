plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.compose.compiler)
}

android {
    namespace = "org.eidolang.app"
    compileSdk = 37

    defaultConfig {
        applicationId = "org.eidolang.app"
        minSdk = 26
        targetSdk = 37
        versionCode = 1
        versionName = "0.1-R20"
    }

    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(project(":feature-editor"))
    implementation(project(":core-model"))
    implementation(project(":core-crypto"))
    implementation(project(":core-message"))
    implementation(project(":core-multidevice"))
    implementation(project(":core-archive"))
    implementation(project(":core-transport"))
    implementation(project(":feature-sync"))
    implementation(project(":feature-messenger"))
    implementation(project(":feature-viewer"))
    implementation(project(":core-repository"))
    implementation(project(":feature-archive"))
    implementation(project(":core-recovery"))
    val composeBom = platform(libs.androidx.compose.bom)
    implementation(composeBom)
    androidTestImplementation(composeBom)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.ui.tooling.preview)
    debugImplementation(libs.androidx.compose.ui.tooling)
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}
