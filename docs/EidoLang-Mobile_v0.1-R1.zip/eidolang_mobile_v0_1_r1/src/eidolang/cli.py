import argparse,json
from pathlib import Path
from .schema import EidoSession
from .segmenter import StrokeSegmenter
from .state import state_delta

def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True); a=sub.add_parser('analyze'); a.add_argument('session_json'); ns=ap.parse_args()
    if ns.cmd=='analyze':
        s=EidoSession.from_dict(json.loads(Path(ns.session_json).read_text(encoding='utf-8'))); toks,segs=StrokeSegmenter().tokens(s)
        print(json.dumps({'session_id':s.session_id,'segments':len(segs),'tokens':toks,'state_delta':state_delta(s)},ensure_ascii=False,indent=2))
