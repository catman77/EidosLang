# EidoLang-Mobile v0.1-R4.7 — Cross-Observer Effect Alignment

## 1. Necessity

R4.6 can compare topological representations across observers only if the externally supplied causal effects are already comparable. For real observers this is not automatic.

Observer A can report an effect vector `Δo_A`; observer B can report `Δo_B`. Even when both interfaces use the same words (`focus`, `noise`, ...), equality of coordinates does not imply equality of latent states.

### Cross-Observer Coordinate No-Go

Without an empirically identified transport

```text
Φ_AB : O_A -> O_B
```

cross-observer statements such as

```text
Effect_A(w_A) ≃ Effect_B(w_B)
```

are representation-dependent. An invertible reparameterization of one observer's state coordinates can preserve all within-observer R4 results while changing cross-observer distances and class assignments.

Therefore R5 is ill-posed before a state-coordinate alignment certificate exists.

## 2. Minimal admitted transport family

R4.7 does not jump to an affine map, neural network, or latent model. The first admitted family is a zero-preserving similarity transform on state-effect deltas:

```text
Φ_i(Δo) = s_i Δo R_i
```

where `s_i > 0` and `R_i` is orthogonal (rotation or reflection).

Zero is fixed because these are changes of state: `Δo = 0` must remain no change.

If this family fails on real data, a more expressive family is not admitted automatically. The failure trace becomes the counterexample from which the weakest necessary extension must be derived.

## 3. Anchors

An anchor is not a semantic label such as "calm". It is a shared physical protocol ID executed under the same preregistered protocol by each observer.

For anchor `a` and observer `i`:

```text
v_i(a) = state_after(i,a) - state_before(i,a)
```

R4.7 tests whether the pattern `{v_i(a)}` can be transported into the reference observer's effect space. It does not assume that any single anchor has the same subjective meaning for all observers.

## 4. Fit / holdout separation

Anchor IDs are partitioned before fitting:

```text
A = A_fit ⊔ A_holdout
```

The transform is fitted on `A_fit` only and judged on unseen `A_holdout` anchors. No anchor can appear in both sets.

## 5. Identifiability gate

For a `d`-dimensional state proxy, the fit anchor matrix must have rank at least `d` by default. Rank-deficient anchors return `INVALID`.

## 6. Exact destructive control

The null destroys anchor correspondence on the fit anchors while preserving the measured effect vectors, the holdout identities, the transport family, and the fitting algorithm.

All fit-anchor permutations are enumerated exactly when `|A_fit|! <= permutation_cap`.

```text
p = #{permutations with holdout error <= observed holdout error} / #permutations
```

If enumeration exceeds the cap, the result is `UNRESOLVED`; no Monte Carlo or asymptotic substitute is inserted silently.

## 7. Familywise gate

For several non-reference observers:

```text
alpha_adjusted = alpha_familywise / (# non-reference observers)
```

Each observer must satisfy both:

```text
holdout_RMSE <= preregistered_margin
exact_permutation_p <= alpha_adjusted
```

The full report passes only when every observer passes.

## 8. Output

A PASS produces `SimilarityTransform` objects that map future R4 causal-effect deltas into the reference chart:

```text
Δo_i -> Φ_i(Δo_i)
```

It does not yet create a cross-observer `MacroName`.

## 9. What R4.7 does not prove

- self-report coordinates are latent consciousness coordinates;
- similarity transport is universally correct;
- shared anchors have shared phenomenology;
- T3 topology transports between real subjects;
- failed similarity alignment implies nonlinear state geometry.

## 10. Next gate

Only after a real `EffectAlignmentReport(PASS)` may R5 compare independently R4-certified operators across observers in the aligned effect space and ask whether T3 topological motifs predict causal substitution classes.
