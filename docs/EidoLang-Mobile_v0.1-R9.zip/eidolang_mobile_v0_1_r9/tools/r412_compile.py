from __future__ import annotations
import argparse, json
from pathlib import Path
from dataclasses import asdict

from eidolang.protocol_compiler import (
    MasterAnchorSpec, MasterStudyManifest, ProtocolCompiler
)

def load_master(path):
    d=json.loads(Path(path).read_text(encoding="utf-8"))
    d["observer_ids"]=tuple(d["observer_ids"])
    d["state_metric_keys"]=tuple(d["state_metric_keys"])
    d["primary_endpoint_alternatives"]=tuple(tuple(x) for x in d["primary_endpoint_alternatives"])
    d["alignment_anchor_specs"]=tuple(MasterAnchorSpec(**x) for x in d["alignment_anchor_specs"])
    d["reliability_anchor_specs"]=tuple(MasterAnchorSpec(**x) for x in d["reliability_anchor_specs"])
    return MasterStudyManifest(**d)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("master_manifest")
    ap.add_argument("--out",default="compiled_protocol")
    ns=ap.parse_args()
    m=load_master(ns.master_manifest)
    c=ProtocolCompiler()
    b=c.compile(m)
    c.write_bundle(b,ns.out)
    print(json.dumps({
        "master_hash":b.master_hash,
        "runtime_lock_hash":b.runtime_lock_hash,
        "bundle_hash":b.bundle_hash,
        "status":b.feasibility.status,
        "session_budget":asdict(b.session_budget),
    },indent=2))

if __name__=="__main__":
    main()
