from __future__ import annotations
import argparse, json
from dataclasses import asdict
from pathlib import Path
from eidolang.feasibility import FeasibilityManifest, analyze_feasibility

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("manifest")
    ns=ap.parse_args()
    d=json.loads(Path(ns.manifest).read_text(encoding="utf-8"))
    m=FeasibilityManifest(**d)
    print(json.dumps(asdict(analyze_feasibility(m)),indent=2,ensure_ascii=False))

if __name__=="__main__":
    main()
