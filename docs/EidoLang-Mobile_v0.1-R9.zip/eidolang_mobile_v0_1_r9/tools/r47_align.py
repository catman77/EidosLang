#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from dataclasses import asdict
from eidolang.effect_alignment import AnchorObservation, AlignmentConfig, CrossObserverEffectAligner

ap=argparse.ArgumentParser(description='R4.7 cross-observer effect alignment gate')
ap.add_argument('observations_json')
ap.add_argument('--reference',required=True)
ap.add_argument('--fit',required=True)
ap.add_argument('--holdout',required=True)
ap.add_argument('--margin',type=float,required=True)
ap.add_argument('--alpha',type=float,default=.05)
ap.add_argument('--permutation-cap',type=int,default=100000)
ns=ap.parse_args()
raw=json.loads(Path(ns.observations_json).read_text(encoding='utf-8'))
obs=[AnchorObservation(**x) for x in raw]
cfg=AlignmentConfig(tuple(filter(None,ns.fit.split(','))),tuple(filter(None,ns.holdout.split(','))),ns.margin,ns.alpha,permutation_cap=ns.permutation_cap)
r=CrossObserverEffectAligner(cfg).align(obs,ns.reference)
print(json.dumps(asdict(r),ensure_ascii=False,indent=2))
