#!/usr/bin/env python3
"""Exploratory raster-T0 probe for page 7 of the attached article.

This is NOT part of the language-discovery gate. The published PDF lacks raw stroke
history and original color layers, so the probe only tests whether very coarse
single-threshold Betti signatures visibly solve the illustrated cross-author problem.
They do not.

Requires Pillow. Usage:
  python tools/article_raster_probe.py /path/to/page_7.png
"""
from PIL import Image
from collections import deque
import json, sys

BOXES={
    'whole_1':(234,558,362,688), 'whole_2':(390,558,519,688), 'whole_3':(548,558,675,688),
    'discrete_1':(234,710,362,837), 'discrete_2':(390,710,519,837), 'discrete_3':(548,710,675,837),
}
THRESHOLDS=(64,96,128,160,192,224,245)

def comps(mask,value,conn):
    h=len(mask); w=len(mask[0]); seen=[[False]*w for _ in range(h)]; out=[]
    ds4=((1,0),(-1,0),(0,1),(0,-1)); ds8=ds4+((1,1),(1,-1),(-1,1),(-1,-1))
    ds=ds4 if conn==4 else ds8
    for y in range(h):
        for x in range(w):
            if seen[y][x] or mask[y][x]!=value: continue
            q=deque([(x,y)]); seen[y][x]=True; c=[]
            while q:
                a,b=q.popleft(); c.append((a,b))
                for dx,dy in ds:
                    nx,ny=a+dx,b+dy
                    if 0<=nx<w and 0<=ny<h and not seen[ny][nx] and mask[ny][nx]==value:
                        seen[ny][nx]=True;q.append((nx,ny))
            out.append(c)
    return out

def betti(crop,thr,min_area=20):
    pix=crop.load(); w,h=crop.size
    mask=[[pix[x,y]<thr for x in range(w)] for y in range(h)]
    # Remove printed box frame and tiny raster artifacts.
    for x in range(w):
        for y in (0,1,2,h-1,h-2,h-3): mask[y][x]=False
    for y in range(h):
        for x in (0,1,2,w-1,w-2,w-3): mask[y][x]=False
    ink=[c for c in comps(mask,True,8) if len(c)>=min_area]
    clean=[[False]*w for _ in range(h)]
    for c in ink:
        for x,y in c: clean[y][x]=True
    bg=comps(clean,False,4); holes=0
    for c in bg:
        if len(c)<min_area: continue
        if not any(x==0 or y==0 or x==w-1 or y==h-1 for x,y in c): holes+=1
    return {'beta0':len(ink),'beta1':holes,'chi':len(ink)-holes}

def main(path):
    im=Image.open(path).convert('L')
    report={'source_page':'article page 7 raster','thresholds':list(THRESHOLDS),'motifs':{}}
    for name,box in BOXES.items():
        cr=im.crop(box)
        report['motifs'][name]={str(t):betti(cr,t) for t in THRESHOLDS}
    clean=[]
    for t in THRESHOLDS:
        w=[report['motifs'][f'whole_{i}'][str(t)] for i in (1,2,3)]
        d=[report['motifs'][f'discrete_{i}'][str(t)] for i in (1,2,3)]
        ws={(x['beta0'],x['beta1']) for x in w}; ds={(x['beta0'],x['beta1']) for x in d}
        # A single threshold is 'clean' only if all within-class signatures collapse and classes differ.
        clean.append({'threshold':t,'clean_class_invariant':len(ws)==1 and len(ds)==1 and ws!=ds,
                      'whole_signatures':sorted(map(list,ws)),'discrete_signatures':sorted(map(list,ds))})
    report['single_threshold_audit']=clean
    report['conclusion']='No tested threshold yields a single invariant T0 signature for each illustrated class; richer relational/process topology is required.'
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('usage: article_raster_probe.py page_7.png')
    main(sys.argv[1])
