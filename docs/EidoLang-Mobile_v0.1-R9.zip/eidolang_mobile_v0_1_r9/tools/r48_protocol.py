from __future__ import annotations
import argparse, json
from dataclasses import asdict
from pathlib import Path

from eidolang.acquisition import (
    AnchorDefinition, AnalysisLock, AcquisitionManifest, deterministic_schedule
)

def load_manifest(path):
    d=json.loads(Path(path).read_text(encoding="utf-8"))
    anchors=tuple(AnchorDefinition(**x) for x in d["anchors"])
    lock=AnalysisLock(**d["analysis_lock"])
    return AcquisitionManifest(
        study_id=d["study_id"],
        protocol_version=d["protocol_version"],
        anchors=anchors,
        fit_anchor_count=int(d["fit_anchor_count"]),
        split_seed=d["split_seed"],
        planned_observer_count=int(d["planned_observer_count"]),
        state_metric_keys=tuple(d["state_metric_keys"]),
        exclusion_rules=tuple(d["exclusion_rules"]),
        analysis_lock=lock,
        recommendation_mode=d.get("recommendation_mode","NONE"),
        target_state_allowed_for_anchors=bool(d.get("target_state_allowed_for_anchors",False)),
        external_commit_ref=d.get("external_commit_ref"),
    )

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("manifest")
    ap.add_argument("--observer")
    ap.add_argument("--private-split",action="store_true")
    ns=ap.parse_args()
    m=load_manifest(ns.manifest)
    out={
        "protocol_hash":m.protocol_hash,
        "public_collection_manifest":m.public_collection_manifest(),
    }
    if ns.observer:
        out["schedule"]=[asdict(x) for x in deterministic_schedule(m,ns.observer)]
    if ns.private_split:
        out["private_split"]=asdict(m.anchor_split())
    print(json.dumps(out,ensure_ascii=False,indent=2))

if __name__=="__main__":
    main()
