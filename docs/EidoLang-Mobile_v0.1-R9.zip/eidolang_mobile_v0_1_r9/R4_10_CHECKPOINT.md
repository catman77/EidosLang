# R4.10 checkpoint

Status: IMPLEMENTED / SYNTHETIC RELIABILITY TESTS ONLY

Implemented:
- frozen reliability manifest;
- disjoint repeat pairing;
- finite-sample conformal-style repeatability radius;
- explicit minimum-sample `UNRESOLVED`;
- quantization floor;
- exact repeat-order sign test;
- per-observer/per-metric certificates;
- whole-corpus reliability gate;
- common empirical resolution floor;
- R4 equivalence-margin compatibility gate.

Critical no-gos:
1. repeat discrepancy is not identifiable as pure sensor noise;
2. fewer than 19 disjoint pairs cannot provide a 95% finite-sample radius by this method;
3. an equivalence margin below the measured repeatability floor is invalid without a new
   explicit measurement-error theory.

R5 remains blocked until R4.8, R4.9 and R4.10 all pass on a real frozen corpus.
