let protocol=null, schedule=[], idx=0, started=null;

async function digestHex(s){
  const b=new TextEncoder().encode(s);
  const h=await crypto.subtle.digest("SHA-256",b);
  return [...new Uint8Array(h)].map(x=>x.toString(16).padStart(2,"0")).join("");
}
async function rankSchedule(protocolHash,observer,anchors){
  let rows=[];
  for(const a of anchors){
    for(let r=0;r<(a.repeats||1);r++){
      let key=protocolHash+"\0"+observer+"\0"+a.anchor_id+"\0"+r;
      rows.push([await digestHex(key),a.anchor_id,r]);
    }
  }
  rows.sort((a,b)=>a[0].localeCompare(b[0]));
  return rows.map((x,i)=>({schedule_index:i,anchor_id:x[1],repeat_index:x[2]}));
}
function metricInputs(root,keys,prefix){
  root.innerHTML="";
  for(const k of keys){
    const label=document.createElement("label");
    label.textContent=k+" ";
    const inp=document.createElement("input");
    inp.type="number"; inp.step="0.01"; inp.dataset.metric=k; inp.id=prefix+"-"+k;
    label.appendChild(inp); root.appendChild(label); root.appendChild(document.createElement("br"));
  }
}
function currentAnchor(){
  const t=schedule[idx], a=protocol.anchors.find(x=>x.anchor_id===t.anchor_id);
  document.getElementById("aid").textContent=`${idx+1}/${schedule.length}: ${t.anchor_id} (repeat ${t.repeat_index})`;
  document.getElementById("instruction").textContent=a.instruction;
}
document.getElementById("load").onclick=async()=>{
  const f=document.getElementById("mf").files[0], observer=document.getElementById("observer").value.trim();
  if(!f||!observer)return alert("Нужны manifest и observer id");
  protocol=JSON.parse(await f.text());
  schedule=await rankSchedule(protocol.protocol_hash,observer,protocol.anchors);
  document.getElementById("info").textContent=`study=${protocol.study_id}\nprotocol_hash=${protocol.protocol_hash}\ntrials=${schedule.length}`;
  metricInputs(document.getElementById("pre"),protocol.state_metric_keys,"pre");
  metricInputs(document.getElementById("post"),protocol.state_metric_keys,"post");
  idx=0; currentAnchor(); document.getElementById("trial").classList.remove("hidden");
};
document.getElementById("start").onclick=()=>{started=performance.now();};
document.getElementById("finish").onclick=()=>{
  if(started===null)return alert("Сначала нажмите Старт");
  const observer=document.getElementById("observer").value.trim(), t=schedule[idx];
  const read=(p)=>Object.fromEntries(protocol.state_metric_keys.map(k=>[k,Number(document.getElementById(p+"-"+k).value)]));
  const elapsed=Math.round((performance.now()-started)*1000);
  const s={
    session_id:`${protocol.study_id}-${observer}-${t.schedule_index}-${Date.now()}`,
    protocol_version:"0.1-R4.8",
    mode:"CAPTURE", recommendation_mode:"NONE",
    started_at:new Date().toISOString(),
    raw_events:[],
    state_observations:[
      {t_us:0,metrics:read("pre"),source:"self_report"},
      {t_us:elapsed,metrics:read("post"),source:"self_report"}
    ],
    target_state:null,
    metadata:{
      study_id:protocol.study_id,protocol_hash:protocol.protocol_hash,
      observer_id:observer,anchor_id:t.anchor_id,anchor_repeat:t.repeat_index,
      schedule_index:t.schedule_index,capture:"r48-anchor-web-v1"
    }
  };
  const blob=new Blob([JSON.stringify(s,null,2)],{type:"application/json"});
  const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download=s.session_id+".json"; a.click();
  URL.revokeObjectURL(a.href);
  idx++; started=null;
  if(idx<schedule.length) currentAnchor(); else document.getElementById("trial").innerHTML="<b>Расписание завершено.</b>";
};
