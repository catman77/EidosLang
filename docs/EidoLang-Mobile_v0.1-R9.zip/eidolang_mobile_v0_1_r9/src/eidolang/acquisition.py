from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from hashlib import sha256
from typing import Any, Iterable, Optional
import json

from .schema import EidoSession, RecommendationMode


def _canon(x: Any) -> Any:
    if isinstance(x, Enum):
        return x.value
    if hasattr(x, "__dataclass_fields__"):
        return _canon(asdict(x))
    if isinstance(x, dict):
        return {str(k): _canon(v) for k, v in sorted(x.items(), key=lambda kv: str(kv[0]))}
    if isinstance(x, (list, tuple)):
        return [_canon(v) for v in x]
    return x


def canonical_json_bytes(x: Any) -> bytes:
    return json.dumps(
        _canon(x),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def sha256_object(x: Any) -> str:
    return sha256(canonical_json_bytes(x)).hexdigest()


@dataclass(frozen=True)
class AnchorDefinition:
    anchor_id: str
    instruction: str
    duration_s: float
    repeats: int = 1
    media_ref: Optional[str] = None

    def __post_init__(self):
        if not self.anchor_id.strip():
            raise ValueError("empty anchor_id")
        if self.duration_s <= 0:
            raise ValueError("duration_s must be positive")
        if self.repeats < 1:
            raise ValueError("repeats must be >=1")


@dataclass(frozen=True)
class AnalysisLock:
    topology_representation: str = "T3"
    topology_extractor_version: str = "multilayer-topology-v1"
    state_metric_keys: tuple[str, ...] = ()
    alignment_transport_family: str = "zero_similarity"
    causal_label_policy: str = "ALL_R4_PASSING_AT_CUTOFF"
    cross_observer_policy: str = "LEAVE_ONE_OBSERVER_OUT"
    notes: str = ""


@dataclass(frozen=True)
class AcquisitionManifest:
    study_id: str
    protocol_version: str
    anchors: tuple[AnchorDefinition, ...]
    fit_anchor_count: int
    split_seed: str
    planned_observer_count: int
    state_metric_keys: tuple[str, ...]
    exclusion_rules: tuple[str, ...]
    analysis_lock: AnalysisLock
    recommendation_mode: str = "NONE"
    target_state_allowed_for_anchors: bool = False
    external_commit_ref: Optional[str] = None

    def __post_init__(self):
        ids = [a.anchor_id for a in self.anchors]
        if len(ids) != len(set(ids)):
            raise ValueError("anchor ids must be unique")
        if self.fit_anchor_count < 2:
            raise ValueError("need >=2 fit anchors")
        if len(self.anchors) - self.fit_anchor_count < 1:
            raise ValueError("need >=1 holdout anchor")
        if self.planned_observer_count < 2:
            raise ValueError("planned_observer_count must be >=2")
        if not self.state_metric_keys:
            raise ValueError("state_metric_keys cannot be empty")
        if tuple(self.analysis_lock.state_metric_keys) not in ((), tuple(self.state_metric_keys)):
            raise ValueError("analysis_lock.state_metric_keys must match manifest state_metric_keys")

    @property
    def protocol_hash(self) -> str:
        return sha256_object(self)

    def anchor_split(self) -> "AnchorSplit":
        ranked = sorted(
            (sha256((self.split_seed + "\0" + a.anchor_id).encode("utf-8")).hexdigest(), a.anchor_id)
            for a in self.anchors
        )
        fit = tuple(sorted(a for _, a in ranked[:self.fit_anchor_count]))
        holdout = tuple(sorted(a for _, a in ranked[self.fit_anchor_count:]))
        return AnchorSplit(fit, holdout, self.split_seed, self.protocol_hash)

    def public_collection_manifest(self) -> dict[str, Any]:
        # Deliberately omits fit/holdout membership.
        return {
            "study_id": self.study_id,
            "protocol_version": self.protocol_version,
            "protocol_hash": self.protocol_hash,
            "anchors": [_canon(a) for a in self.anchors],
            "planned_observer_count": self.planned_observer_count,
            "state_metric_keys": list(self.state_metric_keys),
            "recommendation_mode": self.recommendation_mode,
            "analysis_lock_digest": sha256_object(self.analysis_lock),
        }


@dataclass(frozen=True)
class AnchorSplit:
    fit_anchor_ids: tuple[str, ...]
    holdout_anchor_ids: tuple[str, ...]
    split_seed: str
    protocol_hash: str


@dataclass(frozen=True)
class ScheduledTrial:
    schedule_index: int
    anchor_id: str
    repeat_index: int


def deterministic_schedule(manifest: AcquisitionManifest, observer_id: str) -> tuple[ScheduledTrial, ...]:
    expanded = []
    for a in manifest.anchors:
        for r in range(a.repeats):
            expanded.append((a.anchor_id, r))
    ranked = sorted(
        (
            sha256(
                (
                    manifest.protocol_hash
                    + "\0"
                    + observer_id
                    + "\0"
                    + aid
                    + "\0"
                    + str(rep)
                ).encode("utf-8")
            ).hexdigest(),
            aid,
            rep,
        )
        for aid, rep in expanded
    )
    return tuple(ScheduledTrial(i, aid, rep) for i, (_, aid, rep) in enumerate(ranked))


@dataclass(frozen=True)
class AdmissionResult:
    status: str
    reasons: tuple[str, ...]

    @property
    def passed(self) -> bool:
        return self.status == "PASS"


class AcquisitionGate:
    def __init__(self, manifest: AcquisitionManifest):
        self.manifest = manifest
        self.anchor_ids = {a.anchor_id for a in manifest.anchors}

    def validate_anchor_session(
        self,
        session: EidoSession,
        observer_id: str,
        expected: Optional[ScheduledTrial] = None,
    ) -> AdmissionResult:
        m = self.manifest
        reasons = []
        md = session.metadata
        if md.get("study_id") != m.study_id:
            reasons.append("study_id mismatch")
        if md.get("protocol_hash") != m.protocol_hash:
            reasons.append("protocol_hash mismatch")
        if str(md.get("observer_id", "")) != str(observer_id):
            reasons.append("observer_id mismatch")
        aid = str(md.get("anchor_id", ""))
        if aid not in self.anchor_ids:
            reasons.append("undeclared anchor_id")
        if session.recommendation_mode.value != m.recommendation_mode:
            reasons.append("recommendation mode differs from frozen protocol")
        if session.target_state is not None and not m.target_state_allowed_for_anchors:
            reasons.append("target_state forbidden for anchor acquisition")
        if expected is not None:
            if aid != expected.anchor_id:
                reasons.append("anchor differs from deterministic schedule")
            if int(md.get("anchor_repeat", -1)) != expected.repeat_index:
                reasons.append("anchor repeat differs from deterministic schedule")
            if int(md.get("schedule_index", -1)) != expected.schedule_index:
                reasons.append("schedule index differs from deterministic schedule")
        sin, sout = session.state_in(), session.state_out()
        if sin is None or sout is None:
            reasons.append("missing pre/post state observation")
        else:
            required = set(m.state_metric_keys)
            if set(sin.metrics) != required:
                reasons.append("pre-state metric keys differ from frozen schema")
            if set(sout.metrics) != required:
                reasons.append("post-state metric keys differ from frozen schema")
            if sout.t_us <= sin.t_us:
                reasons.append("post-state timestamp must follow pre-state")
        return AdmissionResult("PASS" if not reasons else "FAIL", tuple(reasons))


@dataclass(frozen=True)
class LedgerEntry:
    sequence_no: int
    session_id: str
    session_hash: str
    previous_entry_hash: str
    protocol_hash: str
    entry_hash: str


@dataclass
class AcquisitionLedger:
    protocol_hash: str
    entries: list[LedgerEntry] = field(default_factory=list)

    def append(self, session: EidoSession) -> LedgerEntry:
        session_hash = sha256_object(session)
        prev = self.entries[-1].entry_hash if self.entries else "GENESIS"
        seq = len(self.entries)
        material = {
            "sequence_no": seq,
            "session_id": session.session_id,
            "session_hash": session_hash,
            "previous_entry_hash": prev,
            "protocol_hash": self.protocol_hash,
        }
        entry_hash = sha256_object(material)
        e = LedgerEntry(seq, session.session_id, session_hash, prev, self.protocol_hash, entry_hash)
        self.entries.append(e)
        return e

    def verify(self, sessions_by_id: dict[str, EidoSession]) -> tuple[bool, str]:
        prev = "GENESIS"
        for i, e in enumerate(self.entries):
            if e.sequence_no != i:
                return False, f"sequence mismatch at {i}"
            if e.previous_entry_hash != prev:
                return False, f"previous hash mismatch at {i}"
            if e.protocol_hash != self.protocol_hash:
                return False, f"protocol hash mismatch at {i}"
            s = sessions_by_id.get(e.session_id)
            if s is None:
                return False, f"missing session {e.session_id}"
            sh = sha256_object(s)
            if sh != e.session_hash:
                return False, f"session hash mismatch for {e.session_id}"
            material = {
                "sequence_no": e.sequence_no,
                "session_id": e.session_id,
                "session_hash": e.session_hash,
                "previous_entry_hash": e.previous_entry_hash,
                "protocol_hash": e.protocol_hash,
            }
            if sha256_object(material) != e.entry_hash:
                return False, f"entry hash mismatch at {i}"
            prev = e.entry_hash
        return True, "PASS"

    @property
    def data_root(self) -> str:
        return self.entries[-1].entry_hash if self.entries else sha256(
            ("EMPTY\0" + self.protocol_hash).encode("utf-8")
        ).hexdigest()


@dataclass(frozen=True)
class DataFreezeCertificate:
    study_id: str
    protocol_hash: str
    data_root: str
    ledger_length: int
    enrolled_observers: tuple[str, ...]
    excluded_session_ids: tuple[str, ...]
    exclusion_reasons: tuple[tuple[str, str], ...]
    external_commit_ref: Optional[str] = None

    @property
    def freeze_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class EvaluationManifest:
    study_id: str
    protocol_hash: str
    data_freeze_hash: str
    topology_representation: str
    topology_extractor_version: str
    alignment_fit_anchor_ids: tuple[str, ...]
    alignment_holdout_anchor_ids: tuple[str, ...]
    causal_label_policy: str
    eligible_causal_label_refs: tuple[str, ...]
    included_causal_label_refs: tuple[str, ...]
    cross_observer_policy: str
    evaluator_version: str
    external_commit_ref: Optional[str] = None

    @property
    def evaluation_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class EvaluationLockResult:
    status: str
    reasons: tuple[str, ...]

    @property
    def passed(self) -> bool:
        return self.status == "PASS"


def validate_evaluation_manifest(
    acquisition: AcquisitionManifest,
    freeze: DataFreezeCertificate,
    evaluation: EvaluationManifest,
) -> EvaluationLockResult:
    reasons = []
    split = acquisition.anchor_split()
    if evaluation.study_id != acquisition.study_id:
        reasons.append("study_id mismatch")
    if evaluation.protocol_hash != acquisition.protocol_hash:
        reasons.append("protocol_hash mismatch")
    if freeze.protocol_hash != acquisition.protocol_hash:
        reasons.append("freeze protocol_hash mismatch")
    if evaluation.data_freeze_hash != freeze.freeze_hash:
        reasons.append("evaluation does not reference frozen dataset")
    if tuple(sorted(evaluation.alignment_fit_anchor_ids)) != tuple(sorted(split.fit_anchor_ids)):
        reasons.append("fit anchors differ from preregistered deterministic split")
    if tuple(sorted(evaluation.alignment_holdout_anchor_ids)) != tuple(sorted(split.holdout_anchor_ids)):
        reasons.append("holdout anchors differ from preregistered deterministic split")
    lock = acquisition.analysis_lock
    if evaluation.topology_representation != lock.topology_representation:
        reasons.append("topology representation changed after acquisition")
    if evaluation.topology_extractor_version != lock.topology_extractor_version:
        reasons.append("topology extractor version changed after acquisition")
    if evaluation.causal_label_policy != lock.causal_label_policy:
        reasons.append("causal label policy changed")
    if evaluation.cross_observer_policy != lock.cross_observer_policy:
        reasons.append("cross-observer policy changed")
    if lock.causal_label_policy == "ALL_R4_PASSING_AT_CUTOFF":
        if set(evaluation.included_causal_label_refs) != set(evaluation.eligible_causal_label_refs):
            reasons.append("post-hoc causal-label subset selection forbidden")
    return EvaluationLockResult("PASS" if not reasons else "FAIL", tuple(reasons))


def freeze_dataset(
    manifest: AcquisitionManifest,
    ledger: AcquisitionLedger,
    sessions_by_id: dict[str, EidoSession],
    enrolled_observers: Iterable[str],
    exclusions: dict[str, str] | None = None,
    external_commit_ref: Optional[str] = None,
) -> DataFreezeCertificate:
    ok, reason = ledger.verify(sessions_by_id)
    if not ok:
        raise ValueError("cannot freeze invalid ledger: " + reason)
    ex = exclusions or {}
    unknown = set(ex) - set(sessions_by_id)
    if unknown:
        raise ValueError(f"exclusion references unknown sessions: {sorted(unknown)}")
    return DataFreezeCertificate(
        study_id=manifest.study_id,
        protocol_hash=manifest.protocol_hash,
        data_root=ledger.data_root,
        ledger_length=len(ledger.entries),
        enrolled_observers=tuple(sorted(str(x) for x in enrolled_observers)),
        excluded_session_ids=tuple(sorted(ex)),
        exclusion_reasons=tuple(sorted((k, str(v)) for k, v in ex.items())),
        external_commit_ref=external_commit_ref,
    )
