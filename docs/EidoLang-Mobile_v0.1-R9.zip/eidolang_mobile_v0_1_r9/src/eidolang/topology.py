from __future__ import annotations
from dataclasses import dataclass, asdict
from collections import deque
import math, hashlib
from typing import Iterable

from .schema import EidoSession, StrokeSegment
from .segmenter import StrokeSegmenter


@dataclass(frozen=True)
class TopologyConfig:
    version: str = "topology-v1"
    grid_size: int = 96
    stroke_radius_px: int = 2
    closure_ratio: float = 0.12
    fg_connectivity: int = 8
    bg_connectivity: int = 4


@dataclass(frozen=True)
class TopologySnapshot:
    beta0: int
    beta1: int
    euler: int
    boundary_touch_counts: tuple[int, int, int, int]  # left,right,top,bottom
    horizontal_spanning_components: int
    vertical_spanning_components: int
    closed_strokes: int
    containment_edges: int
    max_containment_depth: int
    intersection_pairs: int
    disjoint_closed_pairs: int
    ink_fraction: float

    def t0_vector(self) -> tuple[float, ...]:
        return (float(self.beta0), float(self.beta1), float(self.euler))

    def t1_vector(self) -> tuple[float, ...]:
        return self.t0_vector() + tuple(float(x) for x in self.boundary_touch_counts) + (
            float(self.horizontal_spanning_components),
            float(self.vertical_spanning_components),
            float(self.closed_strokes),
            float(self.containment_edges),
            float(self.max_containment_depth),
            float(self.intersection_pairs),
            float(self.disjoint_closed_pairs),
            float(self.ink_fraction),
        )

    def t0_signature(self) -> str:
        return f"T0:b0={self.beta0};b1={self.beta1};chi={self.euler}"

    def t1_signature(self) -> str:
        bt = ".".join(map(str, self.boundary_touch_counts))
        return (
            f"T1:{self.t0_signature()};bt={bt};hs={self.horizontal_spanning_components};"
            f"vs={self.vertical_spanning_components};cl={self.closed_strokes};"
            f"ce={self.containment_edges};depth={self.max_containment_depth};"
            f"ix={self.intersection_pairs};dc={self.disjoint_closed_pairs}"
        )


@dataclass(frozen=True)
class TopologicalEvent:
    stroke_index: int
    delta_beta0: int
    delta_beta1: int
    delta_closed: int
    delta_containment: int
    delta_intersections: int
    new_contains_existing: int
    new_contained_by_existing: int
    delta_hspan: int
    delta_vspan: int

    def token(self) -> str:
        return (
            f"dB0={self.delta_beta0},dB1={self.delta_beta1},dC={self.delta_closed},"
            f"dN={self.delta_containment},dX={self.delta_intersections},"
            f"nContains={self.new_contains_existing},nInside={self.new_contained_by_existing},"
            f"dH={self.delta_hspan},dV={self.delta_vspan}"
        )


@dataclass(frozen=True)
class TemporalTopology:
    snapshots: tuple[TopologySnapshot, ...]
    events: tuple[TopologicalEvent, ...]
    signature: str

    def t2_vector(self) -> tuple[float, ...]:
        # Counts of signed topological events. Sequence is preserved separately in signature.
        keys = [
            lambda e: e.delta_beta0 > 0,
            lambda e: e.delta_beta0 < 0,
            lambda e: e.delta_beta1 > 0,
            lambda e: e.delta_beta1 < 0,
            lambda e: e.delta_containment > 0,
            lambda e: e.delta_intersections > 0,
            lambda e: e.new_contains_existing > 0,
            lambda e: e.new_contained_by_existing > 0,
            lambda e: e.delta_hspan != 0,
            lambda e: e.delta_vspan != 0,
        ]
        return tuple(float(sum(1 for e in self.events if pred(e))) for pred in keys)


@dataclass(frozen=True)
class TopologyDescriptor:
    config_version: str
    final: TopologySnapshot
    temporal: TemporalTopology

    def feature_vector(self, level: str = "T2") -> tuple[float, ...]:
        level = level.upper()
        if level == "T0":
            return self.final.t0_vector()
        if level == "T1":
            return self.final.t1_vector()
        if level == "T2":
            return self.final.t1_vector() + self.temporal.t2_vector()
        raise ValueError(f"unknown topology level {level}")


def _neighbors(x: int, y: int, w: int, h: int, conn: int):
    if conn == 4:
        ds = ((1,0),(-1,0),(0,1),(0,-1))
    elif conn == 8:
        ds = ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1))
    else:
        raise ValueError("connectivity must be 4 or 8")
    for dx,dy in ds:
        nx,ny=x+dx,y+dy
        if 0 <= nx < w and 0 <= ny < h:
            yield nx,ny


def _components(mask: list[list[bool]], value: bool, conn: int):
    h=len(mask); w=len(mask[0]) if h else 0
    seen=[[False]*w for _ in range(h)]
    comps=[]
    for y in range(h):
        for x in range(w):
            if seen[y][x] or mask[y][x] != value:
                continue
            q=deque([(x,y)]); seen[y][x]=True; pts=[]
            while q:
                a,b=q.popleft(); pts.append((a,b))
                for nx,ny in _neighbors(a,b,w,h,conn):
                    if not seen[ny][nx] and mask[ny][nx] == value:
                        seen[ny][nx]=True; q.append((nx,ny))
            comps.append(pts)
    return comps


def _mark_disk(mask: list[list[bool]], cx: float, cy: float, r: int):
    h=len(mask); w=len(mask[0]) if h else 0
    ix=int(round(cx)); iy=int(round(cy)); rr=max(0,r)
    for y in range(max(0,iy-rr),min(h,iy+rr+1)):
        for x in range(max(0,ix-rr),min(w,ix+rr+1)):
            if (x-cx)*(x-cx)+(y-cy)*(y-cy) <= (rr+0.5)*(rr+0.5):
                mask[y][x]=True


def rasterize_strokes(strokes: Iterable[StrokeSegment], config: TopologyConfig) -> list[list[bool]]:
    n=config.grid_size
    mask=[[False]*n for _ in range(n)]
    for s in strokes:
        pts=list(s.points)
        if not pts:
            continue
        if len(pts)==1:
            _mark_disk(mask,pts[0][0]*(n-1),pts[0][1]*(n-1),config.stroke_radius_px)
            continue
        for a,b in zip(pts,pts[1:]):
            ax,ay=a[0]*(n-1),a[1]*(n-1)
            bx,by=b[0]*(n-1),b[1]*(n-1)
            steps=max(1,int(math.ceil(max(abs(bx-ax),abs(by-ay))*2)))
            for i in range(steps+1):
                t=i/steps
                _mark_disk(mask,ax+t*(bx-ax),ay+t*(by-ay),config.stroke_radius_px)
    return mask


def _polyline_length(points):
    return sum(math.hypot(b[0]-a[0],b[1]-a[1]) for a,b in zip(points,points[1:]))


def _is_closed(points, ratio):
    if len(points)<3: return False
    L=_polyline_length(points)
    if L <= 1e-12: return False
    return math.hypot(points[-1][0]-points[0][0],points[-1][1]-points[0][1]) <= ratio*L


def _orient(a,b,c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])


def _on_segment(a,b,p,eps=1e-9):
    return (min(a[0],b[0])-eps <= p[0] <= max(a[0],b[0])+eps and
            min(a[1],b[1])-eps <= p[1] <= max(a[1],b[1])+eps and abs(_orient(a,b,p)) <= eps)


def _segments_intersect(a,b,c,d,eps=1e-9):
    o1,o2,o3,o4=_orient(a,b,c),_orient(a,b,d),_orient(c,d,a),_orient(c,d,b)
    if ((o1>eps and o2<-eps) or (o1<-eps and o2>eps)) and ((o3>eps and o4<-eps) or (o3<-eps and o4>eps)):
        return True
    return (_on_segment(a,b,c,eps) or _on_segment(a,b,d,eps) or _on_segment(c,d,a,eps) or _on_segment(c,d,b,eps))


def _polylines_intersect(pa,pb):
    for a,b in zip(pa,pa[1:]):
        for c,d in zip(pb,pb[1:]):
            if _segments_intersect(a,b,c,d):
                return True
    return False


def _point_in_polygon(p, poly):
    # Even-odd rule; boundary counts as inside.
    x,y=p; inside=False
    n=len(poly)
    if n<3: return False
    for i in range(n):
        a=poly[i]; b=poly[(i+1)%n]
        if _on_segment(a,b,p): return True
        x1,y1=a; x2,y2=b
        cond=((y1>y)!=(y2>y))
        if cond:
            xin=(x2-x1)*(y-y1)/(y2-y1)+x1
            if x < xin: inside=not inside
    return inside


def _closed_relations(strokes: list[StrokeSegment], closure_ratio: float):
    closed=[s for s in strokes if _is_closed(list(s.points),closure_ratio)]
    containment=[]; intersections=[]; disjoint=0
    for i,a in enumerate(closed):
        pa=list(a.points)
        for j in range(i+1,len(closed)):
            b=closed[j]; pb=list(b.points)
            if _polylines_intersect(pa,pb):
                intersections.append((i,j)); continue
            ainb=_point_in_polygon(pa[0],pb)
            bina=_point_in_polygon(pb[0],pa)
            if ainb and not bina:
                containment.append((j,i))  # b contains a
            elif bina and not ainb:
                containment.append((i,j))  # a contains b
            else:
                disjoint += 1
    # depth in containment DAG
    parents={i:[] for i in range(len(closed))}
    for p,c in containment: parents[c].append(p)
    def depth(i,stack=None):
        stack=set() if stack is None else stack
        if i in stack: return 0
        if not parents[i]: return 0
        return 1+max(depth(p,stack|{i}) for p in parents[i])
    maxdepth=max((depth(i) for i in parents),default=0)
    return len(closed), len(containment), maxdepth, len(intersections), disjoint


def snapshot_from_strokes(strokes: list[StrokeSegment], config: TopologyConfig=TopologyConfig()) -> TopologySnapshot:
    mask=rasterize_strokes(strokes,config)
    ink=_components(mask,True,config.fg_connectivity)
    beta0=len(ink)
    bg=_components(mask,False,config.bg_connectivity)
    n=config.grid_size
    holes=0
    for comp in bg:
        touches=any(x==0 or y==0 or x==n-1 or y==n-1 for x,y in comp)
        if not touches: holes += 1
    beta1=holes
    left=right=top=bottom=hspan=vspan=0
    for comp in ink:
        ls=any(x==0 for x,y in comp); rs=any(x==n-1 for x,y in comp)
        ts=any(y==0 for x,y in comp); bs=any(y==n-1 for x,y in comp)
        left+=ls; right+=rs; top+=ts; bottom+=bs
        hspan += int(ls and rs); vspan += int(ts and bs)
    cl,ce,depth,ix,dc=_closed_relations(strokes,config.closure_ratio)
    ink_count=sum(sum(1 for v in row if v) for row in mask)
    frac=ink_count/(n*n)
    return TopologySnapshot(
        beta0=beta0,beta1=beta1,euler=beta0-beta1,
        boundary_touch_counts=(left,right,top,bottom),
        horizontal_spanning_components=hspan,vertical_spanning_components=vspan,
        closed_strokes=cl,containment_edges=ce,max_containment_depth=depth,
        intersection_pairs=ix,disjoint_closed_pairs=dc,ink_fraction=frac
    )


def _new_stroke_relation_direction(strokes: list[StrokeSegment], closure_ratio: float) -> tuple[int,int]:
    """Return (new_contains_existing, new_contained_by_existing) for last stroke.

    This is a temporal-topological relation, not a metric descriptor. It distinguishes
    outer-first from inner-first construction when final containment is identical.
    """
    if len(strokes) < 2:
        return (0,0)
    new=strokes[-1]; pn=list(new.points)
    if not _is_closed(pn,closure_ratio):
        return (0,0)
    contains=inside=0
    for old in strokes[:-1]:
        po=list(old.points)
        if not _is_closed(po,closure_ratio) or _polylines_intersect(po,pn):
            continue
        old_in_new=_point_in_polygon(po[0],pn)
        new_in_old=_point_in_polygon(pn[0],po)
        if old_in_new and not new_in_old: contains += 1
        elif new_in_old and not old_in_new: inside += 1
    return contains,inside


def temporal_topology(strokes: list[StrokeSegment], config: TopologyConfig=TopologyConfig()) -> TemporalTopology:
    snaps=[]; events=[]; prev=TopologySnapshot(0,0,0,(0,0,0,0),0,0,0,0,0,0,0,0.0)
    for i in range(1,len(strokes)+1):
        cur=snapshot_from_strokes(strokes[:i],config); snaps.append(cur)
        ncontains,ninside=_new_stroke_relation_direction(strokes[:i],config.closure_ratio)
        events.append(TopologicalEvent(
            stroke_index=i,
            delta_beta0=cur.beta0-prev.beta0,
            delta_beta1=cur.beta1-prev.beta1,
            delta_closed=cur.closed_strokes-prev.closed_strokes,
            delta_containment=cur.containment_edges-prev.containment_edges,
            delta_intersections=cur.intersection_pairs-prev.intersection_pairs,
            new_contains_existing=ncontains,
            new_contained_by_existing=ninside,
            delta_hspan=cur.horizontal_spanning_components-prev.horizontal_spanning_components,
            delta_vspan=cur.vertical_spanning_components-prev.vertical_spanning_components,
        ))
        prev=cur
    raw="|".join(e.token() for e in events)
    sig="T2:"+hashlib.sha1(raw.encode()).hexdigest()[:16]+":"+raw
    return TemporalTopology(tuple(snaps),tuple(events),sig)


def describe_session(session: EidoSession, config: TopologyConfig=TopologyConfig(), segmenter: StrokeSegmenter|None=None) -> TopologyDescriptor:
    segmenter=segmenter or StrokeSegmenter()
    strokes=segmenter.segment(session)
    final=snapshot_from_strokes(strokes,config)
    temporal=temporal_topology(strokes,config)
    return TopologyDescriptor(config.version,final,temporal)
