from __future__ import annotations
from dataclasses import dataclass
from .schema import EidoSession,EventType,StrokeSegment,RelationDescriptor
from .geometry import shape_signature,segment_features,bbox,bbox_overlap

@dataclass(frozen=True)
class SegmenterConfig:
    version:str='stroke-v1'; resample_n:int=12; quantization_bins:int=8; relation_bins:int=8

class StrokeSegmenter:
    def __init__(self,config:SegmenterConfig=SegmenterConfig()): self.config=config
    def segment(self,session:EidoSession)->list[StrokeSegment]:
        active={}; out=[]; serial=0
        for ev in sorted(session.raw_events,key=lambda e:e.t_us):
            if ev.pointer_id is None or ev.type not in {EventType.START,EventType.MOVE,EventType.END,EventType.CANCEL}: continue
            pid=ev.pointer_id
            if ev.type==EventType.START: active[pid]=[ev]
            elif ev.type==EventType.MOVE and pid in active: active[pid].append(ev)
            elif ev.type in {EventType.END,EventType.CANCEL} and pid in active:
                active[pid].append(ev); es=active.pop(pid)
                pts=[(e.x,e.y) for e in es if e.x is not None and e.y is not None]
                if not pts: continue
                ps=[e.pressure for e in es if e.pressure is not None]; mp=sum(ps)/len(ps) if ps else None
                dur=max(0,(es[-1].t_us-es[0].t_us)/1e6)
                sig,_=shape_signature(pts,self.config.resample_n,self.config.quantization_bins)
                sid=f'{session.session_id}:seg:{serial}'; serial+=1
                out.append(StrokeSegment(sid,session.session_id,pid,es[0].t_us,es[-1].t_us,tuple(pts),mp,tuple(segment_features(pts,dur,mp)),sig))
        return out
    def relations(self,segs:list[StrokeSegment])->list[RelationDescriptor]:
        out=[]; b=self.config.relation_bins
        def qs(v,span=1.0):
            v=max(-span,min(span,v)); return min(b-1,int(((v+span)/(2*span))*b))
        def qp(v,span=2.0):
            v=max(0,min(span,v)); return min(b-1,int((v/span)*b))
        for a,c in zip(segs,segs[1:]):
            ax0,ay0,ax1,ay1=bbox(list(a.points)); bx0,by0,bx1,by1=bbox(list(c.points))
            acx,acy=(ax0+ax1)/2,(ay0+ay1)/2; bcx,bcy=(bx0+bx1)/2,(by0+by1)/2
            dx,dy=bcx-acx,bcy-acy; d=(dx*dx+dy*dy)**0.5; gap=max(0,(c.t_start_us-a.t_end_us)/1e6); ov=bbox_overlap(list(a.points),list(c.points))
            sig=f'R{qs(dx)}.{qs(dy)}.{qp(d,1.5)}.{qp(gap,2.0)}.{qp(ov,1.0)}'
            out.append(RelationDescriptor(a.segment_id,c.segment_id,(dx,dy,d,gap,ov),sig))
        return out
    def tokens(self,session:EidoSession):
        segs=self.segment(session); rels=self.relations(segs); toks=[]
        for i,s in enumerate(segs): toks.append(s.signature if i==0 else rels[i-1].signature+'|'+s.signature)
        return toks,segs
