from __future__ import annotations
from dataclasses import asdict
import math, json
from .schema import EidoSession
from .topological_discovery import TopologicalExample, CrossObserverTopologyEvaluator
from .topology import describe_session


def _poly(kind,cx,cy,r,n=36,phase=0.0):
    if kind=='circle':
        pts=[(cx+r*math.cos(2*math.pi*i/n+phase),cy+r*math.sin(2*math.pi*i/n+phase)) for i in range(n)]
    elif kind=='square':
        pts=[(cx-r,cy-r),(cx+r,cy-r),(cx+r,cy+r),(cx-r,cy+r)]
    elif kind=='diamond':
        pts=[(cx,cy-r),(cx+r,cy),(cx,cy+r),(cx-r,cy)]
    elif kind=='triangle':
        pts=[(cx,cy-r),(cx+r*.92,cy+r*.7),(cx-r*.92,cy+r*.7)]
    else: raise ValueError(kind)
    return pts+[pts[0]]


def _session(sid,strokes):
    ev=[]; t=0
    for pid,pts in enumerate(strokes):
        for j,(x,y) in enumerate(pts):
            typ='START' if j==0 else ('END' if j==len(pts)-1 else 'MOVE')
            ev.append({'type':typ,'t_us':t,'pointer_id':pid,'x':x,'y':y})
            t+=10_000
        t+=40_000
    return EidoSession.from_dict({
        'session_id':sid,'protocol_version':'0.1-R4.5','mode':'RECALL',
        'recommendation_mode':'NONE','started_at':'','raw_events':ev,'state_observations':[]
    })


def necessity_examples():
    # Same T0: two closed components / two holes. T1 differs by containment.
    nested=_session('necessity:nested',[_poly('circle',.5,.5,.34),_poly('square',.5,.5,.14)])
    separate=_session('necessity:separate',[_poly('circle',.28,.5,.16),_poly('square',.72,.5,.16)])
    # Same final T1, different construction order -> T2 differs.
    outer=_poly('diamond',.5,.5,.34); inner=_poly('triangle',.5,.5,.13)
    outer_first=_session('necessity:outer-first',[outer,inner])
    inner_first=_session('necessity:inner-first',[inner,outer])
    return nested,separate,outer_first,inner_first


def make_cross_observer_examples():
    shapes=['circle','square','diamond','triangle']
    out=[]
    for oi in range(6):
        obs=f'obs:{oi}'
        a=shapes[oi%4]; b=shapes[(oi+1)%4]
        # Class NESTED: different geometry by observer, same containment program outer->inner.
        s1=_session(f'{obs}:nested',[_poly(a,.5,.5,.34,phase=.07*oi),_poly(b,.5,.5,.13,phase=.11*oi)])
        # Class SEPARATE: same number of closed strokes / T0, but no containment.
        s2=_session(f'{obs}:separate',[_poly(a,.28,.5,.15,phase=.03*oi),_poly(b,.72,.5,.15,phase=.09*oi)])
        out.append(TopologicalExample(s1.session_id,obs,'class:nested',s1))
        out.append(TopologicalExample(s2.session_id,obs,'class:separate',s2))
    return out


def make_report():
    nested,separate,outer_first,inner_first=necessity_examples()
    dn,ds,do,di=[describe_session(x) for x in (nested,separate,outer_first,inner_first)]
    examples=make_cross_observer_examples()
    transport=CrossObserverTopologyEvaluator(negative_controls=16).evaluate(examples,min_gain=.15)
    return {
        'necessity':{
            'T0_collision':{
                'nested':dn.final.t0_signature(),'separate':ds.final.t0_signature(),
                'equal':dn.final.t0_vector()==ds.final.t0_vector(),
                'T1_equal':dn.final.t1_signature()==ds.final.t1_signature(),
                'interpretation':'T0 cannot distinguish containment from separation; T1 is necessary.'
            },
            'T1_final_collision':{
                'outer_first':do.final.t1_signature(),'inner_first':di.final.t1_signature(),
                'equal':do.final.t1_signature()==di.final.t1_signature(),
                'T2_equal':do.temporal.signature==di.temporal.signature,
                'interpretation':'Final T1 cannot identify construction history; T2 is necessary when history matters.'
            }
        },
        'transport':asdict(transport)
    }
