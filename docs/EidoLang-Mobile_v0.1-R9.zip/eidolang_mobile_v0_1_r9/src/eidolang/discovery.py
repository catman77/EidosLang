from __future__ import annotations
from dataclasses import dataclass
from .schema import EidoSession
from .alphabet import AlphabetInducer, AlphabetConfig
from .grammar import EffectGrammarInducer, GrammarConfig
from .validation import deterministic_split
from .language import DiscoveryReport

@dataclass(frozen=True)
class DiscoveryConfig:
    holdout_fraction: float = 0.25
    alphabet: AlphabetConfig = AlphabetConfig()
    grammar: GrammarConfig = GrammarConfig()

class LanguageDiscovery:
    def __init__(self, config:DiscoveryConfig=DiscoveryConfig()):
        self.config=config
        self.alphabet=AlphabetInducer(config=config.alphabet)
        self.grammar=EffectGrammarInducer(config=config.grammar)

    def fit(self,sessions:list[EidoSession])->DiscoveryReport:
        split=deterministic_split(sessions,self.config.holdout_fraction)
        alphabet=self.alphabet.fit(sessions,split)
        grammar=self.grammar.fit(sessions,alphabet,split)
        notes=[]
        if not alphabet.passed_negative_control_gate:
            notes.append("alphabet negative-control gate not passed")
        if not grammar.passed_negative_control_gate:
            notes.append("grammar negative-control gate not passed")
        return DiscoveryReport(alphabet=alphabet,grammar=grammar,notes=tuple(notes))
