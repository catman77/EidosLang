from __future__ import annotations

from dataclasses import replace
from functools import lru_cache
import numpy as np

from .r6_synthetic import run_r6_dryrun, _remap_alignment
from .r412_dryrun import _alignment_observations
from .effect_alignment import AlignmentConfig, CrossObserverEffectAligner, AnchorObservation
from .prospective_instantiation import (
    DiscoverySelectorObservation, ConfirmationSelectorCandidate,
    freeze_instantiation_rule, R7ConfirmationAnalyzer,
)


def _transforms(report):
    out={report.reference_observer:None}
    for r in report.results:
        if r.status=="PASS":
            out[r.observer_id]=r.transform
    return out


def _selector_profiles(metric_keys):
    c0={"activation":.35,"valence":.25,"clarity":.40,"imagery":.20}
    c1={"activation":-.30,"valence":-.20,"clarity":-.35,"imagery":-.15}
    return (
        {k:c0[k] for k in metric_keys},
        {k:c1[k] for k in metric_keys},
    )


def _selector_alignment(bundle, observer_ids, selector_keys):
    # Independent selector-only anchor channel. This is necessary because an arbitrary
    # 6D R4.7 rotation need not preserve the selector/primary coordinate partition.
    # The synthetic positive control therefore generates selector-anchor responses from
    # their own 4D similarity family and validates it exactly before class matching.
    fit=bundle.r47.fit_anchor_ids
    hold=bundle.r47.holdout_anchor_ids
    d=len(selector_keys)
    if d!=4:
        raise ValueError("R7 synthetic positive control currently expects four selector metrics")
    canon={}
    basis=[
        np.array([.80,.10,0,0]),
        np.array([0,.75,.15,0]),
        np.array([0,0,.85,.10]),
        np.array([.12,0,0,.78]),
        np.array([.35,.22,.18,.10]),
        np.array([-.20,.31,.27,-.15]),
    ]
    for a,v in zip(fit,basis): canon[a]=v
    holdvec=[
        np.array([.30,.20,-.10,.25]),
        np.array([-.15,.28,.32,.12]),
        np.array([.22,-.18,.14,.36]),
    ]
    for a,v in zip(hold,holdvec): canon[a]=v
    rows=[]
    for oi,oid in enumerate(observer_ids):
        perm=list(range(d)); sh=oi%d; perm=perm[sh:]+perm[:sh]
        signs=np.array([(-1 if (j+oi)%3==0 else 1) for j in range(d)])
        P=np.zeros((d,d))
        for j,pj in enumerate(perm): P[j,pj]=signs[j]
        scale=.82+.065*oi
        for ai,a in enumerate(fit+hold):
            local=(canon[a]@P.T)/scale
            # deterministic tiny anchor noise, far below the frozen .02 holdout margin
            eps=np.array([(((oi+1)*(ai+2)*(j+3))%7-3)*1e-5 for j in range(d)])
            local=local+eps
            rows.append(AnchorObservation(
                oid,a,{k:float(v) for k,v in zip(selector_keys,local)},
                f"{oid}:{a}:selector","selector-anchor-v1"
            ))
    b=bundle.r47
    cfg=AlignmentConfig(
        fit_anchor_ids=fit,
        holdout_anchor_ids=hold,
        holdout_rmse_margin=b.holdout_rmse_margin,
        alpha_familywise=.05,
        min_rank=d,
        permutation_cap=b.permutation_cap,
        protocol_version="selector-alignment-v1",
    )
    return cfg,CrossObserverEffectAligner(cfg).align(rows,observer_ids[0])


def make_selector_data(hyp,rule_metric_keys,alignment,primary_classes,discovery=True,add_distractor=False):
    trs=_transforms(alignment)
    profiles=_selector_profiles(rule_metric_keys)
    out=[]
    for c in primary_classes:
        true="H0" if c.macro_name_id.endswith("C0") else "H1"
        pi=0 if true=="H0" else 1
        base=profiles[pi]
        local=[]
        for k in range(3):
            common=dict(base)
            for j,m in enumerate(rule_metric_keys):
                common[m]+=((k-1)*(.0015+j*.0002))
            tr=trs[c.observer_id]
            if tr is None:
                le=dict(common)
            else:
                # Selector alignment is exactly selector-dimensional.
                y=np.array([common[m] for m in tr.metric_keys],dtype=float)
                R=np.array(tr.rotation,dtype=float)
                x=(y/tr.scale)@R.T
                le={m:float(v) for m,v in zip(tr.metric_keys,x)}
            local.append(le)
        refs=tuple(f"selector:{c.observer_id}:{true}:{k}" for k in range(3))
        if discovery:
            out.append(DiscoverySelectorObservation(
                c.observer_id,true,c.macro_name_id,tuple(local),refs
            ))
        else:
            out.append(ConfirmationSelectorCandidate(
                c.observer_id,c.macro_name_id,tuple(local),refs,True
            ))

    if (not discovery) and add_distractor:
        for oid in sorted({c.observer_id for c in primary_classes}):
            tr=trs[oid]
            mid={m:0.0 for m in rule_metric_keys}
            local=[]
            for k in range(3):
                if tr is None:
                    le=dict(mid)
                else:
                    y=np.array([mid[m] for m in tr.metric_keys],dtype=float)
                    R=np.array(tr.rotation,dtype=float)
                    x=(y/tr.scale)@R.T
                    le={m:float(v) for m,v in zip(tr.metric_keys,x)}
                local.append(le)
            out.append(ConfirmationSelectorCandidate(
                oid,f"{oid}:macro:DISTRACTOR",tuple(local),
                tuple(f"selector:{oid}:D:{k}" for k in range(3)),True
            ))
    return out


@lru_cache(maxsize=1)
def run_r7_dryrun():
    vals=run_r6_dryrun()
    m,b,split,ald,rgd,dclasses,dcert,hyp,alc,rgc,cclasses,pkg,r6=vals
    selector_keys=tuple(sorted(k for k in m.state_metric_keys if k not in set(hyp.effect_metric_keys)))
    dcfg,dsel_align=_selector_alignment(b,split.discovery_observers(),selector_keys)
    ccfg,csel_align=_selector_alignment(b,split.confirmation_observers(),selector_keys)
    if not dsel_align.passed or not csel_align.passed:
        raise RuntimeError("synthetic selector alignment failed")
    dsel=make_selector_data(hyp,selector_keys,dsel_align,dclasses,discovery=True)
    rule=freeze_instantiation_rule(
        hyp,dsel_align,rgd,dsel,m.state_metric_keys,
        selector_alignment_ref="synthetic:"+dcfg.protocol_version,
        external_commit_ref="synthetic:r7-instantiation-rule-freeze"
    )
    csel=make_selector_data(hyp,selector_keys,csel_align,cclasses,discovery=False,add_distractor=True)
    r7=R7ConfirmationAnalyzer(
        split,hyp,pkg,rule,csel_align,alc,rgc
    ).certify(dclasses,csel,cclasses)
    return vals,dsel_align,csel_align,dsel,rule,csel,r7
