from .schema import UTCBinding

def bind_operator(operator,mem_object_id,utc_address,confidence=1.0): return UTCBinding(mem_object_id,utc_address,operator.operator_id,float(confidence))
def bind_name(name,mem_object_id,utc_address,confidence=1.0): return UTCBinding(mem_object_id,utc_address,name.name_id,float(confidence))
