from __future__ import annotations
import hashlib
from collections import defaultdict
from dataclasses import dataclass
from .schema import EidoSession
from .segmenter import StrokeSegmenter
from .state import state_delta
from .language import AlphabetSymbol, PersonalAlphabet, SplitManifest
from .validation import deterministic_split, squared_error, mean_vector, permuted_deltas

@dataclass(frozen=True)
class AlphabetConfig:
    min_train_support: int = 2
    min_holdout_support: int = 1
    holdout_fraction: float = 0.25
    negative_controls: int = 16
    protocol_version: str = "alphabet-v2"

class AlphabetInducer:
    """
    Effect-equivalence quotient.

    Two token clusters may merge only when the pooled predictor is no worse on
    holdout than the separate predictors. A resulting symbol is admitted only
    when its holdout predictor beats the global-state baseline.
    """
    def __init__(self, segmenter: StrokeSegmenter|None=None, config: AlphabetConfig=AlphabetConfig()):
        self.segmenter = segmenter or StrokeSegmenter()
        self.config = config

    def _extract(self, sessions: list[EidoSession]):
        toks = {}
        protos = defaultdict(list)
        for s in sessions:
            segs = self.segmenter.segment(s)
            toks[s.session_id] = tuple(seg.signature for seg in segs)
            for seg in segs:
                protos[seg.signature].append(seg.segment_id)
        return toks, protos

    def _fit_core(self, sessions: list[EidoSession], split: SplitManifest, delta_override=None, do_controls=False):
        byid = {s.session_id:s for s in sessions}
        toks, protos = self._extract(sessions)
        deltas = delta_override or {s.session_id:state_delta(s) for s in sessions}
        train_ids, hold_ids = set(split.train_ids), set(split.holdout_ids)

        train_occ=defaultdict(list); hold_occ=defaultdict(list)
        for sid, seq in toks.items():
            dest = train_occ if sid in train_ids else hold_occ
            for tok in set(seq):  # session is unit of evidence; repeated stroke in same session counts once
                if deltas.get(sid):
                    dest[tok].append(sid)

        eligible = sorted(tok for tok in train_occ
                          if len(train_occ[tok]) >= self.config.min_train_support
                          and len(hold_occ.get(tok,[])) >= self.config.min_holdout_support)
        clusters = [{t} for t in eligible]
        global_train = mean_vector([deltas[sid] for sid in split.train_ids if deltas.get(sid)])

        def cluster_train_mean(c):
            sids=sorted(set().union(*(set(train_occ[t]) for t in c)))
            return mean_vector([deltas[sid] for sid in sids])
        def token_pred(c):
            return {t:cluster_train_mean({t}) for t in c}
        def hold_sessions(c):
            # Session, not stroke occurrence, is the statistical unit because R2 has
            # only session-level state deltas. A session containing several members
            # of the same candidate cluster is counted once.
            d=defaultdict(set)
            for t in c:
                for sid in hold_occ.get(t,[]): d[sid].add(t)
            return d
        def loss_separate(c):
            preds=token_pred(c); total=0.0
            for sid,present in hold_sessions(c).items():
                pred=mean_vector([preds[t] for t in sorted(present)])
                total += squared_error(deltas[sid],pred)
            return total
        def loss_merged(c):
            m=cluster_train_mean(c)
            return sum(squared_error(deltas[sid],m) for sid in hold_sessions(c))
        def loss_baseline(c):
            return sum(squared_error(deltas[sid],global_train) for sid in hold_sessions(c))

        # Deterministic agglomeration. Merge only when pooled prediction is
        # holdout-noninferior to keeping clusters separate.
        while True:
            best=None
            for i in range(len(clusters)):
                for j in range(i+1,len(clusters)):
                    ci,cj=clusters[i],clusters[j]
                    # Substitution is not identifiable when one candidate is always
                    # co-present with the other. Require bidirectional exclusive
                    # evidence in both train and holdout before an equivalence merge.
                    tri=set().union(*(set(train_occ[t]) for t in ci))
                    trj=set().union(*(set(train_occ[t]) for t in cj))
                    hoi=set().union(*(set(hold_occ.get(t,[])) for t in ci))
                    hoj=set().union(*(set(hold_occ.get(t,[])) for t in cj))
                    if not (tri-trj and trj-tri and hoi-hoj and hoj-hoi):
                        continue
                    c=ci|cj
                    sep = loss_merged(ci) + loss_merged(cj)
                    mer = loss_merged(c)
                    gain = sep-mer
                    if gain >= -1e-15:
                        key=(gain, -len(c), tuple(sorted(c)))
                        if best is None or key>best[0]: best=(key,i,j,c)
            if best is None: break
            _,i,j,c=best
            clusters=[x for k,x in enumerate(clusters) if k not in {i,j}] + [c]
            clusters.sort(key=lambda x:tuple(sorted(x)))

        symbols=[]; mapping={}; resolved=set(); total_model=0.0; total_base=0.0
        for c in clusters:
            train_sids=sorted(set().union(*(set(train_occ[t]) for t in c)))
            hold_sids=sorted(set().union(*(set(hold_occ.get(t,[])) for t in c)))
            m=cluster_train_mean(c); lm=loss_merged(c); lb=loss_baseline(c)
            # Symbol exists only if it predicts holdout state better than the global baseline.
            if not (lm < lb - 1e-15):
                continue
            digest=hashlib.sha1("\n".join(sorted(c)).encode()).hexdigest()[:12]
            sid=f"alpha:{digest}"
            ps=[]
            for t in sorted(c): ps.extend(protos[t][:2])
            sym=AlphabetSymbol(
                symbol_id=sid, member_tokens=tuple(sorted(c)),
                train_support=len(train_sids), holdout_support=len(hold_sids),
                train_effect=m, holdout_model_loss=lm, holdout_baseline_loss=lb,
                prototype_segment_ids=tuple(ps[:8]), metadata={"merge_size":len(c)}
            )
            symbols.append(sym)
            for t in c: mapping[t]=sid; resolved.add(t)
            total_model += lm; total_base += lb
        unresolved=tuple(sorted(set(t for seq in toks.values() for t in seq)-resolved))
        observed_gain=total_base-total_model
        return symbols,mapping,unresolved,observed_gain

    def fit(self, sessions: list[EidoSession], split: SplitManifest|None=None) -> PersonalAlphabet:
        split=split or deterministic_split(sessions,self.config.holdout_fraction)
        symbols,mapping,unresolved,gain=self._fit_core(sessions,split)
        controls=[]
        for seed in range(self.config.negative_controls):
            pd=permuted_deltas(sessions,seed)
            _,_,_,cg=self._fit_core(sessions,split,delta_override=pd)
            controls.append(cg)
        passed = bool(symbols) and (not controls or gain > max(controls) + 1e-15)
        digest=hashlib.sha1(("|".join(split.train_ids)+"//"+"|".join(split.holdout_ids)).encode()).hexdigest()[:12]
        return PersonalAlphabet(
            alphabet_id=f"alphabet:{digest}", symbols=symbols, token_to_symbol=mapping,
            unresolved_tokens=unresolved, split=split, observed_gain=gain,
            negative_control_gains=tuple(controls), passed_negative_control_gate=passed,
            protocol_version=self.config.protocol_version,
            metadata={"gate":"holdout predictive merge + max label-permutation control"}
        )
