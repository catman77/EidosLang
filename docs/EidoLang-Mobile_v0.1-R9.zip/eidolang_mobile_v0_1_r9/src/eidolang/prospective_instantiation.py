from __future__ import annotations

from dataclasses import dataclass, asdict
from itertools import permutations
from math import sqrt
from typing import Iterable, Optional

from .acquisition import sha256_object
from .effect_alignment import EffectAlignmentReport, SimilarityTransform
from .reliability import ReliabilityGateResult
from .cross_observer_transport import R5CausalClassObservation
from .discovery_confirmation import (
    R6SplitManifest, FrozenTransportHypothesis, ConfirmationPackage,
    R6ConfirmationAnalyzer, R6ConfirmationCertificate,
)


@dataclass(frozen=True)
class DiscoverySelectorObservation:
    observer_id: str
    frozen_class_id: str
    macro_name_id: str
    selector_effects: tuple[dict[str,float], ...]
    selector_certificate_refs: tuple[str, ...]


@dataclass(frozen=True)
class ConfirmationSelectorCandidate:
    observer_id: str
    macro_name_id: str
    selector_effects: tuple[dict[str,float], ...]
    selector_certificate_refs: tuple[str, ...]
    r4_macro_name_passed: bool = True


@dataclass(frozen=True)
class SelectorPrototype:
    frozen_class_id: str
    aligned_selector_vector: tuple[tuple[str,float], ...]


@dataclass(frozen=True)
class FrozenInstantiationRule:
    frozen_hypothesis_hash: str
    source_discovery_observers: tuple[str, ...]
    selector_metric_keys: tuple[str, ...]
    primary_metric_keys: tuple[str, ...]
    frozen_class_ids: tuple[str, ...]
    prototypes: tuple[SelectorPrototype, ...]
    max_assignment_cost: float
    min_assignment_gap: float
    prototype_method: str
    threshold_method: str
    distance_version: str
    selection_version: str
    selector_alignment_ref: str
    external_commit_ref: Optional[str] = None

    def __post_init__(self):
        if set(self.selector_metric_keys) & set(self.primary_metric_keys):
            raise ValueError("selector metrics overlap primary R5 metrics")
        if not self.selector_metric_keys:
            raise ValueError("selector metric set cannot be empty")
        if len(self.frozen_class_ids)!=2:
            raise ValueError("R7 v1 requires two frozen classes")
        if len(set(self.frozen_class_ids))!=2:
            raise ValueError("frozen class ids must be unique")
        if set(p.frozen_class_id for p in self.prototypes)!=set(self.frozen_class_ids):
            raise ValueError("prototype classes mismatch")
        if self.max_assignment_cost < 0 or self.min_assignment_gap < 0:
            raise ValueError("negative selector thresholds")
        if self.prototype_method!="DISCOVERY_ALIGNED_MEAN":
            raise ValueError("unsupported prototype method")
        if self.threshold_method!="DISCOVERY_LOO_COST_R410_UNIT_GAP":
            raise ValueError("unsupported threshold method")
        if self.distance_version!="R410_NORMALIZED_EUCLIDEAN_V1":
            raise ValueError("unsupported distance version")
        if self.selection_version!="EXACT_INJECTIVE_MIN_COST_V1":
            raise ValueError("unsupported selection version")

    @property
    def rule_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class CandidateCost:
    observer_id: str
    frozen_class_id: str
    candidate_macro_name_id: str
    cost: float


@dataclass(frozen=True)
class ObserverInstantiation:
    observer_id: str
    status: str  # PASS | NO_MATCH | AMBIGUOUS | INVALID
    selected: tuple[tuple[str,str], ...] # (frozen_class_id, macro_name_id)
    best_total_cost: Optional[float]
    second_best_total_cost: Optional[float]
    assignment_gap: Optional[float]
    candidate_costs: tuple[CandidateCost, ...]
    reasons: tuple[str, ...]


@dataclass(frozen=True)
class R7InstantiationCertificate:
    rule_hash: str
    observer_results: tuple[ObserverInstantiation, ...]
    status: str
    selected_macro_names: tuple[tuple[str,str,str], ...] # observer, frozen class, macro
    reasons: tuple[str, ...]

    @property
    def certificate_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class R7ConfirmationCertificate:
    certificate_id: str
    instantiation: R7InstantiationCertificate
    r6: R6ConfirmationCertificate
    status: str
    passed: bool
    reasons: tuple[str, ...]
    protocol_version: str = "prospective-instantiation-v1"

    @property
    def certificate_hash(self) -> str:
        return sha256_object(self)


def _transforms(report:EffectAlignmentReport) -> dict[str,Optional[SimilarityTransform]]:
    out={report.reference_observer:None}
    for r in report.results:
        if r.status=="PASS" and r.transform is not None:
            out[r.observer_id]=r.transform
    return out


def _map(effect:dict[str,float], tr:Optional[SimilarityTransform]) -> dict[str,float]:
    return dict(effect) if tr is None else tr.map_delta(effect)


def _mean(effects:tuple[dict[str,float],...], keys:tuple[str,...]) -> dict[str,float]:
    if not effects:
        raise ValueError("empty selector effect set")
    return {k:sum(float(e[k]) for e in effects)/len(effects) for k in keys}


def _distance(a:dict[str,float], b:dict[str,float], keys:tuple[str,...], floors:dict[str,float]) -> float:
    z=0.0
    for k in keys:
        if k not in floors or floors[k]<=0:
            raise ValueError(f"missing/nonpositive reliability floor for selector metric {k}")
        d=(float(a[k])-float(b[k]))/float(floors[k])
        z+=d*d
    return sqrt(z)


def _prototype_dict(rule:FrozenInstantiationRule) -> dict[str,dict[str,float]]:
    return {
        p.frozen_class_id:{k:float(v) for k,v in p.aligned_selector_vector}
        for p in rule.prototypes
    }


def freeze_instantiation_rule(
    hypothesis:FrozenTransportHypothesis,
    discovery_alignment:EffectAlignmentReport,
    discovery_reliability:ReliabilityGateResult,
    observations:Iterable[DiscoverySelectorObservation],
    full_metric_keys:tuple[str,...],
    selector_alignment_ref:str,
    external_commit_ref:Optional[str]=None,
) -> FrozenInstantiationRule:
    primary=tuple(hypothesis.effect_metric_keys)
    selector=tuple(sorted(k for k in full_metric_keys if k not in set(primary)))
    if set(selector)&set(primary) or not selector:
        raise ValueError("cannot construct disjoint selector projection")
    if not discovery_alignment.passed:
        raise ValueError("discovery alignment must PASS before freezing selector rule")
    if discovery_reliability.status!="PASS":
        raise ValueError("discovery reliability must PASS before freezing selector rule")
    trs=_transforms(discovery_alignment)
    for oid,tr in trs.items():
        if tr is not None and set(tr.metric_keys)!=set(selector):
            raise ValueError("discovery selector alignment is not restricted to selector metrics")
    obs=list(observations)
    if set(o.observer_id for o in obs)!=set(hypothesis.source_discovery_observers):
        raise ValueError("selector discovery observers differ from frozen hypothesis source")
    classes=tuple(sorted({o.frozen_class_id for o in obs}))
    if len(classes)!=2:
        raise ValueError("need exactly two discovery selector classes")

    # Exactly one selector observation per discovery observer x frozen class.
    by={}
    for o in obs:
        key=(o.observer_id,o.frozen_class_id)
        if key in by:
            raise ValueError("duplicate discovery selector class observation")
        if o.observer_id not in trs:
            raise ValueError("missing discovery alignment transform")
        if not o.selector_effects:
            raise ValueError("empty selector effects")
        for e in o.selector_effects:
            if set(selector)-set(e):
                raise ValueError("selector effect missing frozen selector metric")
        mapped=tuple(_map(e,trs[o.observer_id]) for e in o.selector_effects)
        by[key]=_mean(mapped,selector)

    expected={(oid,c) for oid in hypothesis.source_discovery_observers for c in classes}
    if set(by)!=expected:
        raise ValueError("discovery selector grid incomplete")

    # Full-discovery prototypes.
    proto={}
    for c in classes:
        proto[c]={k:sum(by[(oid,c)][k] for oid in hypothesis.source_discovery_observers)/
                    len(hypothesis.source_discovery_observers) for k in selector}

    # Deterministic leave-one-observer-out envelope.
    floors=discovery_reliability.common_resolution_floor
    best_costs=[]
    wrong_gaps=[]
    oids=hypothesis.source_discovery_observers
    for held in oids:
        train=[o for o in oids if o!=held]
        loo={}
        for c in classes:
            loo[c]={k:sum(by[(oid,c)][k] for oid in train)/len(train) for k in selector}
        x0=by[(held,classes[0])]; x1=by[(held,classes[1])]
        correct=_distance(x0,loo[classes[0]],selector,floors)+_distance(x1,loo[classes[1]],selector,floors)
        wrong=_distance(x0,loo[classes[1]],selector,floors)+_distance(x1,loo[classes[0]],selector,floors)
        best_costs.append(correct)
        wrong_gaps.append(wrong-correct)

    max_cost=max(best_costs)
    discovery_min_gap=min(wrong_gaps)
    # Distances are already normalized by R4.10 repeatability floors. Therefore one
    # unit is the smallest non-arbitrary separation scale available to the protocol.
    min_gap=1.0
    if discovery_min_gap < min_gap:
        raise ValueError("discovery selector does not separate frozen classes by one R4.10 resolution unit under LOO")

    return FrozenInstantiationRule(
        frozen_hypothesis_hash=hypothesis.hypothesis_hash,
        source_discovery_observers=hypothesis.source_discovery_observers,
        selector_metric_keys=selector,
        primary_metric_keys=primary,
        frozen_class_ids=classes,
        prototypes=tuple(
            SelectorPrototype(c,tuple((k,float(proto[c][k])) for k in selector))
            for c in classes
        ),
        max_assignment_cost=float(max_cost),
        min_assignment_gap=float(min_gap),
        prototype_method="DISCOVERY_ALIGNED_MEAN",
        threshold_method="DISCOVERY_LOO_COST_R410_UNIT_GAP",
        distance_version="R410_NORMALIZED_EUCLIDEAN_V1",
        selection_version="EXACT_INJECTIVE_MIN_COST_V1",
        selector_alignment_ref=selector_alignment_ref,
        external_commit_ref=external_commit_ref,
    )


class ProspectiveClassInstantiator:
    """
    Blind class selection. It receives no T3 objects and no primary R5 endpoint data.
    It sees only selector-effect projections whose metric keys are disjoint from R5.
    """
    def __init__(
        self,
        rule:FrozenInstantiationRule,
        confirmation_alignment:EffectAlignmentReport,
        confirmation_reliability:ReliabilityGateResult,
    ):
        self.rule=rule
        self.alignment=confirmation_alignment
        self.reliability=confirmation_reliability

    def instantiate(self, candidates:Iterable[ConfirmationSelectorCandidate]) -> R7InstantiationCertificate:
        rule=self.rule
        reasons=[]
        if not self.alignment.passed:
            reasons.append("confirmation alignment is not PASS")
        if self.reliability.status!="PASS":
            reasons.append("confirmation reliability is not PASS")
        if reasons:
            return R7InstantiationCertificate(rule.rule_hash,(),"INVALID",(),tuple(reasons))

        trs=_transforms(self.alignment)
        for oid,tr in trs.items():
            if tr is not None and set(tr.metric_keys)!=set(rule.selector_metric_keys):
                reasons.append("confirmation selector alignment is not restricted to selector metrics")
        if reasons:
            return R7InstantiationCertificate(rule.rule_hash,(),"INVALID",(),tuple(reasons))
        proto=_prototype_dict(rule)
        by={}
        for c in candidates:
            by.setdefault(c.observer_id,[]).append(c)

        results=[]
        selected_global=[]
        for oid in self.alignment.aligned_observers:
            cs=by.get(oid,[])
            rs=[]
            if oid not in trs:
                rs.append("missing alignment transform")
            if len(cs)<2:
                rs.append("fewer than two eligible confirmation MacroNames")
            ids=[c.macro_name_id for c in cs]
            if len(ids)!=len(set(ids)):
                rs.append("duplicate candidate MacroName id")
            for c in cs:
                if not c.r4_macro_name_passed:
                    rs.append(f"candidate MacroName not R4 PASS: {c.macro_name_id}")
                if not c.selector_effects:
                    rs.append(f"empty selector effects: {c.macro_name_id}")
                if len(c.selector_certificate_refs)!=len(c.selector_effects):
                    rs.append(f"selector certificate/effect count mismatch: {c.macro_name_id}")
                if len(set(c.selector_certificate_refs))!=len(c.selector_certificate_refs):
                    rs.append(f"duplicate selector certificate refs: {c.macro_name_id}")
                for e in c.selector_effects:
                    # Hard blindness: selector records may contain selector coordinates only.
                    if set(e)!=set(rule.selector_metric_keys):
                        rs.append(f"selector effect schema is not exactly blinded selector projection: {c.macro_name_id}")
            if rs:
                results.append(ObserverInstantiation(oid,"INVALID",(),None,None,None,(),tuple(rs)))
                continue

            mapped={}
            costs=[]
            for c in cs:
                me=tuple(_map(e,trs[oid]) for e in c.selector_effects)
                mv=_mean(me,rule.selector_metric_keys)
                mapped[c.macro_name_id]=mv
                for fc in rule.frozen_class_ids:
                    d=_distance(mv,proto[fc],rule.selector_metric_keys,self.reliability.common_resolution_floor)
                    costs.append(CandidateCost(oid,fc,c.macro_name_id,d))

            cmap={(x.frozen_class_id,x.candidate_macro_name_id):x.cost for x in costs}
            assignments=[]
            # Exact injective mappings of the 2 frozen classes into all eligible candidates.
            for pair in permutations([c.macro_name_id for c in cs],2):
                total=sum(cmap[(fc,mid)] for fc,mid in zip(rule.frozen_class_ids,pair))
                assignments.append((float(total),tuple(zip(rule.frozen_class_ids,pair))))
            assignments.sort(key=lambda x:(x[0],x[1]))
            best_cost,best=assignments[0]
            second_cost=assignments[1][0] if len(assignments)>1 else None
            gap=(second_cost-best_cost) if second_cost is not None else None

            status="PASS"; r=[]
            if best_cost>rule.max_assignment_cost+1e-15:
                status="NO_MATCH"
                r.append("best selector assignment lies outside frozen discovery LOO envelope")
            elif gap is None or gap<rule.min_assignment_gap-1e-15:
                status="AMBIGUOUS"
                r.append("best-vs-second selector assignment gap below frozen discovery LOO separation")
            if status=="PASS":
                for fc,mid in best:
                    selected_global.append((oid,fc,mid))
            results.append(ObserverInstantiation(
                oid,status,best if status=="PASS" else (),
                best_cost,second_cost,gap,tuple(costs),tuple(r)
            ))

        if any(r.status=="INVALID" for r in results):
            status="INVALID"
        elif any(r.status=="AMBIGUOUS" for r in results):
            status="AMBIGUOUS"
        elif any(r.status=="NO_MATCH" for r in results):
            status="NO_MATCH"
        else:
            status="PASS"
        return R7InstantiationCertificate(
            rule.rule_hash,tuple(results),status,
            tuple(sorted(selected_global)),()
        )


def audit_selector_primary_independence(
    instantiation:R7InstantiationCertificate,
    selector_candidates:Iterable[ConfirmationSelectorCandidate],
    primary_classes:Iterable[R5CausalClassObservation],
) -> tuple[str,...]:
    reasons=[]
    sc=list(selector_candidates)
    pc=list(primary_classes)
    selector_refs={r for c in sc for r in c.selector_certificate_refs}
    primary_refs={r for c in pc for r in c.operator_causal_certificate_refs}
    if selector_refs & primary_refs:
        reasons.append("selector and primary R5 causal certificate refs overlap")
    # Ensure R5 receives exactly the MacroNames selected blindly.
    selected={(o,m) for o,fc,m in instantiation.selected_macro_names}
    supplied={(c.observer_id,c.macro_name_id) for c in pc}
    if selected!=supplied:
        reasons.append("primary R5 class set differs from blind-instantiation selection")
    return tuple(reasons)


class R7ConfirmationAnalyzer:
    def __init__(
        self,
        split:R6SplitManifest,
        hypothesis:FrozenTransportHypothesis,
        r6_package:ConfirmationPackage,
        rule:FrozenInstantiationRule,
        confirmation_selector_alignment:EffectAlignmentReport,
        confirmation_primary_alignment:EffectAlignmentReport,
        confirmation_reliability:ReliabilityGateResult,
    ):
        self.split=split
        self.hypothesis=hypothesis
        self.r6_package=r6_package
        self.rule=rule
        self.selector_alignment=confirmation_selector_alignment
        self.primary_alignment=confirmation_primary_alignment
        self.reliability=confirmation_reliability

    def certify(
        self,
        discovery_primary_classes:Iterable[R5CausalClassObservation],
        selector_candidates:Iterable[ConfirmationSelectorCandidate],
        all_confirmation_primary_classes:Iterable[R5CausalClassObservation],
    ) -> R7ConfirmationCertificate:
        reasons=[]
        if self.rule.frozen_hypothesis_hash!=self.hypothesis.hypothesis_hash:
            reasons.append("instantiation rule does not bind frozen discovery hypothesis")
        inst=ProspectiveClassInstantiator(self.rule,self.selector_alignment,self.reliability).instantiate(selector_candidates)
        if inst.status!="PASS":
            reasons.append(f"prospective class instantiation did not PASS: {inst.status}")

        # Seal primary R5 input until after instantiation: select only by MacroName IDs.
        selected_ids={(o,m) for o,fc,m in inst.selected_macro_names}
        allp=list(all_confirmation_primary_classes)
        selected=[c for c in allp if (c.observer_id,c.macro_name_id) in selected_ids]
        if inst.status=="PASS":
            reasons.extend(audit_selector_primary_independence(inst,selector_candidates,selected))

        if reasons:
            # Use R6 analyzer only after selector gate; do not compute R5 on invalid selection.
            from .cross_observer_transport import R5TransportCertificate
            from .discovery_confirmation import LeakageAudit, R6ConfirmationCertificate
            dummy=R5TransportCertificate(
                "r5:not-run",self.r6_package.r5_config.config_hash,
                self.r6_package.r5_config.reference_observer_id,
                self.r6_package.r5_config.observer_ids,
                None,None,0,False,None,self.r6_package.r5_config.alpha_local,
                (),(),"INVALID",False,("R7 prerequisite failure",),
                self.r6_package.r5_config.protocol_version
            )
            audit=LeakageAudit("FAIL",tuple(reasons),
                self.split.discovery_observers(),self.split.confirmation_observers(),(),())
            r6=R6ConfirmationCertificate(
                "r6:not-run",self.split.manifest_hash,self.hypothesis.hypothesis_hash,
                self.r6_package.package_hash,audit,dummy,"INVALID",False,tuple(reasons)
            )
            return R7ConfirmationCertificate(
                "r7:invalid",inst,r6,"INVALID",False,tuple(reasons)
            )

        r6=R6ConfirmationAnalyzer(
            self.split,self.hypothesis,self.r6_package,self.primary_alignment,self.reliability
        ).certify(discovery_primary_classes,selected)
        passed=r6.passed
        status="PASS" if passed else r6.status
        rs=() if passed else (f"independent R6/R5 confirmation failed: {r6.status}",)
        cid="r7:"+sha256_object({
            "rule":self.rule.rule_hash,
            "instantiation":inst.certificate_hash,
            "r6":r6.certificate_hash,
        })[:16]
        return R7ConfirmationCertificate(cid,inst,r6,status,passed,rs)
