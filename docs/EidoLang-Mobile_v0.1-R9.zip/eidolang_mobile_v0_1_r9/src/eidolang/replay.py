from __future__ import annotations
from dataclasses import dataclass
import math, statistics, hashlib
from typing import Iterable

from .schema import EidoSession
from .segmenter import StrokeSegmenter
from .geometry import normalize_bbox, polyline_length, bbox
from .language import EffectGrammarRule, PersonalAlphabet
from .grammar import EffectGrammarInducer
from .causal import ReplayTemplate, MatchedControl


@dataclass(frozen=True)
class ReplayConfig:
    protocol_version: str = "replay-template-v3"
    control_match_version: str = "zscore-motor-v1"


def _template_profile(segs) -> dict[str,float]:
    if not segs:
        return {"stroke_count":0.0,"total_length":0.0,"duration_s":0.0,"mean_speed":0.0,
                "mean_pressure":0.0,"bbox_area":0.0,"relation_count":0.0}
    lengths=[polyline_length(list(s.points)) for s in segs]
    total_length=sum(lengths)
    t0=min(s.t_start_us for s in segs); t1=max(s.t_end_us for s in segs)
    duration=max(0.0,(t1-t0)/1_000_000.0)
    speeds=[]
    for s,l in zip(segs,lengths):
        ds=max(1e-12,(s.t_end_us-s.t_start_us)/1_000_000.0)
        speeds.append(l/ds)
    pressures=[s.mean_pressure for s in segs if s.mean_pressure is not None]
    pts=[p for s in segs for p in s.points]
    x0,y0,x1,y1=bbox(pts)
    return {
        "stroke_count":float(len(segs)),
        "total_length":total_length,
        "duration_s":duration,
        "mean_speed":sum(speeds)/len(speeds),
        "mean_pressure":sum(pressures)/len(pressures) if pressures else 0.0,
        "bbox_area":max(0.0,x1-x0)*max(0.0,y1-y0),
        "relation_count":float(max(0,len(segs)-1)),
    }


class ReplayTemplateBuilder:
    def __init__(self, segmenter:StrokeSegmenter|None=None, config:ReplayConfig=ReplayConfig()):
        self.segmenter=segmenter or StrokeSegmenter(); self.config=config

    def from_session(self, session:EidoSession, pattern_ref:str="session") -> ReplayTemplate:
        segs=self.segmenter.segment(session)
        strokes=tuple(tuple(normalize_bbox(list(s.points))) for s in segs)
        digest=hashlib.sha1((session.session_id+"|"+pattern_ref).encode()).hexdigest()[:12]
        return ReplayTemplate(
            template_id=f"template:{digest}", source_session_id=session.session_id,
            pattern_ref=pattern_ref, strokes=strokes, motor_profile=_template_profile(segs),
            metadata={"segment_ids":[s.segment_id for s in segs],"protocol_version":self.config.protocol_version}
        )

    def from_rule(self, rule:EffectGrammarRule, alphabet:PersonalAlphabet, sessions:list[EidoSession]) -> ReplayTemplate:
        byid={s.session_id:s for s in sessions}
        # Holdout evidence is preferred so the replay template is not selected for having trained the rule.
        for sid in rule.evidence_refs:
            if sid in byid:
                return self.from_session(byid[sid], pattern_ref=rule.rule_id)
        raise ValueError("rule has no materializable evidence session")


class MatchedControlBuilder:
    """
    Selects controls using low-level motor geometry only; state outcomes are never read.
    Candidate sessions containing the target grammar rule are excluded.
    """
    def __init__(self, segmenter:StrokeSegmenter|None=None, config:ReplayConfig=ReplayConfig()):
        self.segmenter=segmenter or StrokeSegmenter(); self.config=config
        self.tb=ReplayTemplateBuilder(self.segmenter,config)

    def _contains_rule(self,s:EidoSession,rule:EffectGrammarRule,alphabet:PersonalAlphabet)->bool:
        seq=EffectGrammarInducer(self.segmenter).sequence(s,alphabet)
        n=len(rule.pattern)
        return any(tuple(seq[i:i+n])==rule.pattern for i in range(max(0,len(seq)-n+1)))

    def match_rule(self, target:ReplayTemplate, rule:EffectGrammarRule,
                   alphabet:PersonalAlphabet, sessions:list[EidoSession]) -> tuple[ReplayTemplate,MatchedControl]:
        candidates=[]
        for s in sessions:
            if s.session_id==target.source_session_id: continue
            if self._contains_rule(s,rule,alphabet): continue
            candidates.append(self.tb.from_session(s,pattern_ref="matched-control"))
        if not candidates:
            raise ValueError("no rule-negative control session available")
        keys=tuple(sorted(target.motor_profile))
        pool=[target]+candidates
        means={k:sum(t.motor_profile[k] for t in pool)/len(pool) for k in keys}
        sds={}
        for k in keys:
            vals=[t.motor_profile[k] for t in pool]
            if len(vals)>1:
                m=means[k]; sd=math.sqrt(sum((v-m)**2 for v in vals)/(len(vals)-1))
            else: sd=0.0
            sds[k]=sd
        def d(t):
            total=0.0
            used=0
            for k in keys:
                sd=sds[k]
                if sd<=1e-12: continue
                total += ((target.motor_profile[k]-t.motor_profile[k])/sd)**2
                used += 1
            return math.sqrt(total/used) if used else 0.0
        best=min(candidates,key=lambda t:(d(t),t.template_id))
        mc=MatchedControl(target.template_id,best.template_id,d(best),keys,self.config.control_match_version)
        return best,mc
