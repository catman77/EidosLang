from __future__ import annotations

from dataclasses import dataclass, asdict
from itertools import combinations, permutations
from math import factorial, sqrt
from typing import Iterable, Optional

from .schema import EidoSession
from .multilayer_topology import MultilayerConfig, describe_multilayer_session
from .effect_alignment import EffectAlignmentReport, SimilarityTransform
from .reliability import ReliabilityGateResult
from .acquisition import sha256_object


@dataclass(frozen=True)
class R5CausalClassObservation:
    observer_id: str
    local_class_id: str
    macro_name_id: str
    macro_name_passed: bool
    realization_sessions: tuple[EidoSession, ...]
    operator_effects: tuple[dict[str, float], ...]
    operator_causal_certificate_refs: tuple[str, ...]
    substitution_certificate_refs: tuple[str, ...]
    topology_representation: str = "T3"


@dataclass(frozen=True)
class R5TransportConfig:
    observer_ids: tuple[str, ...]
    reference_observer_id: str
    causal_class_count: int
    realizations_per_class: int
    effect_metric_keys: tuple[str, ...]
    alpha_local: float
    exact_cap: int
    topology_representation: str = "T3"
    topology_extractor_version: str = "multilayer-topology-v1"
    statistic_version: str = "pairing-orientation-product-v1"
    protocol_version: str = "cross-observer-transport-v1"

    def __post_init__(self):
        if len(self.observer_ids) < 2:
            raise ValueError("need >=2 observers")
        if self.reference_observer_id not in self.observer_ids:
            raise ValueError("reference observer absent")
        if self.causal_class_count != 2:
            raise ValueError("R5 v1 is the preregistered binary-class test")
        if self.realizations_per_class < 2:
            raise ValueError("need >=2 causal realizations/class")
        if not self.effect_metric_keys:
            raise ValueError("effect_metric_keys cannot be empty")
        if not (0 < self.alpha_local < 1):
            raise ValueError("alpha_local must be in (0,1)")
        if self.exact_cap < 1:
            raise ValueError("exact_cap must be positive")
        if self.topology_representation != "T3":
            raise ValueError("R5 v1 primary representation is frozen to T3")

    @property
    def config_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class PairOrientation:
    observer_a: str
    observer_b: str
    topology_same_cost: float
    topology_cross_cost: float
    topology_orientation: float
    effect_same_cost: float
    effect_cross_cost: float
    effect_orientation: float
    observed_contribution: float


@dataclass(frozen=True)
class R5TransportCertificate:
    certificate_id: str
    config_hash: str
    reference_observer_id: str
    observer_ids: tuple[str, ...]
    observed_statistic: Optional[float]
    exact_p_value: Optional[float]
    exact_conventions: int
    exact_test_completed: bool
    p_floor: Optional[float]
    alpha_local: float
    pair_orientations: tuple[PairOrientation, ...]
    null_statistics: tuple[float, ...]
    status: str
    passed: bool
    reasons: tuple[str, ...]
    protocol_version: str


def _feature_scales(vectors: list[tuple[float, ...]]) -> tuple[float, ...]:
    if not vectors:
        return ()
    d=len(vectors[0])
    out=[]
    for j in range(d):
        vals=[float(v[j]) for v in vectors]
        span=max(vals)-min(vals)
        out.append(span if span>1e-12 else 1.0)
    return tuple(out)


def _feature_distance(a,b,scales):
    if len(a)!=len(b) or len(a)!=len(scales):
        raise ValueError("T3 vector dimension mismatch")
    return sum(abs(float(x)-float(y))/float(s) for x,y,s in zip(a,b,scales))/max(1,len(scales))


def _multiset_distance(a: tuple[str,...], b: tuple[str,...]) -> float:
    from collections import Counter
    ca,cb=Counter(a),Counter(b)
    keys=set(ca)|set(cb)
    num=sum(abs(ca[k]-cb[k]) for k in keys)
    den=max(1,sum(ca.values())+sum(cb.values()))
    return num/den


@dataclass(frozen=True)
class _T3Realization:
    vector: tuple[float, ...]
    color_multiset: tuple[str, ...]
    media_multiset: tuple[str, ...]


def _t3_repr(session:EidoSession, cfg:MultilayerConfig) -> _T3Realization:
    d=describe_multilayer_session(session,cfg)
    return _T3Realization(
        tuple(float(x) for x in d.t3_vector()),
        tuple(d.anonymous_color_signatures),
        tuple(d.media_form_couplings),
    )


def _realization_distance(a:_T3Realization,b:_T3Realization,scales) -> float:
    # Frozen R4.6 weighting; R5 does not fit a new representation metric.
    return (
        .55*_feature_distance(a.vector,b.vector,scales)
        + .25*_multiset_distance(a.color_multiset,b.color_multiset)
        + .20*_multiset_distance(a.media_multiset,b.media_multiset)
    )


def _class_distance(a:tuple[_T3Realization,...],b:tuple[_T3Realization,...],scales) -> float:
    if len(a)!=len(b):
        raise ValueError("class realization counts differ")
    n=len(a)
    if n==0:
        raise ValueError("empty causal class topology")
    # MacroName members are an unordered all-pairs causal clique. Therefore topology
    # comparison minimizes only over bijections; no realization is dropped.
    best=None
    for perm in permutations(range(n)):
        d=sum(_realization_distance(a[i],b[perm[i]],scales) for i in range(n))/n
        if best is None or d<best:
            best=d
    return float(best)


def _orientation(same:float,cross:float) -> float:
    den=same+cross
    if den<=1e-15:
        return 0.0
    return (cross-same)/den


def _euclid(a:dict[str,float],b:dict[str,float],keys:tuple[str,...],floors:dict[str,float]) -> float:
    s=0.0
    for k in keys:
        f=float(floors[k])
        if f<=0:
            raise ValueError(f"non-positive reliability floor for {k}")
        z=(float(a[k])-float(b[k]))/f
        s+=z*z
    return sqrt(s)


def _mean_effect(effects:tuple[dict[str,float],...],keys:tuple[str,...]) -> dict[str,float]:
    if not effects:
        raise ValueError("empty operator effect set")
    return {k:sum(float(e[k]) for e in effects)/len(effects) for k in keys}


def _transforms(report:EffectAlignmentReport) -> dict[str,Optional[SimilarityTransform]]:
    out={report.reference_observer:None}
    for r in report.results:
        if r.status=="PASS" and r.transform is not None:
            out[r.observer_id]=r.transform
    return out


def _map_effect(effect:dict[str,float], tr:Optional[SimilarityTransform]) -> dict[str,float]:
    return dict(effect) if tr is None else tr.map_delta(effect)


class R5CrossObserverTransportAnalyzer:
    """
    Exact binary cross-observer test.

    Each observer contributes two unordered R4 causal MacroNames. The primary statistic
    compares which of the two possible class correspondences is cheaper in T3 topology
    and in aligned causal-effect space.

    For observer pair i,j:
        A_ij = (T_cross - T_same)/(T_cross + T_same)
        B_ij = (E_cross - E_same)/(E_cross + E_same)

    S = mean_{i<j} A_ij B_ij.

    Swapping local class order flips A and B together, so S is invariant to local naming.
    Under the null, effect pairing is independently flipped relative to topology for each
    observer. A flip s_i in {-1,+1} sends B_ij -> s_i s_j B_ij.
    Global sign reversal leaves every s_i s_j unchanged, hence the exact null quotient has
    2^(O-1) conventions.
    """
    def __init__(
        self,
        config:R5TransportConfig,
        alignment_report:EffectAlignmentReport,
        reliability:ReliabilityGateResult,
        multilayer_config:MultilayerConfig=MultilayerConfig(),
    ):
        self.config=config
        self.alignment_report=alignment_report
        self.reliability=reliability
        self.multilayer_config=multilayer_config

    def _validate(self, classes:list[R5CausalClassObservation]) -> list[str]:
        cfg=self.config
        reasons=[]
        if not self.alignment_report.passed:
            reasons.append("R4.7 effect alignment report is not PASS")
        if set(self.alignment_report.aligned_observers)!=set(cfg.observer_ids):
            reasons.append("R4.7 aligned observer set differs from R5 preregistration")
        if self.reliability.status!="PASS":
            reasons.append("R4.10 reliability gate is not PASS")
        for k in cfg.effect_metric_keys:
            if k not in self.reliability.common_resolution_floor:
                reasons.append(f"missing R4.10 resolution floor for {k}")

        by={}
        all_sessions=set()
        for c in classes:
            by.setdefault(c.observer_id,[]).append(c)
            if not c.macro_name_passed:
                reasons.append(f"unpassed R4 MacroName: {c.observer_id}/{c.local_class_id}")
            if c.topology_representation!=cfg.topology_representation:
                reasons.append(f"topology representation mismatch: {c.observer_id}/{c.local_class_id}")
            if len(c.realization_sessions)!=cfg.realizations_per_class:
                reasons.append(f"wrong topology realization count: {c.observer_id}/{c.local_class_id}")
            if len(c.operator_effects)!=cfg.realizations_per_class:
                reasons.append(f"wrong operator-effect count: {c.observer_id}/{c.local_class_id}")
            if len(c.operator_causal_certificate_refs)!=cfg.realizations_per_class:
                reasons.append(f"wrong R3 certificate-ref count: {c.observer_id}/{c.local_class_id}")
            expected_pairs=cfg.realizations_per_class*(cfg.realizations_per_class-1)//2
            if len(c.substitution_certificate_refs)!=expected_pairs:
                reasons.append(f"wrong R4 pair-certificate count: {c.observer_id}/{c.local_class_id}")
            if len(set(c.operator_causal_certificate_refs))!=len(c.operator_causal_certificate_refs):
                reasons.append(f"duplicate R3 certificate refs: {c.observer_id}/{c.local_class_id}")
            if len(set(c.substitution_certificate_refs))!=len(c.substitution_certificate_refs):
                reasons.append(f"duplicate R4 pair refs: {c.observer_id}/{c.local_class_id}")
            for e in c.operator_effects:
                for k in cfg.effect_metric_keys:
                    if k not in e:
                        reasons.append(f"operator effect missing {k}: {c.observer_id}/{c.local_class_id}")
            for s in c.realization_sessions:
                if s.session_id in all_sessions:
                    reasons.append(f"topology realization session reused: {s.session_id}")
                all_sessions.add(s.session_id)

        if set(by)!=set(cfg.observer_ids):
            reasons.append("R5 observer set differs from preregistration")
        for o in cfg.observer_ids:
            xs=by.get(o,[])
            if len(xs)!=cfg.causal_class_count:
                reasons.append(f"observer {o} has {len(xs)} classes, expected {cfg.causal_class_count}")
            if len({x.local_class_id for x in xs})!=len(xs):
                reasons.append(f"duplicate local class id for observer {o}")
            if len({x.macro_name_id for x in xs})!=len(xs):
                reasons.append(f"duplicate MacroName for observer {o}")
        return reasons

    def certify(self, classes:Iterable[R5CausalClassObservation]) -> R5TransportCertificate:
        cfg=self.config
        xs=list(classes)
        reasons=self._validate(xs)
        if reasons:
            return R5TransportCertificate(
                "r5:invalid",cfg.config_hash,cfg.reference_observer_id,cfg.observer_ids,
                None,None,0,False,None,cfg.alpha_local,(),(),"INVALID",False,tuple(reasons),cfg.protocol_version
            )

        nconv=2**(len(cfg.observer_ids)-1)
        p_floor=1.0/nconv
        if nconv>cfg.exact_cap:
            return R5TransportCertificate(
                "r5:unresolved",cfg.config_hash,cfg.reference_observer_id,cfg.observer_ids,
                None,None,nconv,False,p_floor,cfg.alpha_local,(),(),"UNRESOLVED",False,
                (f"exact observer convention space {nconv} > cap {cfg.exact_cap}",),cfg.protocol_version
            )

        # Precompute T3 of every causal realization and a completely label-free scaling.
        t3_by={}
        all_vectors=[]
        for c in xs:
            rs=tuple(_t3_repr(s,self.multilayer_config) for s in c.realization_sessions)
            t3_by[(c.observer_id,c.local_class_id)]=rs
            all_vectors.extend(r.vector for r in rs)
        scales=_feature_scales(all_vectors)

        # R4.7 transform each operator's causal effect before symmetric class averaging.
        trs=_transforms(self.alignment_report)
        if set(trs)!=set(cfg.observer_ids):
            return R5TransportCertificate(
                "r5:invalid-transform",cfg.config_hash,cfg.reference_observer_id,cfg.observer_ids,
                None,None,0,False,None,cfg.alpha_local,(),(),"INVALID",False,
                ("not every R5 observer has a passed R4.7 transform",),cfg.protocol_version
            )
        class_effect={}
        for c in xs:
            tr=trs[c.observer_id]
            mapped=tuple(_map_effect(e,tr) for e in c.operator_effects)
            # transform is defined on full R4.7 coordinates; primary R5 statistic then
            # projects only to compiler-frozen causal endpoint coordinates.
            keys_full=tuple(next(iter(mapped)).keys())
            class_effect[(c.observer_id,c.local_class_id)]=_mean_effect(mapped,keys_full)

        by={}
        for c in xs:
            by.setdefault(c.observer_id,[]).append(c)
        for o in by:
            by[o]=sorted(by[o],key=lambda c:c.local_class_id)

        floors=self.reliability.common_resolution_floor
        po=[]
        for oa,ob in combinations(cfg.observer_ids,2):
            a0,a1=by[oa]; b0,b1=by[ob]
            ta0=t3_by[(oa,a0.local_class_id)]; ta1=t3_by[(oa,a1.local_class_id)]
            tb0=t3_by[(ob,b0.local_class_id)]; tb1=t3_by[(ob,b1.local_class_id)]
            t00=_class_distance(ta0,tb0,scales); t11=_class_distance(ta1,tb1,scales)
            t01=_class_distance(ta0,tb1,scales); t10=_class_distance(ta1,tb0,scales)
            ts=t00+t11; tc=t01+t10; A=_orientation(ts,tc)

            ea0=class_effect[(oa,a0.local_class_id)]; ea1=class_effect[(oa,a1.local_class_id)]
            eb0=class_effect[(ob,b0.local_class_id)]; eb1=class_effect[(ob,b1.local_class_id)]
            e00=_euclid(ea0,eb0,cfg.effect_metric_keys,floors)
            e11=_euclid(ea1,eb1,cfg.effect_metric_keys,floors)
            e01=_euclid(ea0,eb1,cfg.effect_metric_keys,floors)
            e10=_euclid(ea1,eb0,cfg.effect_metric_keys,floors)
            es=e00+e11; ec=e01+e10; B=_orientation(es,ec)
            po.append(PairOrientation(oa,ob,ts,tc,A,es,ec,B,A*B))

        observed=sum(p.observed_contribution for p in po)/len(po)
        ref=cfg.reference_observer_id
        nonref=[o for o in cfg.observer_ids if o!=ref]
        null=[]
        for code in range(1<<len(nonref)):
            signs={ref:1}
            for i,o in enumerate(nonref):
                signs[o]=-1 if ((code>>i)&1) else 1
            s=sum(
                p.topology_orientation*(signs[p.observer_a]*signs[p.observer_b]*p.effect_orientation)
                for p in po
            )/len(po)
            null.append(float(s))
        extreme=sum(s>=observed-1e-15 for s in null)
        p=extreme/len(null)
        passed=bool(observed>0 and p<=cfg.alpha_local)
        status="PASS" if passed else "FAIL"
        digest=sha256_object({
            "config":cfg.config_hash,
            "macro_names":sorted(c.macro_name_id for c in xs),
            "sessions":sorted(s.session_id for c in xs for s in c.realization_sessions),
        })[:16]
        rs=[]
        if not passed:
            rs.append(f"primary exact gate failed: S={observed:.6g}, p={p:.6g}, alpha={cfg.alpha_local:.6g}")
        return R5TransportCertificate(
            f"r5:{digest}",cfg.config_hash,cfg.reference_observer_id,cfg.observer_ids,
            observed,p,len(null),True,p_floor,cfg.alpha_local,tuple(po),tuple(null),
            status,passed,tuple(rs),cfg.protocol_version
        )
