from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from math import comb
from typing import Iterable, Optional

from .acquisition import (
    AcquisitionLedger, DataFreezeCertificate, sha256_object,
)
from .schema import EidoSession, EidoOperator
from .operators import MinerConfig, OperatorMiner
from .substitution import (
    CertifiedOperatorRef, SubstitutionCertificate, EquivalenceStatus,
    CausalMacroName, CausalMacroNameBuilder,
)


R3_STATUSES = {"PASS", "FAIL", "UNRESOLVED", "INVALID"}
R4_STATUSES = {"PASS", "FAIL", "UNRESOLVED", "INVALID"}


@dataclass(frozen=True)
class R3Disposition:
    operator_id: str
    operator_object_hash: str
    causal_certificate_id: str
    status: str
    domain_id: str
    probe_schedule_id: str
    causal_protocol_version: str = "causal-replay-v3"

    def __post_init__(self):
        if self.status not in R3_STATUSES:
            raise ValueError("unsupported R3 disposition status")
        if not self.operator_id or not self.causal_certificate_id:
            raise ValueError("operator/certificate ids cannot be empty")


@dataclass(frozen=True)
class R4PairDisposition:
    pair_id: str
    left_operator_id: str
    right_operator_id: str
    left_causal_certificate_id: str
    right_causal_certificate_id: str
    substitution_certificate_id: str
    status: str
    domain_id: str
    probe_schedule_id: str
    policy_hash: str
    protocol_version: str = "causal-substitution-v4"

    def __post_init__(self):
        if self.status not in R4_STATUSES:
            raise ValueError("unsupported R4 disposition status")
        a,b=sorted((self.left_operator_id,self.right_operator_id))
        if self.pair_id != f"{a}::{b}":
            raise ValueError("pair_id must be canonical sorted operator pair")
        if (self.left_operator_id,self.right_operator_id)!=(a,b):
            raise ValueError("R4 pair endpoints must be stored in sorted order")


@dataclass(frozen=True)
class CandidateUniverseConfig:
    observer_id: str
    data_freeze_hash: str
    miner_min_support: int
    miner_max_ngram: int
    miner_protocol_version: str
    domain_id: str
    probe_schedule_id: str
    causal_protocol_version: str
    substitution_policy_hash: str
    substitution_protocol_version: str
    macro_size: int
    max_operator_candidates: int = 10_000
    max_pair_dispositions: int = 200_000
    max_clique_combinations: int = 1_000_000
    enumeration_version: str = "candidate-universe-closure-v1"

    def __post_init__(self):
        if self.miner_min_support < 1:
            raise ValueError("miner_min_support must be >=1")
        if self.miner_max_ngram < 1:
            raise ValueError("miner_max_ngram must be >=1")
        if self.macro_size < 2:
            raise ValueError("macro_size must be >=2")
        if min(self.max_operator_candidates,self.max_pair_dispositions,self.max_clique_combinations)<1:
            raise ValueError("enumeration caps must be positive")

    @property
    def config_hash(self) -> str:
        return sha256_object(self)

    def miner_config(self) -> MinerConfig:
        return MinerConfig(
            min_support=self.miner_min_support,
            max_ngram=self.miner_max_ngram,
            protocol_version=self.miner_protocol_version,
        )


@dataclass(frozen=True)
class MacroCandidate:
    macro_name: CausalMacroName
    operator_object_hashes: tuple[str,...]

    @property
    def macro_name_id(self) -> str:
        return self.macro_name.name_id


@dataclass(frozen=True)
class CandidateUniverseCertificate:
    certificate_id: str
    config_hash: str
    observer_id: str
    source_data_freeze_hash: str
    source_ledger_root: str
    source_session_ids: tuple[str,...]
    source_session_root: str
    mined_operator_count: int
    mined_operator_ids: tuple[str,...]
    r3_pass_count: int
    expected_r4_pair_count: int
    registered_r4_pair_count: int
    clique_combinations_tested: int
    eligible_macro_names: tuple[MacroCandidate,...]
    candidate_set_root: str
    status: str
    complete: bool
    reasons: tuple[str,...]
    scope_statement: str

    @property
    def eligible_macro_name_ids(self) -> tuple[str,...]:
        return tuple(x.macro_name_id for x in self.eligible_macro_names)

    @property
    def certificate_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class CandidateSetAudit:
    status: str
    reasons: tuple[str,...]
    expected_by_observer: tuple[tuple[str,tuple[str,...]],...]
    supplied_by_observer: tuple[tuple[str,tuple[str,...]],...]

    @property
    def audit_hash(self) -> str:
        return sha256_object(self)


def _operator_hash(op:EidoOperator) -> str:
    return sha256_object(op)


def _source_root(sessions:Iterable[EidoSession]) -> str:
    return sha256_object(tuple(sorted((s.session_id,sha256_object(s)) for s in sessions)))


def freeze_generic_candidate_ledger(
    study_id:str,
    protocol_hash:str,
    observer_id:str,
    ledger:AcquisitionLedger,
    sessions_by_id:dict[str,EidoSession],
    exclusions:dict[str,str]|None=None,
    external_commit_ref:Optional[str]=None,
) -> DataFreezeCertificate:
    ok,reason=ledger.verify(sessions_by_id)
    if not ok:
        raise ValueError("candidate ledger invalid: "+reason)
    ex=exclusions or {}
    if set(ex)-set(sessions_by_id):
        raise ValueError("candidate exclusions reference unknown session")
    return DataFreezeCertificate(
        study_id=study_id,
        protocol_hash=protocol_hash,
        data_root=ledger.data_root,
        ledger_length=len(ledger.entries),
        enrolled_observers=(observer_id,),
        excluded_session_ids=tuple(sorted(ex)),
        exclusion_reasons=tuple(sorted((k,str(v)) for k,v in ex.items())),
        external_commit_ref=external_commit_ref,
    )


class ExhaustiveCandidateUniverseEnumerator:
    """
    Extensional closure relative to a frozen raw-session ledger and frozen grammar/policies.

    PASS means exactly:
      1) every OperatorMiner candidate from every non-excluded ledger session has one R3 disposition;
      2) every compatible pair of R3-PASS operators has one R4 disposition;
      3) every q-subset is enumerated; every all-PASS clique becomes a candidate MacroName;
      4) no operator, pair, or clique is sampled or manually omitted.

    It does NOT prove the frozen OperatorMiner grammar is semantically complete.
    """
    def __init__(self,config:CandidateUniverseConfig):
        self.config=config

    def certify(
        self,
        ledger:AcquisitionLedger,
        freeze:DataFreezeCertificate,
        sessions_by_id:dict[str,EidoSession],
        r3_dispositions:Iterable[R3Disposition],
        r4_pair_dispositions:Iterable[R4PairDisposition],
    ) -> CandidateUniverseCertificate:
        cfg=self.config
        reasons=[]
        status="PASS"

        if freeze.freeze_hash!=cfg.data_freeze_hash:
            reasons.append("candidate-universe config does not bind supplied data freeze")
        if freeze.data_root!=ledger.data_root or freeze.ledger_length!=len(ledger.entries):
            reasons.append("data freeze does not bind supplied candidate ledger")
        if cfg.observer_id not in freeze.enrolled_observers:
            reasons.append("observer absent from candidate data freeze")
        ok,why=ledger.verify(sessions_by_id)
        if not ok:
            reasons.append("candidate ledger verification failed: "+why)
        ledger_ids=tuple(e.session_id for e in ledger.entries)
        if set(sessions_by_id)!=set(ledger_ids):
            reasons.append("sessions_by_id must equal the complete frozen ledger session set")

        excluded=set(freeze.excluded_session_ids)
        included_ids=tuple(sid for sid in ledger_ids if sid not in excluded)
        source=[sessions_by_id[sid] for sid in included_ids if sid in sessions_by_id]
        sroot=_source_root(source)

        if reasons:
            return self._failed("INVALID",reasons,ledger,freeze,included_ids,sroot)

        mined=OperatorMiner(config=cfg.miner_config()).mine(source)
        mined=sorted(mined,key=lambda x:x.operator_id)
        if len(mined)>cfg.max_operator_candidates:
            return self._failed(
                "UNRESOLVED",
                [f"mined operator count {len(mined)} exceeds cap {cfg.max_operator_candidates}"],
                ledger,freeze,included_ids,sroot,mined=mined,
            )
        if len({o.operator_id for o in mined})!=len(mined):
            return self._failed("INVALID",["OperatorMiner emitted duplicate operator ids"],ledger,freeze,included_ids,sroot,mined=mined)

        mined_map={o.operator_id:o for o in mined}
        r3=list(r3_dispositions)
        if len({x.operator_id for x in r3})!=len(r3):
            reasons.append("duplicate R3 dispositions")
        r3map={x.operator_id:x for x in r3}
        missing=set(mined_map)-set(r3map)
        extra=set(r3map)-set(mined_map)
        if missing:
            reasons.append("missing R3 dispositions for mined operators: "+",".join(sorted(missing)))
        if extra:
            reasons.append("R3 registry contains operators outside frozen miner output: "+",".join(sorted(extra)))
        for oid in set(mined_map)&set(r3map):
            if r3map[oid].operator_object_hash!=_operator_hash(mined_map[oid]):
                reasons.append(f"R3 disposition operator hash mismatch: {oid}")
            if r3map[oid].causal_protocol_version!=cfg.causal_protocol_version:
                reasons.append(f"R3 causal protocol mismatch: {oid}")

        if reasons:
            return self._failed("INVALID",reasons,ledger,freeze,included_ids,sroot,mined=mined)

        eligible=[]
        for oid,d in sorted(r3map.items()):
            if d.status=="PASS" and d.domain_id==cfg.domain_id and d.probe_schedule_id==cfg.probe_schedule_id:
                eligible.append(d)
        epass={d.operator_id:d for d in eligible}

        expected_pairs={f"{a}::{b}" for a,b in combinations(sorted(epass),2)}
        if len(expected_pairs)>cfg.max_pair_dispositions:
            return self._failed(
                "UNRESOLVED",
                [f"required R4 pair count {len(expected_pairs)} exceeds cap {cfg.max_pair_dispositions}"],
                ledger,freeze,included_ids,sroot,mined=mined,r3_pass_count=len(epass),
                expected_pair_count=len(expected_pairs),
            )

        r4=list(r4_pair_dispositions)
        if len({x.pair_id for x in r4})!=len(r4):
            reasons.append("duplicate R4 pair dispositions")
        r4map={x.pair_id:x for x in r4}
        missing=expected_pairs-set(r4map)
        extra=set(r4map)-expected_pairs
        if missing:
            reasons.append("missing R4 dispositions for compatible R3-PASS pairs: "+",".join(sorted(missing)))
        if extra:
            reasons.append("R4 registry contains pairs outside frozen compatible-pair universe: "+",".join(sorted(extra)))
        for pid in expected_pairs & set(r4map):
            d=r4map[pid]
            a,b=pid.split("::",1)
            if d.left_causal_certificate_id!=epass[a].causal_certificate_id or d.right_causal_certificate_id!=epass[b].causal_certificate_id:
                reasons.append(f"R4 pair causal-certificate refs mismatch: {pid}")
            if d.domain_id!=cfg.domain_id or d.probe_schedule_id!=cfg.probe_schedule_id:
                reasons.append(f"R4 domain/schedule mismatch: {pid}")
            if d.policy_hash!=cfg.substitution_policy_hash:
                reasons.append(f"R4 policy hash mismatch: {pid}")
            if d.protocol_version!=cfg.substitution_protocol_version:
                reasons.append(f"R4 protocol mismatch: {pid}")
        if reasons:
            return self._failed(
                "INVALID",reasons,ledger,freeze,included_ids,sroot,mined=mined,
                r3_pass_count=len(epass),expected_pair_count=len(expected_pairs),registered_pair_count=len(r4),
            )

        n=len(epass)
        combos=comb(n,cfg.macro_size) if n>=cfg.macro_size else 0
        if combos>cfg.max_clique_combinations:
            return self._failed(
                "UNRESOLVED",
                [f"q-clique combination count {combos} exceeds cap {cfg.max_clique_combinations}"],
                ledger,freeze,included_ids,sroot,mined=mined,
                r3_pass_count=n,expected_pair_count=len(expected_pairs),registered_pair_count=len(r4),
                clique_combinations_tested=0,
            )

        macros=[]
        builder=CausalMacroNameBuilder()
        for ops in combinations(sorted(epass),cfg.macro_size):
            pids=[f"{a}::{b}" for a,b in combinations(ops,2)]
            edges=[r4map[p] for p in pids]
            if not all(e.status=="PASS" for e in edges):
                continue
            refs=[CertifiedOperatorRef(
                operator_id=o,
                causal_certificate_id=epass[o].causal_certificate_id,
                causal_certificate_passed=True,
                domain_id=cfg.domain_id,
                probe_schedule_id=cfg.probe_schedule_id,
                causal_protocol_version=cfg.causal_protocol_version,
            ) for o in ops]
            certs=[]
            for e in edges:
                certs.append(SubstitutionCertificate(
                    certificate_id=e.substitution_certificate_id,
                    pair_id=e.pair_id,
                    left_operator_id=e.left_operator_id,
                    right_operator_id=e.right_operator_id,
                    left_causal_certificate_id=e.left_causal_certificate_id,
                    right_causal_certificate_id=e.right_causal_certificate_id,
                    domain_id=e.domain_id,
                    probe_schedule_id=e.probe_schedule_id,
                    policy_hash=e.policy_hash,
                    estimates=(),
                    passed=True,
                    status=EquivalenceStatus.PASS,
                    protocol_version=e.protocol_version,
                    notes=("R8 registry stub: disposition already certified upstream",),
                ))
            macro=builder.build(refs,certs)
            macros.append(MacroCandidate(
                macro,
                tuple(_operator_hash(mined_map[o]) for o in macro.operator_ids),
            ))
        macros=tuple(sorted(macros,key=lambda x:x.macro_name_id))
        root=sha256_object(tuple((m.macro_name_id,m.macro_name.operator_ids,m.macro_name.pair_certificate_ids) for m in macros))
        scope=(
            "complete only relative to the frozen data freeze, OperatorMiner grammar/config, "
            "R3 domain+probe gate, R4 substitution policy/protocol, and fixed MacroName size"
        )
        cid="r8univ:"+sha256_object({
            "config":cfg.config_hash,"source":sroot,"candidate_root":root,
        })[:16]
        return CandidateUniverseCertificate(
            cid,cfg.config_hash,cfg.observer_id,freeze.freeze_hash,ledger.data_root,
            included_ids,sroot,len(mined),tuple(o.operator_id for o in mined),len(epass),
            len(expected_pairs),len(r4),combos,macros,root,"PASS",True,(),scope
        )

    def _failed(
        self,status,reasons,ledger,freeze,included_ids,sroot,
        mined=(),r3_pass_count=0,expected_pair_count=0,registered_pair_count=0,
        clique_combinations_tested=0,
    ):
        cfg=self.config
        root=sha256_object(())
        cid="r8univ:"+sha256_object({
            "config":cfg.config_hash,"source":sroot,"status":status,"reasons":tuple(reasons)
        })[:16]
        return CandidateUniverseCertificate(
            cid,cfg.config_hash,cfg.observer_id,freeze.freeze_hash,ledger.data_root,
            tuple(included_ids),sroot,len(mined),tuple(o.operator_id for o in mined),
            r3_pass_count,expected_pair_count,registered_pair_count,clique_combinations_tested,
            (),root,status,False,tuple(reasons),
            "closure not established"
        )


def audit_selector_candidate_universe(
    certificates:Iterable[CandidateUniverseCertificate],
    selector_candidates:Iterable[object],
) -> CandidateSetAudit:
    certs=list(certificates)
    reasons=[]
    bycert={}
    for c in certs:
        if c.observer_id in bycert:
            reasons.append(f"duplicate candidate-universe certificate for {c.observer_id}")
        bycert[c.observer_id]=c
        if c.status!="PASS" or not c.complete:
            reasons.append(f"candidate-universe closure not PASS for {c.observer_id}")

    supplied={}
    for x in selector_candidates:
        oid=str(x.observer_id); mid=str(x.macro_name_id)
        supplied.setdefault(oid,[]).append(mid)
    for oid,ids in supplied.items():
        if len(ids)!=len(set(ids)):
            reasons.append(f"duplicate selector candidate MacroName for {oid}")

    expected={oid:set(c.eligible_macro_name_ids) for oid,c in bycert.items()}
    actual={oid:set(ids) for oid,ids in supplied.items()}
    if set(expected)!=set(actual):
        reasons.append("selector candidate observer set differs from closure-certificate observer set")
    for oid in sorted(set(expected)|set(actual)):
        miss=expected.get(oid,set())-actual.get(oid,set())
        extra=actual.get(oid,set())-expected.get(oid,set())
        if miss:
            reasons.append(f"selector omitted eligible MacroNames for {oid}: "+",".join(sorted(miss)))
        if extra:
            reasons.append(f"selector contains MacroNames outside closed universe for {oid}: "+",".join(sorted(extra)))

    exp_tuple=tuple(sorted((o,tuple(sorted(v))) for o,v in expected.items()))
    act_tuple=tuple(sorted((o,tuple(sorted(v))) for o,v in actual.items()))
    return CandidateSetAudit("PASS" if not reasons else "FAIL",tuple(reasons),exp_tuple,act_tuple)
