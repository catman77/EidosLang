from __future__ import annotations
import math, random
import numpy as np
from .effect_alignment import AnchorObservation, AlignmentConfig, CrossObserverEffectAligner

def make_alignment_observations(n_observers: int=6, bad_observer: str|None=None, seed: int=47):
    rng=random.Random(seed)
    anchors={
        'F0':(.80,.10),'F1':(-.70,.20),'F2':(.15,.85),
        'F3':(-.20,-.75),'F4':(.65,-.55),'F5':(-.55,.65),
        'H0':(.35,.42),'H1':(-.43,-.31),'H2':(.72,.51),
    }
    out=[]
    for oi in range(n_observers):
        obs=f'O{oi}'; angle=.22*oi; c,s=math.cos(angle),math.sin(angle)
        R=np.array([[c,-s],[s,c]],dtype=float)
        if oi%2: R[:,0]*=-1
        scale=.75+.11*oi
        for aid,(x,y) in anchors.items():
            canon=np.array([x,y],float)
            local=(canon@R.T)/scale
            local += np.array([rng.uniform(-.003,.003),rng.uniform(-.003,.003)])
            if bad_observer==obs and aid.startswith('H'):
                local=np.array([local[0]+.30*local[1]*local[1], local[1]-.25*local[0]*local[0]])
            out.append(AnchorObservation(obs,aid,{'focus':float(local[0]),'noise':float(local[1])},f'{obs}:{aid}','anchor-synthetic-v1'))
    return out

def _cfg():
    return AlignmentConfig(
        fit_anchor_ids=('F0','F1','F2','F3','F4','F5'),
        holdout_anchor_ids=('H0','H1','H2'),
        holdout_rmse_margin=.02,
        alpha_familywise=.05,
        permutation_cap=10_000,
    )

def run_positive_control():
    return CrossObserverEffectAligner(_cfg()).align(make_alignment_observations(),'O0')

def run_nonlinear_counterexample():
    return CrossObserverEffectAligner(_cfg()).align(make_alignment_observations(bad_observer='O5'),'O0')
