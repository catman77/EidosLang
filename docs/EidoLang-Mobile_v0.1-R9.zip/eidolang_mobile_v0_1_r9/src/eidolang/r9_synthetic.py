from __future__ import annotations
from dataclasses import replace
from itertools import combinations
import copy

from .r8_synthetic import run_r8_dryrun, build_observer_candidate_universe, candidate_source_sessions, SHAPES, _session
from .grammar_adequacy import (
    GrammarAdequacyConfig, GrammarAdequacyAnalyzer, RawProgramCausalDisposition,
    RawProgramPairDisposition, raw_program_hash, raw_program_id,
)
from .operators import OperatorMiner, MinerConfig
from .segmenter import StrokeSegmenter
from .candidate_universe import R3Disposition,R4PairDisposition,CandidateUniverseConfig,ExhaustiveCandidateUniverseEnumerator,freeze_generic_candidate_ledger
from .acquisition import AcquisitionLedger, sha256_object
from .r9_confirmation import R9AdequacyGatedConfirmationAnalyzer


def _program_groups(sessions,min_support=3):
    gs={}
    for s in sessions: gs.setdefault(raw_program_hash(s),[]).append(s)
    return {h:rows for h,rows in gs.items() if len(rows)>=min_support}


def make_adequacy_registry(cfg,ledger,freeze,byid,r8_cert,pair_status_override=None,effect_override=None):
    source=[byid[e.session_id] for e in ledger.entries if e.session_id not in set(freeze.excluded_session_ids)]
    groups=_program_groups(source,cfg.raw_program_min_support)
    miner=OperatorMiner(config=cfg.miner_config()).mine(source)
    seg=StrokeSegmenter()
    progs={}
    for h,rows in groups.items():
        toks=tuple(seg.tokens(rows[0])[0])
        addr=tuple(sorted(o.operator_id for o in miner if any(tuple(toks[i:i+len(o.pattern)])==tuple(o.pattern) for i in range(len(toks)-len(o.pattern)+1))))
        pid=raw_program_id(h); progs[pid]=(h,rows,toks,addr)
    causal=[]
    for i,pid in enumerate(sorted(progs)):
        h,rows,toks,addr=progs[pid]
        eff={"focus":.20+.05*i,"noise":-(.20+.05*i)}
        if effect_override and pid in effect_override: eff=dict(effect_override[pid])
        causal.append(RawProgramCausalDisposition(pid,h,f"rawcausal:{cfg.observer_id}:{pid}","PASS",eff,cfg.domain_id,cfg.probe_schedule_id,cfg.raw_causal_protocol_version))
    cmap={d.program_id:d for d in causal}
    pair=[]
    grouped={}
    for pid,(h,rows,toks,addr) in progs.items():
        if addr: grouped.setdefault(addr,[]).append(pid)
    for addr,pids in grouped.items():
        for a,b in combinations(sorted(pids),2):
            st="PASS"
            if pair_status_override:
                st=pair_status_override.get(f"{a}::{b}",st)
            pair.append(RawProgramPairDisposition(
                f"{a}::{b}",a,b,cmap[a].causal_certificate_id,cmap[b].causal_certificate_id,
                f"rawsubst:{cfg.observer_id}:{a}:{b}",st,cfg.domain_id,cfg.probe_schedule_id,
                cfg.raw_pair_policy_hash,cfg.raw_pair_protocol_version))
    return tuple(causal),tuple(pair),progs


def adequacy_for_r8_source(source_objects,observer,policy_hash):
    cfg8,ledger,freeze,byid,r3,r4,r8,mg=source_objects[observer]
    cfg=GrammarAdequacyConfig(observer,r8.certificate_hash,freeze.freeze_hash,
        cfg8.miner_min_support,cfg8.miner_max_ngram,cfg8.miner_protocol_version,3,
        cfg8.domain_id,cfg8.probe_schedule_id,"raw-program-causal-replay-v1",
        policy_hash,"raw-program-substitution-v1",100,1000)
    causal,pairs,progs=make_adequacy_registry(cfg,ledger,freeze,byid,r8)
    cert=GrammarAdequacyAnalyzer(cfg).certify(ledger,freeze,byid,r8,causal,pairs)
    return cfg,causal,pairs,cert


def collision_universe(observer="COLLISION",root="root",policy_hash="policy"):
    # Add an exact replayable raw program with a small bend. It has the same frozen S-token
    # as g0_diag under 12-point/8-bin shape_signature, but a different exact raw-program hash.
    sessions=candidate_source_sessions(observer)
    bent=((.10,.10),(.50,.52),(.90,.90))
    sessions += [_session(observer,"g0_diag_bent",bent,rep) for rep in range(3)]
    byid={s.session_id:s for s in sessions}; ledger=AcquisitionLedger(root)
    for s in sessions: ledger.append(s)
    freeze=freeze_generic_candidate_ledger("r9-collision",root,observer,ledger,byid)
    miner_cfg=MinerConfig(3,1,"operator-miner-v1")
    mined=OperatorMiner(config=miner_cfg).mine(sessions)
    # Give all mined operators R3 PASS. R4 status is arbitrary for R9; complete registry is required by R8.
    r3=[R3Disposition(o.operator_id,sha256_object(o),f"r3:{observer}:{o.operator_id}","PASS","domain:shared","probe:2phase","causal-replay-v3") for o in mined]
    r3m={x.operator_id:x for x in r3}; r4=[]
    for a,b in combinations(sorted(r3m),2):
        r4.append(R4PairDisposition(f"{a}::{b}",a,b,r3m[a].causal_certificate_id,r3m[b].causal_certificate_id,
            f"subst:{observer}:{a}:{b}","FAIL","domain:shared","probe:2phase",policy_hash,"causal-substitution-v4"))
    cfg8=CandidateUniverseConfig(observer,freeze.freeze_hash,3,1,"operator-miner-v1","domain:shared","probe:2phase","causal-replay-v3",
        policy_hash,"causal-substitution-v4",3,100,1000,1000)
    r8=ExhaustiveCandidateUniverseEnumerator(cfg8).certify(ledger,freeze,byid,r3,r4)
    if r8.status!="PASS": raise RuntimeError(r8)
    cfg=GrammarAdequacyConfig(observer,r8.certificate_hash,freeze.freeze_hash,3,1,"operator-miner-v1",3,"domain:shared","probe:2phase",
        "raw-program-causal-replay-v1",policy_hash,"raw-program-substitution-v1",100,1000)
    causal,pairs,progs=make_adequacy_registry(cfg,ledger,freeze,byid,r8)
    # Locate the one grammar-address collision and certify it substitution-FAIL with sharply different effects.
    grouped={}
    seg=StrokeSegmenter(); mined2=OperatorMiner(config=cfg.miner_config()).mine(sessions)
    for pid,(h,rows,toks,addr) in progs.items(): grouped.setdefault(addr,[]).append(pid)
    coll=[sorted(v) for k,v in grouped.items() if k and len(v)>1]
    if len(coll)!=1 or len(coll[0])!=2: raise RuntimeError(f"expected one 2-program collision, got {coll}")
    a,b=coll[0]
    eff={a:{"focus":.45,"noise":-.45},b:{"focus":-.30,"noise":.30}}
    causal,pairs,progs=make_adequacy_registry(cfg,ledger,freeze,byid,r8,{f"{a}::{b}":"FAIL"},eff)
    cert=GrammarAdequacyAnalyzer(cfg).certify(ledger,freeze,byid,r8,causal,pairs)
    return cfg8,ledger,freeze,byid,tuple(r3),tuple(r4),r8,cfg,causal,pairs,progs,cert


def unrepresented_universe(observer="UNREP",root="root2",policy_hash="policy"):
    # A program repeated three times but without source state observations is replayable and
    # can have an independent raw causal certificate, while OperatorMiner cannot mine it
    # because its discovery support counts only sessions carrying deltas.
    sessions=candidate_source_sessions(observer)
    pts=((.18,.18),(.30,.75),(.82,.68))
    for rep in range(3):
        s=_session(observer,"orphan",pts,rep)
        s.state_observations=[]
        sessions.append(s)
    byid={s.session_id:s for s in sessions}; ledger=AcquisitionLedger(root)
    for s in sessions: ledger.append(s)
    freeze=freeze_generic_candidate_ledger("r9-unrepresented",root,observer,ledger,byid)
    mined=OperatorMiner(config=MinerConfig(3,1,"operator-miner-v1")).mine(sessions)
    r3=[R3Disposition(o.operator_id,sha256_object(o),f"r3:{observer}:{o.operator_id}","PASS","domain:shared","probe:2phase","causal-replay-v3") for o in mined]
    r3m={x.operator_id:x for x in r3}; r4=[]
    for a,b in combinations(sorted(r3m),2):
        r4.append(R4PairDisposition(f"{a}::{b}",a,b,r3m[a].causal_certificate_id,r3m[b].causal_certificate_id,
            f"subst:{observer}:{a}:{b}","FAIL","domain:shared","probe:2phase",policy_hash,"causal-substitution-v4"))
    cfg8=CandidateUniverseConfig(observer,freeze.freeze_hash,3,1,"operator-miner-v1","domain:shared","probe:2phase","causal-replay-v3",policy_hash,"causal-substitution-v4",3,100,1000,1000)
    r8=ExhaustiveCandidateUniverseEnumerator(cfg8).certify(ledger,freeze,byid,r3,r4)
    if r8.status!="PASS": raise RuntimeError(r8)
    cfg=GrammarAdequacyConfig(observer,r8.certificate_hash,freeze.freeze_hash,3,1,"operator-miner-v1",3,"domain:shared","probe:2phase","raw-program-causal-replay-v1",policy_hash,"raw-program-substitution-v1",100,1000)
    causal,pairs,progs=make_adequacy_registry(cfg,ledger,freeze,byid,r8)
    # All raw programs, including orphan, are independently causal-PASS in the diagnostic registry.
    cert=GrammarAdequacyAnalyzer(cfg).certify(ledger,freeze,byid,r8,causal,pairs)
    return cfg8,ledger,freeze,byid,tuple(r3),tuple(r4),r8,cfg,causal,pairs,progs,cert


def run_r9_dryrun():
    data=run_r8_dryrun()
    vals,dsa,csa,dsel,rule,csel,cclasses,pkg,universes,sources,r8=data
    m,b,split,ald,rgd,dclasses,dcert,hyp,alc,rgc,oldc,oldpkg,oldr6=vals
    policy=b.r4.as_substitution_policy().policy_hash()
    adeq=[]; registries={}
    for oid in split.confirmation_observers():
        x=adequacy_for_r8_source(sources,oid,policy); registries[oid]=x; adeq.append(x[-1])
    r9=R9AdequacyGatedConfirmationAnalyzer(split,hyp,pkg,rule,csa,alc,rgc,universes,adeq).certify(dclasses,csel,cclasses)
    collision=collision_universe(policy_hash=policy)
    unrepresented=unrepresented_universe(policy_hash=policy)
    return data,tuple(adeq),registries,r9,collision,unrepresented
