from __future__ import annotations
from functools import lru_cache

import copy
from dataclasses import replace

from .r412_dryrun import dryrun_master, _alignment_observations, _reliability_observations
from .protocol_compiler import ProtocolCompiler
from .effect_alignment import AlignmentConfig, CrossObserverEffectAligner
from .reliability import ReliabilityManifest, reliability_gate
from .cross_observer_transport import R5TransportConfig, R5CrossObserverTransportAnalyzer
from .r5_synthetic import make_r5_dryrun_inputs
from .discovery_confirmation import (
    R6SplitManifest, freeze_transport_hypothesis, ConfirmationPackage,
    R6ConfirmationAnalyzer,
)


def _remap_alignment(rows, target_ids):
    src=tuple(sorted({r.observer_id for r in rows}))
    if len(src)!=len(target_ids):
        raise ValueError("profile count mismatch")
    mp=dict(zip(src,target_ids))
    out=[]
    for r in rows:
        out.append(replace(
            r,observer_id=mp[r.observer_id],
            source_ref=f"{mp[r.observer_id]}:{r.anchor_id}",
        ))
    return out


def _align(bundle, rows, observer_ids):
    b=bundle.r47
    cfg=AlignmentConfig(
        fit_anchor_ids=b.fit_anchor_ids,
        holdout_anchor_ids=b.holdout_anchor_ids,
        holdout_rmse_margin=b.holdout_rmse_margin,
        alpha_familywise=.05,
        min_rank=b.min_rank,
        permutation_cap=b.permutation_cap,
        protocol_version=b.protocol_version,
    )
    return CrossObserverEffectAligner(cfg).align(rows,observer_ids[0])


def _remap_reliability_manifest(base, observer_ids):
    return ReliabilityManifest(
        study_id=base.study_id,
        protocol_hash=base.protocol_hash,
        manifest_version=base.manifest_version,
        observer_ids=tuple(observer_ids),
        anchor_ids=base.anchor_ids,
        metric_keys=base.metric_keys,
        repeats_per_anchor=base.repeats_per_anchor,
        alpha_repeatability=base.alpha_repeatability,
        alpha_drift=base.alpha_drift,
        max_repeatability_radius=dict(base.max_repeatability_radius),
        quantization_step=dict(base.quantization_step),
        pairing_policy=base.pairing_policy,
        unreliable_metric_policy=base.unreliable_metric_policy,
        external_commit_ref=base.external_commit_ref,
    )


def _remap_reliability(rows,target_ids):
    src=tuple(sorted({r.observer_id for r in rows}))
    mp=dict(zip(src,target_ids))
    return [replace(
        r,observer_id=mp[r.observer_id],
        session_id=f"{mp[r.observer_id]}:{r.anchor_id}:{r.repeat_index}",
    ) for r in rows]


def _r5_config(bundle, observer_ids):
    b=bundle.r5
    return R5TransportConfig(
        observer_ids=tuple(observer_ids),
        reference_observer_id=observer_ids[0],
        causal_class_count=b.causal_class_count,
        realizations_per_class=b.realizations_per_class,
        effect_metric_keys=b.effect_metric_keys,
        alpha_local=b.alpha_local,
        exact_cap=b.exact_cap,
        topology_representation=b.topology_representation,
        topology_extractor_version=b.topology_extractor_version,
        statistic_version=b.statistic_version,
        protocol_version=b.protocol_version,
    )


def _remap_classes(base_classes,target_ids):
    src=tuple(sorted({x.observer_id for x in base_classes}))
    mp=dict(zip(src,target_ids))
    out=[]
    for x in base_classes:
        old=x.observer_id; new=mp[old]
        sessions=[]
        for s in x.realization_sessions:
            s2=copy.deepcopy(s)
            s2.session_id=s2.session_id.replace(old,new,1)
            sessions.append(s2)
        out.append(replace(
            x,
            observer_id=new,
            macro_name_id=x.macro_name_id.replace(old,new,1),
            realization_sessions=tuple(sessions),
            operator_causal_certificate_refs=tuple(r.replace(old,new,1) for r in x.operator_causal_certificate_refs),
            substitution_certificate_refs=tuple(r.replace(old,new,1) for r in x.substitution_certificate_refs),
        ))
    return out


@lru_cache(maxsize=1)
def run_r6_dryrun():
    master=dryrun_master()
    bundle=ProtocolCompiler().compile(master)

    all_obs=tuple(f"R6O{i:02d}" for i in range(12))
    split=R6SplitManifest(
        study_id="r6-dryrun",
        root_protocol_hash=bundle.master_hash,
        observer_ids=all_obs,
        discovery_count=6,
        split_seed="r6-frozen-cohort-split",
        minimum_confirmation_observers=6,
    )
    disc=split.discovery_observers()
    conf=split.confirmation_observers()

    base_alignment_rows=_alignment_observations(bundle)
    base_alignment=_align(bundle,base_alignment_rows,tuple(f"O{i}" for i in range(6)))
    base_classes=make_r5_dryrun_inputs(bundle,base_alignment)
    base_rel_rows=_reliability_observations(master,bundle)

    # Discovery cohort: independent IDs, independent alignment/reliability records,
    # fresh local MacroName/session/certificate IDs.
    drows=_remap_alignment(base_alignment_rows,disc)
    dalign=_align(bundle,drows,disc)
    drel_manifest=_remap_reliability_manifest(bundle.reliability,disc)
    dreliability=reliability_gate(drel_manifest,_remap_reliability(base_rel_rows,disc))
    dclasses=_remap_classes(base_classes,disc)
    dcfg=_r5_config(bundle,disc)
    dcert=R5CrossObserverTransportAnalyzer(dcfg,dalign,dreliability).certify(dclasses)

    hypothesis=freeze_transport_hypothesis(
        split,dcfg,
        discovery_macro_name_refs=[x.macro_name_id for x in dclasses],
        discovery_evidence_refs=[dcert.certificate_id],
        external_commit_ref="synthetic:discovery-freeze",
    )

    # Confirmation cohort is generated from the same synthetic population mechanism only;
    # all identity-bearing evidence objects are fresh and disjoint.
    crows=_remap_alignment(base_alignment_rows,conf)
    calign=_align(bundle,crows,conf)
    crel_manifest=_remap_reliability_manifest(bundle.reliability,conf)
    creliability=reliability_gate(crel_manifest,_remap_reliability(base_rel_rows,conf))
    cclasses=_remap_classes(base_classes,conf)
    ccfg=_r5_config(bundle,conf)

    package=ConfirmationPackage(
        split_manifest_hash=split.manifest_hash,
        frozen_hypothesis_hash=hypothesis.hypothesis_hash,
        confirmation_observers=conf,
        r5_config=ccfg,
        confirmation_data_freeze_ref="synthetic:confirmation-data-freeze",
        confirmation_alignment_ref="synthetic:confirmation-alignment-pass",
        confirmation_reliability_ref="synthetic:confirmation-reliability-pass",
        confirmation_class_refs=tuple(sorted(x.macro_name_id for x in cclasses)),
        compiler_runtime_lock_hash=bundle.runtime_lock_hash,
        external_commit_ref="synthetic:confirmation-package-freeze",
    )

    r6=R6ConfirmationAnalyzer(
        split,hypothesis,package,calign,creliability
    ).certify(dclasses,cclasses)

    return (
        master,bundle,split,
        dalign,dreliability,dclasses,dcert,hypothesis,
        calign,creliability,cclasses,package,r6,
    )
