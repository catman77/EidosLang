from __future__ import annotations
import hashlib
import math
from dataclasses import dataclass
from .schema import EidoSession
from .language import SplitManifest
from .state import state_delta


def deterministic_split(sessions: list[EidoSession], holdout_fraction: float = 0.25, version: str = "sha256-rank-v1") -> SplitManifest:
    if not 0.0 < holdout_fraction < 1.0:
        raise ValueError("holdout_fraction must be in (0,1)")
    ids = sorted({s.session_id for s in sessions}, key=lambda x: hashlib.sha256(x.encode()).hexdigest())
    if len(ids) < 2:
        raise ValueError("at least two sessions are required")
    nh = max(1, min(len(ids)-1, int(round(len(ids)*holdout_fraction))))
    holdout = tuple(ids[:nh])
    train = tuple(ids[nh:])
    return SplitManifest(train, holdout, version)


def squared_error(y: dict[str,float], pred: dict[str,float]) -> float:
    keys = set(y) | set(pred)
    return sum((y.get(k,0.0)-pred.get(k,0.0))**2 for k in keys)


def mean_vector(vs: list[dict[str,float]]) -> dict[str,float]:
    if not vs:
        return {}
    keys = sorted(set().union(*(v.keys() for v in vs)))
    return {k: sum(v.get(k,0.0) for v in vs)/len(vs) for k in keys}


def permuted_deltas(sessions: list[EidoSession], seed: int) -> dict[str,dict[str,float]]:
    """Deterministic label permutation preserving the empirical delta distribution."""
    ids = sorted(s.session_id for s in sessions)
    vals = {s.session_id: state_delta(s) for s in sessions}
    ranked = sorted(ids, key=lambda sid: hashlib.sha256(f"{seed}:{sid}".encode()).hexdigest())
    # A non-zero cyclic shift prevents fixed identity permutations.
    shift = 1 + (seed % max(1, len(ids)-1)) if len(ids) > 1 else 0
    donor = ranked[shift:] + ranked[:shift]
    return {ranked[i]: vals[donor[i]] for i in range(len(ranked))}
