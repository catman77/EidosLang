from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

from .acquisition import sha256_object


class StimulusKind(str, Enum):
    WAIT = "WAIT"
    VISUAL = "VISUAL"
    AUDIO_TONE = "AUDIO_TONE"
    HAPTIC = "HAPTIC"
    PROMPT = "PROMPT"
    DRAW_WINDOW = "DRAW_WINDOW"


class FidelityScope(str, Enum):
    DIGITAL_EXECUTION = "DIGITAL_EXECUTION"
    PHYSICAL_OUTPUT = "PHYSICAL_OUTPUT"


@dataclass(frozen=True)
class DeviceCapabilityProfile:
    device_id: str
    profile_version: str
    user_agent: str
    platform: str
    screen_width_px: int
    screen_height_px: int
    device_pixel_ratio: float
    supports_audio: bool
    supports_haptic: bool
    supports_pointer_pressure: bool
    audio_sample_rate_hz: Optional[float] = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def profile_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class PhysicalCalibrationRef:
    calibration_id: str
    device_id: str
    instrument: str
    calibrated_modalities: tuple[str, ...]
    measured_parameters: dict[str, float]
    valid_from: str
    valid_until: Optional[str] = None
    external_record_ref: Optional[str] = None

    @property
    def calibration_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class StimulusStep:
    step_id: str
    kind: StimulusKind
    offset_ms: int
    duration_ms: int
    params: dict[str, Any] = field(default_factory=dict)
    required: bool = True
    start_tolerance_ms: int = 80
    duration_tolerance_ms: int = 100
    requires_capability: Optional[str] = None
    requires_physical_calibration: bool = False

    def __post_init__(self):
        if self.offset_ms < 0:
            raise ValueError("offset_ms must be >=0")
        if self.duration_ms < 0:
            raise ValueError("duration_ms must be >=0")
        if self.start_tolerance_ms < 0 or self.duration_tolerance_ms < 0:
            raise ValueError("tolerances must be >=0")


@dataclass(frozen=True)
class AnchorExecutionPlan:
    anchor_id: str
    plan_version: str
    steps: tuple[StimulusStep, ...]
    required_fidelity_scope: FidelityScope = FidelityScope.DIGITAL_EXECUTION

    def __post_init__(self):
        ids = [s.step_id for s in self.steps]
        if len(ids) != len(set(ids)):
            raise ValueError("step ids must be unique")
        offsets = [s.offset_ms for s in self.steps]
        if offsets != sorted(offsets):
            raise ValueError("steps must be sorted by offset_ms")

    @property
    def plan_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class StepExecution:
    step_id: str
    kind: StimulusKind
    requested_start_ms: float
    actual_start_ms: Optional[float]
    actual_end_ms: Optional[float]
    api_success: bool
    observed: dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None


@dataclass(frozen=True)
class ExecutionTrace:
    anchor_id: str
    plan_hash: str
    device_profile_hash: str
    session_id: str
    trace_version: str
    steps: tuple[StepExecution, ...]
    undeclared_media_events: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def trace_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class StepFidelityResult:
    step_id: str
    status: str
    start_error_ms: Optional[float]
    duration_error_ms: Optional[float]
    reasons: tuple[str, ...]


@dataclass(frozen=True)
class FidelityCertificate:
    anchor_id: str
    session_id: str
    plan_hash: str
    trace_hash: str
    device_profile_hash: str
    scope: FidelityScope
    status: str
    step_results: tuple[StepFidelityResult, ...]
    reasons: tuple[str, ...]
    physical_calibration_hash: Optional[str] = None

    @property
    def certificate_hash(self) -> str:
        return sha256_object(self)


def _capability_ok(profile: DeviceCapabilityProfile, name: Optional[str]) -> bool:
    if name is None:
        return True
    mapping = {
        "audio": profile.supports_audio,
        "haptic": profile.supports_haptic,
        "pointer_pressure": profile.supports_pointer_pressure,
    }
    return bool(mapping.get(name, False))


def certify_execution(
    plan: AnchorExecutionPlan,
    trace: ExecutionTrace,
    profile: DeviceCapabilityProfile,
    physical_calibration: Optional[PhysicalCalibrationRef] = None,
) -> FidelityCertificate:
    global_reasons: list[str] = []
    results: list[StepFidelityResult] = []

    if trace.anchor_id != plan.anchor_id:
        global_reasons.append("anchor_id mismatch")
    if trace.plan_hash != plan.plan_hash:
        global_reasons.append("plan_hash mismatch")
    if trace.device_profile_hash != profile.profile_hash:
        global_reasons.append("device_profile_hash mismatch")
    if trace.undeclared_media_events:
        global_reasons.append("undeclared media events present")

    executions_by_id: dict[str, list[StepExecution]] = {}
    for e in trace.steps:
        executions_by_id.setdefault(e.step_id, []).append(e)

    for step in plan.steps:
        reasons: list[str] = []
        start_err = None
        dur_err = None
        xs = executions_by_id.get(step.step_id, [])
        if len(xs) == 0:
            if step.required:
                reasons.append("required step missing")
            results.append(StepFidelityResult(step.step_id, "FAIL" if reasons else "PASS", None, None, tuple(reasons)))
            continue
        if len(xs) > 1:
            reasons.append("step executed more than once")
        ex = xs[0]
        if ex.kind != step.kind:
            reasons.append("stimulus kind mismatch")
        if not _capability_ok(profile, step.requires_capability):
            reasons.append("required device capability absent")
        if not ex.api_success:
            reasons.append("device API reported failure")
        if ex.actual_start_ms is None:
            reasons.append("missing actual_start_ms")
        else:
            start_err = ex.actual_start_ms - step.offset_ms
            if abs(start_err) > step.start_tolerance_ms:
                reasons.append("start timing outside tolerance")
        if step.duration_ms > 0:
            if ex.actual_start_ms is None or ex.actual_end_ms is None:
                reasons.append("missing duration observation")
            else:
                actual_duration = ex.actual_end_ms - ex.actual_start_ms
                dur_err = actual_duration - step.duration_ms
                if abs(dur_err) > step.duration_tolerance_ms:
                    reasons.append("duration outside tolerance")
        results.append(StepFidelityResult(step.step_id, "PASS" if not reasons else "FAIL", start_err, dur_err, tuple(reasons)))

    declared = {s.step_id for s in plan.steps}
    extras = set(executions_by_id) - declared
    if extras:
        global_reasons.append("undeclared execution steps present")

    calibration_hash = None
    if plan.required_fidelity_scope == FidelityScope.PHYSICAL_OUTPUT:
        if physical_calibration is None:
            global_reasons.append("physical-output scope requires external calibration")
        else:
            calibration_hash = physical_calibration.calibration_hash
            if physical_calibration.device_id != profile.device_id:
                global_reasons.append("physical calibration belongs to another device")
            required_modalities: set[str] = set()
            for s in plan.steps:
                if s.requires_physical_calibration:
                    if s.kind == StimulusKind.AUDIO_TONE:
                        required_modalities.add("audio")
                    elif s.kind == StimulusKind.HAPTIC:
                        required_modalities.add("haptic")
                    elif s.kind == StimulusKind.VISUAL:
                        required_modalities.add("visual")
            missing = required_modalities - set(physical_calibration.calibrated_modalities)
            if missing:
                global_reasons.append("physical calibration missing modalities: " + ",".join(sorted(missing)))

    if any(r.status != "PASS" for r in results):
        global_reasons.append("one or more planned steps failed fidelity")

    return FidelityCertificate(
        anchor_id=plan.anchor_id,
        session_id=trace.session_id,
        plan_hash=plan.plan_hash,
        trace_hash=trace.trace_hash,
        device_profile_hash=profile.profile_hash,
        scope=plan.required_fidelity_scope,
        status="PASS" if not global_reasons else "FAIL",
        step_results=tuple(results),
        reasons=tuple(global_reasons),
        physical_calibration_hash=calibration_hash,
    )


@dataclass(frozen=True)
class CorpusFidelityGateResult:
    status: str
    reasons: tuple[str, ...]
    accepted_session_ids: tuple[str, ...]
    rejected_session_ids: tuple[str, ...]


def corpus_fidelity_gate(
    required_session_ids: tuple[str, ...],
    certificates: tuple[FidelityCertificate, ...],
    required_scope: FidelityScope,
) -> CorpusFidelityGateResult:
    by: dict[str, FidelityCertificate] = {}
    reasons: list[str] = []
    for c in certificates:
        if c.session_id in by:
            reasons.append(f"duplicate fidelity certificate for {c.session_id}")
        by[c.session_id] = c
    accepted: list[str] = []
    rejected: list[str] = []
    for sid in required_session_ids:
        c = by.get(sid)
        if c is None:
            rejected.append(sid)
            reasons.append(f"missing fidelity certificate for {sid}")
            continue
        if c.status != "PASS":
            rejected.append(sid)
            reasons.append(f"fidelity certificate failed for {sid}")
            continue
        if c.scope != required_scope:
            rejected.append(sid)
            reasons.append(f"fidelity scope mismatch for {sid}")
            continue
        accepted.append(sid)
    return CorpusFidelityGateResult(
        "PASS" if not reasons else "FAIL",
        tuple(reasons),
        tuple(sorted(accepted)),
        tuple(sorted(rejected)),
    )
