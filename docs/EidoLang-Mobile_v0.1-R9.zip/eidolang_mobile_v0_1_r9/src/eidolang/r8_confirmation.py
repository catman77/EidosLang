from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .acquisition import sha256_object
from .candidate_universe import CandidateUniverseCertificate, CandidateSetAudit, audit_selector_candidate_universe
from .prospective_instantiation import (
    ConfirmationSelectorCandidate, FrozenInstantiationRule,
    R7ConfirmationAnalyzer, R7ConfirmationCertificate,
)
from .cross_observer_transport import R5CausalClassObservation
from .discovery_confirmation import R6SplitManifest, FrozenTransportHypothesis, ConfirmationPackage
from .effect_alignment import EffectAlignmentReport
from .reliability import ReliabilityGateResult


@dataclass(frozen=True)
class R8ConfirmationCertificate:
    certificate_id: str
    candidate_set_audit: CandidateSetAudit
    universe_certificate_hashes: tuple[tuple[str,str],...]
    r7: R7ConfirmationCertificate
    status: str
    passed: bool
    reasons: tuple[str,...]
    protocol_version: str = "candidate-universe-closure-v1"

    @property
    def certificate_hash(self) -> str:
        return sha256_object(self)


class R8ClosedConfirmationAnalyzer:
    def __init__(
        self,
        split:R6SplitManifest,
        hypothesis:FrozenTransportHypothesis,
        r6_package:ConfirmationPackage,
        rule:FrozenInstantiationRule,
        confirmation_selector_alignment:EffectAlignmentReport,
        confirmation_primary_alignment:EffectAlignmentReport,
        confirmation_reliability:ReliabilityGateResult,
        universe_certificates:Iterable[CandidateUniverseCertificate],
    ):
        self.split=split
        self.hypothesis=hypothesis
        self.r6_package=r6_package
        self.rule=rule
        self.selector_alignment=confirmation_selector_alignment
        self.primary_alignment=confirmation_primary_alignment
        self.reliability=confirmation_reliability
        self.universe_certificates=tuple(universe_certificates)

    def certify(
        self,
        discovery_primary_classes:Iterable[R5CausalClassObservation],
        selector_candidates:Iterable[ConfirmationSelectorCandidate],
        all_confirmation_primary_classes:Iterable[R5CausalClassObservation],
    ) -> R8ConfirmationCertificate:
        sc=list(selector_candidates)
        reasons=[]
        audit=audit_selector_candidate_universe(self.universe_certificates,sc)
        if audit.status!="PASS":
            reasons.extend(audit.reasons)
        conf=set(self.split.confirmation_observers())
        uc={c.observer_id for c in self.universe_certificates}
        if uc!=conf:
            reasons.append("candidate-universe certificate observer set differs from confirmation cohort")
        for c in self.universe_certificates:
            if c.status!="PASS" or not c.complete:
                reasons.append(f"candidate universe is not closed for {c.observer_id}")

        if reasons:
            # Do not run blind selector or R5 when the candidate quantifier is open.
            from .prospective_instantiation import R7InstantiationCertificate
            from .discovery_confirmation import R6ConfirmationCertificate, LeakageAudit
            from .cross_observer_transport import R5TransportCertificate
            inst=R7InstantiationCertificate(self.rule.rule_hash,(),"INVALID",(),tuple(reasons))
            r5=R5TransportCertificate(
                "r5:not-run",self.r6_package.r5_config.config_hash,
                self.r6_package.r5_config.reference_observer_id,
                self.r6_package.r5_config.observer_ids,
                None,None,0,False,None,self.r6_package.r5_config.alpha_local,
                (),(),"INVALID",False,("R8 candidate-universe closure failure",),
                self.r6_package.r5_config.protocol_version,
            )
            leak=LeakageAudit("FAIL",tuple(reasons),self.split.discovery_observers(),self.split.confirmation_observers(),(),())
            r6=R6ConfirmationCertificate(
                "r6:not-run",self.split.manifest_hash,self.hypothesis.hypothesis_hash,
                self.r6_package.package_hash,leak,r5,"INVALID",False,tuple(reasons)
            )
            r7=R7ConfirmationCertificate("r7:not-run",inst,r6,"INVALID",False,tuple(reasons))
            return R8ConfirmationCertificate(
                "r8:invalid",audit,
                tuple(sorted((c.observer_id,c.certificate_hash) for c in self.universe_certificates)),
                r7,"INVALID",False,tuple(reasons)
            )

        r7=R7ConfirmationAnalyzer(
            self.split,self.hypothesis,self.r6_package,self.rule,
            self.selector_alignment,self.primary_alignment,self.reliability,
        ).certify(discovery_primary_classes,sc,all_confirmation_primary_classes)
        passed=r7.passed
        status="PASS" if passed else r7.status
        rs=() if passed else (f"R7 confirmation did not pass: {r7.status}",)
        cid="r8:"+sha256_object({
            "audit":audit.audit_hash,
            "universes":sorted((c.observer_id,c.certificate_hash) for c in self.universe_certificates),
            "r7":r7.certificate_hash,
        })[:16]
        return R8ConfirmationCertificate(
            cid,audit,tuple(sorted((c.observer_id,c.certificate_hash) for c in self.universe_certificates)),
            r7,status,passed,rs
        )
