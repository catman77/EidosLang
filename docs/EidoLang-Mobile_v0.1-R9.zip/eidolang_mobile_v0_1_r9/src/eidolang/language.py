from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

@dataclass(frozen=True)
class SplitManifest:
    train_ids: tuple[str, ...]
    holdout_ids: tuple[str, ...]
    split_version: str

@dataclass
class AlphabetSymbol:
    symbol_id: str
    member_tokens: tuple[str, ...]
    train_support: int
    holdout_support: int
    train_effect: dict[str, float]
    holdout_model_loss: float
    holdout_baseline_loss: float
    prototype_segment_ids: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def holdout_gain(self) -> float:
        return self.holdout_baseline_loss - self.holdout_model_loss

@dataclass
class PersonalAlphabet:
    alphabet_id: str
    symbols: list[AlphabetSymbol]
    token_to_symbol: dict[str, str]
    unresolved_tokens: tuple[str, ...]
    split: SplitManifest
    observed_gain: float
    negative_control_gains: tuple[float, ...]
    passed_negative_control_gate: bool
    protocol_version: str = "alphabet-v2"
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass
class EffectGrammarRule:
    rule_id: str
    pattern: tuple[str, ...]
    suffix_baseline: tuple[str, ...]
    train_support: int
    holdout_support: int
    effect: dict[str, float]
    holdout_rule_loss: float
    holdout_baseline_loss: float
    evidence_refs: tuple[str, ...]
    counterexample_refs: tuple[str, ...]
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def holdout_gain(self) -> float:
        return self.holdout_baseline_loss - self.holdout_rule_loss

@dataclass
class PersonalGrammar:
    grammar_id: str
    rules: list[EffectGrammarRule]
    split: SplitManifest
    observed_gain: float
    negative_control_gains: tuple[float, ...]
    passed_negative_control_gate: bool
    protocol_version: str = "effect-grammar-v2"
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass
class DiscoveryReport:
    alphabet: PersonalAlphabet
    grammar: PersonalGrammar
    notes: tuple[str, ...] = ()
