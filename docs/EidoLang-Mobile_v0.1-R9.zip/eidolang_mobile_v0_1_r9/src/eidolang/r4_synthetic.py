from __future__ import annotations
from .schema import StateObservation
from .causal import StateProbe, ProbeKind
from .substitution import SubstitutionTrial, SubstitutionArm, stratified_balanced_assignment


def make_substitution_trials(
    left_operator_id: str = "op:A",
    right_operator_id: str = "op:B",
    n: int = 16,
    seed: int = 404,
    left_effect: float = 0.45,
    right_effect: float = 0.46,
    left_probe=(0.14, 0.31),
    right_probe=(0.15, 0.30),
    stratum_id: str = "s0",
    domain_id: str = "domain:calm-mid",
    probe_schedule_id: str = "probe:2phase",
):
    if n % 2:
        raise ValueError("synthetic n must be even")
    pair = sorted([left_operator_id,right_operator_id])
    pair_id=f"{pair[0]}::{pair[1]}"
    ids=[f"sub:{i:03d}" for i in range(n)]
    assign=stratified_balanced_assignment({tid:stratum_id for tid in ids},seed)
    out=[]
    for i,tid in enumerate(ids):
        arm=assign[tid]
        op=left_operator_id if arm==SubstitutionArm.LEFT else right_operator_id
        # Deterministic, arm-independent small nuisance variation.
        eps=((i*7)%9-4)*0.002
        eff=(left_effect if arm==SubstitutionArm.LEFT else right_effect)+eps
        pp=(left_probe if arm==SubstitutionArm.LEFT else right_probe)
        pre=StateObservation(0,{"focus":0.30,"noise":0.70},0.9,"synthetic")
        post=StateObservation(1_000_000,{"focus":0.30+eff,"noise":0.70-eff},0.9,"synthetic")
        probes=(
            StateProbe(f"{tid}:p1",300_000,1,ProbeKind.ACTIVE_SELF_REPORT,
                       {"focus":0.30+pp[0]+eps/3,"noise":0.70-pp[0]-eps/3},"synthetic"),
            StateProbe(f"{tid}:p2",650_000,2,ProbeKind.ACTIVE_SELF_REPORT,
                       {"focus":0.30+pp[1]+eps/2,"noise":0.70-pp[1]-eps/2},"synthetic"),
        )
        out.append(SubstitutionTrial(
            trial_id=tid,pair_id=pair_id,arm=arm,operator_id=op,template_id=f"tpl:{op}",
            assignment_seed=seed,randomized=True,domain_id=domain_id,stratum_id=stratum_id,
            probe_schedule_id=probe_schedule_id,pre_state=pre,post_state=post,probes=probes
        ))
    return out
