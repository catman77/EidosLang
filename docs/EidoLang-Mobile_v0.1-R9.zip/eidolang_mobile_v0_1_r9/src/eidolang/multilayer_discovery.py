from __future__ import annotations
from dataclasses import dataclass
from collections import Counter
from .topological_discovery import TopologicalExample, RepresentationResult, _seq_distance, _feature_distance, _scales
from .topology import describe_session, TopologyConfig
from .multilayer_topology import describe_multilayer_session, MultilayerConfig
from .segmenter import StrokeSegmenter


@dataclass(frozen=True)
class MultilayerTransportReport:
    geometry: RepresentationResult
    t2: RepresentationResult
    t3: RepresentationResult
    multilayer_gain_over_t2: float
    negative_control_max_t3_accuracy: float
    passed: bool
    reason: str


def _multiset_distance(a: tuple[str,...], b: tuple[str,...]) -> float:
    ca,cb=Counter(a),Counter(b)
    keys=set(ca)|set(cb)
    num=sum(abs(ca[k]-cb[k]) for k in keys)
    den=max(1,sum(ca.values())+sum(cb.values()))
    return num/den


class CrossObserverMultilayerEvaluator:
    """Leave-one-observer-out comparison of T2 vs T3.

    Labels must be external causal classes (R4). R4.6 is only a representation test.
    """
    def __init__(self, config: MultilayerConfig=MultilayerConfig(), negative_controls: int=16):
        self.config=config; self.negative_controls=negative_controls; self.segmenter=StrokeSegmenter(); self._cache={}

    def _repr(self,e: TopologicalExample):
        if e.example_id in self._cache:
            return self._cache[e.example_id]
        toks,_=self.segmenter.tokens(e.session)
        t2=describe_session(e.session,self.config.topology,self.segmenter)
        t3=describe_multilayer_session(e.session,self.config,self.segmenter)
        out={
            'geometry':tuple(toks),
            'T2':(t2.feature_vector('T2'),tuple(x.token() for x in t2.temporal.events)),
            'T3':(t3.t3_vector(),t3.anonymous_color_signatures,t3.media_form_couplings),
        }
        self._cache[e.example_id]=out
        return out

    def _evaluate(self,examples,labels,rep):
        reps={e.example_id:self._repr(e)[rep] for e in examples}
        obs=sorted({e.observer_id for e in examples})
        correct=total=0
        for o in obs:
            train=[e for e in examples if e.observer_id!=o]; test=[e for e in examples if e.observer_id==o]
            if not train: continue
            if rep=='T2': scales=_scales([reps[e.example_id][0] for e in train])
            elif rep=='T3': scales=_scales([reps[e.example_id][0] for e in train])
            else: scales=None
            for q in test:
                best=None
                for tr in train:
                    if rep=='geometry':
                        d=_seq_distance(reps[q.example_id],reps[tr.example_id])
                    elif rep=='T2':
                        fq,sq=reps[q.example_id]; ft,st=reps[tr.example_id]
                        d=.65*_feature_distance(fq,ft,scales)+.35*_seq_distance(sq,st)
                    else:
                        fq,cq,mq=reps[q.example_id]; ft,ct,mt=reps[tr.example_id]
                        d=.55*_feature_distance(fq,ft,scales)+.25*_multiset_distance(cq,ct)+.20*_multiset_distance(mq,mt)
                    key=(d,tr.example_id)
                    if best is None or key<best[0]: best=(key,labels[tr.example_id])
                correct += int(best[1]==labels[q.example_id]); total += 1
        return RepresentationResult(rep,correct,total,correct/total if total else 0.0)

    def _permuted_labels(self,examples,k):
        # same observer-wise destructive control as R4.5, duplicated intentionally to keep R4.6 self-contained
        by={}
        for e in examples: by.setdefault(e.observer_id,[]).append(e)
        obs=sorted(by)
        codes=[c for c in range(1,1<<len(obs)) if bin(c).count('1') in {len(obs)//2,(len(obs)+1)//2}]
        code=codes[k%len(codes)]
        out={}
        for oi,o in enumerate(obs):
            es=sorted(by[o],key=lambda e:e.example_id); labs=[e.causal_class for e in es]
            if ((code>>oi)&1) and len(labs)>1: labs=labs[1:]+labs[:1]
            for e,l in zip(es,labs): out[e.example_id]=l
        return out

    def evaluate(self,examples: list[TopologicalExample], min_gain: float=.15) -> MultilayerTransportReport:
        self._cache={}
        for e in examples: self._repr(e)
        labels={e.example_id:e.causal_class for e in examples}
        g=self._evaluate(examples,labels,'geometry')
        t2=self._evaluate(examples,labels,'T2')
        t3=self._evaluate(examples,labels,'T3')
        neg=[self._evaluate(examples,self._permuted_labels(examples,k),'T3').accuracy for k in range(self.negative_controls)]
        negmax=max(neg,default=0.0); gain=t3.accuracy-t2.accuracy
        passed=(gain>=min_gain and t3.accuracy>negmax)
        reason=f"{'PASS' if passed else 'FAIL'}: T3-T2={gain:.3f}; negative_max={negmax:.3f}"
        return MultilayerTransportReport(g,t2,t3,gain,negmax,passed,reason)
