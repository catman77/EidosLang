from __future__ import annotations
from dataclasses import dataclass
from collections import defaultdict, deque
import hashlib, json, math
from typing import Any, Iterable

from .schema import EidoSession, EventType, RawEvent, StrokeSegment
from .segmenter import StrokeSegmenter
from .topology import (
    TopologyConfig, TopologyDescriptor, describe_session, snapshot_from_strokes,
    _is_closed, _polylines_intersect, _point_in_polygon,
)


@dataclass(frozen=True)
class MultilayerConfig:
    version: str = "multilayer-topology-v1"
    topology: TopologyConfig = TopologyConfig()
    anonymous_color_layers: bool = True


@dataclass(frozen=True)
class ColorRun:
    run_id: str
    parent_stroke: int
    t_start_us: int
    t_end_us: int
    points: tuple[tuple[float, float], ...]
    color_token: str


@dataclass(frozen=True)
class ColorLayerDescriptor:
    layer_token: str
    stroke_count: int
    beta0: int
    beta1: int
    closed_strokes: int
    containment_edges: int
    intersection_pairs: int
    boundary_touch_total: int
    signature: str

    def anonymous_signature(self) -> str:
        return (
            f"CL:b0={self.beta0};b1={self.beta1};cl={self.closed_strokes};"
            f"ce={self.containment_edges};ix={self.intersection_pairs};bt={self.boundary_touch_total};"
            f"n={self.stroke_count}"
        )


@dataclass(frozen=True)
class TemporalMediaEpisode:
    episode_id: str
    channel: str
    t_start_us: int
    t_end_us: int
    payload_token: str


@dataclass(frozen=True)
class TemporalLayerDescriptor:
    channel: str
    episode_count: int
    beta0_time: int
    overlap_pairs: int
    max_concurrency: int
    signature: str


@dataclass(frozen=True)
class MultilayerTopologyDescriptor:
    config_version: str
    form: TopologyDescriptor
    color_layers: tuple[ColorLayerDescriptor, ...]
    anonymous_color_signatures: tuple[str, ...]
    color_switches: int
    cross_color_containment_edges: int
    cross_color_intersection_pairs: int
    color_nesting_patterns: tuple[str, ...]
    media_layers: tuple[TemporalLayerDescriptor, ...]
    media_form_couplings: tuple[str, ...]
    cross_media_overlap_pairs: int
    signature: str

    def t3_vector(self) -> tuple[float, ...]:
        # Fixed-dimensional summary. Exact multiset/sequence information is in signature.
        cls = self.color_layers
        aud = next((x for x in self.media_layers if x.channel == 'AUDIO'), None)
        hap = next((x for x in self.media_layers if x.channel == 'HAPTIC'), None)
        def m(x, field):
            return float(getattr(x, field)) if x is not None else 0.0
        nesting_counts=defaultdict(int)
        for pat in self.color_nesting_patterns: nesting_counts[pat] += 1
        coupling_counts = defaultdict(int)
        for tok in self.media_form_couplings:
            # channel|event-category; category list is fixed by _event_categories.
            coupling_counts[tok] += 1
        categories = [
            'dB0+','dB0-','dB1+','dB1-','contain+','intersect+',
            'newContains','newInside','hspan','vspan','neutral'
        ]
        coupling_vec=[]
        for ch in ('AUDIO','HAPTIC'):
            for cat in categories:
                coupling_vec.append(float(coupling_counts.get(f'{ch}|{cat}', 0)))
        return self.form.feature_vector('T2') + (
            float(len(cls)),
            float(self.color_switches),
            float(sum(c.beta0 for c in cls)),
            float(sum(c.beta1 for c in cls)),
            float(sum(c.closed_strokes for c in cls)),
            float(max((c.beta0 for c in cls), default=0)),
            float(max((c.beta1 for c in cls), default=0)),
            float(self.cross_color_containment_edges),
            float(self.cross_color_intersection_pairs),
            float(nesting_counts.get('AAA',0)),float(nesting_counts.get('AAB',0)),
            float(nesting_counts.get('ABA',0)),float(nesting_counts.get('ABB',0)),
            float(nesting_counts.get('ABC',0)),
            m(aud,'episode_count'),m(aud,'beta0_time'),m(aud,'overlap_pairs'),m(aud,'max_concurrency'),
            m(hap,'episode_count'),m(hap,'beta0_time'),m(hap,'overlap_pairs'),m(hap,'max_concurrency'),
            float(self.cross_media_overlap_pairs),
        ) + tuple(coupling_vec)


def _payload_token(payload: dict[str, Any]) -> str:
    raw=json.dumps(payload or {}, sort_keys=True, ensure_ascii=False, separators=(',',':'))
    return hashlib.sha1(raw.encode('utf-8')).hexdigest()[:12]


def _color_value(ev: RawEvent) -> str:
    p=ev.payload or {}
    # No semantic interpretation: canonicalize whatever the capture protocol supplied.
    val=p.get('value', p.get('color', p.get('rgba', p)))
    if isinstance(val,(dict,list,tuple)):
        return json.dumps(val,sort_keys=True,ensure_ascii=False,separators=(',',':'))
    return str(val)


def color_runs(session: EidoSession) -> list[ColorRun]:
    """Split raw pointer trajectories when the explicit COLOR state changes.

    This avoids the hidden assumption that one START..END stroke necessarily has one color.
    COLOR is treated as a stateful renderer command. It changes only future points.
    """
    current_color='UNSPECIFIED'
    active: dict[int, dict[str, Any]]={}
    runs=[]; serial=0; parent_serial=0
    events=sorted(enumerate(session.raw_events), key=lambda p:(p[1].t_us,p[0]))

    def flush(pid: int, end_t: int | None=None, keep_last: bool=True):
        nonlocal serial
        a=active.get(pid)
        if not a or not a['pts']:
            return
        pts=a['pts']
        if len(pts)==1:
            pts=pts+pts
        runs.append(ColorRun(
            run_id=f'{session.session_id}:cr:{serial}', parent_stroke=a['parent'],
            t_start_us=a['start'], t_end_us=(end_t if end_t is not None else a['last_t']),
            points=tuple(pts), color_token=a['color']
        )); serial += 1
        if keep_last:
            last=pts[-1]
            active[pid]={**a,'pts':[last],'start':end_t if end_t is not None else a['last_t']}
        else:
            active.pop(pid,None)

    for _,ev in events:
        if ev.type == EventType.COLOR:
            # Finish all current color-runs at the color state transition without ending parent stroke.
            for pid in list(active):
                flush(pid,ev.t_us,keep_last=True)
                active[pid]['color']=_color_value(ev)
            current_color=_color_value(ev)
            continue
        if ev.pointer_id is None or ev.type not in {EventType.START,EventType.MOVE,EventType.END,EventType.CANCEL}:
            continue
        pid=ev.pointer_id
        if ev.type == EventType.START:
            active[pid]={'parent':parent_serial,'pts':[],'start':ev.t_us,'last_t':ev.t_us,'color':current_color}
            parent_serial += 1
        if pid not in active:
            continue
        if ev.x is not None and ev.y is not None:
            active[pid]['pts'].append((ev.x,ev.y)); active[pid]['last_t']=ev.t_us
        if ev.type in {EventType.END,EventType.CANCEL}:
            flush(pid,ev.t_us,keep_last=False)
    for pid in list(active): flush(pid,active[pid]['last_t'],keep_last=False)
    return runs


def _as_strokes(session_id: str, runs: Iterable[ColorRun]) -> list[StrokeSegment]:
    out=[]
    for i,r in enumerate(runs):
        out.append(StrokeSegment(
            segment_id=r.run_id,session_id=session_id,pointer_id=r.parent_stroke,
            t_start_us=r.t_start_us,t_end_us=r.t_end_us,points=r.points,
            mean_pressure=None,feature_vector=tuple(),signature=''
        ))
    return out


def describe_color_layers(session: EidoSession, config: MultilayerConfig) -> tuple[tuple[ColorLayerDescriptor,...], tuple[ColorRun,...]]:
    runs=color_runs(session)
    by=defaultdict(list)
    for r in runs: by[r.color_token].append(r)
    desc=[]
    for token,rs in sorted(by.items(), key=lambda kv:kv[0]):
        snap=snapshot_from_strokes(_as_strokes(session.session_id,rs),config.topology)
        bt=sum(snap.boundary_touch_counts)
        sig=(
            f'C:{hashlib.sha1(token.encode()).hexdigest()[:8]}:'
            f'b0={snap.beta0};b1={snap.beta1};cl={snap.closed_strokes};ce={snap.containment_edges};'
            f'ix={snap.intersection_pairs};bt={bt};n={len(rs)}'
        )
        desc.append(ColorLayerDescriptor(token,len(rs),snap.beta0,snap.beta1,snap.closed_strokes,
                                         snap.containment_edges,snap.intersection_pairs,bt,sig))
    return tuple(desc),tuple(runs)


def _cross_color_relations(runs: tuple[ColorRun,...], closure_ratio: float) -> tuple[int,int]:
    closed=[r for r in runs if _is_closed(list(r.points),closure_ratio)]
    ce=ix=0
    for i,a in enumerate(closed):
        for b in closed[i+1:]:
            if a.color_token == b.color_token:
                continue
            pa,pb=list(a.points),list(b.points)
            if _polylines_intersect(pa,pb):
                ix += 1; continue
            ainb=_point_in_polygon(pa[0],pb); bina=_point_in_polygon(pb[0],pa)
            if ainb != bina: ce += 1
    return ce,ix


def _normalize_layer_pattern(tokens: list[str]) -> str:
    m={}; next_code=0; out=[]
    for t in tokens:
        if t not in m:
            m[t]=chr(ord('A')+next_code); next_code += 1
        out.append(m[t])
    return ''.join(out)


def _color_nesting_patterns(runs: tuple[ColorRun,...], closure_ratio: float) -> tuple[str,...]:
    """Canonical equality-patterns on immediate containment chains.

    Actual color identities are removed: only equality/inequality relations along the
    containment poset survive (e.g. ABAC versus ABCB). This is invariant under an
    arbitrary renaming of a user's palette.
    """
    closed=[r for r in runs if _is_closed(list(r.points),closure_ratio)]
    n=len(closed)
    contains=set()
    for i,a in enumerate(closed):
        pa=list(a.points)
        for j,b in enumerate(closed):
            if i==j: continue
            pb=list(b.points)
            if _polylines_intersect(pa,pb): continue
            if _point_in_polygon(pb[0],pa) and not _point_in_polygon(pa[0],pb):
                contains.add((i,j))
    # Hasse reduction: i->j is immediate iff no k lies strictly between.
    immediate=set()
    for i,j in contains:
        if not any((i,k) in contains and (k,j) in contains for k in range(n) if k not in {i,j}):
            immediate.add((i,j))
    children={i:[] for i in range(n)}; parents={i:[] for i in range(n)}
    for i,j in immediate:
        children[i].append(j); parents[j].append(i)
    for d in (children,parents):
        for k in d: d[k].sort()
    roots=[i for i in range(n) if not parents[i]]
    paths=[]
    def walk(i,path):
        if not children[i]:
            if len(path)>=2:
                paths.append(_normalize_layer_pattern([closed[k].color_token for k in path]))
            return
        for j in children[i]: walk(j,path+[j])
    for r in roots: walk(r,[r])
    return tuple(sorted(paths))


def _duration_us(ev: RawEvent) -> int:
    p=ev.payload or {}
    for k in ('duration_us','durationUs'):
        if k in p:
            try: return max(0,int(p[k]))
            except Exception: pass
    for k in ('duration_ms','durationMs'):
        if k in p:
            try: return max(0,int(float(p[k])*1000))
            except Exception: pass
    return 0


def media_episodes(session: EidoSession, channels=('AUDIO','HAPTIC')) -> tuple[TemporalMediaEpisode,...]:
    allowed={EventType(ch) for ch in channels}
    out=[]; serial=0
    for ev in sorted(session.raw_events,key=lambda e:e.t_us):
        if ev.type not in allowed: continue
        dur=_duration_us(ev)
        out.append(TemporalMediaEpisode(
            episode_id=f'{session.session_id}:media:{serial}',channel=ev.type.value,
            t_start_us=ev.t_us,t_end_us=ev.t_us+dur,payload_token=_payload_token(ev.payload)
        )); serial += 1
    return tuple(out)


def _interval_overlap(a0,a1,b0,b1) -> bool:
    if a0==a1: return b0 <= a0 <= b1
    if b0==b1: return a0 <= b0 <= a1
    return max(a0,b0) <= min(a1,b1)


def _temporal_layer(channel: str, episodes: list[TemporalMediaEpisode]) -> TemporalLayerDescriptor:
    if not episodes:
        return TemporalLayerDescriptor(channel,0,0,0,0,f'{channel}:empty')
    eps=sorted(episodes,key=lambda e:(e.t_start_us,e.t_end_us,e.episode_id))
    overlap_pairs=0
    for i,a in enumerate(eps):
        for b in eps[i+1:]:
            overlap_pairs += int(_interval_overlap(a.t_start_us,a.t_end_us,b.t_start_us,b.t_end_us))
    # Connected components of union of closed time intervals.
    comps=0; end=None
    endpoints=[]
    for e in eps:
        if end is None or e.t_start_us > end:
            comps += 1; end=e.t_end_us
        else:
            end=max(end,e.t_end_us)
        endpoints.append((e.t_start_us,+1)); endpoints.append((e.t_end_us,-1))
    # Points of zero duration should still count as concurrency 1.
    maxc=1
    if any(e.t_end_us>e.t_start_us for e in eps):
        c=0
        for t,d in sorted(endpoints,key=lambda x:(x[0],-x[1])):
            c+=d; maxc=max(maxc,c)
    sig=f'{channel}:n={len(eps)};b0t={comps};ov={overlap_pairs};mc={maxc}'
    return TemporalLayerDescriptor(channel,len(eps),comps,overlap_pairs,maxc,sig)


def _event_categories(e) -> tuple[str,...]:
    cats=[]
    if e.delta_beta0>0: cats.append('dB0+')
    if e.delta_beta0<0: cats.append('dB0-')
    if e.delta_beta1>0: cats.append('dB1+')
    if e.delta_beta1<0: cats.append('dB1-')
    if e.delta_containment>0: cats.append('contain+')
    if e.delta_intersections>0: cats.append('intersect+')
    if e.new_contains_existing>0: cats.append('newContains')
    if e.new_contained_by_existing>0: cats.append('newInside')
    if e.delta_hspan!=0: cats.append('hspan')
    if e.delta_vspan!=0: cats.append('vspan')
    return tuple(cats or ['neutral'])


def _media_form_couplings(session: EidoSession, form: TopologyDescriptor, episodes: tuple[TemporalMediaEpisode,...], segmenter: StrokeSegmenter) -> tuple[str,...]:
    strokes=segmenter.segment(session)
    toks=[]
    for i,(stroke,te) in enumerate(zip(strokes,form.temporal.events)):
        cats=_event_categories(te)
        for ep in episodes:
            if _interval_overlap(stroke.t_start_us,stroke.t_end_us,ep.t_start_us,ep.t_end_us):
                for cat in cats: toks.append(f'{ep.channel}|{cat}')
    return tuple(toks)


def _cross_media_overlap(episodes: tuple[TemporalMediaEpisode,...]) -> int:
    n=0
    for i,a in enumerate(episodes):
        for b in episodes[i+1:]:
            if a.channel==b.channel: continue
            n += int(_interval_overlap(a.t_start_us,a.t_end_us,b.t_start_us,b.t_end_us))
    return n


def _color_switches(runs: tuple[ColorRun,...]) -> int:
    if not runs: return 0
    rs=sorted(runs,key=lambda r:(r.t_start_us,r.run_id))
    return sum(a.color_token!=b.color_token for a,b in zip(rs,rs[1:]))


def describe_multilayer_session(session: EidoSession, config: MultilayerConfig=MultilayerConfig(), segmenter: StrokeSegmenter|None=None) -> MultilayerTopologyDescriptor:
    segmenter=segmenter or StrokeSegmenter()
    form=describe_session(session,config.topology,segmenter)
    cls,runs=describe_color_layers(session,config)
    anon=tuple(sorted(c.anonymous_signature() for c in cls))
    ce,ix=_cross_color_relations(runs,config.topology.closure_ratio)
    nesting=_color_nesting_patterns(runs,config.topology.closure_ratio)
    eps=media_episodes(session)
    mls=tuple(_temporal_layer(ch,[e for e in eps if e.channel==ch]) for ch in ('AUDIO','HAPTIC'))
    couplings=_media_form_couplings(session,form,eps,segmenter)
    cm=_cross_media_overlap(eps)
    raw='|'.join([
        form.temporal.signature,
        'colors=' + '|'.join(anon if config.anonymous_color_layers else tuple(c.signature for c in cls)),
        f'cs={_color_switches(runs)};xce={ce};xix={ix};nest=' + ','.join(nesting),
        'media=' + '|'.join(m.signature for m in mls),
        'couple=' + '|'.join(couplings),
        f'xmedia={cm}',
    ])
    sig='T3:'+hashlib.sha1(raw.encode()).hexdigest()[:16]+':'+raw
    return MultilayerTopologyDescriptor(
        config_version=config.version,form=form,color_layers=cls,anonymous_color_signatures=anon,
        color_switches=_color_switches(runs),cross_color_containment_edges=ce,
        cross_color_intersection_pairs=ix,color_nesting_patterns=nesting,media_layers=mls,media_form_couplings=couplings,
        cross_media_overlap_pairs=cm,signature=sig
    )
