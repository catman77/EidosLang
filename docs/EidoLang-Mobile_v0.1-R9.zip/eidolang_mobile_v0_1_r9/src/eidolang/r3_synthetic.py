from __future__ import annotations
from .schema import StateObservation
from .causal import ReplayTrial, ReplayArm, StateProbe, ProbeKind, balanced_random_assignment


def make_trials(operator_id:str="op:synthetic", n:int=16, seed:int=731,
                treatment_effect:float=0.45, control_effect:float=0.02):
    ids=[f"trial:{i:02d}" for i in range(n)]
    assignment=balanced_random_assignment(ids,seed)
    out=[]
    for i,tid in enumerate(ids):
        arm=assignment[tid]
        # Deterministic nuisance drift shared by both arms; assignment breaks its alignment.
        nuisance=((i*7)%9-4)*0.012
        eff=(treatment_effect if arm==ReplayArm.OPERATOR else control_effect)+nuisance
        pre=StateObservation(0,{"focus":0.30,"noise":0.70},0.9,"synthetic")
        post=StateObservation(3_000_000,{"focus":0.30+eff,"noise":0.70-eff},0.9,"synthetic")
        probes=(
            StateProbe(f"{tid}:p1",1_000_000,1,ProbeKind.ACTIVE_SELF_REPORT,
                       {"focus":0.30+(0.15 if arm==ReplayArm.OPERATOR else 0.01)+nuisance/3,
                        "noise":0.70-(0.15 if arm==ReplayArm.OPERATOR else 0.01)-nuisance/3},"synthetic"),
            StateProbe(f"{tid}:p2",2_000_000,2,ProbeKind.ACTIVE_SELF_REPORT,
                       {"focus":0.30+(0.32 if arm==ReplayArm.OPERATOR else 0.015)+2*nuisance/3,
                        "noise":0.70-(0.32 if arm==ReplayArm.OPERATOR else 0.015)-2*nuisance/3},"synthetic"),
        )
        out.append(ReplayTrial(
            trial_id=tid,operator_id=operator_id,arm=arm,
            template_id=("template:operator" if arm==ReplayArm.OPERATOR else "template:control"),
            assignment_seed=seed,randomized=True,probe_schedule_id="probe:2-active-v1",
            pre_state=pre,post_state=post,probes=probes,
            metadata={"synthetic":True}
        ))
    return out
