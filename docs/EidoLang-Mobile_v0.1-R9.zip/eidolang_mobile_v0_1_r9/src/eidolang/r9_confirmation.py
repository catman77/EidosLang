from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable
from .acquisition import sha256_object
from .grammar_adequacy import GrammarAdequacyCertificate
from .r8_confirmation import R8ClosedConfirmationAnalyzer, R8ConfirmationCertificate
from .candidate_universe import CandidateUniverseCertificate, CandidateSetAudit
from .prospective_instantiation import ConfirmationSelectorCandidate, FrozenInstantiationRule
from .cross_observer_transport import R5CausalClassObservation, R5TransportCertificate
from .discovery_confirmation import R6SplitManifest, FrozenTransportHypothesis, ConfirmationPackage, LeakageAudit, R6ConfirmationCertificate
from .effect_alignment import EffectAlignmentReport
from .reliability import ReliabilityGateResult
from .prospective_instantiation import R7InstantiationCertificate, R7ConfirmationCertificate

@dataclass(frozen=True)
class R9ConfirmationCertificate:
    certificate_id:str
    adequacy_certificate_hashes:tuple[tuple[str,str],...]
    r8:R8ConfirmationCertificate
    status:str
    passed:bool
    reasons:tuple[str,...]
    protocol_version:str="grammar-adequacy-gated-confirmation-v1"
    @property
    def certificate_hash(self): return sha256_object(self)

class R9AdequacyGatedConfirmationAnalyzer:
    def __init__(self,split:R6SplitManifest,hypothesis:FrozenTransportHypothesis,
                 r6_package:ConfirmationPackage,rule:FrozenInstantiationRule,
                 selector_alignment:EffectAlignmentReport,primary_alignment:EffectAlignmentReport,
                 reliability:ReliabilityGateResult,universe_certificates:Iterable[CandidateUniverseCertificate],
                 adequacy_certificates:Iterable[GrammarAdequacyCertificate]):
        self.split=split; self.hypothesis=hypothesis; self.pkg=r6_package; self.rule=rule
        self.sa=selector_alignment; self.pa=primary_alignment; self.rel=reliability
        self.universes=tuple(universe_certificates); self.adequacy=tuple(adequacy_certificates)

    def certify(self,discovery_primary_classes:Iterable[R5CausalClassObservation],
                selector_candidates:Iterable[ConfirmationSelectorCandidate],
                all_confirmation_primary_classes:Iterable[R5CausalClassObservation])->R9ConfirmationCertificate:
        reasons=[]; conf=set(self.split.confirmation_observers())
        amap={c.observer_id:c for c in self.adequacy}
        if len(amap)!=len(self.adequacy): reasons.append("duplicate R9 adequacy certificate observer")
        if set(amap)!=conf: reasons.append("R9 adequacy observer set differs from confirmation cohort")
        umap={c.observer_id:c for c in self.universes}
        for oid,c in amap.items():
            if c.status!="PASS" or not c.adequate: reasons.append(f"grammar adequacy not PASS for {oid}: {c.status}")
            if oid in umap and c.source_r8_certificate_hash!=umap[oid].certificate_hash:
                reasons.append(f"R9 certificate does not bind supplied R8 universe for {oid}")
        if reasons:
            audit=CandidateSetAudit("FAIL",tuple(reasons),(),())
            r5=R5TransportCertificate("r5:not-run",self.pkg.r5_config.config_hash,self.pkg.r5_config.reference_observer_id,
                self.pkg.r5_config.observer_ids,None,None,0,False,None,self.pkg.r5_config.alpha_local,(),(),"INVALID",False,
                ("R9 grammar-adequacy failure",),self.pkg.r5_config.protocol_version)
            leak=LeakageAudit("FAIL",tuple(reasons),self.split.discovery_observers(),self.split.confirmation_observers(),(),())
            r6=R6ConfirmationCertificate("r6:not-run",self.split.manifest_hash,self.hypothesis.hypothesis_hash,self.pkg.package_hash,
                leak,r5,"INVALID",False,tuple(reasons))
            inst=R7InstantiationCertificate(self.rule.rule_hash,(),"INVALID",(),tuple(reasons))
            r7=R7ConfirmationCertificate("r7:not-run",inst,r6,"INVALID",False,tuple(reasons))
            r8=R8ConfirmationCertificate("r8:not-run",audit,(),r7,"INVALID",False,tuple(reasons))
            return R9ConfirmationCertificate("r9confirm:invalid",tuple(sorted((o,c.certificate_hash) for o,c in amap.items())),r8,
                "INVALID",False,tuple(reasons))
        r8=R8ClosedConfirmationAnalyzer(self.split,self.hypothesis,self.pkg,self.rule,self.sa,self.pa,self.rel,self.universes).certify(
            discovery_primary_classes,selector_candidates,all_confirmation_primary_classes)
        passed=r8.passed; status="PASS" if passed else r8.status
        rs=() if passed else (f"R8 confirmation did not pass: {r8.status}",)
        cid="r9confirm:"+sha256_object({"adequacy":sorted((o,c.certificate_hash) for o,c in amap.items()),"r8":r8.certificate_hash})[:16]
        return R9ConfirmationCertificate(cid,tuple(sorted((o,c.certificate_hash) for o,c in amap.items())),r8,status,passed,rs)
