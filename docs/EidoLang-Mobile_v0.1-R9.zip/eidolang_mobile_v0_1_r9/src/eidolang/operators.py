from __future__ import annotations
from dataclasses import dataclass
from collections import defaultdict
import math,hashlib
from .schema import EidoSession,EidoOperator
from .segmenter import StrokeSegmenter
from .state import state_delta

@dataclass(frozen=True)
class MinerConfig:
    min_support:int=3; max_ngram:int=3; protocol_version:str='operator-miner-v1'

def mean_dict(ds):
    if not ds:return {}
    ks=sorted(set().union(*(d.keys() for d in ds))); return {k:sum(d.get(k,0) for d in ds)/len(ds) for k in ks}
def stderr_dict(ds,mean):
    if len(ds)<=1:return {k:0.0 for k in mean}
    out={}
    for k,m in mean.items():
        xs=[d.get(k,0) for d in ds]; var=sum((x-m)**2 for x in xs)/(len(xs)-1); out[k]=math.sqrt(var/len(xs))
    return out

class OperatorMiner:
    def __init__(self,segmenter=None,config:MinerConfig=MinerConfig()): self.segmenter=segmenter or StrokeSegmenter(); self.config=config
    def mine(self,sessions:list[EidoSession])->list[EidoOperator]:
        tokens={}; segments={}; deltas={}
        for s in sessions:
            tokens[s.session_id],segments[s.session_id]=self.segmenter.tokens(s); deltas[s.session_id]=state_delta(s)
        baseline=mean_dict([d for d in deltas.values() if d]); occ=defaultdict(set); protos=defaultdict(list)
        for s in sessions:
            ts=tokens[s.session_id]; ss=segments[s.session_id]
            for n in range(1,self.config.max_ngram+1):
                for i in range(len(ts)-n+1):
                    p=tuple(ts[i:i+n]); occ[p].add(s.session_id)
                    if i<len(ss): protos[p].append(ss[i].segment_id)
        out=[]
        for pat,sids in sorted(occ.items(),key=lambda kv:(len(kv[0]),kv[0])):
            eids=sorted(sids); ds=[deltas[x] for x in eids if deltas[x]]
            if len(ds)<self.config.min_support:continue
            mean=mean_dict(ds); se=stderr_dict(ds,mean); direction={k:mean.get(k,0)-baseline.get(k,0) for k in set(mean)|set(baseline)}
            counter=[]
            for sid in eids:
                d=deltas[sid]
                centered={k:d.get(k,0)-baseline.get(k,0) for k in direction}
                if sum(centered.get(k,0)*direction.get(k,0) for k in direction)<=0: counter.append(sid)
            digest=hashlib.sha1(('\n'.join(pat)).encode()).hexdigest()[:12]
            out.append(EidoOperator(f'op:{digest}',pat,len(ds),mean,se,baseline,eids,counter,protos[pat][:8],self.config.protocol_version,{'ngram_len':len(pat)}))
        return out
