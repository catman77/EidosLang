from __future__ import annotations
import argparse,json
from pathlib import Path
from dataclasses import asdict
from enum import Enum
from .schema import EidoSession
from .segmenter import StrokeSegmenter
from .state import state_delta
from .discovery import LanguageDiscovery
from .causal import CausalAnalyzer
from .r3_synthetic import make_trials
from .topology import describe_session
from .r45_synthetic import make_report as make_r45_report
from .multilayer_topology import describe_multilayer_session
from .r46_synthetic import make_report as make_r46_report

def jsonable(x):
    if isinstance(x,Enum): return x.value
    if isinstance(x,tuple): return [jsonable(v) for v in x]
    if isinstance(x,list): return [jsonable(v) for v in x]
    if isinstance(x,dict): return {k:jsonable(v) for k,v in x.items()}
    return x

def load_session(p): return EidoSession.from_dict(json.loads(Path(p).read_text(encoding='utf-8')))

def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    a=sub.add_parser('analyze'); a.add_argument('session_json')
    d=sub.add_parser('discover'); d.add_argument('session_json',nargs='+')
    c=sub.add_parser('r3-synthetic'); c.add_argument('--n',type=int,default=16); c.add_argument('--seed',type=int,default=731)
    t=sub.add_parser('topology'); t.add_argument('session_json'); t.add_argument('--level',choices=['T0','T1','T2'],default='T2')
    sub.add_parser('r45-synthetic')
    ml=sub.add_parser('multilayer'); ml.add_argument('session_json')
    sub.add_parser('r46-synthetic')
    ns=ap.parse_args()
    if ns.cmd=='analyze':
        s=load_session(ns.session_json); toks,segs=StrokeSegmenter().tokens(s)
        print(json.dumps({'session_id':s.session_id,'segments':len(segs),'tokens':toks,'state_delta':state_delta(s)},ensure_ascii=False,indent=2))
    elif ns.cmd=='discover':
        report=LanguageDiscovery().fit([load_session(p) for p in ns.session_json])
        print(json.dumps(jsonable(asdict(report)),ensure_ascii=False,indent=2))
    elif ns.cmd=='r3-synthetic':
        trials=make_trials(n=ns.n,seed=ns.seed)
        cert=CausalAnalyzer().certify(trials,'op:synthetic',{'focus':'greater','noise':'less'})
        print(json.dumps(jsonable(asdict(cert)),ensure_ascii=False,indent=2))
    elif ns.cmd=='topology':
        td=describe_session(load_session(ns.session_json))
        print(json.dumps({'level':ns.level,'feature_vector':td.feature_vector(ns.level),'final':jsonable(asdict(td.final)),'temporal_signature':td.temporal.signature},ensure_ascii=False,indent=2))
    elif ns.cmd=='r45-synthetic':
        print(json.dumps(jsonable(make_r45_report()),ensure_ascii=False,indent=2))
    elif ns.cmd=='multilayer':
        td=describe_multilayer_session(load_session(ns.session_json))
        print(json.dumps({'feature_vector':td.t3_vector(),'signature':td.signature,'color_layers':jsonable([asdict(x) for x in td.color_layers]),'media_layers':jsonable([asdict(x) for x in td.media_layers]),'media_form_couplings':td.media_form_couplings},ensure_ascii=False,indent=2))
    else:
        print(json.dumps(jsonable(make_r46_report()),ensure_ascii=False,indent=2))
if __name__=='__main__': main()
