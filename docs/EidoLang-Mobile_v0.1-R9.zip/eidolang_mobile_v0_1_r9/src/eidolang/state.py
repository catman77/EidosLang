from __future__ import annotations
import math
from .schema import EidoSession

def state_delta(session:EidoSession):
    a,b=session.state_in(),session.state_out()
    if a is None or b is None:return {}
    ks=sorted(set(a.metrics)&set(b.metrics)); return {k:b.metrics[k]-a.metrics[k] for k in ks}

def desired_delta(current,target): return {k:target[k]-current[k] for k in sorted(set(current)&set(target))}
def norm(v): return math.sqrt(sum(x*x for x in v.values()))
def unit(v):
    n=norm(v); return {k:(x/n if n>1e-12 else 0.0) for k,x in v.items()}
def dot(a,b): return sum(a.get(k,0)*b.get(k,0) for k in set(a)|set(b))
def sub(a,b): return {k:a.get(k,0)-b.get(k,0) for k in set(a)|set(b)}
