from __future__ import annotations

from dataclasses import replace
from itertools import combinations
from functools import lru_cache

from .schema import EidoSession
from .geometry import shape_signature
from .operators import OperatorMiner, MinerConfig
from .acquisition import AcquisitionLedger
from .candidate_universe import (
    R3Disposition, R4PairDisposition, CandidateUniverseConfig,
    ExhaustiveCandidateUniverseEnumerator, freeze_generic_candidate_ledger,
)
from .r7_synthetic import run_r7_dryrun
from .prospective_instantiation import R7ConfirmationAnalyzer
from .r8_confirmation import R8ClosedConfirmationAnalyzer


SHAPES=(
    ("g0_diag",((.10,.10),(.50,.50),(.90,.90))),
    ("g0_anti",((.10,.90),(.50,.50),(.90,.10))),
    ("g0_horiz",((.10,.50),(.50,.50),(.90,.50))),
    ("g1_vert",((.50,.10),(.50,.50),(.50,.90))),
    ("g1_v",((.10,.10),(.50,.90),(.90,.10))),
    ("g1_a",((.10,.90),(.50,.10),(.90,.90))),
    ("g2_zig",((.10,.10),(.30,.80),(.50,.20),(.70,.80),(.90,.10))),
    ("g2_u",((.10,.10),(.10,.80),(.50,.90),(.90,.80),(.90,.10))),
    ("g2_box",((.10,.10),(.90,.10),(.90,.90),(.10,.90),(.10,.10))),
)


def _session(observer:str,label:str,points,rep:int) -> EidoSession:
    raw=[]
    for i,(x,y) in enumerate(points):
        typ="START" if i==0 else ("END" if i==len(points)-1 else "MOVE")
        raw.append({"type":typ,"t_us":i*100_000,"pointer_id":0,"x":x,"y":y})
    # State values are irrelevant to candidate identity but keep OperatorMiner's effect record valid.
    dy=.03*(1+(sum(ord(c) for c in label)%5))+.001*rep
    return EidoSession.from_dict({
        "session_id":f"{observer}:cand:{label}:{rep}",
        "protocol_version":"candidate-source-v1",
        "mode":"FREE","recommendation_mode":"NONE","raw_events":raw,
        "state_observations":[
            {"t_us":0,"metrics":{"focus":.2,"noise":.8}},
            {"t_us":max(400_000,len(points)*100_000),"metrics":{"focus":.2+dy,"noise":.8-dy}},
        ],
        "metadata":{"observer_id":observer,"candidate_source":True},
    })


def candidate_source_sessions(observer:str):
    return [
        _session(observer,label,pts,rep)
        for label,pts in SHAPES for rep in range(3)
    ]


def _signature_group():
    out={}
    for label,pts in SHAPES:
        sig,_=shape_signature(list(pts))
        out[sig]=int(label[1])
    return out


def build_observer_candidate_universe(observer:str,root_protocol_hash:str,policy_hash:str,macro_size:int=3):
    sessions=candidate_source_sessions(observer)
    byid={s.session_id:s for s in sessions}
    ledger=AcquisitionLedger(root_protocol_hash)
    for s in sessions:
        ledger.append(s)
    freeze=freeze_generic_candidate_ledger(
        "r8-synthetic-candidate-source",root_protocol_hash,observer,ledger,byid,
        external_commit_ref="synthetic:r8-source-freeze"
    )
    miner_cfg=MinerConfig(min_support=3,max_ngram=1,protocol_version="operator-miner-v1")
    mined=OperatorMiner(config=miner_cfg).mine(sessions)
    sig_group=_signature_group()
    group_by_op={o.operator_id:sig_group[o.pattern[0]] for o in mined}
    r3=[]
    for o in mined:
        from .acquisition import sha256_object
        r3.append(R3Disposition(
            o.operator_id,sha256_object(o),f"r3:{observer}:{o.operator_id}","PASS",
            "domain:shared","probe:2phase","causal-replay-v3"
        ))
    r3map={x.operator_id:x for x in r3}
    r4=[]
    for a,b in combinations(sorted(r3map),2):
        passed=group_by_op[a]==group_by_op[b]
        r4.append(R4PairDisposition(
            f"{a}::{b}",a,b,
            r3map[a].causal_certificate_id,r3map[b].causal_certificate_id,
            f"subst:{observer}:{a}:{b}","PASS" if passed else "FAIL",
            "domain:shared","probe:2phase",policy_hash,"causal-substitution-v4"
        ))
    cfg=CandidateUniverseConfig(
        observer_id=observer,data_freeze_hash=freeze.freeze_hash,
        miner_min_support=3,miner_max_ngram=1,miner_protocol_version="operator-miner-v1",
        domain_id="domain:shared",probe_schedule_id="probe:2phase",
        causal_protocol_version="causal-replay-v3",
        substitution_policy_hash=policy_hash,
        substitution_protocol_version="causal-substitution-v4",
        macro_size=macro_size,
        max_operator_candidates=100,max_pair_dispositions=1000,max_clique_combinations=1000,
    )
    cert=ExhaustiveCandidateUniverseEnumerator(cfg).certify(ledger,freeze,byid,r3,r4)
    if cert.status!="PASS":
        raise RuntimeError(cert)
    # Resolve the three synthetic graph components by operator group.
    macro_group={}
    for mc in cert.eligible_macro_names:
        gs={group_by_op[o] for o in mc.macro_name.operator_ids}
        if len(gs)!=1:
            raise RuntimeError("synthetic closure produced cross-group clique")
        macro_group[next(iter(gs))]=mc.macro_name_id
    if set(macro_group)!={0,1,2}:
        raise RuntimeError("synthetic closure did not yield exactly three clique groups")
    return cfg,ledger,freeze,byid,tuple(r3),tuple(r4),cert,macro_group


@lru_cache(maxsize=1)
def run_r8_dryrun():
    vals,dsel_align,csel_align,dsel,rule,csel,r7_old=run_r7_dryrun()
    m,b,split,ald,rgd,dclasses,dcert,hyp,alc,rgc,cclasses,pkg,r6=vals
    policy_hash=b.r4.as_substitution_policy().policy_hash()

    universes=[]; groupmap={}
    source_objects={}
    for oid in split.confirmation_observers():
        objs=build_observer_candidate_universe(oid,b.master_hash,policy_hash)
        cfg,ledger,freeze,byid,r3,r4,cert,mg=objs
        universes.append(cert); groupmap[oid]=mg; source_objects[oid]=objs

    # R7 generated the selector information before primary data were opened. Keep the
    # selector measurements but replace arbitrary synthetic MacroName labels by the
    # canonical all-clique IDs produced by R8 closure.
    csel2=[]
    for x in csel:
        if x.macro_name_id.endswith("C0"):
            mid=groupmap[x.observer_id][0]
        elif x.macro_name_id.endswith("C1"):
            mid=groupmap[x.observer_id][1]
        elif "DISTRACTOR" in x.macro_name_id:
            mid=groupmap[x.observer_id][2]
        else:
            raise RuntimeError("unknown synthetic selector class")
        csel2.append(replace(x,macro_name_id=mid))

    cclasses2=[]
    for x in cclasses:
        if x.macro_name_id.endswith("C0"):
            mid=groupmap[x.observer_id][0]
        elif x.macro_name_id.endswith("C1"):
            mid=groupmap[x.observer_id][1]
        else:
            raise RuntimeError("unknown synthetic primary class")
        cclasses2.append(replace(x,macro_name_id=mid))

    pkg2=replace(pkg,confirmation_class_refs=tuple(sorted(x.macro_name_id for x in cclasses2)))
    r8=R8ClosedConfirmationAnalyzer(
        split,hyp,pkg2,rule,csel_align,alc,rgc,universes
    ).certify(dclasses,csel2,cclasses2)
    return vals,dsel_align,csel_align,dsel,rule,tuple(csel2),tuple(cclasses2),pkg2,tuple(universes),source_objects,r8
