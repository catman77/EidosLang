from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from typing import Optional, Iterable

from .acquisition import sha256_object
from .cross_observer_transport import (
    R5TransportConfig,
    R5CausalClassObservation,
    R5TransportCertificate,
    R5CrossObserverTransportAnalyzer,
)
from .effect_alignment import EffectAlignmentReport
from .reliability import ReliabilityGateResult


@dataclass(frozen=True)
class CohortAssignment:
    observer_id: str
    role: str
    rank_hash: str


@dataclass(frozen=True)
class R6SplitManifest:
    study_id: str
    root_protocol_hash: str
    observer_ids: tuple[str, ...]
    discovery_count: int
    split_seed: str
    minimum_confirmation_observers: int = 6
    role_policy: str = "HASH_RANK_DISJOINT"
    external_commit_ref: Optional[str] = None

    def __post_init__(self):
        if len(set(self.observer_ids)) != len(self.observer_ids):
            raise ValueError("observer_ids must be unique")
        if self.discovery_count < 1 or self.discovery_count >= len(self.observer_ids):
            raise ValueError("discovery_count must leave both cohorts nonempty")
        if self.minimum_confirmation_observers < 2:
            raise ValueError("minimum_confirmation_observers must be >=2")
        if len(self.observer_ids)-self.discovery_count < self.minimum_confirmation_observers:
            raise ValueError("confirmation cohort is smaller than required")
        if self.role_policy != "HASH_RANK_DISJOINT":
            raise ValueError("unsupported role policy")

    @property
    def manifest_hash(self) -> str:
        return sha256_object(self)

    def assignments(self) -> tuple[CohortAssignment, ...]:
        ranked = sorted(
            (
                sha256((self.root_protocol_hash+"\0"+self.split_seed+"\0"+oid).encode()).hexdigest(),
                oid,
            )
            for oid in self.observer_ids
        )
        discovery={oid for _,oid in ranked[:self.discovery_count]}
        return tuple(sorted(
            (CohortAssignment(oid,"DISCOVERY" if oid in discovery else "CONFIRMATION",h)
             for h,oid in ranked),
            key=lambda x:x.observer_id,
        ))

    def discovery_observers(self) -> tuple[str, ...]:
        return tuple(a.observer_id for a in self.assignments() if a.role=="DISCOVERY")

    def confirmation_observers(self) -> tuple[str, ...]:
        return tuple(a.observer_id for a in self.assignments() if a.role=="CONFIRMATION")


@dataclass(frozen=True)
class FrozenTransportHypothesis:
    hypothesis_id: str
    source_discovery_observers: tuple[str, ...]
    causal_class_count: int
    realizations_per_class: int
    topology_representation: str
    topology_extractor_version: str
    r5_statistic_version: str
    effect_metric_keys: tuple[str, ...]
    class_semantics: str
    discovery_macro_name_refs: tuple[str, ...]
    discovery_r5_config_hash: str
    discovery_evidence_refs: tuple[str, ...]
    selection_rule: str
    forbidden_postfreeze_changes: tuple[str, ...]
    external_commit_ref: Optional[str] = None

    @property
    def hypothesis_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class ConfirmationPackage:
    split_manifest_hash: str
    frozen_hypothesis_hash: str
    confirmation_observers: tuple[str, ...]
    r5_config: R5TransportConfig
    confirmation_data_freeze_ref: str
    confirmation_alignment_ref: str
    confirmation_reliability_ref: str
    confirmation_class_refs: tuple[str, ...]
    compiler_runtime_lock_hash: str
    external_commit_ref: Optional[str] = None

    @property
    def package_hash(self) -> str:
        return sha256_object(self)


@dataclass(frozen=True)
class LeakageAudit:
    status: str
    reasons: tuple[str, ...]
    discovery_observers: tuple[str, ...]
    confirmation_observers: tuple[str, ...]
    discovery_session_ids: tuple[str, ...]
    confirmation_session_ids: tuple[str, ...]


@dataclass(frozen=True)
class R6ConfirmationCertificate:
    certificate_id: str
    split_manifest_hash: str
    frozen_hypothesis_hash: str
    confirmation_package_hash: str
    leakage_audit: LeakageAudit
    r5_certificate: R5TransportCertificate
    status: str
    passed: bool
    reasons: tuple[str, ...]
    protocol_version: str = "discovery-confirmation-v1"

    @property
    def certificate_hash(self) -> str:
        return sha256_object(self)


def freeze_transport_hypothesis(
    split: R6SplitManifest,
    discovery_r5_config: R5TransportConfig,
    discovery_macro_name_refs: Iterable[str],
    discovery_evidence_refs: Iterable[str],
    external_commit_ref: Optional[str] = None,
) -> FrozenTransportHypothesis:
    disc=split.discovery_observers()
    if set(discovery_r5_config.observer_ids) != set(disc):
        raise ValueError("discovery R5 observer set must equal discovery cohort")
    if discovery_r5_config.causal_class_count != 2:
        raise ValueError("R6 v1 freezes binary transport only")
    return FrozenTransportHypothesis(
        hypothesis_id="hyp:"+sha256_object({
            "split":split.manifest_hash,
            "r5":discovery_r5_config.config_hash,
            "macros":sorted(discovery_macro_name_refs),
        })[:16],
        source_discovery_observers=disc,
        causal_class_count=discovery_r5_config.causal_class_count,
        realizations_per_class=discovery_r5_config.realizations_per_class,
        topology_representation=discovery_r5_config.topology_representation,
        topology_extractor_version=discovery_r5_config.topology_extractor_version,
        r5_statistic_version=discovery_r5_config.statistic_version,
        effect_metric_keys=discovery_r5_config.effect_metric_keys,
        class_semantics="operational_binary_transport_only",
        discovery_macro_name_refs=tuple(sorted(discovery_macro_name_refs)),
        discovery_r5_config_hash=discovery_r5_config.config_hash,
        discovery_evidence_refs=tuple(sorted(discovery_evidence_refs)),
        selection_rule="ALL_DISCOVERY_CLASSES_PASSING_FROZEN_R4_CUTOFF",
        forbidden_postfreeze_changes=(
            "topology representation",
            "topology extractor version",
            "R5 primary statistic",
            "effect metric set",
            "causal class count",
            "realizations per class",
            "class selection rule",
        ),
        external_commit_ref=external_commit_ref,
    )


def audit_discovery_confirmation_separation(
    split: R6SplitManifest,
    hypothesis: FrozenTransportHypothesis,
    discovery_classes: Iterable[R5CausalClassObservation],
    confirmation_classes: Iterable[R5CausalClassObservation],
) -> LeakageAudit:
    reasons=[]
    disc=set(split.discovery_observers())
    conf=set(split.confirmation_observers())
    if disc & conf:
        reasons.append("observer cohorts overlap")
    if set(hypothesis.source_discovery_observers) != disc:
        reasons.append("frozen hypothesis discovery observer set mismatch")

    d=list(discovery_classes); c=list(confirmation_classes)
    if not {x.observer_id for x in d} <= disc:
        reasons.append("discovery classes contain non-discovery observer")
    if not {x.observer_id for x in c} <= conf:
        reasons.append("confirmation classes contain non-confirmation observer")

    ds={s.session_id for x in d for s in x.realization_sessions}
    cs={s.session_id for x in c for s in x.realization_sessions}
    if ds & cs:
        reasons.append("session reuse across discovery/confirmation")

    d3={r for x in d for r in x.operator_causal_certificate_refs}
    c3={r for x in c for r in x.operator_causal_certificate_refs}
    if d3 & c3:
        reasons.append("R3 certificate reuse across discovery/confirmation")

    d4={r for x in d for r in x.substitution_certificate_refs}
    c4={r for x in c for r in x.substitution_certificate_refs}
    if d4 & c4:
        reasons.append("R4 substitution certificate reuse across discovery/confirmation")

    dm={x.macro_name_id for x in d}
    cm={x.macro_name_id for x in c}
    if dm & cm:
        reasons.append("MacroName object reused across discovery/confirmation")

    return LeakageAudit(
        "PASS" if not reasons else "FAIL",
        tuple(reasons),tuple(sorted(disc)),tuple(sorted(conf)),
        tuple(sorted(ds)),tuple(sorted(cs)),
    )


def validate_confirmation_package(
    split: R6SplitManifest,
    hypothesis: FrozenTransportHypothesis,
    package: ConfirmationPackage,
) -> tuple[str, ...]:
    reasons=[]
    conf=split.confirmation_observers()
    cfg=package.r5_config
    if package.split_manifest_hash != split.manifest_hash:
        reasons.append("split manifest hash mismatch")
    if package.frozen_hypothesis_hash != hypothesis.hypothesis_hash:
        reasons.append("frozen hypothesis hash mismatch")
    if tuple(sorted(package.confirmation_observers)) != tuple(sorted(conf)):
        reasons.append("confirmation observer set mismatch")
    if tuple(sorted(cfg.observer_ids)) != tuple(sorted(conf)):
        reasons.append("R5 observer set differs from confirmation cohort")
    if cfg.causal_class_count != hypothesis.causal_class_count:
        reasons.append("causal class count changed after freeze")
    if cfg.realizations_per_class != hypothesis.realizations_per_class:
        reasons.append("realizations/class changed after freeze")
    if cfg.topology_representation != hypothesis.topology_representation:
        reasons.append("topology representation changed after freeze")
    if cfg.topology_extractor_version != hypothesis.topology_extractor_version:
        reasons.append("topology extractor changed after freeze")
    if cfg.statistic_version != hypothesis.r5_statistic_version:
        reasons.append("R5 statistic changed after freeze")
    if tuple(cfg.effect_metric_keys) != tuple(hypothesis.effect_metric_keys):
        reasons.append("effect metric set changed after freeze")
    if not package.confirmation_data_freeze_ref:
        reasons.append("missing confirmation data-freeze reference")
    if not package.confirmation_alignment_ref:
        reasons.append("missing confirmation alignment reference")
    if not package.confirmation_reliability_ref:
        reasons.append("missing confirmation reliability reference")
    if not package.compiler_runtime_lock_hash:
        reasons.append("missing compiler runtime lock hash")
    return tuple(reasons)


class R6ConfirmationAnalyzer:
    def __init__(
        self,
        split: R6SplitManifest,
        hypothesis: FrozenTransportHypothesis,
        package: ConfirmationPackage,
        alignment_report: EffectAlignmentReport,
        reliability: ReliabilityGateResult,
    ):
        self.split=split
        self.hypothesis=hypothesis
        self.package=package
        self.alignment_report=alignment_report
        self.reliability=reliability

    def certify(
        self,
        discovery_classes: Iterable[R5CausalClassObservation],
        confirmation_classes: Iterable[R5CausalClassObservation],
    ) -> R6ConfirmationCertificate:
        d=list(discovery_classes); c=list(confirmation_classes)
        reasons=list(validate_confirmation_package(self.split,self.hypothesis,self.package))
        audit=audit_discovery_confirmation_separation(self.split,self.hypothesis,d,c)
        if audit.status != "PASS":
            reasons.extend(audit.reasons)

        if reasons:
            r5=R5TransportCertificate(
                "r5:not-run",self.package.r5_config.config_hash,
                self.package.r5_config.reference_observer_id,
                self.package.r5_config.observer_ids,None,None,0,False,None,
                self.package.r5_config.alpha_local,(),(),"INVALID",False,
                ("R6 prerequisite failure",),self.package.r5_config.protocol_version,
            )
            return R6ConfirmationCertificate(
                "r6:invalid",self.split.manifest_hash,self.hypothesis.hypothesis_hash,
                self.package.package_hash,audit,r5,"INVALID",False,tuple(reasons)
            )

        r5=R5CrossObserverTransportAnalyzer(
            self.package.r5_config,self.alignment_report,self.reliability
        ).certify(c)
        status="PASS" if r5.passed else ("UNRESOLVED" if r5.status=="UNRESOLVED" else "FAIL")
        reasons2=() if r5.passed else (f"independent confirmation R5 did not pass: {r5.status}",)
        cid="r6:"+sha256_object({
            "split":self.split.manifest_hash,"hyp":self.hypothesis.hypothesis_hash,
            "pkg":self.package.package_hash,"r5":r5.certificate_id,
        })[:16]
        return R6ConfirmationCertificate(
            cid,self.split.manifest_hash,self.hypothesis.hypothesis_hash,
            self.package.package_hash,audit,r5,status,r5.passed,reasons2
        )
