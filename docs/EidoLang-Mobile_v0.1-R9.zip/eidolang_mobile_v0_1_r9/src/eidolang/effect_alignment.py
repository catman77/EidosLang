from __future__ import annotations
from dataclasses import dataclass
from itertools import permutations
from math import factorial
from typing import Iterable, Optional
import numpy as np

from .schema import EidoSession
from .state import state_delta

@dataclass(frozen=True)
class AnchorObservation:
    observer_id: str
    anchor_id: str
    effect: dict[str, float]
    source_ref: str = ''
    protocol_version: str = 'anchor-v1'

@dataclass(frozen=True)
class AlignmentConfig:
    fit_anchor_ids: tuple[str, ...]
    holdout_anchor_ids: tuple[str, ...]
    holdout_rmse_margin: float
    alpha_familywise: float = 0.05
    min_rank: Optional[int] = None
    permutation_cap: int = 100_000
    protocol_version: str = 'effect-alignment-v1'

@dataclass(frozen=True)
class SimilarityTransform:
    source_observer: str
    reference_observer: str
    metric_keys: tuple[str, ...]
    scale: float
    rotation: tuple[tuple[float, ...], ...]

    def map_delta(self, effect: dict[str, float]) -> dict[str, float]:
        x=np.array([float(effect[k]) for k in self.metric_keys],dtype=float)
        r=np.array(self.rotation,dtype=float)
        y=self.scale*(x@r)
        return {k:float(v) for k,v in zip(self.metric_keys,y)}

@dataclass(frozen=True)
class ObserverAlignmentResult:
    observer_id: str
    reference_observer: str
    status: str
    metric_keys: tuple[str, ...]
    rank_source: int
    rank_reference: int
    fit_rmse: Optional[float]
    holdout_rmse: Optional[float]
    margin: float
    permutation_p: Optional[float]
    permutations_evaluated: int
    adjusted_alpha: float
    transform: Optional[SimilarityTransform]
    reason: str

@dataclass(frozen=True)
class EffectAlignmentReport:
    reference_observer: str
    results: tuple[ObserverAlignmentResult, ...]
    passed: bool
    aligned_observers: tuple[str, ...]
    blocked_observers: tuple[str, ...]
    reason: str

def anchor_from_session(session: EidoSession) -> AnchorObservation:
    md=session.metadata
    observer_id=str(md.get('observer_id','')).strip()
    anchor_id=str(md.get('anchor_id','')).strip()
    protocol=str(md.get('anchor_protocol_version','anchor-v1'))
    if not observer_id or not anchor_id:
        raise ValueError('anchor session requires metadata.observer_id and metadata.anchor_id')
    d=state_delta(session)
    if not d:
        raise ValueError('anchor session requires compatible pre/post state observations')
    return AnchorObservation(observer_id,anchor_id,d,session.session_id,protocol)

def collect_anchor_observations(sessions: Iterable[EidoSession]) -> list[AnchorObservation]:
    return [anchor_from_session(s) for s in sessions]

def _index(observations: Iterable[AnchorObservation]):
    d={}
    for o in observations:
        key=(o.observer_id,o.anchor_id)
        if key in d:
            raise ValueError(f'duplicate anchor observation: {key}')
        d[key]=o
    return d

def _keys_for(index, observers, anchor_ids):
    keys=None
    for obs in observers:
        for aid in anchor_ids:
            o=index.get((obs,aid))
            if o is None:
                raise ValueError(f'missing anchor {aid!r} for observer {obs!r}')
            k=set(o.effect)
            keys=k if keys is None else keys & k
    return tuple(sorted(keys or ()))

def _matrix(index, observer, anchor_ids, metric_keys):
    return np.array([[index[(observer,a)].effect[k] for k in metric_keys] for a in anchor_ids],dtype=float)

def _fit_zero_similarity(x: np.ndarray, y: np.ndarray):
    # Row-vector convention: y ~= scale * x @ R, R orthogonal.
    c=x.T@y
    u,s,vt=np.linalg.svd(c,full_matrices=False)
    r=u@vt
    denom=float(np.sum(x*x))
    if denom <= 1e-15:
        raise ValueError('zero anchor energy: similarity transport not identifiable')
    scale=float(np.sum(s)/denom)
    pred=scale*(x@r)
    rmse=float(np.sqrt(np.mean((pred-y)**2)))
    return scale,r,rmse

def _rmse(x,y,scale,r):
    pred=scale*(x@r)
    return float(np.sqrt(np.mean((pred-y)**2)))

def _rank(x):
    return int(np.linalg.matrix_rank(x))

class CrossObserverEffectAligner:
    """Empirical transport gate for observer-state effect coordinates.

    First admitted transport family: zero-preserving global similarity transform.
    Affine/nonlinear maps are not tried automatically after failure.
    """
    def __init__(self, config: AlignmentConfig):
        self.config=config

    def align(self, observations: list[AnchorObservation], reference_observer: str) -> EffectAlignmentReport:
        cfg=self.config
        if set(cfg.fit_anchor_ids) & set(cfg.holdout_anchor_ids):
            raise ValueError('fit and holdout anchor ids must be disjoint')
        if len(cfg.fit_anchor_ids) < 2 or len(cfg.holdout_anchor_ids) < 1:
            raise ValueError('need >=2 fit anchors and >=1 holdout anchor')
        index=_index(observations)
        observers=sorted({o.observer_id for o in observations})
        if reference_observer not in observers:
            raise ValueError('reference observer absent')
        protocol_versions={o.protocol_version for o in observations}
        if len(protocol_versions)!=1:
            reason='INVALID: mixed anchor protocol versions'
            return EffectAlignmentReport(reference_observer,tuple(),False,tuple(),tuple(observers),reason)
        all_anchor_ids=cfg.fit_anchor_ids+cfg.holdout_anchor_ids
        try:
            metric_keys=_keys_for(index,observers,all_anchor_ids)
        except ValueError as e:
            return EffectAlignmentReport(reference_observer,tuple(),False,tuple(),tuple(observers),f'INVALID: {e}')
        if not metric_keys:
            return EffectAlignmentReport(reference_observer,tuple(),False,tuple(),tuple(observers),'INVALID: no common metric coordinates')

        ref_fit=_matrix(index,reference_observer,cfg.fit_anchor_ids,metric_keys)
        ref_hold=_matrix(index,reference_observer,cfg.holdout_anchor_ids,metric_keys)
        dim=len(metric_keys)
        required_rank=dim if cfg.min_rank is None else int(cfg.min_rank)
        n_nonref=max(1,len(observers)-1)
        adjusted=cfg.alpha_familywise/n_nonref
        results=[]; aligned=[reference_observer]; blocked=[]

        for obs in observers:
            if obs==reference_observer: continue
            src_fit=_matrix(index,obs,cfg.fit_anchor_ids,metric_keys)
            src_hold=_matrix(index,obs,cfg.holdout_anchor_ids,metric_keys)
            rs,rr=_rank(src_fit),_rank(ref_fit)
            if min(rs,rr)<required_rank:
                results.append(ObserverAlignmentResult(obs,reference_observer,'INVALID',metric_keys,rs,rr,None,None,cfg.holdout_rmse_margin,None,0,adjusted,None,f'anchor rank {min(rs,rr)} < required {required_rank}'))
                blocked.append(obs); continue
            nperm=factorial(len(cfg.fit_anchor_ids))
            if nperm>cfg.permutation_cap:
                results.append(ObserverAlignmentResult(obs,reference_observer,'UNRESOLVED',metric_keys,rs,rr,None,None,cfg.holdout_rmse_margin,None,0,adjusted,None,f'exact anchor permutation count {nperm} > cap {cfg.permutation_cap}'))
                blocked.append(obs); continue
            try:
                scale,r,fit_rmse=_fit_zero_similarity(src_fit,ref_fit)
            except ValueError as e:
                results.append(ObserverAlignmentResult(obs,reference_observer,'INVALID',metric_keys,rs,rr,None,None,cfg.holdout_rmse_margin,None,0,adjusted,None,str(e)))
                blocked.append(obs); continue
            hold_rmse=_rmse(src_hold,ref_hold,scale,r)

            better=0; evaluated=0
            base=list(range(len(cfg.fit_anchor_ids)))
            for perm in permutations(base):
                yperm=ref_fit[list(perm),:]
                try:
                    ps,pr,_=_fit_zero_similarity(src_fit,yperm)
                except ValueError:
                    continue
                er=_rmse(src_hold,ref_hold,ps,pr)
                evaluated+=1
                if er <= hold_rmse + 1e-12:
                    better+=1
            p=better/evaluated if evaluated else None
            passes_margin=hold_rmse<=cfg.holdout_rmse_margin
            passes_perm=(p is not None and p<=adjusted)
            status='PASS' if passes_margin and passes_perm else 'FAIL'
            reason=f'{status}: holdout_rmse={hold_rmse:.6f} <= {cfg.holdout_rmse_margin:.6f}: {passes_margin}; exact_p={p:.6g} <= adjusted_alpha={adjusted:.6g}: {passes_perm}'
            tr=SimilarityTransform(obs,reference_observer,metric_keys,scale,tuple(tuple(float(v) for v in row) for row in r))
            results.append(ObserverAlignmentResult(obs,reference_observer,status,metric_keys,rs,rr,fit_rmse,hold_rmse,cfg.holdout_rmse_margin,p,evaluated,adjusted,tr,reason))
            (aligned if status=='PASS' else blocked).append(obs)

        passed=(len(blocked)==0 and len(aligned)==len(observers))
        reason=('PASS' if passed else 'BLOCKED')+f': aligned={len(aligned)}/{len(observers)}; cross-observer causal-class comparison '+('admitted' if passed else 'not admitted')
        return EffectAlignmentReport(reference_observer,tuple(results),passed,tuple(sorted(aligned)),tuple(sorted(blocked)),reason)
