from __future__ import annotations
from dataclasses import asdict
import math
from .schema import EidoSession
from .topological_discovery import TopologicalExample
from .multilayer_topology import describe_multilayer_session
from .multilayer_discovery import CrossObserverMultilayerEvaluator


def _circle(cx,cy,r,n=24,phase=0.0):
    pts=[(cx+r*math.cos(2*math.pi*i/n+phase),cy+r*math.sin(2*math.pi*i/n+phase)) for i in range(n)]
    return pts+[pts[0]]

def _square(cx,cy,r):
    p=[(cx-r,cy-r),(cx+r,cy-r),(cx+r,cy+r),(cx-r,cy+r)]; return p+[p[0]]

def _diamond(cx,cy,r):
    p=[(cx,cy-r),(cx+r,cy),(cx,cy+r),(cx-r,cy)]; return p+[p[0]]

def _triangle(cx,cy,r):
    p=[(cx,cy-r),(cx+r*.9,cy+r*.7),(cx-r*.9,cy+r*.7)]; return p+[p[0]]

SHAPES=(_circle,_square,_diamond,_triangle)
COLORS=(('#d33','#26a'),('#080','#a40'),('#609','#0aa'),('#111','#bbb'),('#f80','#05f'),('#b07','#297'))


def _session(sid,strokes,colors,media=None):
    ev=[]; t=0
    current=None
    for pid,(pts,col) in enumerate(zip(strokes,colors)):
        if col!=current:
            ev.append({'type':'COLOR','t_us':t,'payload':{'value':col}}); current=col
        start=t
        for j,(x,y) in enumerate(pts):
            typ='START' if j==0 else ('END' if j==len(pts)-1 else 'MOVE')
            ev.append({'type':typ,'t_us':t,'pointer_id':pid,'x':x,'y':y}); t+=10_000
        if media:
            for m in media:
                if m.get('stroke')==pid:
                    # Put episode deterministically in middle of this stroke.
                    mt=(start+t)//2
                    ev.append({'type':m['type'],'t_us':mt,'payload':{'duration_ms':m.get('duration_ms',20),'code':m.get('code','x')}})
        t+=40_000
    return EidoSession.from_dict({'session_id':sid,'protocol_version':'0.1-R4.6','mode':'RECALL','recommendation_mode':'NONE','started_at':'','raw_events':ev,'state_observations':[]})


def necessity_examples():
    # Same form/T2, different relation between color layers: two layers vs one layer.
    outer=_circle(.5,.5,.34); inner=_square(.5,.5,.14)
    split=_session('r46:split',[outer,inner],['#a00','#00a'])
    unified=_session('r46:unified',[outer,inner],['#a00','#a00'])

    # Same form and same colors; HAPTIC is coupled to a different topological event.
    # Three open sides + closing side assembled as four strokes.
    s1=[(.25,.25),(.75,.25)]; s2=[(.75,.25),(.75,.75)]; s3=[(.75,.75),(.25,.75)]; s4=[(.25,.75),(.25,.25)]
    media_early=_session('r46:haptic-early',[s1,s2,s3,s4],['#111']*4,[{'type':'HAPTIC','stroke':0,'duration_ms':30}])
    media_close=_session('r46:haptic-close',[s1,s2,s3,s4],['#111']*4,[{'type':'HAPTIC','stroke':3,'duration_ms':30}])
    # Harder collision: identical form, same number of layers, same per-layer topology multiset,
    # same color-switch count and same cross-color containment count. Only the equality pattern
    # along the containment chain differs: ABAC vs ABCB.
    rings=[_circle(.5,.5,.38),_square(.5,.5,.29),_diamond(.5,.5,.20),_triangle(.5,.5,.11)]
    abac=_session('r46:nest-abac',rings,['A','B','A','C'])
    abcb=_session('r46:nest-abcb',rings,['A','B','C','B'])
    return split,unified,media_early,media_close,abac,abcb


def make_cross_observer_examples():
    out=[]
    for oi in range(6):
        obs=f'obs:{oi}'; a,b=COLORS[oi]
        outer=SHAPES[oi%len(SHAPES)](.5,.5,.34) if oi%len(SHAPES)!=0 else _circle(.5,.5,.34,phase=.03*oi)
        inner=SHAPES[(oi+1)%len(SHAPES)](.5,.5,.14) if (oi+1)%len(SHAPES)!=0 else _circle(.5,.5,.14,phase=.07*oi)
        # SAME form topology in both classes. Actual color identities differ by observer.
        # Class SPLIT: nested components occupy two visual layers.
        x=_session(f'{obs}:split',[outer,inner],[a,b])
        # Class UNIFIED: both components occupy one visual layer.
        y=_session(f'{obs}:unified',[outer,inner],[a,a])
        out.append(TopologicalExample(x.session_id,obs,'class:split-layers',x))
        out.append(TopologicalExample(y.session_id,obs,'class:unified-layer',y))
    return out


def make_report():
    split,unified,early,close,abac,abcb=necessity_examples()
    ds,du,de,dc,da,db=[describe_multilayer_session(s) for s in (split,unified,early,close,abac,abcb)]
    r=CrossObserverMultilayerEvaluator(negative_controls=16).evaluate(make_cross_observer_examples(),min_gain=.25)
    return {
      'necessity':{
        'same_form_different_color_layer_topology':{
          'T2_equal':ds.form.temporal.signature==du.form.temporal.signature,
          'T3_equal':ds.signature==du.signature,
          'split_color_layers':len(ds.color_layers),'unified_color_layers':len(du.color_layers),
          'interpretation':'Form topology alone loses whether nested structures occupy one or multiple visual layers.'
        },
        'same_form_same_color_different_haptic_coupling':{
          'T2_equal':de.form.temporal.signature==dc.form.temporal.signature,
          'T3_equal':de.signature==dc.signature,
          'early_couplings':de.media_form_couplings,'close_couplings':dc.media_form_couplings,
          'interpretation':'Media timing is relational: identical haptic pulses differ by the topological event they overlap.'
        },
        'same_summary_different_layer_nesting_pattern':{
          'T2_equal':da.form.temporal.signature==db.form.temporal.signature,
          'color_layer_count_equal':len(da.color_layers)==len(db.color_layers),
          'anonymous_layer_multiset_equal':da.anonymous_color_signatures==db.anonymous_color_signatures,
          'color_switches_equal':da.color_switches==db.color_switches,
          'cross_color_containment_equal':da.cross_color_containment_edges==db.cross_color_containment_edges,
          'patterns_A':da.color_nesting_patterns,'patterns_B':db.color_nesting_patterns,
          'T3_equal':da.signature==db.signature,
          'interpretation':'Layer counts and aggregate cross-layer counts are insufficient; the equality pattern along the containment poset must be retained.'
        }
      },
      'transport':asdict(r)
    }
