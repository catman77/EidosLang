from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from itertools import combinations, product
from math import comb
import hashlib, math, random
from typing import Any, Optional

from .schema import StateObservation
from .causal import StateProbe, ProbeKind


class SubstitutionArm(str, Enum):
    LEFT = "LEFT"
    RIGHT = "RIGHT"


class EquivalenceStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    UNRESOLVED = "UNRESOLVED"
    INVALID = "INVALID"


@dataclass(frozen=True)
class CertifiedOperatorRef:
    operator_id: str
    causal_certificate_id: str
    causal_certificate_passed: bool
    domain_id: str
    probe_schedule_id: str
    causal_protocol_version: str = "causal-replay-v3"


@dataclass(frozen=True)
class DomainSpec:
    domain_id: str
    metric_bounds: dict[str, tuple[float, float]]
    required_metrics: tuple[str, ...] = ()

    def contains(self, state: StateObservation) -> bool:
        for metric in self.required_metrics:
            if metric not in state.metrics:
                return False
        for metric, (lo, hi) in self.metric_bounds.items():
            if metric not in state.metrics:
                return False
            v = state.metrics[metric]
            if not (lo <= v <= hi):
                return False
        return True


@dataclass
class SubstitutionTrial:
    trial_id: str
    pair_id: str
    arm: SubstitutionArm
    operator_id: str
    template_id: str
    assignment_seed: int
    randomized: bool
    domain_id: str
    stratum_id: str
    probe_schedule_id: str
    pre_state: StateObservation
    post_state: StateObservation
    probes: tuple[StateProbe, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    def delta(self, metric: str) -> Optional[float]:
        if metric not in self.pre_state.metrics or metric not in self.post_state.metrics:
            return None
        return self.post_state.metrics[metric] - self.pre_state.metrics[metric]


@dataclass(frozen=True)
class SubstitutionPolicy:
    endpoint_margins: dict[str, float]
    trajectory_margins: dict[str, float]
    alpha_familywise: float = 0.05
    min_trials_per_arm_per_stratum: int = 4
    max_exact_allocations: int = 200_000
    protocol_version: str = "causal-substitution-v4"

    def __post_init__(self):
        if not 0.0 < self.alpha_familywise < 1.0:
            raise ValueError("alpha_familywise must be in (0,1)")
        if self.min_trials_per_arm_per_stratum < 2:
            raise ValueError("min_trials_per_arm_per_stratum must be >=2")
        for name, margins in (("endpoint", self.endpoint_margins), ("trajectory", self.trajectory_margins)):
            for metric, eps in margins.items():
                if eps <= 0:
                    raise ValueError(f"{name} margin for {metric} must be >0")

    def policy_hash(self) -> str:
        payload = repr((
            tuple(sorted(self.endpoint_margins.items())),
            tuple(sorted(self.trajectory_margins.items())),
            self.alpha_familywise,
            self.min_trials_per_arm_per_stratum,
            self.max_exact_allocations,
            self.protocol_version,
        ))
        return hashlib.sha256(payload.encode()).hexdigest()[:16]


@dataclass(frozen=True)
class EquivalenceEstimate:
    metric: str
    phase_index: Optional[int]
    stratum_id: str
    n_left: int
    n_right: int
    mean_left_change: float
    mean_right_change: float
    observed_difference: float
    margin: float
    alpha_local: float
    p_lower_boundary: Optional[float]
    p_upper_boundary: Optional[float]
    exact_allocations: int
    exact_test_completed: bool
    status: EquivalenceStatus
    notes: tuple[str, ...] = ()


@dataclass(frozen=True)
class SubstitutionCertificate:
    certificate_id: str
    pair_id: str
    left_operator_id: str
    right_operator_id: str
    left_causal_certificate_id: str
    right_causal_certificate_id: str
    domain_id: str
    probe_schedule_id: str
    policy_hash: str
    estimates: tuple[EquivalenceEstimate, ...]
    passed: bool
    status: EquivalenceStatus
    protocol_version: str
    notes: tuple[str, ...] = ()


@dataclass(frozen=True)
class CausalMacroName:
    name_id: str
    operator_ids: tuple[str, ...]
    pair_certificate_ids: tuple[str, ...]
    domain_id: str
    probe_schedule_id: str
    policy_hash: str
    protocol_version: str
    semantics: str = "operational_substitution_at_protocol_resolution"


def _stable_seed(seed: int, stratum: str) -> int:
    h = hashlib.sha256(f"{seed}|{stratum}".encode()).digest()
    return int.from_bytes(h[:8], "big")


def stratified_balanced_assignment(trial_to_stratum: dict[str, str], seed: int) -> dict[str, SubstitutionArm]:
    """Deterministic balanced randomization independently inside each pre-registered stratum."""
    by: dict[str, list[str]] = {}
    for tid, st in trial_to_stratum.items():
        by.setdefault(st, []).append(tid)
    out: dict[str, SubstitutionArm] = {}
    for st in sorted(by):
        ids = sorted(set(by[st]))
        if len(ids) < 2:
            raise ValueError(f"stratum {st!r} has fewer than 2 trials")
        rng = random.Random(_stable_seed(seed, st))
        rng.shuffle(ids)
        n_left = len(ids) // 2
        for i, tid in enumerate(ids):
            out[tid] = SubstitutionArm.LEFT if i < n_left else SubstitutionArm.RIGHT
    return out


def _mean(xs: list[float]) -> float:
    return sum(xs) / len(xs) if xs else float("nan")


def _diff(left: list[float], right: list[float]) -> float:
    return _mean(left) - _mean(right)


def _one_sided_extreme(stat: float, obs: float, alternative: str) -> bool:
    eps = 1e-15
    if alternative == "greater":
        return stat >= obs - eps
    if alternative == "less":
        return stat <= obs + eps
    raise ValueError("alternative must be greater|less")


def _stratum_stat(values: dict[str, list[tuple[float, SubstitutionArm]]]) -> float:
    total_n = sum(len(v) for v in values.values())
    if total_n == 0:
        return float("nan")
    acc = 0.0
    for st, rows in values.items():
        l = [v for v, a in rows if a == SubstitutionArm.LEFT]
        r = [v for v, a in rows if a == SubstitutionArm.RIGHT]
        if not l or not r:
            return float("nan")
        acc += (len(rows) / total_n) * (_mean(l) - _mean(r))
    return acc


def _exact_boundary_p(
    rows_by_stratum: dict[str, list[tuple[str, float, SubstitutionArm]]],
    tau0: float,
    alternative: str,
    max_allocations: int,
) -> tuple[Optional[float], int, bool]:
    """
    Exact randomization test at a *sharp constant-additive* boundary tau0.

    For observed LEFT assignment z, construct invariant outcome y0 = y - tau0*z.
    Enumerate all allocations allowed by the original stratified balanced design.
    This is exact for the sharp additive null; it is not a free theorem about arbitrary
    heterogeneous unit-level substitution effects.
    """
    strata = sorted(rows_by_stratum)
    choice_lists = []
    allocations = 1
    adjusted: dict[str, list[tuple[str, float, SubstitutionArm]]] = {}
    observed_values: dict[str, list[tuple[float, SubstitutionArm]]] = {}
    for st in strata:
        rows = rows_by_stratum[st]
        n_left = sum(a == SubstitutionArm.LEFT for _, _, a in rows)
        if n_left <= 0 or n_left >= len(rows):
            return None, 0, False
        allocations *= comb(len(rows), n_left)
        if allocations > max_allocations:
            return None, allocations, False
        ids = [tid for tid, _, _ in rows]
        choice_lists.append((st, tuple(combinations(range(len(rows)), n_left))))
        ar = []
        ov = []
        for tid, y, arm in rows:
            z = 1.0 if arm == SubstitutionArm.LEFT else 0.0
            ar.append((tid, y - tau0 * z, arm))
            ov.append((y, arm))
        adjusted[st] = ar
        observed_values[st] = ov

    obs = _stratum_stat(observed_values) - tau0
    extreme = 0
    total = 0
    iterables = [x[1] for x in choice_lists]
    for combo in product(*iterables):
        perm_values: dict[str, list[tuple[float, SubstitutionArm]]] = {}
        for st, chosen in zip(strata, combo):
            chosen_set = set(chosen)
            arr = adjusted[st]
            perm_values[st] = [
                (y0, SubstitutionArm.LEFT if i in chosen_set else SubstitutionArm.RIGHT)
                for i, (_, y0, _) in enumerate(arr)
            ]
        s = _stratum_stat(perm_values)
        total += 1
        if _one_sided_extreme(s, obs, alternative):
            extreme += 1
    return extreme / total, total, True


class CausalSubstitutionAnalyzer:
    def __init__(self, policy: SubstitutionPolicy):
        self.policy = policy

    def _validate_pair(
        self,
        trials: list[SubstitutionTrial],
        left: CertifiedOperatorRef,
        right: CertifiedOperatorRef,
        domain: DomainSpec,
    ) -> tuple[bool, tuple[str, ...], list[SubstitutionTrial]]:
        notes: list[str] = []
        if left.operator_id == right.operator_id:
            notes.append("operator IDs must differ")
        if not left.causal_certificate_passed or not right.causal_certificate_passed:
            notes.append("both operators must already have passed independent R3 causal certificates")
        if left.domain_id != right.domain_id or left.domain_id != domain.domain_id:
            notes.append("R3 operator domains and R4 domain must coincide")
        if left.probe_schedule_id != right.probe_schedule_id:
            notes.append("operator probe schedules differ")
        pair = sorted([left.operator_id, right.operator_id])
        pair_id = f"{pair[0]}::{pair[1]}"
        xs = [t for t in trials if t.pair_id == pair_id]
        if not xs:
            notes.append("no trials for requested operator pair")
            return False, tuple(notes), xs
        if any(not t.randomized for t in xs):
            notes.append("non-randomized substitution trial present")
        if any(t.domain_id != domain.domain_id for t in xs):
            notes.append("trial domain mismatch")
        if any(t.probe_schedule_id != left.probe_schedule_id for t in xs):
            notes.append("trial probe schedule does not match R3 operator schedule")
        if any(not domain.contains(t.pre_state) for t in xs):
            notes.append("at least one pre-state lies outside pre-registered substitution domain")
        expected_op = {SubstitutionArm.LEFT: left.operator_id, SubstitutionArm.RIGHT: right.operator_id}
        if any(t.operator_id != expected_op[t.arm] for t in xs):
            notes.append("arm/operator identity mismatch")
        seeds = {t.assignment_seed for t in xs}
        if len(seeds) != 1:
            notes.append("substitution trials do not share one pre-registered assignment seed")
        else:
            seed = next(iter(seeds))
            expected = stratified_balanced_assignment({t.trial_id: t.stratum_id for t in xs}, seed)
            if any(expected[t.trial_id] != t.arm for t in xs):
                notes.append("observed arms do not reproduce pre-registered stratified assignment")
        # Identifiability/support gate in every stratum.
        for st in sorted({t.stratum_id for t in xs}):
            ys = [t for t in xs if t.stratum_id == st]
            nl = sum(t.arm == SubstitutionArm.LEFT for t in ys)
            nr = sum(t.arm == SubstitutionArm.RIGHT for t in ys)
            if nl < self.policy.min_trials_per_arm_per_stratum or nr < self.policy.min_trials_per_arm_per_stratum:
                notes.append(f"insufficient randomized support in stratum {st}: left={nl}, right={nr}")
        # Probe structure itself must coincide at the declared resolution.
        signatures = set()
        for t in xs:
            signatures.add(tuple((p.phase_index, p.kind.value, p.source) for p in t.probes))
        if len(signatures) != 1:
            notes.append("probe phase/kind/source signatures differ across trials")
        return (not notes), tuple(notes), xs

    @staticmethod
    def _change_at_phase(t: SubstitutionTrial, metric: str, phase: Optional[int]) -> Optional[float]:
        if metric not in t.pre_state.metrics:
            return None
        if phase is None:
            return t.delta(metric)
        matches = [p for p in t.probes if p.phase_index == phase and metric in p.metrics]
        if len(matches) != 1:
            return None
        return matches[0].metrics[metric] - t.pre_state.metrics[metric]

    def _estimate_one(
        self,
        xs: list[SubstitutionTrial],
        metric: str,
        phase: Optional[int],
        stratum: str,
        margin: float,
        alpha_local: float,
    ) -> EquivalenceEstimate:
        ys = [t for t in xs if t.stratum_id == stratum]
        rows = []
        missing = False
        for t in ys:
            v = self._change_at_phase(t, metric, phase)
            if v is None:
                missing = True
            else:
                rows.append((t.trial_id, float(v), t.arm))
        left = [v for _, v, a in rows if a == SubstitutionArm.LEFT]
        right = [v for _, v, a in rows if a == SubstitutionArm.RIGHT]
        notes: list[str] = []
        if missing:
            notes.append("metric/phase missing in at least one trial")
        if len(left) < self.policy.min_trials_per_arm_per_stratum or len(right) < self.policy.min_trials_per_arm_per_stratum:
            notes.append("insufficient complete cases for equivalence test")
        if notes:
            return EquivalenceEstimate(metric, phase, stratum, len(left), len(right), _mean(left), _mean(right),
                                       _diff(left, right) if left and right else float("nan"), margin, alpha_local,
                                       None, None, 0, False, EquivalenceStatus.INVALID, tuple(notes))
        by = {stratum: rows}
        # TOST at the two equivalence boundaries under the sharp constant-additive model.
        p_lo, alloc_lo, done_lo = _exact_boundary_p(by, -margin, "greater", self.policy.max_exact_allocations)
        p_hi, alloc_hi, done_hi = _exact_boundary_p(by, +margin, "less", self.policy.max_exact_allocations)
        allocations = max(alloc_lo, alloc_hi)
        completed = done_lo and done_hi
        if not completed:
            status = EquivalenceStatus.UNRESOLVED
            notes.append("exact boundary randomization unresolved under allocation cap")
        else:
            passed = (p_lo is not None and p_hi is not None and p_lo <= alpha_local and p_hi <= alpha_local)
            status = EquivalenceStatus.PASS if passed else EquivalenceStatus.FAIL
        return EquivalenceEstimate(
            metric=metric, phase_index=phase, stratum_id=stratum,
            n_left=len(left), n_right=len(right),
            mean_left_change=_mean(left), mean_right_change=_mean(right), observed_difference=_diff(left,right),
            margin=margin, alpha_local=alpha_local,
            p_lower_boundary=p_lo, p_upper_boundary=p_hi,
            exact_allocations=allocations, exact_test_completed=completed,
            status=status, notes=tuple(notes)
        )

    def certify(
        self,
        trials: list[SubstitutionTrial],
        left: CertifiedOperatorRef,
        right: CertifiedOperatorRef,
        domain: DomainSpec,
    ) -> SubstitutionCertificate:
        design_valid, design_notes, xs = self._validate_pair(trials, left, right, domain)
        pair = sorted([left.operator_id, right.operator_id])
        pair_id = f"{pair[0]}::{pair[1]}"
        if not design_valid:
            digest = hashlib.sha256((pair_id + "|INVALID|" + self.policy.policy_hash()).encode()).hexdigest()[:16]
            return SubstitutionCertificate(
                certificate_id=f"subst:{digest}", pair_id=pair_id,
                left_operator_id=left.operator_id, right_operator_id=right.operator_id,
                left_causal_certificate_id=left.causal_certificate_id,
                right_causal_certificate_id=right.causal_certificate_id,
                domain_id=domain.domain_id, probe_schedule_id=left.probe_schedule_id,
                policy_hash=self.policy.policy_hash(), estimates=(), passed=False,
                status=EquivalenceStatus.INVALID, protocol_version=self.policy.protocol_version,
                notes=design_notes
            )

        phases = sorted(set(p.phase_index for t in xs for p in t.probes))
        strata = sorted(set(t.stratum_id for t in xs))
        checks: list[tuple[str, Optional[int], str, float]] = []
        for metric, margin in sorted(self.policy.endpoint_margins.items()):
            for st in strata:
                checks.append((metric, None, st, margin))
        for metric, margin in sorted(self.policy.trajectory_margins.items()):
            for phase in phases:
                for st in strata:
                    checks.append((metric, phase, st, margin))
        if not checks:
            raise ValueError("policy has no endpoint or trajectory equivalence checks")
        alpha_local = self.policy.alpha_familywise / len(checks)
        estimates = tuple(self._estimate_one(xs, m, ph, st, eps, alpha_local) for m, ph, st, eps in checks)
        statuses = {e.status for e in estimates}
        if EquivalenceStatus.INVALID in statuses:
            status = EquivalenceStatus.INVALID
        elif EquivalenceStatus.UNRESOLVED in statuses:
            status = EquivalenceStatus.UNRESOLVED
        elif all(e.status == EquivalenceStatus.PASS for e in estimates):
            status = EquivalenceStatus.PASS
        else:
            status = EquivalenceStatus.FAIL
        passed = status == EquivalenceStatus.PASS
        notes = list(design_notes)
        notes.append("equivalence is operational at the declared domain, metric set, margins, and probe resolution")
        notes.append("exact TOST boundaries assume a sharp constant-additive differential effect within each tested stratum")
        notes.append("mechanistic identity is not implied by substitution equivalence")
        digest_payload = repr((pair_id, left.causal_certificate_id, right.causal_certificate_id,
                               domain.domain_id, left.probe_schedule_id, self.policy.policy_hash()))
        digest = hashlib.sha256(digest_payload.encode()).hexdigest()[:16]
        return SubstitutionCertificate(
            certificate_id=f"subst:{digest}", pair_id=pair_id,
            left_operator_id=left.operator_id, right_operator_id=right.operator_id,
            left_causal_certificate_id=left.causal_certificate_id,
            right_causal_certificate_id=right.causal_certificate_id,
            domain_id=domain.domain_id, probe_schedule_id=left.probe_schedule_id,
            policy_hash=self.policy.policy_hash(), estimates=estimates,
            passed=passed, status=status, protocol_version=self.policy.protocol_version,
            notes=tuple(notes)
        )


class CausalMacroNameBuilder:
    """
    Approximate equivalence is not transitive. Therefore a MacroName is not built by
    connected components/union-find. It is an all-pairs certified substitution clique.
    """
    def build(self, operator_refs: list[CertifiedOperatorRef], certificates: list[SubstitutionCertificate]) -> CausalMacroName:
        refs = {r.operator_id: r for r in operator_refs}
        ops = tuple(sorted(refs))
        if len(ops) < 2:
            raise ValueError("a causal MacroName requires at least two distinct operators")
        if any(not refs[o].causal_certificate_passed for o in ops):
            raise ValueError("every member must already have a passed R3 causal certificate")
        domains = {refs[o].domain_id for o in ops}
        schedules = {refs[o].probe_schedule_id for o in ops}
        if len(domains) != 1 or len(schedules) != 1:
            raise ValueError("all MacroName members must share one domain and probe schedule")
        cert_by_pair = {c.pair_id: c for c in certificates}
        selected = []
        policies = set()
        protocols = set()
        for a, b in combinations(ops, 2):
            pid = f"{a}::{b}"
            c = cert_by_pair.get(pid)
            if c is None:
                raise ValueError(f"missing all-pairs substitution certificate for {pid}")
            if not c.passed or c.status != EquivalenceStatus.PASS:
                raise ValueError(f"substitution certificate did not pass for {pid}")
            if c.domain_id != next(iter(domains)) or c.probe_schedule_id != next(iter(schedules)):
                raise ValueError(f"certificate domain/schedule mismatch for {pid}")
            selected.append(c.certificate_id)
            policies.add(c.policy_hash)
            protocols.add(c.protocol_version)
        if len(policies) != 1:
            raise ValueError("pair certificates use different equivalence policies/margins")
        if len(protocols) != 1:
            raise ValueError("pair certificates use different substitution protocol versions")
        digest = hashlib.sha256(("|".join(ops)+"|"+"|".join(sorted(selected))).encode()).hexdigest()[:16]
        return CausalMacroName(
            name_id=f"cname:{digest}", operator_ids=ops,
            pair_certificate_ids=tuple(sorted(selected)), domain_id=next(iter(domains)),
            probe_schedule_id=next(iter(schedules)), policy_hash=next(iter(policies)),
            protocol_version=next(iter(protocols))
        )
