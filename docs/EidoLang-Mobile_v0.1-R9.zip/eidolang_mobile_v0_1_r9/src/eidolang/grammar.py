from __future__ import annotations
import hashlib
from collections import defaultdict
from dataclasses import dataclass
from .schema import EidoSession
from .segmenter import StrokeSegmenter
from .state import state_delta
from .language import PersonalAlphabet, EffectGrammarRule, PersonalGrammar, SplitManifest
from .validation import deterministic_split, squared_error, mean_vector, permuted_deltas

@dataclass(frozen=True)
class GrammarConfig:
    min_train_support: int = 2
    min_holdout_support: int = 1
    max_order: int = 5
    negative_controls: int = 16
    protocol_version: str = "effect-grammar-v2"

class EffectGrammarInducer:
    """Discovers sequence context whose state-transition semantics beats its suffix baseline on holdout."""
    def __init__(self, segmenter: StrokeSegmenter|None=None, config: GrammarConfig=GrammarConfig()):
        self.segmenter=segmenter or StrokeSegmenter(); self.config=config

    def sequence(self, s:EidoSession, alphabet:PersonalAlphabet) -> tuple[str,...]:
        segs=self.segmenter.segment(s); rels=self.segmenter.relations(segs)
        out=[]
        for i,seg in enumerate(segs):
            sym=alphabet.token_to_symbol.get(seg.signature, f"RAW:{seg.signature}")
            out.append(f"A:{sym}")
            if i < len(rels): out.append(f"R:{rels[i].signature}")
        return tuple(out)

    def _fit_core(self,sessions,alphabet,split,delta_override=None):
        deltas=delta_override or {s.session_id:state_delta(s) for s in sessions}
        seqs={s.session_id:self.sequence(s,alphabet) for s in sessions}
        train=set(split.train_ids); hold=set(split.holdout_ids)
        tr_occ=defaultdict(set); ho_occ=defaultdict(set)
        for sid,seq in seqs.items():
            for n in range(1,min(self.config.max_order,len(seq))+1):
                for i in range(len(seq)-n+1):
                    p=seq[i:i+n]
                    (tr_occ if sid in train else ho_occ)[p].add(sid)
        global_mean=mean_vector([deltas[sid] for sid in split.train_ids if deltas.get(sid)])
        rules=[]; total_gain=0.0
        for pat in sorted(tr_occ,key=lambda x:(len(x),x)):
            if len(pat)<2: continue
            ts=sorted(tr_occ[pat]); hs=sorted(ho_occ.get(pat,set()))
            if len(ts)<self.config.min_train_support or len(hs)<self.config.min_holdout_support: continue
            suffix=pat[1:]
            suffix_train=sorted(tr_occ.get(suffix,set()))
            if len(suffix_train)<self.config.min_train_support: continue
            pred_rule=mean_vector([deltas[sid] for sid in ts if deltas.get(sid)])
            pred_base=mean_vector([deltas[sid] for sid in suffix_train if deltas.get(sid)]) or global_mean
            lr=sum(squared_error(deltas[sid],pred_rule) for sid in hs if deltas.get(sid))
            lb=sum(squared_error(deltas[sid],pred_base) for sid in hs if deltas.get(sid))
            if not (lr < lb - 1e-15): continue
            counter=[]
            for sid in hs:
                y=deltas.get(sid,{})
                if squared_error(y,pred_rule) >= squared_error(y,pred_base): counter.append(sid)
            digest=hashlib.sha1("\n".join(pat).encode()).hexdigest()[:12]
            rules.append(EffectGrammarRule(
                rule_id=f"rule:{digest}", pattern=pat, suffix_baseline=suffix,
                train_support=len(ts), holdout_support=len(hs), effect=pred_rule,
                holdout_rule_loss=lr, holdout_baseline_loss=lb,
                evidence_refs=tuple(hs), counterexample_refs=tuple(counter),
                metadata={"order":len(pat)}
            ))
            total_gain += lb-lr
        return rules,total_gain

    def fit(self,sessions:list[EidoSession],alphabet:PersonalAlphabet,split:SplitManifest|None=None)->PersonalGrammar:
        split=split or alphabet.split
        rules,gain=self._fit_core(sessions,alphabet,split)
        controls=[]
        for seed in range(self.config.negative_controls):
            pd=permuted_deltas(sessions,1000+seed)
            _,cg=self._fit_core(sessions,alphabet,split,delta_override=pd); controls.append(cg)
        passed=bool(rules) and (not controls or gain>max(controls)+1e-15)
        digest=hashlib.sha1((alphabet.alphabet_id+"|"+"|".join(split.train_ids)).encode()).hexdigest()[:12]
        return PersonalGrammar(
            grammar_id=f"grammar:{digest}", rules=rules, split=split,
            observed_gain=gain, negative_control_gains=tuple(controls),
            passed_negative_control_gate=passed, protocol_version=self.config.protocol_version,
            metadata={"gate":"holdout context-vs-suffix prediction + max permuted-label control"}
        )
