from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from itertools import combinations
from math import comb
import hashlib, math, random
from typing import Any, Optional

from .schema import StateObservation


class ReplayArm(str, Enum):
    OPERATOR = "OPERATOR"
    MATCHED_CONTROL = "MATCHED_CONTROL"


class ProbeKind(str, Enum):
    ACTIVE_SELF_REPORT = "ACTIVE_SELF_REPORT"
    PASSIVE_SENSOR = "PASSIVE_SENSOR"


@dataclass(frozen=True)
class StateProbe:
    probe_id: str
    t_us: int
    phase_index: int
    kind: ProbeKind
    metrics: dict[str, float]
    source: str


@dataclass(frozen=True)
class ReplayTemplate:
    template_id: str
    source_session_id: str
    pattern_ref: str
    strokes: tuple[tuple[tuple[float, float], ...], ...]
    motor_profile: dict[str, float]
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class MatchedControl:
    target_template_id: str
    control_template_id: str
    distance: float
    matched_dimensions: tuple[str, ...]
    construction_version: str


@dataclass
class ReplayTrial:
    trial_id: str
    operator_id: str
    arm: ReplayArm
    template_id: str
    assignment_seed: int
    randomized: bool
    probe_schedule_id: str
    pre_state: StateObservation
    post_state: StateObservation
    probes: tuple[StateProbe, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    def delta(self, metric: str) -> Optional[float]:
        if metric not in self.pre_state.metrics or metric not in self.post_state.metrics:
            return None
        return self.post_state.metrics[metric] - self.pre_state.metrics[metric]


@dataclass(frozen=True)
class CausalEstimate:
    operator_id: str
    metric: str
    alternative: str
    n_operator: int
    n_control: int
    mean_operator_delta: float
    mean_control_delta: float
    ate: float
    exact_p_value: Optional[float]
    exact_allocations: int
    exact_test_completed: bool
    design_valid: bool
    certified: bool
    notes: tuple[str, ...] = ()


@dataclass(frozen=True)
class ProbeTrajectoryPoint:
    phase_index: int
    n_operator: int
    n_control: int
    mean_operator_change: float
    mean_control_change: float
    contrast: float


@dataclass(frozen=True)
class CausalOperatorCertificate:
    certificate_id: str
    operator_id: str
    estimates: tuple[CausalEstimate, ...]
    probe_trajectory: tuple[ProbeTrajectoryPoint, ...]
    policy_alpha: float
    protocol_version: str
    passed: bool
    notes: tuple[str, ...] = ()


def balanced_random_assignment(trial_ids: list[str], seed: int) -> dict[str, ReplayArm]:
    """
    Uniform balanced allocation after pre-registration of trial IDs.
    The seed must be generated/logged before outcome collection.
    """
    ids = list(dict.fromkeys(trial_ids))
    if len(ids) < 2:
        raise ValueError("at least two trials are required")
    rng = random.Random(seed)
    rng.shuffle(ids)
    n_op = len(ids) // 2
    return {tid: (ReplayArm.OPERATOR if i < n_op else ReplayArm.MATCHED_CONTROL)
            for i, tid in enumerate(ids)}


def _mean(xs: list[float]) -> float:
    return sum(xs) / len(xs) if xs else float("nan")


def _stat(op: list[float], ct: list[float]) -> float:
    return _mean(op) - _mean(ct)


def _extreme(stat: float, obs: float, alternative: str) -> bool:
    eps = 1e-15
    if alternative == "greater":
        return stat >= obs - eps
    if alternative == "less":
        return stat <= obs + eps
    if alternative == "two-sided":
        return abs(stat) >= abs(obs) - eps
    raise ValueError("alternative must be greater|less|two-sided")


class CausalAnalyzer:
    def __init__(self, alpha: float = 0.05, max_exact_allocations: int = 200_000,
                 protocol_version: str = "causal-replay-v3"):
        if not 0.0 < alpha < 1.0:
            raise ValueError("alpha must be in (0,1)")
        self.alpha = alpha
        self.max_exact_allocations = max_exact_allocations
        self.protocol_version = protocol_version

    def validate_design(self, trials: list[ReplayTrial], operator_id: str) -> tuple[bool, tuple[str, ...]]:
        xs = [t for t in trials if t.operator_id == operator_id]
        notes = []
        if not xs:
            return False, ("no trials for operator",)
        if not all(t.randomized for t in xs):
            notes.append("non-randomized trial present")
        arms = {t.arm for t in xs}
        if arms != {ReplayArm.OPERATOR, ReplayArm.MATCHED_CONTROL}:
            notes.append("both replay arms are required")
        seeds = {t.assignment_seed for t in xs}
        if len(seeds) != 1:
            notes.append("trials do not share one pre-registered assignment seed")
        # Intermediate active probing is itself an intervention. It is admissible only
        # under a common schedule in both arms; otherwise replay and control are not comparable.
        schedules = {t.probe_schedule_id for t in xs}
        if len(schedules) != 1:
            notes.append("probe schedules differ across trials")
        return (not notes), tuple(notes)

    def estimate(self, trials: list[ReplayTrial], operator_id: str, metric: str,
                 alternative: str = "greater") -> CausalEstimate:
        design_valid, design_notes = self.validate_design(trials, operator_id)
        xs = [t for t in trials if t.operator_id == operator_id and t.delta(metric) is not None]
        op = [t.delta(metric) for t in xs if t.arm == ReplayArm.OPERATOR]
        ct = [t.delta(metric) for t in xs if t.arm == ReplayArm.MATCHED_CONTROL]
        op = [float(x) for x in op if x is not None]
        ct = [float(x) for x in ct if x is not None]
        notes = list(design_notes)
        if not op or not ct:
            return CausalEstimate(operator_id, metric, alternative, len(op), len(ct),
                                  _mean(op), _mean(ct), float("nan"), None, 0, False,
                                  design_valid, False, tuple(notes + ["missing arm data"]))
        obs = _stat(op, ct)
        values = [float(t.delta(metric)) for t in xs]
        n_op = len(op)
        allocations = comb(len(values), n_op)
        p = None
        completed = False
        if allocations <= self.max_exact_allocations:
            extreme = 0
            total = 0
            idx = range(len(values))
            for choose in combinations(idx, n_op):
                mask = set(choose)
                a = [values[i] for i in idx if i in mask]
                b = [values[i] for i in idx if i not in mask]
                s = _stat(a, b)
                total += 1
                if _extreme(s, obs, alternative):
                    extreme += 1
            p = extreme / total
            completed = True
        else:
            notes.append(f"exact randomization unresolved: {allocations} allocations exceed cap {self.max_exact_allocations}")

        direction_ok = (obs > 0 if alternative == "greater" else
                        obs < 0 if alternative == "less" else abs(obs) > 0)
        certified = bool(design_valid and completed and p is not None and p <= self.alpha and direction_ok)
        return CausalEstimate(
            operator_id=operator_id, metric=metric, alternative=alternative,
            n_operator=len(op), n_control=len(ct),
            mean_operator_delta=_mean(op), mean_control_delta=_mean(ct), ate=obs,
            exact_p_value=p, exact_allocations=allocations,
            exact_test_completed=completed, design_valid=design_valid,
            certified=certified, notes=tuple(notes)
        )

    def probe_trajectory(self, trials: list[ReplayTrial], operator_id: str, metric: str) -> tuple[ProbeTrajectoryPoint, ...]:
        xs = [t for t in trials if t.operator_id == operator_id]
        phases = sorted(set(p.phase_index for t in xs for p in t.probes if metric in p.metrics))
        out = []
        for phase in phases:
            op=[]; ct=[]
            for t in xs:
                ps=[p for p in t.probes if p.phase_index==phase and metric in p.metrics]
                if not ps or metric not in t.pre_state.metrics:
                    continue
                change=ps[0].metrics[metric]-t.pre_state.metrics[metric]
                (op if t.arm==ReplayArm.OPERATOR else ct).append(change)
            if op and ct:
                out.append(ProbeTrajectoryPoint(phase, len(op), len(ct), _mean(op), _mean(ct), _mean(op)-_mean(ct)))
        return tuple(out)

    def certify(self, trials: list[ReplayTrial], operator_id: str,
                metric_alternatives: dict[str, str]) -> CausalOperatorCertificate:
        estimates=tuple(self.estimate(trials,operator_id,m,a) for m,a in metric_alternatives.items())
        # For localization choose the first requested metric; this is descriptive and
        # never substitutes for the randomized end-point estimate.
        first_metric=next(iter(metric_alternatives),None)
        traj=self.probe_trajectory(trials,operator_id,first_metric) if first_metric else ()
        passed=bool(estimates) and all(e.certified for e in estimates)
        digest=hashlib.sha256((operator_id+"|"+"|".join(sorted(metric_alternatives))).encode()).hexdigest()[:16]
        notes=[]
        if not passed:
            notes.append("not all pre-registered endpoint metrics passed causal replay gate")
        return CausalOperatorCertificate(
            certificate_id=f"causal:{digest}", operator_id=operator_id,
            estimates=estimates, probe_trajectory=traj,
            policy_alpha=self.alpha, protocol_version=self.protocol_version,
            passed=passed, notes=tuple(notes)
        )
