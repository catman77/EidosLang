from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from typing import Iterable, Optional, Any

from .acquisition import AcquisitionLedger, DataFreezeCertificate, sha256_object
from .schema import EidoSession, RawEvent, EidoOperator
from .operators import OperatorMiner, MinerConfig
from .segmenter import StrokeSegmenter
from .candidate_universe import CandidateUniverseCertificate


RAW_CAUSAL_STATUSES={"PASS","FAIL","UNRESOLVED","INVALID"}
PAIR_STATUSES={"PASS","FAIL","UNRESOLVED","INVALID"}


def _raw_program_payload(session:EidoSession) -> tuple:
    """
    Exact intervention program identity, intentionally finer than the current grammar.
    State observations, session IDs, metadata and wall-clock start are excluded.
    Event times are made relative to the first raw event; all recorded actuation fields remain.

    This is a diagnostic identity, not a new semantic grammar token.
    """
    es=sorted(session.raw_events,key=lambda e:e.t_us)
    t0=es[0].t_us if es else 0
    out=[]
    for e in es:
        out.append((
            e.type.value,int(e.t_us-t0),e.pointer_id,e.x,e.y,e.pressure,
            e.contact_major,e.contact_minor,e.tilt_x,e.tilt_y,
            tuple(sorted((str(k),sha256_object(v)) for k,v in e.payload.items())),
        ))
    return tuple(out)


def raw_program_hash(session:EidoSession) -> str:
    return sha256_object(_raw_program_payload(session))


def raw_program_id(program_hash:str) -> str:
    return "rawprog:"+program_hash[:16]


@dataclass(frozen=True)
class RawProgram:
    program_id: str
    program_hash: str
    source_session_ids: tuple[str,...]
    grammar_tokens: tuple[str,...]
    grammar_address: tuple[str,...]
    support_count: int


@dataclass(frozen=True)
class RawProgramCausalDisposition:
    program_id: str
    program_hash: str
    causal_certificate_id: str
    status: str
    effect_vector: dict[str,float]
    domain_id: str
    probe_schedule_id: str
    causal_protocol_version: str="raw-program-causal-replay-v1"

    def __post_init__(self):
        if self.status not in RAW_CAUSAL_STATUSES:
            raise ValueError("unsupported raw-program causal status")
        if not self.program_id or not self.causal_certificate_id:
            raise ValueError("program/certificate id cannot be empty")


@dataclass(frozen=True)
class RawProgramPairDisposition:
    pair_id: str
    left_program_id: str
    right_program_id: str
    left_causal_certificate_id: str
    right_causal_certificate_id: str
    substitution_certificate_id: str
    status: str
    domain_id: str
    probe_schedule_id: str
    policy_hash: str
    protocol_version: str="raw-program-substitution-v1"

    def __post_init__(self):
        if self.status not in PAIR_STATUSES:
            raise ValueError("unsupported raw-program pair status")
        a,b=sorted((self.left_program_id,self.right_program_id))
        if (self.left_program_id,self.right_program_id)!=(a,b):
            raise ValueError("raw-program pair endpoints must be sorted")
        if self.pair_id!=f"{a}::{b}":
            raise ValueError("raw-program pair_id must be canonical")


@dataclass(frozen=True)
class GrammarAdequacyConfig:
    observer_id: str
    source_r8_certificate_hash: str
    source_data_freeze_hash: str
    miner_min_support: int
    miner_max_ngram: int
    miner_protocol_version: str
    raw_program_min_support: int
    domain_id: str
    probe_schedule_id: str
    raw_causal_protocol_version: str
    raw_pair_policy_hash: str
    raw_pair_protocol_version: str
    max_raw_programs: int=10_000
    max_indistinguishable_pairs: int=200_000
    adequacy_version: str="grammar-adequacy-v1"

    def __post_init__(self):
        if min(self.miner_min_support,self.miner_max_ngram,self.raw_program_min_support)<1:
            raise ValueError("support/ngram values must be >=1")
        if min(self.max_raw_programs,self.max_indistinguishable_pairs)<1:
            raise ValueError("caps must be positive")

    @property
    def config_hash(self)->str:
        return sha256_object(self)

    def miner_config(self)->MinerConfig:
        return MinerConfig(self.miner_min_support,self.miner_max_ngram,self.miner_protocol_version)


@dataclass(frozen=True)
class GrammarResidualWitness:
    witness_type: str  # COLLISION | UNREPRESENTED
    left_program_id: str
    right_program_id: Optional[str]
    grammar_address: tuple[str,...]
    left_program_hash: str
    right_program_hash: Optional[str]
    left_effect_vector: dict[str,float]
    right_effect_vector: Optional[dict[str,float]]
    pair_certificate_id: Optional[str]
    obligation: str


@dataclass(frozen=True)
class GrammarAdequacyCertificate:
    certificate_id: str
    config_hash: str
    observer_id: str
    source_r8_certificate_hash: str
    source_data_freeze_hash: str
    raw_program_count: int
    causal_pass_program_count: int
    represented_causal_program_count: int
    unrepresented_causal_program_count: int
    indistinguishable_pair_count: int
    registered_pair_count: int
    collision_witnesses: tuple[GrammarResidualWitness,...]
    unrepresented_witnesses: tuple[GrammarResidualWitness,...]
    separation_obligations: tuple[tuple[str,str],...]
    status: str  # PASS | INADEQUATE | UNRESOLVED | INVALID
    adequate: bool
    reasons: tuple[str,...]
    scope_statement: str

    @property
    def certificate_hash(self)->str:
        return sha256_object(self)


def _contains_pattern(tokens:tuple[str,...],pattern:tuple[str,...])->bool:
    n=len(pattern)
    return n>0 and any(tuple(tokens[i:i+n])==pattern for i in range(len(tokens)-n+1))


def _extract_raw_programs(
    sessions:list[EidoSession],
    mined:list[EidoOperator],
    min_support:int,
)->list[RawProgram]:
    seg=StrokeSegmenter()
    groups={}
    for s in sessions:
        h=raw_program_hash(s)
        groups.setdefault(h,[]).append(s)
    out=[]
    for h,rows in sorted(groups.items()):
        if len(rows)<min_support:
            continue
        token_sets=[]
        for s in rows:
            toks,_=seg.tokens(s); token_sets.append(tuple(toks))
        if len(set(token_sets))!=1:
            # This should be impossible for identical raw event programs.
            raise ValueError("identical raw program hash produced nonidentical grammar tokens")
        toks=token_sets[0]
        address=tuple(sorted(o.operator_id for o in mined if _contains_pattern(toks,tuple(o.pattern))))
        out.append(RawProgram(
            raw_program_id(h),h,tuple(sorted(s.session_id for s in rows)),toks,address,len(rows)
        ))
    return out


class GrammarAdequacyAnalyzer:
    """
    Tests semantic/mechanism homogeneity of the entire *current* grammar representation.

    Two exact raw intervention programs are grammar-indistinguishable iff their incidence
    address over every frozen mined operator is identical. If independently causal-PASS
    programs with the same nonempty address are substitution-FAIL, the grammar has merged
    a causally relevant distinction.

    PASS is relative to the frozen ledger and supplied complete causal/substitution registry.
    No grammar refinement is chosen here.
    """
    def __init__(self,config:GrammarAdequacyConfig):
        self.config=config

    def certify(
        self,
        ledger:AcquisitionLedger,
        freeze:DataFreezeCertificate,
        sessions_by_id:dict[str,EidoSession],
        r8_certificate:CandidateUniverseCertificate,
        causal_dispositions:Iterable[RawProgramCausalDisposition],
        pair_dispositions:Iterable[RawProgramPairDisposition],
    )->GrammarAdequacyCertificate:
        cfg=self.config; reasons=[]
        if r8_certificate.certificate_hash!=cfg.source_r8_certificate_hash:
            reasons.append("R9 config does not bind supplied R8 certificate")
        if r8_certificate.status!="PASS" or not r8_certificate.complete:
            reasons.append("source R8 candidate universe is not PASS/complete")
        if r8_certificate.source_data_freeze_hash!=cfg.source_data_freeze_hash:
            reasons.append("R8/data-freeze binding mismatch")
        if freeze.freeze_hash!=cfg.source_data_freeze_hash:
            reasons.append("R9 config does not bind supplied data freeze")
        if r8_certificate.source_ledger_root!=ledger.data_root:
            reasons.append("R8 certificate does not bind supplied ledger")
        ok,why=ledger.verify(sessions_by_id)
        if not ok: reasons.append("source ledger verification failed: "+why)
        ledger_ids=tuple(e.session_id for e in ledger.entries)
        if set(sessions_by_id)!=set(ledger_ids):
            reasons.append("sessions_by_id must equal complete frozen ledger")
        if cfg.observer_id!=r8_certificate.observer_id:
            reasons.append("observer mismatch between R8 and R9")
        if reasons:
            return self._result("INVALID",reasons,r8_certificate,(),(),(),())

        excluded=set(freeze.excluded_session_ids)
        source=[sessions_by_id[sid] for sid in ledger_ids if sid not in excluded]
        mined=sorted(OperatorMiner(config=cfg.miner_config()).mine(source),key=lambda x:x.operator_id)
        if tuple(o.operator_id for o in mined)!=r8_certificate.mined_operator_ids:
            return self._result("INVALID",["re-mined operator universe differs from bound R8 certificate"],r8_certificate,(),(),(),())

        try:
            programs=_extract_raw_programs(source,mined,cfg.raw_program_min_support)
        except ValueError as e:
            return self._result("INVALID",[str(e)],r8_certificate,(),(),(),())
        if len(programs)>cfg.max_raw_programs:
            return self._result("UNRESOLVED",[f"raw program count {len(programs)} exceeds cap {cfg.max_raw_programs}"],r8_certificate,programs,(),(),())
        pmap={p.program_id:p for p in programs}
        if len(pmap)!=len(programs):
            return self._result("INVALID",["duplicate raw program ids"],r8_certificate,programs,(),(),())

        causal=list(causal_dispositions)
        if len({d.program_id for d in causal})!=len(causal): reasons.append("duplicate raw causal dispositions")
        cmap={d.program_id:d for d in causal}
        miss=set(pmap)-set(cmap); extra=set(cmap)-set(pmap)
        if miss: reasons.append("missing raw causal dispositions: "+",".join(sorted(miss)))
        if extra: reasons.append("raw causal registry contains programs outside frozen raw universe: "+",".join(sorted(extra)))
        for pid in set(pmap)&set(cmap):
            d=cmap[pid]; p=pmap[pid]
            if d.program_hash!=p.program_hash: reasons.append(f"raw causal program hash mismatch: {pid}")
            if d.causal_protocol_version!=cfg.raw_causal_protocol_version: reasons.append(f"raw causal protocol mismatch: {pid}")
            if d.domain_id!=cfg.domain_id or d.probe_schedule_id!=cfg.probe_schedule_id: reasons.append(f"raw causal domain/schedule mismatch: {pid}")
        if reasons:
            return self._result("INVALID",reasons,r8_certificate,programs,(),(),())

        cpass={pid:d for pid,d in cmap.items() if d.status=="PASS"}
        unrepresented=[]
        for pid,d in sorted(cpass.items()):
            p=pmap[pid]
            if not p.grammar_address:
                unrepresented.append(GrammarResidualWitness(
                    "UNREPRESENTED",pid,None,p.grammar_address,p.program_hash,None,
                    dict(d.effect_vector),None,None,
                    f"future admissible grammar must assign at least one operator address to raw program {pid}",
                ))

        # Current grammar makes a stronger claim than any one token: two programs are
        # indistinguishable iff every mined operator has identical incidence on both.
        expected=[]
        groups={}
        for pid,d in cpass.items():
            p=pmap[pid]
            if p.grammar_address:
                groups.setdefault(p.grammar_address,[]).append(pid)
        for addr,pids in groups.items():
            for a,b in combinations(sorted(pids),2): expected.append((a,b,addr))
        if len(expected)>cfg.max_indistinguishable_pairs:
            return self._result("UNRESOLVED",[f"indistinguishable pair count {len(expected)} exceeds cap {cfg.max_indistinguishable_pairs}"],r8_certificate,programs,(),(),tuple(unrepresented),causal_pass_count=len(cpass),represented_causal_count=len(cpass)-len(unrepresented))
        expected_ids={f"{a}::{b}" for a,b,_ in expected}

        pairs=list(pair_dispositions)
        if len({d.pair_id for d in pairs})!=len(pairs): reasons.append("duplicate raw pair dispositions")
        dmap={d.pair_id:d for d in pairs}
        miss=expected_ids-set(dmap); extra=set(dmap)-expected_ids
        if miss: reasons.append("missing raw pair dispositions for grammar-indistinguishable programs: "+",".join(sorted(miss)))
        if extra: reasons.append("raw pair registry contains pairs outside grammar-indistinguishable universe: "+",".join(sorted(extra)))
        addrmap={f"{a}::{b}":addr for a,b,addr in expected}
        for pid in expected_ids & set(dmap):
            d=dmap[pid]; a,b=pid.split("::",1)
            if d.left_causal_certificate_id!=cpass[a].causal_certificate_id or d.right_causal_certificate_id!=cpass[b].causal_certificate_id:
                reasons.append(f"raw pair causal certificate refs mismatch: {pid}")
            if d.domain_id!=cfg.domain_id or d.probe_schedule_id!=cfg.probe_schedule_id:
                reasons.append(f"raw pair domain/schedule mismatch: {pid}")
            if d.policy_hash!=cfg.raw_pair_policy_hash: reasons.append(f"raw pair policy mismatch: {pid}")
            if d.protocol_version!=cfg.raw_pair_protocol_version: reasons.append(f"raw pair protocol mismatch: {pid}")
        if reasons:
            return self._result("INVALID",reasons,r8_certificate,programs,expected,pairs,tuple(unrepresented),causal_pass_count=len(cpass),represented_causal_count=len(cpass)-len(unrepresented))

        collisions=[]; unresolved=[]; invalid=[]
        for a,b,addr in expected:
            d=dmap[f"{a}::{b}"]
            if d.status=="FAIL":
                collisions.append(GrammarResidualWitness(
                    "COLLISION",a,b,addr,pmap[a].program_hash,pmap[b].program_hash,
                    dict(cpass[a].effect_vector),dict(cpass[b].effect_vector),d.substitution_certificate_id,
                    f"every admissible refinement must separate {a} and {b}: G'(x) != G'(y)",
                ))
            elif d.status=="UNRESOLVED": unresolved.append(d.pair_id)
            elif d.status=="INVALID": invalid.append(d.pair_id)
        if invalid:
            return self._result("INVALID",["invalid raw substitution dispositions: "+",".join(sorted(invalid))],r8_certificate,programs,expected,pairs,tuple(unrepresented),tuple(collisions),len(cpass),len(cpass)-len(unrepresented))
        if unresolved:
            return self._result("UNRESOLVED",["unresolved grammar-indistinguishable causal pairs: "+",".join(sorted(unresolved))],r8_certificate,programs,expected,pairs,tuple(unrepresented),tuple(collisions),len(cpass),len(cpass)-len(unrepresented))
        if collisions or unrepresented:
            rs=[]
            if collisions: rs.append(f"{len(collisions)} causal collision witness(es) inside current grammar cells")
            if unrepresented: rs.append(f"{len(unrepresented)} causal raw program(s) have empty current grammar address")
            return self._result("INADEQUATE",rs,r8_certificate,programs,expected,pairs,tuple(unrepresented),tuple(collisions),len(cpass),len(cpass)-len(unrepresented))
        return self._result("PASS",[],r8_certificate,programs,expected,pairs,(),(),len(cpass),len(cpass))

    def _result(self,status,reasons,r8,programs,expected,pairs,unrepresented=(),collisions=(),causal_pass_count=None,represented_causal_count=None):
        cfg=self.config
        if causal_pass_count is None:
            causal_pass_count=0
        if represented_causal_count is None:
            represented_causal_count=max(0,causal_pass_count-len(unrepresented))
        # Counts from supplied dispositions are unavailable in early invalid paths; derive
        # represented raw programs only from the extensional programs for diagnostics.
        obligations=tuple(sorted((w.left_program_id,w.right_program_id) for w in collisions if w.right_program_id is not None))
        adequate=(status=="PASS")
        scope=(
            "adequate only relative to the frozen raw-program identity, frozen OperatorMiner grammar, "
            "complete raw causal registry, complete within-cell substitution registry, domain/probe and policy"
        )
        cid="r9:"+sha256_object({
            "config":cfg.config_hash,"r8":r8.certificate_hash,"status":status,
            "collisions":[(w.left_program_id,w.right_program_id) for w in collisions],
            "unrepresented":[w.left_program_id for w in unrepresented],
        })[:16]
        # Infer causal PASS count only when pair/unrepresented objects can support it later;
        # caller-facing count is recomputed in successful paths by represented + residuals.
        # Since every unrepresented witness is causal PASS and every collision endpoint is PASS,
        # this remains a lower diagnostic count in invalid paths.
        unique_pass=set(w.left_program_id for w in unrepresented)
        for w in collisions:
            unique_pass.add(w.left_program_id)
            if w.right_program_id: unique_pass.add(w.right_program_id)
        # In PASS paths all raw programs may not be causal PASS. We expose total and residual counts;
        # precise causal PASS count is populated by a private attribute not needed for validity.
        return GrammarAdequacyCertificate(
            cid,cfg.config_hash,cfg.observer_id,r8.certificate_hash,cfg.source_data_freeze_hash,
            len(programs),causal_pass_count,
            represented_causal_count,len(unrepresented),
            len(expected),len(pairs),tuple(collisions),tuple(unrepresented),obligations,
            status,adequate,tuple(reasons),scope
        )
