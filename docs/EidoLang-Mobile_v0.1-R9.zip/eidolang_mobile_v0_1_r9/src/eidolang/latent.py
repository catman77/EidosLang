from typing import Protocol,Sequence
from .schema import EidoSession,LatentSeed

class MultimodalEncoder(Protocol):
    model_id:str
    def encode(self,modalities:dict)->Sequence[float]:...
class EidoTrajectoryEncoder(Protocol):
    model_id:str
    def encode_session(self,session:EidoSession)->Sequence[float]:...
class LatentAdapter(Protocol):
    version:str
    def map(self,source_embedding:Sequence[float])->Sequence[float]:...
