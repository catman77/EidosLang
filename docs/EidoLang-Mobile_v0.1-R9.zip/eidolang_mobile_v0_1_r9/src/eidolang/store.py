from __future__ import annotations
from pathlib import Path
from dataclasses import asdict
from enum import Enum
import json
from .schema import EidoSession

def conv(x):
    if isinstance(x,Enum):return x.value
    if isinstance(x,tuple):return [conv(v) for v in x]
    if isinstance(x,list):return [conv(v) for v in x]
    if isinstance(x,dict):return {k:conv(v) for k,v in x.items()}
    return x

class SessionStore:
    def __init__(self,root): self.root=Path(root); (self.root/'sessions').mkdir(parents=True,exist_ok=True)
    def save(self,session:EidoSession):
        p=self.root/'sessions'/f'{session.session_id}.json'
        if p.exists(): raise FileExistsError(f'raw session is immutable: {p}')
        p.write_text(json.dumps(conv(asdict(session)),ensure_ascii=False,indent=2),encoding='utf-8'); return p
    def load(self,path): return EidoSession.from_dict(json.loads(Path(path).read_text(encoding='utf-8')))
