from __future__ import annotations
import math
Point=tuple[float,float]

def dist(a:Point,b:Point)->float: return math.hypot(b[0]-a[0],b[1]-a[1])
def polyline_length(p:list[Point])->float: return sum(dist(a,b) for a,b in zip(p,p[1:]))

def resample_by_arclength(points:list[Point],n:int)->list[Point]:
    if n<2: raise ValueError('n must be >=2')
    if not points: return [(0.0,0.0)]*n
    if len(points)==1: return [points[0]]*n
    cum=[0.0]
    for a,b in zip(points,points[1:]): cum.append(cum[-1]+dist(a,b))
    total=cum[-1]
    if total<=1e-12: return [points[0]]*n
    out=[]; j=0
    for t in [total*i/(n-1) for i in range(n)]:
        while j<len(cum)-2 and cum[j+1]<t: j+=1
        a,b=points[j],points[j+1]; span=cum[j+1]-cum[j]
        u=0 if span<=1e-12 else (t-cum[j])/span
        out.append((a[0]+u*(b[0]-a[0]),a[1]+u*(b[1]-a[1])))
    return out

def bbox(points:list[Point]):
    xs=[x for x,_ in points] or [0.0]; ys=[y for _,y in points] or [0.0]
    return min(xs),min(ys),max(xs),max(ys)

def normalize_bbox(points:list[Point])->list[Point]:
    x0,y0,x1,y1=bbox(points); s=max(x1-x0,y1-y0,1e-12)
    return [((x-x0)/s,(y-y0)/s) for x,y in points]

def total_turning(points:list[Point])->float:
    if len(points)<3:return 0.0
    total=0.0; prev=None
    for a,b in zip(points,points[1:]):
        ang=math.atan2(b[1]-a[1],b[0]-a[0])
        if prev is not None:
            d=ang-prev
            while d>math.pi:d-=2*math.pi
            while d<-math.pi:d+=2*math.pi
            total+=d
        prev=ang
    return total

def q01(v:float,bins:int)->int:
    v=max(0.0,min(1.0,v)); return min(bins-1,int(v*bins))

def shape_signature(points:list[Point],resample_n:int=12,bins:int=8):
    rs=normalize_bbox(resample_by_arclength(points,resample_n))
    flat=tuple(c for p in rs for c in p)
    sig='S'+'.'.join(str(q01(c,bins)) for c in flat)
    return sig,flat

def segment_features(points:list[Point],duration_s:float,mean_pressure:float|None):
    x0,y0,x1,y1=bbox(points); length=polyline_length(points); disp=dist(points[0],points[-1])
    closure=0 if length<=1e-12 else disp/length
    cx=sum(x for x,_ in points)/len(points); cy=sum(y for _,y in points)/len(points)
    speed=0 if duration_s<=1e-12 else length/duration_s
    return (length,closure,total_turning(points),x1-x0,y1-y0,cx,cy,speed,-1.0 if mean_pressure is None else mean_pressure)

def bbox_overlap(a:list[Point],b:list[Point])->float:
    ax0,ay0,ax1,ay1=bbox(a); bx0,by0,bx1,by1=bbox(b)
    ix=max(0,min(ax1,bx1)-max(ax0,bx0)); iy=max(0,min(ay1,by1)-max(ay0,by0)); inter=ix*iy
    aa=max(0,ax1-ax0)*max(0,ay1-ay0); bb=max(0,bx1-bx0)*max(0,by1-by0); union=aa+bb-inter
    return 0 if union<=1e-12 else inter/union
