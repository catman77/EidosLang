from __future__ import annotations
from dataclasses import dataclass
import hashlib, math, random
from .schema import EidoSession
from .segmenter import StrokeSegmenter
from .topology import TopologyConfig, describe_session


@dataclass(frozen=True)
class TopologicalExample:
    example_id: str
    observer_id: str
    causal_class: str
    session: EidoSession


@dataclass(frozen=True)
class RepresentationResult:
    representation: str
    correct: int
    total: int
    accuracy: float


@dataclass(frozen=True)
class TopologicalTransportReport:
    geometry: RepresentationResult
    t0: RepresentationResult
    t1: RepresentationResult
    t2: RepresentationResult
    topology_gain_over_geometry: float
    negative_control_max_t2_accuracy: float
    passed: bool
    reason: str


def _levenshtein(a,b):
    if not a: return len(b)
    if not b: return len(a)
    prev=list(range(len(b)+1))
    for i,x in enumerate(a,1):
        cur=[i]
        for j,y in enumerate(b,1):
            cur.append(min(cur[-1]+1,prev[j]+1,prev[j-1]+(x!=y)))
        prev=cur
    return prev[-1]


def _seq_distance(a,b):
    return _levenshtein(a,b)/max(1,len(a),len(b))


def _feature_distance(a,b,scales):
    return sum(abs(x-y)/s for x,y,s in zip(a,b,scales))/max(1,len(scales))


def _scales(vectors):
    if not vectors: return []
    d=len(vectors[0]); out=[]
    for j in range(d):
        vals=[v[j] for v in vectors]
        span=max(vals)-min(vals)
        out.append(span if span>1e-9 else 1.0)
    return out


class CrossObserverTopologyEvaluator:
    """Leave-one-observer-out evaluator.

    Causal classes are external labels, expected to come from R4 certificates.
    This module only asks which representation transports those already-certified classes.
    """
    def __init__(self, topology_config: TopologyConfig=TopologyConfig(), negative_controls: int=16, seed: int=451):
        self.topology_config=topology_config
        self.negative_controls=negative_controls
        self.seed=seed
        self.segmenter=StrokeSegmenter()

    def _repr(self, ex: TopologicalExample):
        toks,_=self.segmenter.tokens(ex.session)
        td=describe_session(ex.session,self.topology_config,self.segmenter)
        return {
            'geometry':tuple(toks),
            'T0':td.feature_vector('T0'),
            'T1':td.feature_vector('T1'),
            'T2':(td.feature_vector('T2'),tuple(e.token() for e in td.temporal.events)),
        }

    def _evaluate(self, examples, labels, representation):
        reps={e.example_id:self._repr(e)[representation] for e in examples}
        observers=sorted({e.observer_id for e in examples})
        correct=total=0
        for obs in observers:
            train=[e for e in examples if e.observer_id!=obs]
            test=[e for e in examples if e.observer_id==obs]
            if not train: continue
            scales=None
            if representation in {'T0','T1'}:
                scales=_scales([reps[e.example_id] for e in train])
            elif representation=='T2':
                scales=_scales([reps[e.example_id][0] for e in train])
            for q in test:
                best=None
                for tr in train:
                    if representation=='geometry':
                        d=_seq_distance(reps[q.example_id],reps[tr.example_id])
                    elif representation in {'T0','T1'}:
                        d=_feature_distance(reps[q.example_id],reps[tr.example_id],scales)
                    else:
                        fq,sq=reps[q.example_id]; ft,st=reps[tr.example_id]
                        d=0.65*_feature_distance(fq,ft,scales)+0.35*_seq_distance(sq,st)
                    # Deterministic tie-break; nearest individual exemplar.
                    key=(d,tr.example_id)
                    if best is None or key<best[0]: best=(key,labels[tr.example_id])
                pred=best[1]
                correct += int(pred==labels[q.example_id]); total += 1
        return RepresentationResult(representation,correct,total,correct/total if total else 0.0)

    def _permuted_labels(self, examples, k):
        # Observer-wise inconsistent relabeling. A global label swap is NOT a negative
        # control because it preserves the representation->class relation up to naming.
        by_obs={}
        for e in examples:
            by_obs.setdefault(e.observer_id,[]).append(e)
        obs=sorted(by_obs)
        if len(obs) < 2:
            raise ValueError("negative control requires >=2 observers")
        # Use balanced observer-wise swaps. Near-global swaps are not destructive controls:
        # they preserve the mapping up to almost a global relabeling. We therefore require
        # roughly half of observers to use the opposite label convention.
        codes=[c for c in range(1,1<<len(obs)) if bin(c).count("1") in {len(obs)//2,(len(obs)+1)//2}]
        code=codes[k % len(codes)]
        out={}
        for oi,o in enumerate(obs):
            es=sorted(by_obs[o],key=lambda e:e.example_id)
            labels=[e.causal_class for e in es]
            if len(labels)<=1:
                out[es[0].example_id]=labels[0]; continue
            shift=1 if ((code>>oi)&1) else 0
            if shift:
                labels=labels[1:]+labels[:1]
            for e,l in zip(es,labels): out[e.example_id]=l
        return out

    def evaluate(self, examples: list[TopologicalExample], min_gain: float=0.15) -> TopologicalTransportReport:
        labels={e.example_id:e.causal_class for e in examples}
        g=self._evaluate(examples,labels,'geometry')
        t0=self._evaluate(examples,labels,'T0')
        t1=self._evaluate(examples,labels,'T1')
        t2=self._evaluate(examples,labels,'T2')
        neg=[]
        for k in range(self.negative_controls):
            neg.append(self._evaluate(examples,self._permuted_labels(examples,k),'T2').accuracy)
        negmax=max(neg,default=0.0)
        gain=t2.accuracy-g.accuracy
        passed=(gain>=min_gain and t2.accuracy>negmax)
        reason=(
            f"PASS: T2 gain={gain:.3f}, negative_max={negmax:.3f}"
            if passed else f"FAIL: T2 gain={gain:.3f}, negative_max={negmax:.3f}"
        )
        return TopologicalTransportReport(g,t0,t1,t2,gain,negmax,passed,reason)
