from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

class EventType(str, Enum):
    START='START'; MOVE='MOVE'; END='END'; CANCEL='CANCEL'
    COLOR='COLOR'; AUDIO='AUDIO'; HAPTIC='HAPTIC'; ANIMATION='ANIMATION'
    BACKGROUND='BACKGROUND'; SILENCE='SILENCE'; PAUSE='PAUSE'

class SessionMode(str, Enum):
    FREE='FREE'; CAPTURE='CAPTURE'; TRANSFORM='TRANSFORM'; RECALL='RECALL'

class RecommendationMode(str, Enum):
    NONE='NONE'; PASSIVE='PASSIVE'; ACTIVE='ACTIVE'

@dataclass(frozen=True)
class RawEvent:
    type: EventType
    t_us: int
    pointer_id: Optional[int]=None
    x: Optional[float]=None
    y: Optional[float]=None
    pressure: Optional[float]=None
    contact_major: Optional[float]=None
    contact_minor: Optional[float]=None
    tilt_x: Optional[float]=None
    tilt_y: Optional[float]=None
    payload: dict[str,Any]=field(default_factory=dict)

    @staticmethod
    def from_dict(d: dict[str,Any]) -> 'RawEvent':
        x=dict(d); x['type']=EventType(x['type']); return RawEvent(**x)

@dataclass(frozen=True)
class StateObservation:
    t_us: int
    metrics: dict[str,float]
    confidence: Optional[float]=None
    source: str='self_report'

    @staticmethod
    def from_dict(d: dict[str,Any]) -> 'StateObservation':
        return StateObservation(
            t_us=int(d['t_us']),
            metrics={k:float(v) for k,v in d.get('metrics',{}).items()},
            confidence=None if d.get('confidence') is None else float(d['confidence']),
            source=str(d.get('source','self_report')),
        )

@dataclass
class EidoSession:
    session_id: str
    protocol_version: str
    mode: SessionMode
    recommendation_mode: RecommendationMode
    started_at: str
    raw_events: list[RawEvent]
    state_observations: list[StateObservation]
    target_state: Optional[dict[str,float]]=None
    intent: Optional[str]=None
    context_ref: Optional[str]=None
    metadata: dict[str,Any]=field(default_factory=dict)

    @staticmethod
    def from_dict(d: dict[str,Any]) -> 'EidoSession':
        return EidoSession(
            session_id=d['session_id'], protocol_version=d.get('protocol_version','0.1-R1'),
            mode=SessionMode(d.get('mode','FREE')),
            recommendation_mode=RecommendationMode(d.get('recommendation_mode','NONE')),
            started_at=d.get('started_at',''),
            raw_events=[RawEvent.from_dict(x) for x in d.get('raw_events',[])],
            state_observations=[StateObservation.from_dict(x) for x in d.get('state_observations',[])],
            target_state={k:float(v) for k,v in d['target_state'].items()} if d.get('target_state') else None,
            intent=d.get('intent'), context_ref=d.get('context_ref'), metadata=d.get('metadata',{})
        )

    def state_in(self):
        return min(self.state_observations,key=lambda x:x.t_us) if self.state_observations else None
    def state_out(self):
        return max(self.state_observations,key=lambda x:x.t_us) if self.state_observations else None

@dataclass(frozen=True)
class StrokeSegment:
    segment_id: str; session_id: str; pointer_id: int
    t_start_us: int; t_end_us: int
    points: tuple[tuple[float,float],...]
    mean_pressure: Optional[float]
    feature_vector: tuple[float,...]
    signature: str

@dataclass(frozen=True)
class RelationDescriptor:
    prev_segment_id: str; segment_id: str
    feature_vector: tuple[float,...]
    signature: str

@dataclass
class EidoOperator:
    operator_id: str
    pattern: tuple[str,...]
    support_count: int
    mean_delta: dict[str,float]
    stderr_delta: dict[str,float]
    baseline_delta: dict[str,float]
    evidence_refs: list[str]
    counterexample_refs: list[str]
    prototype_segment_ids: list[str]
    protocol_version: str='operator-miner-v1'
    metadata: dict[str,Any]=field(default_factory=dict)

@dataclass
class MacroName:
    name_id: str
    operator_ids: list[str]
    effect_vector: dict[str,float]
    domain_ref: Optional[str]=None
    known_failures: list[str]=field(default_factory=list)
    evidence_refs: list[str]=field(default_factory=list)

@dataclass
class UTCBinding:
    mem_object_id: str
    utc_address: Any
    source_ref: str
    confidence: float

@dataclass
class LatentSeed:
    seed_id: str
    source_modalities: list[str]
    source_embedding: list[float]
    target_eido_embedding: list[float]
    proposed_constraints: dict[str,Any]
    model_id: str
    adapter_version: str
    uncertainty: float

@dataclass
class Recommendation:
    operator_id: str
    next_token: str
    prototype_segment_id: Optional[str]
    expected_gain: float
    uncertainty: float
    reason: str
