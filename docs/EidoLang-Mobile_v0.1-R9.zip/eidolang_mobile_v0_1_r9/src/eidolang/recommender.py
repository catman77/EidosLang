from __future__ import annotations
from dataclasses import dataclass
import math
from .schema import EidoOperator,Recommendation
from .state import desired_delta,unit,dot,sub

@dataclass(frozen=True)
class RecommenderConfig:
    max_results:int=5; min_support:int=3

class DeterministicRecommender:
    def __init__(self,config:RecommenderConfig=RecommenderConfig()): self.config=config
    @staticmethod
    def prefix_match(pattern,recent):
        maxk=min(len(recent),len(pattern)-1)
        for k in range(maxk,-1,-1):
            if k==0:return True,0
            if tuple(recent[-k:])==pattern[:k]:return True,k
        return False,0
    def recommend(self,current_state,target_state,recent_tokens,operators:list[EidoOperator]):
        d=unit(desired_delta(current_state,target_state)); out=[]
        for op in operators:
            if op.support_count<self.config.min_support:continue
            ok,k=self.prefix_match(op.pattern,recent_tokens)
            if not ok or k>=len(op.pattern):continue
            gain=dot(sub(op.mean_delta,op.baseline_delta),d); unc=math.sqrt(sum(v*v for v in op.stderr_delta.values()))
            out.append(Recommendation(op.operator_id,op.pattern[k],op.prototype_segment_ids[0] if op.prototype_segment_ids else None,gain,unc,f'matched_prefix={k}; support={op.support_count}'))
        out.sort(key=lambda r:(-(r.expected_gain-r.uncertainty),-r.expected_gain,r.operator_id)); return out[:self.config.max_results]
