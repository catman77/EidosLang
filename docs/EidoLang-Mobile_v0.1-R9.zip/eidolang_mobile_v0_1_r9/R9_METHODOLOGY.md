# R9 — Grammar Adequacy / Unrepresented-Operator Residual Gate

## 1. What R8 did and did not close

R8 proved an extensional quantifier:

\[
Candidates_{R7}=Eligible_{\text{frozen grammar}}.
\]

It did not prove that the frozen grammar itself preserves every causal distinction present in
replayable raw interventions.

R9 tests exactly that missing implication. It does not add a grammar feature.

---

## 2. Diagnostic raw-program identity

For each frozen source session, R9 hashes only the raw intervention program:

- event type/order;
- relative event timing;
- pointer id;
- raw coordinates;
- pressure/contact/tilt;
- event payload.

It excludes state observations, session id and metadata.

Thus repeated executions of the same exact intervention program form an outcome-independent
raw program class \(x\).

This identity is intentionally finer than `StrokeSegmenter` and is **diagnostic only**. It is
not introduced into the production grammar.

---

## 3. Whole-grammar address

A raw program is not compared by one token. R9 reruns the frozen `OperatorMiner` and defines:

\[
A_G(x)=\{o\in OperatorMiner(L): pattern(o)\subset tokens(x)\}.
\]

Two raw programs are indistinguishable to the *entire current operator grammar* iff:

\[
A_G(x)=A_G(y).
\]

This is stronger than checking only `shape_signature(x)=shape_signature(y)`.

---

## 4. Complete causal diagnostic registry

Every raw program with frozen support at least `raw_program_min_support` must have exactly one
raw-program causal disposition:

\[
PASS,FAIL,UNRESOLVED,INVALID.
\]

For every pair of causal-PASS programs with the same nonempty whole-grammar address, a
substitution disposition is mandatory under the frozen domain/probe/policy.

No pair may be omitted because it is inconvenient.

---

## 5. Forbidden collision witness

If

\[
A_G(x)=A_G(y)\ne\varnothing
\]

but the independent raw-program substitution certificate is `FAIL`, R9 emits:

\[
\boxed{COLLISION(x,y)}.
\]

The only conclusion licensed is the necessity obligation:

\[
\boxed{G'(x)\ne G'(y)}
\]

for every future grammar claiming adequacy on this witness.

R9 does **not** decide whether the separator should be curvature, timing, pressure, topology,
color, or anything else. Choosing that separator is a later refinement problem.

---

## 6. Unrepresented raw-program witness

If a causal-PASS raw program has

\[
A_G(x)=\varnothing,
\]

R9 emits:

\[
\boxed{UNREPRESENTED(x)}.
\]

This is distinct from a collision: the grammar has no admitted operator address at all.

---

## 7. Gate semantics

- `PASS`: every causal-PASS represented raw program is substitution-equivalent to every
  other causal-PASS raw program with the same complete grammar address, and none is unrepresented.
- `INADEQUATE`: at least one `COLLISION` or `UNREPRESENTED` witness exists.
- `UNRESOLVED`: a mandatory within-cell substitution test or enumeration cap is unresolved.
- `INVALID`: registry/ledger/config completeness is broken.

`PASS` is corpus-relative. It is not a proof of universal semantic completeness.

---

## 8. R9 gates R8/R7/R5

The confirmation pipeline now becomes:

\[
RawLedger
\to R8\ CandidateClosure
\to R9\ GrammarAdequacy
\to R7\ BlindInstantiation
\to R6\ IndependentConfirmation
\to R5.
\]

If any confirmation observer has R9 != PASS, the downstream R8/R7/R5 chain is not run.

---

## 9. Synthetic forced witness

R9 includes two exact raw programs:

\[
x=((.10,.10),(.50,.50),(.90,.90)),
\]

\[
y=((.10,.10),(.50,.52),(.90,.90)).
\]

They have different raw-program hashes but the frozen 12-sample/8-bin segmenter maps them to
the same operator grammar address.

Their independent diagnostic effects are set on opposite sides and their raw-program
substitution disposition is `FAIL`.

R9 must return `INADEQUATE` and the explicit pair-separation obligation. The production grammar
is deliberately left unchanged.
