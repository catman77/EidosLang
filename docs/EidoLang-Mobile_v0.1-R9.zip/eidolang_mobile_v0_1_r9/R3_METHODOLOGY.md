# EidoLang-Mobile v0.1-R3 — Causal Replay Methodology

## Goal

R2 discovers a **predictive** language:

```text
pattern w  ->  predicts session-level state transition Δm
```

R3 asks a stricter question:

```text
do(replay(w))  ->  does Δm change relative to a matched control?
```

No R2 pattern is promoted merely because it predicts an outcome.

## R3 objects

### ReplayTemplate

A replayable physical realization of a discovered operator/rule:

```text
ReplayTemplate = normalized stroke trajectory + low-level motor profile
```

The template is materialized from an evidence session. For grammar rules, holdout evidence is preferred.

### MatchedControl

The control is chosen **without reading state outcomes**. Matching uses only low-level motor quantities:

- stroke count;
- total path length;
- duration;
- mean speed;
- available mean pressure;
- bounding-box area;
- relation count.

Dimensions are standardized over the target+candidate pool and combined by equal-weight Euclidean distance in standardized coordinates.

The candidate must not contain the target grammar rule.

This does **not** prove that the control is physically identical in every respect; it only removes specified low-level differences. Randomized replay remains the causal core.

## Randomized replay

For a pre-registered set of trial IDs, `balanced_random_assignment(ids, seed)` produces a balanced OPERATOR / MATCHED_CONTROL allocation.

The randomization seed must be generated and logged before outcomes are observed.

Each trial stores:

```text
operator_id
template_id
arm
assignment_seed
randomized
probe_schedule_id
pre_state
post_state
intermediate probes
```

## Endpoint causal estimand

For metric `y`:

```text
Δy_i = y_post - y_pre
ATE = mean(Δy | OPERATOR) - mean(Δy | MATCHED_CONTROL)
```

The R3 certificate uses an **exact balanced randomization test** conditional on the observed endpoint deltas and the treatment count.

No asymptotic or Monte-Carlo fallback is silently substituted. If the number of allocations

```text
C(n, n_operator)
```

exceeds `max_exact_allocations`, the result is returned as `UNRESOLVED` (`exact_p_value = null`, `certified = false`).

This is intentional: computational inconvenience is not evidence.

## Intermediate probes

Probes localize when a state contrast appears:

```text
pre -> probe 1 -> probe 2 -> ... -> post
```

But an active self-report probe is itself an intervention. Therefore:

1. treatment and control trials must use the same `probe_schedule_id`;
2. probe-trajectory contrasts are descriptive/localizing evidence;
3. the registered endpoint remains the causal certificate;
4. a later protocol should include a probe-free endpoint arm to quantify probe reactivity.

## Causal gate

For each pre-registered endpoint metric:

```text
design_valid
AND exact_test_completed
AND p_exact <= alpha
AND effect has pre-registered direction
```

must hold.

A `CausalOperatorCertificate` passes only when all requested endpoint metrics pass.

`alpha` is an explicit policy parameter stored in the certificate; it is not treated as a theorem or universal constant.

## What R3 proves and does not prove

A passing R3 certificate supports:

```text
replaying physical protocol w causally changes the measured state proxy
relative to the specified matched-control protocol
under the tested domain/probe schedule.
```

It does **not** prove:

- a universal semantic meaning of the shape;
- a unique neural mechanism;
- equivalence of two different causal operators;
- external-world control;
- mystical or quantum mediation.

## MacroName no-go discovered in R3

R2 defined a provisional `MacroName` from predictive operator equivalence.
R3 shows that two separately efficacious operators are not yet a single causal Name.

Even if:

```text
w1 causes target transition
w2 causes target transition
```

it does not follow that:

```text
w1 ≡ w2
```

They may differ in domain, trajectory, side effects, latency, or mechanism.

Therefore causal `MacroName` requires a later **randomized substitution test**:

```text
do(w1) vs do(w2)
```

on the same pre-state domain with equivalence margins fixed in advance.

That is the forced R4 gate.
