import unittest
from dataclasses import replace

from eidolang.r6_synthetic import run_r6_dryrun
from eidolang.discovery_confirmation import (
    R6SplitManifest, audit_discovery_confirmation_separation,
    R6ConfirmationAnalyzer,
)


class R6Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.vals=run_r6_dryrun()

    def test_hash_split_is_disjoint_and_deterministic(self):
        s=R6SplitManifest("S","P",tuple(f"O{i}" for i in range(12)),6,"seed",6)
        self.assertEqual(s.assignments(),s.assignments())
        self.assertFalse(set(s.discovery_observers()) & set(s.confirmation_observers()))
        self.assertEqual(len(s.discovery_observers()),6)
        self.assertEqual(len(s.confirmation_observers()),6)

    def test_confirmation_cohort_below_six_rejected(self):
        with self.assertRaises(ValueError):
            R6SplitManifest("S","P",tuple(f"O{i}" for i in range(10)),5,"seed",6)

    def test_full_two_cohort_confirmation_passes(self):
        *_,r6=self.vals
        self.assertTrue(r6.passed,r6)
        self.assertEqual(r6.leakage_audit.status,"PASS")
        self.assertEqual(r6.r5_certificate.exact_conventions,32)
        self.assertAlmostEqual(r6.r5_certificate.exact_p_value,1/32)

    def test_session_reuse_is_invalid(self):
        m,b,s,ald,rgd,dc,dcert,hyp,alc,rgc,cc,pkg,r6=self.vals
        c0=cc[0]
        reused=replace(c0.realization_sessions[0],session_id=dc[0].realization_sessions[0].session_id)
        cc2=list(cc)
        cc2[0]=replace(c0,realization_sessions=(reused,)+c0.realization_sessions[1:])
        aud=audit_discovery_confirmation_separation(s,hyp,dc,cc2)
        self.assertEqual(aud.status,"FAIL")
        self.assertTrue(any("session reuse" in x for x in aud.reasons))

    def test_r3_ref_reuse_is_invalid(self):
        m,b,s,ald,rgd,dc,dcert,hyp,alc,rgc,cc,pkg,r6=self.vals
        c0=cc[0]
        refs=list(c0.operator_causal_certificate_refs)
        refs[0]=dc[0].operator_causal_certificate_refs[0]
        cc2=list(cc); cc2[0]=replace(c0,operator_causal_certificate_refs=tuple(refs))
        aud=audit_discovery_confirmation_separation(s,hyp,dc,cc2)
        self.assertEqual(aud.status,"FAIL")
        self.assertTrue(any("R3 certificate reuse" in x for x in aud.reasons))

    def test_changed_primary_statistic_is_invalid(self):
        m,b,s,ald,rgd,dc,dcert,hyp,alc,rgc,cc,pkg,r6=self.vals
        badcfg=replace(pkg.r5_config,statistic_version="posthoc-new-statistic")
        badpkg=replace(pkg,r5_config=badcfg)
        c=R6ConfirmationAnalyzer(s,hyp,badpkg,alc,rgc).certify(dc,cc)
        self.assertEqual(c.status,"INVALID")
        self.assertTrue(any("statistic changed" in x for x in c.reasons))

    def test_discovery_macro_object_reuse_is_invalid(self):
        m,b,s,ald,rgd,dc,dcert,hyp,alc,rgc,cc,pkg,r6=self.vals
        cc2=list(cc); cc2[0]=replace(cc2[0],macro_name_id=dc[0].macro_name_id)
        aud=audit_discovery_confirmation_separation(s,hyp,dc,cc2)
        self.assertEqual(aud.status,"FAIL")
        self.assertTrue(any("MacroName object reused" in x for x in aud.reasons))


if __name__=="__main__":
    unittest.main()
