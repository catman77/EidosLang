import unittest
from dataclasses import replace
from eidolang.feasibility import *

class R411Tests(unittest.TestCase):
    def test_r3_minimum_default(self):
        m=FeasibilityManifest("S","P")
        r=analyze_feasibility(m)
        self.assertEqual(r.r3.minimum_total_trials_per_operator,10)
        self.assertEqual(r.r3.exact_allocations,252)
        self.assertLessEqual(r.r3.p_floor,r.r3.alpha_local)

    def test_r4_minimum_default(self):
        r=analyze_feasibility(FeasibilityManifest("S","P"))
        self.assertEqual(r.r4.pair_hypotheses,3)
        self.assertEqual(r.r4.checks_per_pair,6)
        self.assertEqual(r.r4.minimum_trials_per_arm_per_stratum,6)
        self.assertEqual(r.r4.exact_allocations_per_boundary,924)

    def test_alignment_rank_and_p_floor_choose_six(self):
        r=analyze_feasibility(FeasibilityManifest("S","P"))
        self.assertEqual(r.r47.minimum_fit_anchors,6)
        self.assertEqual(r.r47.exact_permutations,720)

    def test_alignment_can_be_computationally_impossible(self):
        m=replace(FeasibilityManifest("S","P"),r47_permutation_cap=100)
        r=analyze_feasibility(m)
        self.assertEqual(r.r47.status,"IMPOSSIBLE")

    def test_reliability_95pct_needs_19_pairs(self):
        r=analyze_feasibility(FeasibilityManifest("S","P"))
        self.assertEqual(r.r410.marginal_min_disjoint_pairs,19)
        self.assertEqual(r.r410.marginal_min_repeat_sessions_per_observer,38)

    def test_simultaneous_6x6_cost_is_719_pairs(self):
        r=analyze_feasibility(FeasibilityManifest("S","P"))
        self.assertEqual(r.r410.observer_metric_channels,36)
        self.assertEqual(r.r410.bonferroni_simultaneous_min_pairs,719)

    def test_five_observers_cannot_pass_single_binary_r5_at_005(self):
        m=replace(FeasibilityManifest("S","P"),observer_count=5,state_dimension=5,r410_metric_count=5)
        r=analyze_feasibility(m)
        self.assertEqual(r.r5.configured_exact_conventions,16)
        self.assertAlmostEqual(r.r5.configured_p_floor,0.0625)
        self.assertEqual(r.r5.status,"IMPOSSIBLE")

    def test_six_observers_can_resolve_single_binary_r5(self):
        r=analyze_feasibility(FeasibilityManifest("S","P"))
        self.assertEqual(r.r5.minimum_observers,6)
        self.assertEqual(r.r5.configured_exact_conventions,32)
        self.assertAlmostEqual(r.r5.configured_p_floor,0.03125)
        self.assertEqual(r.r5.status,"PASS")

    def test_two_primary_r5_hypotheses_need_seven_observers(self):
        m=replace(FeasibilityManifest("S","P"),observer_count=7,r5_primary_hypothesis_count=2)
        r=analyze_feasibility(m)
        self.assertEqual(r.r5.minimum_observers,7)
        self.assertEqual(r.r5.status,"PASS")

    def test_exact_cap_can_make_r3_impossible(self):
        m=replace(FeasibilityManifest("S","P"),r3_exact_cap=100)
        r=analyze_feasibility(m)
        self.assertEqual(r.r3.status,"IMPOSSIBLE")

    def test_conservative_anchor_lower_bound(self):
        r=analyze_feasibility(FeasibilityManifest("S","P"))
        self.assertEqual(r.corpus_lower_bound.conservative_anchor_sessions_per_observer_no_reuse,47)
        self.assertEqual(r.corpus_lower_bound.conservative_anchor_sessions_total_no_reuse,282)

if __name__=="__main__":
    unittest.main()
