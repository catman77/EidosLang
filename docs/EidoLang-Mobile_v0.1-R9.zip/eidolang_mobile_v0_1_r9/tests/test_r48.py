import unittest
from dataclasses import replace

from eidolang.acquisition import (
    AnchorDefinition, AnalysisLock, AcquisitionManifest,
    deterministic_schedule, AcquisitionGate, AcquisitionLedger,
    freeze_dataset, EvaluationManifest, validate_evaluation_manifest,
    sha256_object,
)
from eidolang.schema import EidoSession


def manifest():
    anchors=tuple(AnchorDefinition(f"A{i}",f"anchor {i}",20.0,2) for i in range(1,10))
    keys=("focus","noise")
    return AcquisitionManifest(
        study_id="study",
        protocol_version="acq-v1",
        anchors=anchors,
        fit_anchor_count=6,
        split_seed="frozen-seed",
        planned_observer_count=3,
        state_metric_keys=keys,
        exclusion_rules=("technical failure",),
        analysis_lock=AnalysisLock(
            topology_representation="T3",
            topology_extractor_version="multilayer-topology-v1",
            state_metric_keys=keys,
            causal_label_policy="ALL_R4_PASSING_AT_CUTOFF",
            cross_observer_policy="LEAVE_ONE_OBSERVER_OUT",
        ),
    )


def session(m, oid, trial, sid="s1"):
    return EidoSession.from_dict({
        "session_id":sid,
        "protocol_version":"0.1-R4.8",
        "mode":"CAPTURE",
        "recommendation_mode":"NONE",
        "started_at":"2026-08-11T06:00:00+03:00",
        "raw_events":[],
        "state_observations":[
            {"t_us":0,"metrics":{"focus":0.2,"noise":0.8}},
            {"t_us":30_000_000,"metrics":{"focus":0.3,"noise":0.7}},
        ],
        "metadata":{
            "study_id":m.study_id,
            "protocol_hash":m.protocol_hash,
            "observer_id":oid,
            "anchor_id":trial.anchor_id,
            "anchor_repeat":trial.repeat_index,
            "schedule_index":trial.schedule_index,
        }
    })


class R48Tests(unittest.TestCase):
    def test_manifest_hash_is_canonical(self):
        m=manifest()
        self.assertEqual(m.protocol_hash,sha256_object(m))
        self.assertEqual(m.protocol_hash,len(m.protocol_hash)*"x" if False else m.protocol_hash)

    def test_split_is_deterministic_disjoint_complete(self):
        m=manifest(); a=m.anchor_split(); b=m.anchor_split()
        self.assertEqual(a,b)
        self.assertFalse(set(a.fit_anchor_ids)&set(a.holdout_anchor_ids))
        self.assertEqual(set(a.fit_anchor_ids)|set(a.holdout_anchor_ids),{x.anchor_id for x in m.anchors})
        pub=m.public_collection_manifest()
        self.assertNotIn("fit_anchor_ids",pub)
        self.assertNotIn("holdout_anchor_ids",pub)

    def test_schedule_and_admission(self):
        m=manifest(); oid="O1"; sch=deterministic_schedule(m,oid)
        s=session(m,oid,sch[0])
        self.assertTrue(AcquisitionGate(m).validate_anchor_session(s,oid,sch[0]).passed)

    def test_admission_rejects_protocol_and_schedule_tampering(self):
        m=manifest(); oid="O1"; sch=deterministic_schedule(m,oid)
        s=session(m,oid,sch[0])
        s.metadata["protocol_hash"]="bad"
        r=AcquisitionGate(m).validate_anchor_session(s,oid,sch[0])
        self.assertFalse(r.passed)
        self.assertIn("protocol_hash mismatch",r.reasons)

    def test_ledger_detects_session_mutation(self):
        m=manifest(); oid="O1"; sch=deterministic_schedule(m,oid)
        s=session(m,oid,sch[0])
        ledger=AcquisitionLedger(m.protocol_hash); ledger.append(s)
        self.assertTrue(ledger.verify({s.session_id:s})[0])
        s.metadata["anchor_id"]="A999"
        self.assertFalse(ledger.verify({s.session_id:s})[0])

    def test_freeze_and_evaluation_lock(self):
        m=manifest(); oid="O1"; sch=deterministic_schedule(m,oid)
        s=session(m,oid,sch[0])
        ledger=AcquisitionLedger(m.protocol_hash); ledger.append(s)
        freeze=freeze_dataset(m,ledger,{s.session_id:s},[oid])
        split=m.anchor_split()
        ev=EvaluationManifest(
            study_id=m.study_id,
            protocol_hash=m.protocol_hash,
            data_freeze_hash=freeze.freeze_hash,
            topology_representation="T3",
            topology_extractor_version="multilayer-topology-v1",
            alignment_fit_anchor_ids=split.fit_anchor_ids,
            alignment_holdout_anchor_ids=split.holdout_anchor_ids,
            causal_label_policy="ALL_R4_PASSING_AT_CUTOFF",
            eligible_causal_label_refs=("N1","N2"),
            included_causal_label_refs=("N1","N2"),
            cross_observer_policy="LEAVE_ONE_OBSERVER_OUT",
            evaluator_version="r5-eval-v1",
        )
        self.assertTrue(validate_evaluation_manifest(m,freeze,ev).passed)

    def test_causal_label_cherry_pick_blocked(self):
        m=manifest(); oid="O1"; sch=deterministic_schedule(m,oid)
        s=session(m,oid,sch[0])
        ledger=AcquisitionLedger(m.protocol_hash); ledger.append(s)
        freeze=freeze_dataset(m,ledger,{s.session_id:s},[oid])
        split=m.anchor_split()
        ev=EvaluationManifest(
            study_id=m.study_id,
            protocol_hash=m.protocol_hash,
            data_freeze_hash=freeze.freeze_hash,
            topology_representation="T3",
            topology_extractor_version="multilayer-topology-v1",
            alignment_fit_anchor_ids=split.fit_anchor_ids,
            alignment_holdout_anchor_ids=split.holdout_anchor_ids,
            causal_label_policy="ALL_R4_PASSING_AT_CUTOFF",
            eligible_causal_label_refs=("N1","N2"),
            included_causal_label_refs=("N1",),
            cross_observer_policy="LEAVE_ONE_OBSERVER_OUT",
            evaluator_version="r5-eval-v1",
        )
        r=validate_evaluation_manifest(m,freeze,ev)
        self.assertFalse(r.passed)
        self.assertIn("post-hoc causal-label subset selection forbidden",r.reasons)


if __name__=="__main__":
    unittest.main()
