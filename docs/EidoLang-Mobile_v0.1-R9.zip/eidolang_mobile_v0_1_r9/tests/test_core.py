import unittest
from eidolang.schema import EidoSession
from eidolang.segmenter import StrokeSegmenter
from eidolang.geometry import shape_signature
from eidolang.operators import OperatorMiner,MinerConfig
from eidolang.recommender import DeterministicRecommender

def make_session(sid,dy,offset=0.0):
    raw=[
      {"type":"START","t_us":0,"pointer_id":0,"x":0.1+offset,"y":0.1+offset},
      {"type":"MOVE","t_us":100000,"pointer_id":0,"x":0.5+offset,"y":0.5+offset},
      {"type":"END","t_us":200000,"pointer_id":0,"x":0.9+offset,"y":0.9+offset}]
    return EidoSession.from_dict({"session_id":sid,"mode":"TRANSFORM","recommendation_mode":"NONE","raw_events":raw,"state_observations":[{"t_us":0,"metrics":{"focus":0.2,"noise":0.8}},{"t_us":300000,"metrics":{"focus":0.2+dy,"noise":0.8-dy}}],"target_state":{"focus":0.9,"noise":0.1}})

class Tests(unittest.TestCase):
    def test_translation_scale_invariance(self): self.assertEqual(shape_signature([(0,0),(1,1),(2,0)])[0],shape_signature([(10,10),(12,12),(14,10)])[0])
    def test_one_stroke(self): self.assertEqual(len(StrokeSegmenter().segment(make_session('s',0.2))),1)
    def test_mining_and_recommendation(self):
        ss=[make_session(f's{i}',0.15+0.02*i,0.01*i) for i in range(5)]
        ops=OperatorMiner(config=MinerConfig(min_support=3,max_ngram=1)).mine(ss)
        self.assertTrue(ops)
        rec=DeterministicRecommender().recommend({"focus":0.2,"noise":0.8},{"focus":0.9,"noise":0.1},[],ops)
        self.assertTrue(rec)

if __name__=='__main__':unittest.main()
