import unittest
from eidolang.effect_alignment import AnchorObservation, AlignmentConfig, CrossObserverEffectAligner
from eidolang.r47_synthetic import make_alignment_observations, run_positive_control, run_nonlinear_counterexample

class R47Tests(unittest.TestCase):
    def test_positive_alignment_gate(self):
        r=run_positive_control()
        self.assertTrue(r.passed,r.reason)
        self.assertFalse(r.blocked_observers)
        for x in r.results:
            self.assertEqual(x.status,'PASS',x.reason)
            self.assertLessEqual(x.holdout_rmse,x.margin)
            self.assertLessEqual(x.permutation_p,x.adjusted_alpha)

    def test_unseen_nonlinear_observer_blocks_transport(self):
        r=run_nonlinear_counterexample()
        self.assertFalse(r.passed)
        self.assertIn('O5',r.blocked_observers)
        bad=[x for x in r.results if x.observer_id=='O5'][0]
        self.assertEqual(bad.status,'FAIL')
        self.assertGreater(bad.holdout_rmse,bad.margin)

    def test_rank_deficiency_invalid(self):
        obs=[]
        for o in ('A','B'):
            for a,x in [('F0',.1),('F1',.2),('F2',.3),('F3',.4),('H0',.5)]:
                obs.append(AnchorObservation(o,a,{'x':x,'y':2*x},protocol_version='p'))
        cfg=AlignmentConfig(('F0','F1','F2','F3'),('H0',),.1,permutation_cap=1000)
        r=CrossObserverEffectAligner(cfg).align(obs,'A')
        self.assertFalse(r.passed)
        self.assertEqual(r.results[0].status,'INVALID')

    def test_exact_permutation_cap_returns_unresolved(self):
        obs=make_alignment_observations(n_observers=2)
        cfg=AlignmentConfig(('F0','F1','F2','F3','F4','F5'),('H0','H1'),.05,permutation_cap=100)
        r=CrossObserverEffectAligner(cfg).align(obs,'O0')
        self.assertFalse(r.passed)
        self.assertEqual(r.results[0].status,'UNRESOLVED')

    def test_mixed_protocol_versions_invalid(self):
        obs=make_alignment_observations(n_observers=2)
        obs[0]=AnchorObservation(obs[0].observer_id,obs[0].anchor_id,obs[0].effect,obs[0].source_ref,'other')
        cfg=AlignmentConfig(('F0','F1','F2','F3'),('H0',),.1,permutation_cap=1000)
        r=CrossObserverEffectAligner(cfg).align(obs,'O0')
        self.assertFalse(r.passed)
        self.assertIn('mixed anchor protocol',r.reason)

if __name__=='__main__': unittest.main()
