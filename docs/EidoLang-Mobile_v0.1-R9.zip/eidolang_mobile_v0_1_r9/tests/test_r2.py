import unittest
from eidolang.schema import EidoSession
from eidolang.alphabet import AlphabetInducer, AlphabetConfig
from eidolang.grammar import EffectGrammarInducer, GrammarConfig
from eidolang.validation import deterministic_split

SHAPES={
    'A':[(0.10,0.85),(0.50,0.15),(0.90,0.85)],       # V/inverted orientation
    'B':[(0.15,0.10),(0.15,0.90),(0.85,0.90)],       # L
    'C':[(0.10,0.50),(0.50,0.50),(0.90,0.50)],       # horizontal
    'D':[(0.10,0.10),(0.50,0.90),(0.90,0.10)],       # caret
}

def raw_for(shapes):
    out=[]; t=0
    for name in shapes:
        pts=SHAPES[name]
        out.append({'type':'START','t_us':t,'pointer_id':0,'x':pts[0][0],'y':pts[0][1]})
        t+=100_000
        out.append({'type':'MOVE','t_us':t,'pointer_id':0,'x':pts[1][0],'y':pts[1][1]})
        t+=100_000
        out.append({'type':'END','t_us':t,'pointer_id':0,'x':pts[2][0],'y':pts[2][1]})
        t+=150_000
    return out

def sess(sid, shapes, delta):
    return EidoSession.from_dict({
        'session_id':sid,'mode':'TRANSFORM','recommendation_mode':'NONE','started_at':'',
        'raw_events':raw_for(shapes),
        'state_observations':[
            {'t_us':0,'metrics':{'focus':0.0,'noise':0.0}},
            {'t_us':10_000_000,'metrics':{'focus':delta,'noise':-delta}},
        ],
        'target_state':{'focus':1.0,'noise':-1.0}
    })

class R2Tests(unittest.TestCase):
    def test_effect_equivalent_forms_merge(self):
        ss=[]
        # A and B are geometrically distinct but have identical transition semantics.
        # C has the opposite semantics.
        for i in range(18): ss.append(sess(f'A{i:02d}', ['A'], 0.8))
        for i in range(18): ss.append(sess(f'B{i:02d}', ['B'], 0.8))
        for i in range(18): ss.append(sess(f'C{i:02d}', ['C'], -0.8))
        cfg=AlphabetConfig(min_train_support=2,min_holdout_support=1,negative_controls=8)
        alpha=AlphabetInducer(config=cfg).fit(ss)
        self.assertTrue(alpha.symbols)
        self.assertTrue(alpha.passed_negative_control_gate)
        merged=[set(s.member_tokens) for s in alpha.symbols if len(s.member_tokens)>=2]
        self.assertTrue(merged, 'expected at least one functionally merged symbol')
        # There must be one merged class with positive effect and a separate negative class.
        self.assertTrue(any(s.train_effect.get('focus',0)>0.5 and len(s.member_tokens)>=2 for s in alpha.symbols))
        self.assertTrue(any(s.train_effect.get('focus',0)<-0.5 for s in alpha.symbols))

    def test_context_rule_beats_suffix(self):
        ss=[]
        # Same final C stroke and broadly same relation class; first symbol decides effect.
        for i in range(30): ss.append(sess(f'pos{i:02d}', ['A','C'], 0.9))
        for i in range(30): ss.append(sess(f'neg{i:02d}', ['D','C'], -0.9))
        split=deterministic_split(ss,0.25)
        alpha=AlphabetInducer(config=AlphabetConfig(negative_controls=8)).fit(ss,split)
        self.assertTrue(alpha.passed_negative_control_gate)
        grammar=EffectGrammarInducer(config=GrammarConfig(min_train_support=2,min_holdout_support=1,max_order=3,negative_controls=8)).fit(ss,alpha,split)
        self.assertTrue(grammar.rules)
        self.assertTrue(grammar.passed_negative_control_gate)
        self.assertTrue(any(r.holdout_gain>0 for r in grammar.rules))

if __name__=='__main__': unittest.main()
