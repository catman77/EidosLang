import copy
import unittest
from dataclasses import replace

from eidolang.r5_synthetic import run_r5_dryrun, make_r5_dryrun_inputs
from eidolang.r412_dryrun import dryrun_master, _alignment_observations, _reliability_observations
from eidolang.protocol_compiler import ProtocolCompiler, ConfirmatoryRuntime
from eidolang.reliability import reliability_gate
from eidolang.cross_observer_transport import R5CrossObserverTransportAnalyzer

class R5Tests(unittest.TestCase):
    def test_compiler_locks_r5_exact_space(self):
        b=ProtocolCompiler().compile(dryrun_master())
        self.assertEqual(len(b.r5.observer_ids),6)
        self.assertEqual(b.r5.causal_class_count,2)
        self.assertEqual(b.r5.realizations_per_class,3)
        self.assertAlmostEqual(b.r5.alpha_local,.05)

    def test_positive_exact_transport_passes_at_1_over_32(self):
        *_,cert=run_r5_dryrun()
        self.assertTrue(cert.passed,cert)
        self.assertEqual(cert.exact_conventions,32)
        self.assertAlmostEqual(cert.p_floor,1/32)
        self.assertAlmostEqual(cert.exact_p_value,1/32)
        self.assertGreater(cert.observed_statistic,0)

    def test_local_class_renaming_is_invariant(self):
        m=dryrun_master(); b=ProtocolCompiler().compile(m); rt=ConfirmatoryRuntime(b)
        al=rt.effect_aligner().align(_alignment_observations(b),m.reference_observer_id)
        rg=reliability_gate(b.reliability,_reliability_observations(m,b))
        xs=make_r5_dryrun_inputs(b,al)
        c1=rt.r5_analyzer(al,rg).certify(xs)
        # swap local IDs for one observer; topology and effects remain paired.
        ys=[]
        for x in xs:
            if x.observer_id=="O3":
                nid="A" if x.local_class_id=="B" else "B"
                ys.append(replace(x,local_class_id=nid))
            else:
                ys.append(x)
        c2=rt.r5_analyzer(al,rg).certify(ys)
        self.assertAlmostEqual(c1.observed_statistic,c2.observed_statistic,places=12)
        self.assertAlmostEqual(c1.exact_p_value,c2.exact_p_value,places=12)

    def test_one_observer_effect_pairing_breaks_primary_gate(self):
        m=dryrun_master(); b=ProtocolCompiler().compile(m); rt=ConfirmatoryRuntime(b)
        al=rt.effect_aligner().align(_alignment_observations(b),m.reference_observer_id)
        rg=reliability_gate(b.reliability,_reliability_observations(m,b))
        xs=make_r5_dryrun_inputs(b,al)
        ys=list(xs)
        inds=[i for i,x in enumerate(ys) if x.observer_id=="O4"]
        self.assertEqual(len(inds),2)
        i,j=inds
        a,bb=ys[i],ys[j]
        ys[i]=replace(a,operator_effects=bb.operator_effects)
        ys[j]=replace(bb,operator_effects=a.operator_effects)
        c=rt.r5_analyzer(al,rg).certify(ys)
        self.assertFalse(c.passed)
        self.assertGreater(c.exact_p_value,.05)

    def test_unpassed_macro_invalid(self):
        m=dryrun_master(); b=ProtocolCompiler().compile(m); rt=ConfirmatoryRuntime(b)
        al=rt.effect_aligner().align(_alignment_observations(b),m.reference_observer_id)
        rg=reliability_gate(b.reliability,_reliability_observations(m,b))
        xs=make_r5_dryrun_inputs(b,al)
        xs[0]=replace(xs[0],macro_name_passed=False)
        c=rt.r5_analyzer(al,rg).certify(xs)
        self.assertEqual(c.status,"INVALID")

    def test_exact_cap_unresolved(self):
        m=dryrun_master(); b=ProtocolCompiler().compile(m); rt=ConfirmatoryRuntime(b)
        al=rt.effect_aligner().align(_alignment_observations(b),m.reference_observer_id)
        rg=reliability_gate(b.reliability,_reliability_observations(m,b))
        xs=make_r5_dryrun_inputs(b,al)
        cfg=replace(b.r5,exact_cap=16)
        c=R5CrossObserverTransportAnalyzer(cfg,al,rg).certify(xs)
        self.assertEqual(c.status,"UNRESOLVED")
        self.assertFalse(c.exact_test_completed)

if __name__=="__main__":
    unittest.main()
