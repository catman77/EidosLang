import unittest
from eidolang.fidelity import *


def profile(haptic=True):
    return DeviceCapabilityProfile(
        device_id="D1", profile_version="v1", user_agent="ua", platform="p",
        screen_width_px=1080, screen_height_px=2400, device_pixel_ratio=3.0,
        supports_audio=True, supports_haptic=haptic, supports_pointer_pressure=True,
        audio_sample_rate_hz=48000.0
    )


def plan(scope=FidelityScope.DIGITAL_EXECUTION):
    return AnchorExecutionPlan(
        anchor_id="A1", plan_version="v1", required_fidelity_scope=scope,
        steps=(
            StimulusStep("v",StimulusKind.VISUAL,0,1000,start_tolerance_ms=50,duration_tolerance_ms=60),
            StimulusStep("h",StimulusKind.HAPTIC,1200,100,requires_capability="haptic",
                         start_tolerance_ms=50,duration_tolerance_ms=50,
                         requires_physical_calibration=(scope==FidelityScope.PHYSICAL_OUTPUT)),
        )
    )


def trace(p, prof, bad_start=False, haptic_success=True):
    return ExecutionTrace(
        anchor_id=p.anchor_id, plan_hash=p.plan_hash, device_profile_hash=prof.profile_hash,
        session_id="s1", trace_version="v1",
        steps=(
            StepExecution("v",StimulusKind.VISUAL,0,80 if bad_start else 10,1010 if not bad_start else 1080,True),
            StepExecution("h",StimulusKind.HAPTIC,1200,1210,1310,haptic_success),
        )
    )


class R49Tests(unittest.TestCase):
    def test_digital_execution_passes(self):
        p=plan(); d=profile(); t=trace(p,d)
        c=certify_execution(p,t,d)
        self.assertEqual(c.status,"PASS")
        self.assertEqual(c.scope,FidelityScope.DIGITAL_EXECUTION)

    def test_timing_failure(self):
        p=plan(); d=profile(); t=trace(p,d,bad_start=True)
        c=certify_execution(p,t,d)
        self.assertEqual(c.status,"FAIL")
        self.assertTrue(any("timing" in r for x in c.step_results for r in x.reasons))

    def test_missing_capability_fails(self):
        p=plan(); d=profile(haptic=False); t=trace(p,d)
        c=certify_execution(p,t,d)
        self.assertEqual(c.status,"FAIL")
        self.assertTrue(any("capability" in r for x in c.step_results for r in x.reasons))

    def test_physical_scope_requires_external_calibration(self):
        p=plan(FidelityScope.PHYSICAL_OUTPUT); d=profile(); t=trace(p,d)
        c=certify_execution(p,t,d)
        self.assertEqual(c.status,"FAIL")
        self.assertIn("physical-output scope requires external calibration",c.reasons)

    def test_physical_scope_passes_with_matching_calibration(self):
        p=plan(FidelityScope.PHYSICAL_OUTPUT); d=profile(); t=trace(p,d)
        cal=PhysicalCalibrationRef(
            "C1","D1","external accelerometer",("haptic",),{"haptic_peak_m_s2":1.2},
            "2026-08-01",None,"external:calibration-record"
        )
        c=certify_execution(p,t,d,cal)
        self.assertEqual(c.status,"PASS")
        self.assertIsNotNone(c.physical_calibration_hash)

    def test_wrong_plan_hash_fails(self):
        p=plan(); d=profile(); t=trace(p,d)
        t=ExecutionTrace(t.anchor_id,"bad",t.device_profile_hash,t.session_id,t.trace_version,t.steps)
        c=certify_execution(p,t,d)
        self.assertEqual(c.status,"FAIL")
        self.assertIn("plan_hash mismatch",c.reasons)

    def test_corpus_gate_requires_all_sessions(self):
        p=plan(); d=profile(); t=trace(p,d)
        c=certify_execution(p,t,d)
        r=corpus_fidelity_gate(("s1","s2"),(c,),FidelityScope.DIGITAL_EXECUTION)
        self.assertEqual(r.status,"FAIL")
        self.assertIn("s2",r.rejected_session_ids)


if __name__=="__main__":
    unittest.main()
