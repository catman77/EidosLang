import unittest
from eidolang.r46_synthetic import necessity_examples, make_cross_observer_examples
from eidolang.multilayer_topology import describe_multilayer_session, color_runs
from eidolang.multilayer_discovery import CrossObserverMultilayerEvaluator

class R46Tests(unittest.TestCase):
    def test_color_layer_necessity(self):
        split,unified,_,_,_,_=necessity_examples()
        a,b=describe_multilayer_session(split),describe_multilayer_session(unified)
        self.assertEqual(a.form.temporal.signature,b.form.temporal.signature)
        self.assertNotEqual(a.signature,b.signature)
        self.assertEqual(len(a.color_layers),2)
        self.assertEqual(len(b.color_layers),1)

    def test_media_topological_coupling_necessity(self):
        _,_,early,close,_,_=necessity_examples()
        a,b=describe_multilayer_session(early),describe_multilayer_session(close)
        self.assertEqual(a.form.temporal.signature,b.form.temporal.signature)
        self.assertNotEqual(a.media_form_couplings,b.media_form_couplings)
        self.assertNotEqual(a.signature,b.signature)


    def test_layer_nesting_pattern_needed_beyond_aggregate_counts(self):
        *_,abac,abcb=necessity_examples()
        a,b=describe_multilayer_session(abac),describe_multilayer_session(abcb)
        self.assertEqual(a.form.temporal.signature,b.form.temporal.signature)
        self.assertEqual(len(a.color_layers),len(b.color_layers))
        self.assertEqual(a.anonymous_color_signatures,b.anonymous_color_signatures)
        self.assertEqual(a.color_switches,b.color_switches)
        self.assertEqual(a.cross_color_containment_edges,b.cross_color_containment_edges)
        self.assertNotEqual(a.color_nesting_patterns,b.color_nesting_patterns)
        self.assertNotEqual(a.signature,b.signature)
    def test_cross_observer_t3_gate(self):
        r=CrossObserverMultilayerEvaluator(negative_controls=8).evaluate(make_cross_observer_examples(),min_gain=.25)
        self.assertTrue(r.passed,r.reason)
        self.assertGreater(r.t3.accuracy,r.t2.accuracy)

    def test_negative_control_below_real(self):
        r=CrossObserverMultilayerEvaluator(negative_controls=8).evaluate(make_cross_observer_examples(),min_gain=.25)
        self.assertGreater(r.t3.accuracy,r.negative_control_max_t3_accuracy)

    def test_color_change_inside_stroke_splits_run(self):
        from eidolang.schema import EidoSession
        s=EidoSession.from_dict({'session_id':'splitstroke','mode':'FREE','recommendation_mode':'NONE','started_at':'','raw_events':[
            {'type':'COLOR','t_us':0,'payload':{'value':'A'}},
            {'type':'START','t_us':10,'pointer_id':0,'x':0.1,'y':0.1},
            {'type':'MOVE','t_us':20,'pointer_id':0,'x':0.4,'y':0.4},
            {'type':'COLOR','t_us':25,'payload':{'value':'B'}},
            {'type':'MOVE','t_us':30,'pointer_id':0,'x':0.6,'y':0.6},
            {'type':'END','t_us':40,'pointer_id':0,'x':0.9,'y':0.9},
        ],'state_observations':[]})
        rs=color_runs(s)
        self.assertEqual(len(rs),2)
        self.assertNotEqual(rs[0].color_token,rs[1].color_token)

if __name__=='__main__': unittest.main()
