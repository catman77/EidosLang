import unittest
from dataclasses import replace

from eidolang.r9_synthetic import run_r9_dryrun, collision_universe
from eidolang.grammar_adequacy import GrammarAdequacyAnalyzer
from eidolang.r9_confirmation import R9AdequacyGatedConfirmationAnalyzer

class R9Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls): cls.data=run_r9_dryrun()

    def test_existing_r8_source_is_adequate_and_full_confirmation_passes(self):
        data,adeq,regs,r9,collision,unrep=self.data
        self.assertTrue(r9.passed,r9)
        self.assertEqual(r9.status,"PASS")
        self.assertTrue(r9.r8.passed)
        self.assertEqual(len(adeq),6)
        for c in adeq:
            self.assertEqual(c.status,"PASS")
            self.assertTrue(c.adequate)
            self.assertEqual(c.raw_program_count,9)
            self.assertEqual(c.unrepresented_causal_program_count,0)
            self.assertEqual(c.indistinguishable_pair_count,0)

    def test_forced_quantization_collision_is_detected(self):
        cert=self.data[4][-1]
        self.assertEqual(cert.status,"INADEQUATE")
        self.assertFalse(cert.adequate)
        self.assertEqual(len(cert.collision_witnesses),1)
        w=cert.collision_witnesses[0]
        self.assertEqual(w.witness_type,"COLLISION")
        self.assertNotEqual(w.left_program_hash,w.right_program_hash)
        self.assertTrue(w.grammar_address)
        self.assertIn("G'(x) != G'(y)",w.obligation)
        self.assertEqual(len(cert.separation_obligations),1)

    def test_unrepresented_causal_program_is_detected(self):
        cert=self.data[5][-1]
        self.assertEqual(cert.status,"INADEQUATE")
        self.assertGreaterEqual(len(cert.unrepresented_witnesses),1)
        self.assertTrue(any(w.witness_type=="UNREPRESENTED" and not w.grammar_address for w in cert.unrepresented_witnesses))

    def test_missing_same_address_pair_registry_is_invalid(self):
        cfg8,ledger,freeze,byid,r3,r4,r8,cfg,causal,pairs,progs,cert=self.data[4]
        self.assertEqual(len(pairs),1)
        c=GrammarAdequacyAnalyzer(cfg).certify(ledger,freeze,byid,r8,causal,())
        self.assertEqual(c.status,"INVALID")
        self.assertTrue(any("missing raw pair dispositions" in x for x in c.reasons))

    def test_unresolved_same_address_pair_blocks_adequacy(self):
        cfg8,ledger,freeze,byid,r3,r4,r8,cfg,causal,pairs,progs,cert=self.data[4]
        p=replace(pairs[0],status="UNRESOLVED")
        c=GrammarAdequacyAnalyzer(cfg).certify(ledger,freeze,byid,r8,causal,(p,))
        self.assertEqual(c.status,"UNRESOLVED")
        self.assertFalse(c.adequate)

    def test_r9_does_not_run_r8_when_one_observer_is_inadequate(self):
        data,adeq,regs,r9,collision,unrep=self.data
        r8data=data
        vals,dsa,csa,dsel,rule,csel,cclasses,pkg,universes,sources,r8old=r8data
        m,b,split,ald,rgd,dclasses,dcert,hyp,alc,rgc,oldc,oldpkg,oldr6=vals
        bad=list(adeq)
        # Rebind the forced inadequate certificate to one confirmation observer only by
        # replacing identity/bindings is deliberately impossible; instead mutate one PASS
        # status to demonstrate the wrapper's gate semantics.
        bad[0]=replace(bad[0],status="INADEQUATE",adequate=False,reasons=("forced test residual",))
        c=R9AdequacyGatedConfirmationAnalyzer(split,hyp,pkg,rule,csa,alc,rgc,universes,bad).certify(dclasses,csel,cclasses)
        self.assertEqual(c.status,"INVALID")
        self.assertFalse(c.passed)
        self.assertEqual(c.r8.r7.r6.r5_certificate.certificate_id,"r5:not-run")

    def test_r8_binding_tamper_invalid(self):
        cfg8,ledger,freeze,byid,r3,r4,r8,cfg,causal,pairs,progs,cert=self.data[4]
        badcfg=replace(cfg,source_r8_certificate_hash="bad")
        c=GrammarAdequacyAnalyzer(badcfg).certify(ledger,freeze,byid,r8,causal,pairs)
        self.assertEqual(c.status,"INVALID")

if __name__=='__main__': unittest.main()
