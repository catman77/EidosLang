import copy
import unittest
from dataclasses import replace

from eidolang.r8_synthetic import run_r8_dryrun
from eidolang.candidate_universe import ExhaustiveCandidateUniverseEnumerator, audit_selector_candidate_universe
from eidolang.r8_confirmation import R8ClosedConfirmationAnalyzer


class R8Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data=run_r8_dryrun()

    def test_full_candidate_closure_and_confirmation_pass(self):
        vals,dsa,csa,dsel,rule,csel,cclasses,pkg,universes,sources,r8=self.data
        self.assertTrue(r8.passed,r8)
        self.assertEqual(r8.candidate_set_audit.status,"PASS")
        self.assertTrue(r8.r7.passed)
        self.assertAlmostEqual(r8.r7.r6.r5_certificate.exact_p_value,1/32)

    def test_each_observer_enumerates_exact_9_36_84_to_3(self):
        universes=self.data[8]
        self.assertEqual(len(universes),6)
        for c in universes:
            self.assertEqual(c.status,"PASS")
            self.assertEqual(c.mined_operator_count,9)
            self.assertEqual(c.r3_pass_count,9)
            self.assertEqual(c.expected_r4_pair_count,36)
            self.assertEqual(c.registered_r4_pair_count,36)
            self.assertEqual(c.clique_combinations_tested,84)
            self.assertEqual(len(c.eligible_macro_names),3)

    def test_omitted_selector_candidate_is_detected(self):
        universes=self.data[8]; csel=list(self.data[5])
        victim=csel.pop()
        a=audit_selector_candidate_universe(universes,csel)
        self.assertEqual(a.status,"FAIL")
        self.assertTrue(any("omitted eligible" in x for x in a.reasons))

    def test_extra_selector_candidate_is_detected(self):
        universes=self.data[8]; csel=list(self.data[5])
        x=csel[0]
        csel.append(replace(x,macro_name_id=x.macro_name_id+":FAKE"))
        a=audit_selector_candidate_universe(universes,csel)
        self.assertEqual(a.status,"FAIL")
        self.assertTrue(any("outside closed universe" in x for x in a.reasons))

    def test_missing_r3_disposition_invalidates_closure(self):
        oid,nextobjs=next(iter(self.data[9].items()))
        cfg,ledger,freeze,byid,r3,r4,cert,mg=nextobjs
        c=ExhaustiveCandidateUniverseEnumerator(cfg).certify(ledger,freeze,byid,r3[:-1],r4)
        self.assertEqual(c.status,"INVALID")
        self.assertFalse(c.complete)
        self.assertTrue(any("missing R3 dispositions" in x for x in c.reasons))

    def test_missing_r4_pair_disposition_invalidates_closure(self):
        oid,nextobjs=next(iter(self.data[9].items()))
        cfg,ledger,freeze,byid,r3,r4,cert,mg=nextobjs
        c=ExhaustiveCandidateUniverseEnumerator(cfg).certify(ledger,freeze,byid,r3,r4[:-1])
        self.assertEqual(c.status,"INVALID")
        self.assertTrue(any("missing R4 dispositions" in x for x in c.reasons))

    def test_clique_cap_returns_unresolved_not_sampling(self):
        oid,nextobjs=next(iter(self.data[9].items()))
        cfg,ledger,freeze,byid,r3,r4,cert,mg=nextobjs
        cfg2=replace(cfg,max_clique_combinations=83)
        c=ExhaustiveCandidateUniverseEnumerator(cfg2).certify(ledger,freeze,byid,r3,r4)
        # Config hash changes, therefore the old freeze binding is still valid; only enum cap changes.
        self.assertEqual(c.status,"UNRESOLVED")
        self.assertFalse(c.complete)
        self.assertTrue(any("q-clique combination count 84" in x for x in c.reasons))

    def test_mutated_frozen_source_session_invalidates_closure(self):
        oid,nextobjs=next(iter(self.data[9].items()))
        cfg,ledger,freeze,byid,r3,r4,cert,mg=nextobjs
        bad=copy.deepcopy(byid)
        sid=next(iter(bad))
        bad[sid].metadata["tampered"]=True
        c=ExhaustiveCandidateUniverseEnumerator(cfg).certify(ledger,freeze,bad,r3,r4)
        self.assertEqual(c.status,"INVALID")
        self.assertTrue(any("ledger verification failed" in x for x in c.reasons))

    def test_r8_does_not_run_r7_when_candidate_is_omitted(self):
        vals,dsa,csa,dsel,rule,csel,cclasses,pkg,universes,sources,r8=self.data
        m,b,split,ald,rgd,dclasses,dcert,hyp,alc,rgc,oldc,oldpkg,oldr6=vals
        bad=list(csel); bad.pop()
        c=R8ClosedConfirmationAnalyzer(
            split,hyp,pkg,rule,csa,alc,rgc,universes
        ).certify(dclasses,bad,cclasses)
        self.assertEqual(c.status,"INVALID")
        self.assertFalse(c.passed)
        self.assertEqual(c.r7.r6.r5_certificate.certificate_id,"r5:not-run")


if __name__=="__main__":
    unittest.main()
