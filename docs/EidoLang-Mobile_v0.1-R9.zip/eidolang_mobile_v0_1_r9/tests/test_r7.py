import unittest
from dataclasses import replace

from eidolang.r7_synthetic import run_r7_dryrun, make_selector_data
from eidolang.prospective_instantiation import (
    ProspectiveClassInstantiator, ConfirmationSelectorCandidate,
    audit_selector_primary_independence, R7ConfirmationAnalyzer,
)

class R7Tests(unittest.TestCase):
    def test_full_blinded_confirmation_passes(self):
        vals,dsa,csa,dsel,rule,csel,r7=run_r7_dryrun()
        self.assertTrue(r7.passed,r7)
        self.assertEqual(r7.instantiation.status,"PASS")
        self.assertTrue(r7.r6.passed)
        self.assertAlmostEqual(r7.r6.r5_certificate.exact_p_value,1/32)

    def test_selector_primary_metric_sets_are_disjoint(self):
        vals,dsa,csa,dsel,rule,csel,r7=run_r7_dryrun()
        self.assertFalse(set(rule.selector_metric_keys)&set(rule.primary_metric_keys))
        self.assertEqual(set(rule.primary_metric_keys),{"focus","noise"})

    def test_distractor_is_not_selected(self):
        vals,dsa,csa,dsel,rule,csel,r7=run_r7_dryrun()
        selected={m for o,c,m in r7.instantiation.selected_macro_names}
        self.assertFalse(any("DISTRACTOR" in m for m in selected))

    def test_selector_input_with_primary_metric_is_invalid(self):
        vals,dsa,csa,dsel,rule,csel,r7=run_r7_dryrun()
        vals0=vals
        m,b,split,ald,rgd,dclasses,dcert,hyp,alc,rgc,cclasses,pkg,r6=vals0
        bad=list(csel)
        x=bad[0]
        e=dict(x.selector_effects[0]); e["focus"]=.9
        bad[0]=replace(x,selector_effects=(e,)+x.selector_effects[1:])
        cert=ProspectiveClassInstantiator(rule,csa,rgc).instantiate(bad)
        self.assertEqual(cert.status,"INVALID")

    def test_selector_primary_certificate_reuse_is_invalid(self):
        vals,dsa,csa,dsel,rule,csel,r7=run_r7_dryrun()
        m,b,split,ald,rgd,dclasses,dcert,hyp,alc,rgc,cclasses,pkg,r6=vals
        # instantiate validly first
        inst=ProspectiveClassInstantiator(rule,csa,rgc).instantiate(csel)
        bad=list(csel)
        target=cclasses[0].operator_causal_certificate_refs[0]
        x=bad[0]
        refs=list(x.selector_certificate_refs); refs[0]=target
        bad[0]=replace(x,selector_certificate_refs=tuple(refs))
        inst2=ProspectiveClassInstantiator(rule,csa,rgc).instantiate(bad)
        self.assertEqual(inst2.status,"PASS")  # blindness layer itself doesn't see primary refs
        # cross-channel audit catches reuse before unsealing R5
        reasons=audit_selector_primary_independence(inst2,bad,cclasses)
        self.assertTrue(any("overlap" in r for r in reasons))

    def test_ambiguous_confirmation_returns_ambiguous(self):
        vals,dsa,csa,dsel,rule,csel,r7=run_r7_dryrun()
        m,b,split,ald,rgd,dclasses,dcert,hyp,alc,rgc,cclasses,pkg,r6=vals
        # For one observer make both true candidates have identical selector profiles,
        # while preserving the exact blinded schema.
        oid=rule.source_discovery_observers[0]  # choose any id; replace with a confirmation id below
        co=split.confirmation_observers()[0]
        rows=[x for x in csel if x.observer_id==co and "DISTRACTOR" not in x.macro_name_id]
        self.assertEqual(len(rows),2)
        bad=list(csel)
        i=[k for k,x in enumerate(bad) if x is rows[1]][0]
        bad[i]=replace(rows[1],selector_effects=rows[0].selector_effects)
        cert=ProspectiveClassInstantiator(rule,csa,rgc).instantiate(bad)
        self.assertIn(cert.status,("AMBIGUOUS","NO_MATCH"))

    def test_primary_class_set_must_equal_blind_selection(self):
        vals,dsa,csa,dsel,rule,csel,r7=run_r7_dryrun()
        m,b,split,ald,rgd,dclasses,dcert,hyp,alc,rgc,cclasses,pkg,r6=vals
        inst=ProspectiveClassInstantiator(rule,csa,rgc).instantiate(csel)
        reasons=audit_selector_primary_independence(inst,csel,cclasses[:-1])
        self.assertTrue(any("differs" in r for r in reasons))

if __name__=="__main__":
    unittest.main()
