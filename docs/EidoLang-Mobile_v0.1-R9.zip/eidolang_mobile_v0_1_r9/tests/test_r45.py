import unittest
from eidolang.r45_synthetic import necessity_examples, make_cross_observer_examples
from eidolang.topology import describe_session
from eidolang.topological_discovery import CrossObserverTopologyEvaluator

class R45Tests(unittest.TestCase):
    def test_t0_collision_for_nested_vs_separate(self):
        nested,separate,_,_=necessity_examples()
        a,b=describe_session(nested),describe_session(separate)
        self.assertEqual(a.final.t0_vector(),b.final.t0_vector())
        self.assertNotEqual(a.final.containment_edges,b.final.containment_edges)

    def test_t1_same_final_but_t2_order_differs(self):
        _,_,outer_first,inner_first=necessity_examples()
        a,b=describe_session(outer_first),describe_session(inner_first)
        self.assertEqual(a.final.t1_signature(),b.final.t1_signature())
        self.assertNotEqual(a.temporal.signature,b.temporal.signature)

    def test_closed_loop_has_hole(self):
        nested,_,_,_=necessity_examples()
        a=describe_session(nested)
        self.assertGreaterEqual(a.final.beta1,2)
        self.assertEqual(a.final.closed_strokes,2)

    def test_cross_observer_topology_gate(self):
        xs=make_cross_observer_examples()
        r=CrossObserverTopologyEvaluator(negative_controls=8).evaluate(xs,min_gain=.15)
        self.assertTrue(r.passed, r.reason)
        self.assertGreater(r.t2.accuracy,r.geometry.accuracy)

    def test_negative_label_rotation_not_dominant(self):
        xs=make_cross_observer_examples()
        r=CrossObserverTopologyEvaluator(negative_controls=8).evaluate(xs,min_gain=.15)
        self.assertGreater(r.t2.accuracy,r.negative_control_max_t2_accuracy)

if __name__=='__main__': unittest.main()
