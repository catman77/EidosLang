import unittest
from eidolang.substitution import (
    SubstitutionArm, EquivalenceStatus, CertifiedOperatorRef, DomainSpec,
    SubstitutionPolicy, CausalSubstitutionAnalyzer, CausalMacroNameBuilder,
    stratified_balanced_assignment
)
from eidolang.r4_synthetic import make_substitution_trials


def refs(a='op:A',b='op:B'):
    return (
        CertifiedOperatorRef(a,'causal:A',True,'domain:calm-mid','probe:2phase'),
        CertifiedOperatorRef(b,'causal:B',True,'domain:calm-mid','probe:2phase'),
    )

def domain():
    return DomainSpec('domain:calm-mid',{'focus':(0.2,0.4),'noise':(0.6,0.8)},('focus','noise'))

def policy(cap=200000):
    return SubstitutionPolicy(
        endpoint_margins={'focus':0.08,'noise':0.08},
        trajectory_margins={'focus':0.08,'noise':0.08},
        alpha_familywise=0.05,min_trials_per_arm_per_stratum=4,max_exact_allocations=cap
    )

class R4Tests(unittest.TestCase):
    def test_stratified_assignment_balanced(self):
        m={f'a{i}':'s0' for i in range(8)}|{f'b{i}':'s1' for i in range(10)}
        x=stratified_balanced_assignment(m,123)
        self.assertEqual(sum(x[k]==SubstitutionArm.LEFT for k in m if m[k]=='s0'),4)
        self.assertEqual(sum(x[k]==SubstitutionArm.LEFT for k in m if m[k]=='s1'),5)

    def test_equivalent_endpoint_and_trajectory_pass(self):
        xs=make_substitution_trials(n=16,left_effect=.45,right_effect=.46,
                                    left_probe=(.14,.31),right_probe=(.15,.30))
        l,r=refs()
        c=CausalSubstitutionAnalyzer(policy()).certify(xs,l,r,domain())
        self.assertTrue(c.passed)
        self.assertEqual(c.status,EquivalenceStatus.PASS)
        self.assertTrue(all(e.status==EquivalenceStatus.PASS for e in c.estimates))

    def test_endpoint_difference_fails(self):
        xs=make_substitution_trials(n=16,left_effect=.45,right_effect=.22,
                                    left_probe=(.14,.31),right_probe=(.15,.30))
        l,r=refs()
        c=CausalSubstitutionAnalyzer(policy()).certify(xs,l,r,domain())
        self.assertFalse(c.passed)
        self.assertEqual(c.status,EquivalenceStatus.FAIL)

    def test_same_endpoint_but_different_trajectory_fails(self):
        xs=make_substitution_trials(n=16,left_effect=.45,right_effect=.46,
                                    left_probe=(.10,.20),right_probe=(.27,.38))
        l,r=refs()
        c=CausalSubstitutionAnalyzer(policy()).certify(xs,l,r,domain())
        self.assertFalse(c.passed)
        self.assertEqual(c.status,EquivalenceStatus.FAIL)
        self.assertTrue(any(e.phase_index is not None and e.status==EquivalenceStatus.FAIL for e in c.estimates))

    def test_unpassed_r3_certificate_invalid(self):
        xs=make_substitution_trials(n=16)
        l,r=refs(); r=CertifiedOperatorRef(r.operator_id,r.causal_certificate_id,False,r.domain_id,r.probe_schedule_id)
        c=CausalSubstitutionAnalyzer(policy()).certify(xs,l,r,domain())
        self.assertEqual(c.status,EquivalenceStatus.INVALID)

    def test_exact_cap_is_unresolved(self):
        xs=make_substitution_trials(n=16)
        l,r=refs()
        c=CausalSubstitutionAnalyzer(policy(cap=10)).certify(xs,l,r,domain())
        self.assertFalse(c.passed)
        self.assertEqual(c.status,EquivalenceStatus.UNRESOLVED)

    def test_assignment_tamper_invalid(self):
        xs=make_substitution_trials(n=16)
        xs[0].arm=SubstitutionArm.RIGHT if xs[0].arm==SubstitutionArm.LEFT else SubstitutionArm.LEFT
        l,r=refs()
        c=CausalSubstitutionAnalyzer(policy()).certify(xs,l,r,domain())
        self.assertEqual(c.status,EquivalenceStatus.INVALID)

    def test_macro_name_requires_all_pairs_clique(self):
        p=policy()
        analyzer=CausalSubstitutionAnalyzer(p)
        d=domain()
        A=CertifiedOperatorRef('op:A','causal:A',True,d.domain_id,'probe:2phase')
        B=CertifiedOperatorRef('op:B','causal:B',True,d.domain_id,'probe:2phase')
        C=CertifiedOperatorRef('op:C','causal:C',True,d.domain_id,'probe:2phase')
        ab=analyzer.certify(make_substitution_trials('op:A','op:B'),A,B,d)
        bc=analyzer.certify(make_substitution_trials('op:B','op:C'),B,C,d)
        builder=CausalMacroNameBuilder()
        with self.assertRaises(ValueError):
            builder.build([A,B,C],[ab,bc])
        ac=analyzer.certify(make_substitution_trials('op:A','op:C'),A,C,d)
        name=builder.build([A,B,C],[ab,bc,ac])
        self.assertEqual(name.operator_ids,('op:A','op:B','op:C'))
        self.assertEqual(len(name.pair_certificate_ids),3)

if __name__=='__main__': unittest.main()
