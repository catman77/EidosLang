import unittest
from eidolang.causal import CausalAnalyzer, ReplayArm, balanced_random_assignment
from eidolang.r3_synthetic import make_trials

class R3Tests(unittest.TestCase):
    def test_balanced_randomization(self):
        a=balanced_random_assignment([f"t{i}" for i in range(10)],123)
        self.assertEqual(sum(v==ReplayArm.OPERATOR for v in a.values()),5)
        self.assertEqual(sum(v==ReplayArm.MATCHED_CONTROL for v in a.values()),5)

    def test_causal_effect_certifies(self):
        xs=make_trials(n=16,treatment_effect=0.45,control_effect=0.02)
        a=CausalAnalyzer(alpha=0.05,max_exact_allocations=20000)
        cert=a.certify(xs,"op:synthetic",{"focus":"greater","noise":"less"})
        self.assertTrue(cert.passed)
        self.assertTrue(all(e.exact_test_completed for e in cert.estimates))
        self.assertTrue(all(e.exact_p_value <= 0.05 for e in cert.estimates))
        self.assertEqual(len(cert.probe_trajectory),2)
        self.assertGreater(cert.probe_trajectory[-1].contrast,0.2)

    def test_null_does_not_certify(self):
        xs=make_trials(n=16,treatment_effect=0.02,control_effect=0.02)
        a=CausalAnalyzer(alpha=0.05,max_exact_allocations=20000)
        cert=a.certify(xs,"op:synthetic",{"focus":"greater"})
        self.assertFalse(cert.passed)

    def test_mismatched_probe_schedule_invalid(self):
        xs=make_trials(n=10)
        xs[0].probe_schedule_id="different"
        est=CausalAnalyzer(max_exact_allocations=1000).estimate(xs,"op:synthetic","focus","greater")
        self.assertFalse(est.design_valid)
        self.assertFalse(est.certified)

if __name__=='__main__': unittest.main()

class R3StrictnessTests(unittest.TestCase):
    def test_exact_cap_returns_unresolved_not_approximation(self):
        xs=make_trials(n=16)
        est=CausalAnalyzer(alpha=0.05,max_exact_allocations=10).estimate(xs,"op:synthetic","focus","greater")
        self.assertFalse(est.exact_test_completed)
        self.assertIsNone(est.exact_p_value)
        self.assertFalse(est.certified)

    def test_nonrandomized_trial_invalidates_certificate(self):
        xs=make_trials(n=10)
        xs[0].randomized=False
        est=CausalAnalyzer(max_exact_allocations=1000).estimate(xs,"op:synthetic","focus","greater")
        self.assertFalse(est.design_valid)
        self.assertFalse(est.certified)

from eidolang.schema import EidoSession
from eidolang.alphabet import AlphabetInducer, AlphabetConfig
from eidolang.grammar import EffectGrammarInducer, GrammarConfig
from eidolang.validation import deterministic_split
from eidolang.replay import ReplayTemplateBuilder, MatchedControlBuilder

_SH={
    'A':[(0.10,0.85),(0.50,0.15),(0.90,0.85)],
    'C':[(0.10,0.50),(0.50,0.50),(0.90,0.50)],
    'D':[(0.10,0.10),(0.50,0.90),(0.90,0.10)],
}
def _rraw(names):
    out=[]; t=0
    for name in names:
        pts=_SH[name]
        for typ,p in [('START',pts[0]),('MOVE',pts[1]),('END',pts[2])]:
            out.append({'type':typ,'t_us':t,'pointer_id':0,'x':p[0],'y':p[1]}); t+=100_000
        t+=150_000
    return out

def _rsess(sid,names,delta):
    return EidoSession.from_dict({
        'session_id':sid,'mode':'TRANSFORM','recommendation_mode':'NONE','started_at':'',
        'raw_events':_rraw(names),
        'state_observations':[{'t_us':0,'metrics':{'focus':0.0}},
                              {'t_us':10_000_000,'metrics':{'focus':delta}}]
    })

class R3ReplayBuilderTests(unittest.TestCase):
    def test_rule_control_excludes_target_pattern(self):
        ss=[]
        for i in range(20): ss.append(_rsess(f'p{i:02d}',['A','C'],0.8))
        for i in range(20): ss.append(_rsess(f'n{i:02d}',['D','C'],-0.8))
        split=deterministic_split(ss,0.25)
        alpha=AlphabetInducer(config=AlphabetConfig(negative_controls=4)).fit(ss,split)
        gram=EffectGrammarInducer(config=GrammarConfig(max_order=3,negative_controls=4)).fit(ss,alpha,split)
        rule=max(gram.rules,key=lambda r:r.holdout_gain)
        target=ReplayTemplateBuilder().from_rule(rule,alpha,ss)
        control,match=MatchedControlBuilder().match_rule(target,rule,alpha,ss)
        self.assertNotEqual(target.source_session_id,control.source_session_id)
        seq=EffectGrammarInducer().sequence(next(s for s in ss if s.session_id==control.source_session_id),alpha)
        n=len(rule.pattern)
        self.assertFalse(any(tuple(seq[i:i+n])==rule.pattern for i in range(max(0,len(seq)-n+1))))
        self.assertGreaterEqual(match.distance,0.0)
