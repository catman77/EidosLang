# R4 — Causal Substitution Calculus

## Goal

R3 established the first admissible form of `do(w) -> Δm` relative to matched controls.
R4 answers the next question:

> When may two independently causal graphic programs be treated as the **same operational Name**?

The answer is deliberately stronger than “both improve focus”.

## 1. Preconditions

Two candidates `w1,w2` may enter R4 only if each already has an independent passed R3 causal certificate.
They must share:

- one pre-registered state domain `B`;
- one probe schedule;
- one measured metric set relevant to the claimed effect.

A failed R3 operator cannot be rescued by R4 equivalence.

## 2. Randomized substitution experiment

For eligible initial states `m0 in B`, trials are assigned inside pre-registered strata:

```text
LEFT  -> replay(w1)
RIGHT -> replay(w2)
```

The randomization seed and complete trial ID set are fixed before outcomes and are reproducible from the stored manifest.

## 3. Equivalence is not a failure to find a difference

R4 never accepts

```text
p(difference) > 0.05
```

as evidence of sameness.

Every endpoint metric has a pre-registered equivalence margin `epsilon_y > 0`.
Every trajectory metric has a pre-registered margin `epsilon_y^traj > 0`.

For a differential effect `delta = effect(w1)-effect(w2)`, R4 performs two one-sided boundary tests:

```text
H0_lower: delta <= -epsilon
H0_upper: delta >= +epsilon
```

Operational equivalence requires rejection of both boundaries.

## 4. Exact randomization boundary tests

R4 uses exact enumeration of allocations allowed by the original stratified design.
At a boundary `tau0`, observed outcomes are adjusted under the sharp constant-additive null and the allowed assignments are exhaustively enumerated.

If the number of allocations exceeds `max_exact_allocations`, the result is:

```text
UNRESOLVED
```

not an asymptotic approximation.

### Scope of the theorem

The exactness is with respect to the **sharp constant-additive boundary model inside each tested stratum**.
It is not a theorem that arbitrary heterogeneous unit-level substitution effects are equal.
To narrow that gap, R4 requires pre-registered state strata and equivalence in every stratum separately.
Finer claims require finer strata or a later heterogeneous-effect calculus.

## 5. Familywise multiplicity

Endpoint and trajectory equivalence generate multiple claims.
If there are `K` elementary equivalence checks, each uses

```text
alpha_local = alpha_familywise / K
```

The certificate passes only if every pre-registered check passes.

## 6. Trajectory equivalence

Same final state is not sufficient.
For every common probe phase `j` and trajectory metric `y`, R4 tests

```text
Δy_j(w1) ≃ Δy_j(w2)
```

within the pre-registered trajectory margin.
Therefore equivalence is asserted only at the temporal resolution of the probe schedule.
Unobserved dynamics between probes remain unidentified.

## 7. Domain gate

`DomainSpec` explicitly bounds the admissible initial-state region.
Every trial pre-state must lie inside it.
Thus a certificate means:

```text
w1 ≃ w2 on B
```

not globally.

## 8. Assignment-integrity gate

R4 recomputes the stratified balanced assignment from:

- trial IDs;
- stratum IDs;
- pre-registered seed.

If observed arms do not reproduce the assignment, the design is `INVALID`.
A boolean `randomized=true` is not sufficient.

## 9. Approximate equivalence is not transitive

With a non-zero margin:

```text
w1 ≃_eps w2
w2 ≃_eps w3
```

does **not** imply

```text
w1 ≃_eps w3.
```

Therefore R4 explicitly forbids connected-components / union-find construction of Names.

A `CausalMacroName` is an **all-pairs substitution clique**:

```text
for every i<j:
    passed_substitution_certificate(w_i,w_j)
```

All pair certificates must use the same domain, probe schedule, margins/policy and protocol version.

## 10. Meaning of a Name after R4

If the gate passes:

```text
Name = {w1,...,wk}_causal-substitution
```

means only:

> at the declared domain, measured metric set, margins, strata and probe resolution,
> these independently causal programs are mutually substitutable by the R4 protocol.

It does **not** imply:

- identical microscopic neural mechanism;
- identical subjective phenomenology not represented in the metric set;
- global equivalence outside the tested domain;
- external-world efficacy;
- mystical or historical identity of the symbols.

## 11. R4 necessity result

R4 closes a specific gap from R3:

```text
causes same target
    !=
operationally equivalent
```

The missing evidence is randomized substitution with explicit equivalence margins and trajectory checks.
