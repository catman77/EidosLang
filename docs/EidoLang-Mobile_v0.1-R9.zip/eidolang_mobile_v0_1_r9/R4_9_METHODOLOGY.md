# R4.9 — Protocol Fidelity / Instrument Calibration Gate

## Necessity

R4.8 establishes that a session belongs to a frozen digital protocol. It does **not** establish that two observers physically received the same executed anchor.

A record `anchor_id=A3` is therefore insufficient. We require:

`Plan(A3) -> ExecutionTrace -> FidelityCertificate`.

## 1. Frozen execution plan

Each anchor is compiled to `AnchorExecutionPlan` with frozen:
- stimulus kind;
- nominal offset;
- duration;
- parameters;
- timing tolerances;
- required device capability;
- whether physical calibration is required.

The plan has `plan_hash = SHA256(CanonicalJSON(plan))`.

## 2. Device capability profile

Before acquisition the device records a frozen capability profile:
- screen dimensions and DPR;
- user-agent/platform;
- audio support/sample rate when available;
- haptic API availability;
- pointer-pressure availability.

Its hash is referenced by every execution trace.

## 3. Execution trace

For every step the runtime records:
`requested_start`, `actual_start`, `actual_end`, `api_success`.

The gate rejects:
- missing required steps;
- duplicate steps;
- wrong stimulus kind;
- absent required capability;
- API failure;
- start timing outside frozen tolerance;
- duration outside frozen tolerance;
- undeclared execution/media events.

## 4. Two fidelity scopes

### DIGITAL_EXECUTION

Certifies only that the browser/device API executed the declared digital command within frozen timing tolerances.

It does **not** certify physical equality of output.

### PHYSICAL_OUTPUT

Requires an external `PhysicalCalibrationRef`.

Digital volume is not an SPL; CSS brightness is not calibrated cd/m²; `navigator.vibrate(100)` is not calibrated acceleration. Therefore:

`DigitalExecution != PhysicalStimulusEquality`.

This is a structural no-go.

## 5. Corpus gate

A real corpus can enter cross-observer R5 only when every required session has a `PASS` fidelity certificate at the scope frozen by the study.

## 6. What R4.9 does not claim

R4.9 does not prove equal subjective states, infer semantics, calibrate physiology, or verify any external consciousness channel. Its claim is only protocol identity at an explicitly declared resolution.
