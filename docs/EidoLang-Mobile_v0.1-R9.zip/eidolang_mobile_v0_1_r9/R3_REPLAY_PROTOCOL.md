# R3 practical replay protocol

## 1. Discovery is frozen first

Run R2 and freeze:
- alphabet version;
- grammar version;
- candidate operator/rule IDs;
- target state metrics;
- expected effect direction.

Do not rediscover the operator from the replay outcomes being used to test it.

## 2. Materialize an operator template

Use `ReplayTemplateBuilder.from_rule(...)` or `.from_session(...)`.

The stored template contains normalized strokes and a motor profile. The replay interface may scale it to the screen, but must preserve stroke ordering.

## 3. Construct the control before outcomes

`MatchedControlBuilder.match_rule(...)` searches rule-negative sessions and uses only motor geometry. It never reads `StateObservation` or state deltas.

Freeze the selected control template before causal trials.

## 4. Pre-register trial IDs and assignment seed

Example:

```python
assignment = balanced_random_assignment(
    [f"trial:{i:02d}" for i in range(16)],
    seed=731,
)
```

The seed and complete trial ID list are part of the protocol record.

## 5. Same measurement schedule in both arms

If active probes are used, use the identical schedule. A different schedule invalidates the R3 certificate.

For minimal burden, a first real protocol can use:

```text
pre-state
replay
post-state
```

and a separate localization block with intermediate probes.

## 6. Analyze only pre-registered metrics

Example:

```python
cert = CausalAnalyzer(alpha=0.05).certify(
    trials,
    operator_id="rule:...",
    metric_alternatives={
        "focus": "greater",
        "inner_noise": "less",
    },
)
```

## 7. Interpretation

`passed = true` means causal evidence for the tested physical replay relative to the frozen matched control and measurement protocol.

It does not authorize assigning a symbolic meaning to the drawing beyond that operational statement.
