# R4.5 checkpoint — measured

## Inherited suite

All R1–R4 tests remain green.

## R4.5 tests

```text
T0_COLLISION             PASS
T1_FINAL_COLLISION       PASS
CROSS_OBSERVER_GATE      PASS
NEGATIVE_CONTROL_GATE    PASS
```

Full suite:

```text
Ran 25 tests
OK
```

## Necessity measurement

Synthetic nested and separate constructions deliberately share the same coarse topology:

```text
nested   T0 = (beta0=2, beta1=2, chi=0)
separate T0 = (beta0=2, beta1=2, chi=0)
```

but T1 differs by containment. Therefore T0 is insufficient.

Two constructions with identical final containment topology but opposite outer/inner construction order have:

```text
final T1: equal
T2 temporal signature: different
```

Therefore final relational topology is insufficient when construction history is part of the operator.

## Cross-observer synthetic transport

12 examples / 6 synthetic observers / 2 causal classes.
Leave-one-observer-out:

```text
Geometry accuracy = 10/12 = 0.833333
T0 accuracy       =  6/12 = 0.500000
T1 accuracy       = 12/12 = 1.000000
T2 accuracy       = 12/12 = 1.000000
T2 - Geometry     = 0.166667
negative-control max T2 accuracy = 0.750000
```

Gate:

```text
PASS
```

This is a positive control of the machinery, not evidence that human eidograms have the same invariant.

## Actual article illustration raster probe

The six page-7 examples (`целостность` / `дискретность`, three authors each) were probed only as
published grayscale rasters. At thresholds 64, 96, 128, 160, 192, 224 and 245, **no threshold**
produced one common `(beta0,beta1)` signature for all three examples of each class while separating
the two classes.

Measured conclusion:

```text
single-threshold T0 is not a sufficient cross-author invariant on the published examples
```

This is exactly a negative result: it justifies T1/T2, but does not validate them on the article because
raw stroke history and original eido-medium layers are unavailable in the PDF.
