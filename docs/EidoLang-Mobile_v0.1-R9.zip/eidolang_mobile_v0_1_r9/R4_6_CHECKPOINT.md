# R4.6 checkpoint

Version: `EidoLang-Mobile v0.1-R4.6`

## Implemented

- `multilayer_topology.py`
  - explicit color-state splitting inside strokes;
  - per-color topology;
  - palette-renaming invariant layer signatures;
  - cross-color containment/intersection;
  - containment-chain layer equality motifs;
  - AUDIO/HAPTIC interval topology;
  - media↔form topological incidence;
  - `T3` descriptor.
- `multilayer_discovery.py`
  - leave-one-observer-out T2→T3 representation gate;
  - destructive observer-wise label controls.
- `r46_synthetic.py`
  - three necessity counterexamples;
  - cross-observer positive control.
- smartphone web capture
  - COLOR events;
  - explicit HAPTIC events;
  - explicit AUDIO events;
  - protocol `0.1-R4.6`.
- CLI
  - `eidolang multilayer session.json`
  - `eidolang r46-synthetic`

## Measured inherited + R4.6 tests

```text
Ran 31 tests
OK
```

## Necessity measurements

### Form-only collision

```text
T2_equal              true
T3_equal              false
split_color_layers    2
unified_color_layers  1
```

### Media incidence collision

```text
T2_equal          true
early coupling    HAPTIC|dB0+
closure coupling  HAPTIC|dB1+
T3_equal          false
```

### Aggregate multilayer collision

```text
T2_equal                         true
color_layer_count_equal          true
anonymous_layer_multiset_equal   true
color_switches_equal             true
cross_color_containment_equal    true
nesting patterns equal           false
T3_equal                         false
```

Observed pattern examples in the synthetic counterexample:

```text
A: [AAB, ABC]
B: [ABA, ABC]
```

## Cross-observer synthetic control

12 examples / 6 observers / 2 external causal classes:

```text
Geometry  6/12  = 0.500000
T2        6/12  = 0.500000
T3       12/12  = 1.000000

T3 - T2                  = +0.500000
max negative-control T3  = 0.833333
Gate                     = PASS
```

This is a positive control of the algorithm, not evidence about real subjects.

## Status

R4.6 is mechanically closed for the implemented channel set:

```text
FORM + COLOR + AUDIO + HAPTIC
```

No new modality is admitted without an observed representation counterexample.
