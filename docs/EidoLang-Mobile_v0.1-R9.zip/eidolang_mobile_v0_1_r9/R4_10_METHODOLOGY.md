# R4.10 — Observer-State Measurement Reliability Gate

## Necessity

All earlier causal/equivalence statements use an observed state vector:

\[
o_t = R(m_t).
\]

Without repeatability of \(R\), statements about small changes in \(o\) can be artifacts of
the measurement channel.

R4.10 therefore estimates **repeatability of the whole protocol-to-observation channel**,
not a fictional pure sensor-noise term.

Repeated responses to the same anchor contain at least:

\[
\text{true state variability}
+
\text{protocol variability}
+
\text{self-report / measurement variability}.
\]

Without an additional model these components are not identifiable separately.

## Frozen reliability manifest

Before reliability analysis we freeze:
- observers;
- calibration anchors;
- required state metrics;
- repeats per anchor;
- repeatability confidence level;
- drift-test alpha;
- maximum admissible repeatability radius per metric;
- quantization floor;
- pairing rule.

R4.10 admits only:
- `ADJACENT_DISJOINT` repeat pairing;
- `FAIL_WHOLE_GATE` for unreliable required metrics.

This avoids choosing convenient pairs or dropping inconvenient state coordinates post hoc.

## Disjoint repeat discrepancies

For each observer/anchor:

\[
(o_0,o_1),(o_2,o_3),\ldots
\]

are paired without reuse.

For metric \(j\):

\[
d_k^{(j)}
=
\Delta o_{b,k}^{(j)}
-
\Delta o_{a,k}^{(j)}.
\]

The absolute discrepancies are:

\[
e_k^{(j)}=|d_k^{(j)}|.
\]

## Distribution-free finite-sample radius

Given \(n\) disjoint discrepancies and error level \(\alpha\),

\[
k=\lceil(n+1)(1-\alpha)\rceil.
\]

If \(k>n\), the requested finite-sample guarantee cannot be formed and the metric is:

\[
\boxed{UNRESOLVED}.
\]

Otherwise:

\[
r_j=e_{(k)}
\]

where \(e_{(k)}\) is the \(k\)-th order statistic.

This is used as an empirical finite-sample repeatability radius for a future exchangeable
repeat discrepancy.

Important consequence:

For \(\alpha=0.05\), at least 19 independent/disjoint repeat pairs are needed even to obtain
a finite bound. The code refuses to replace this with an asymptotic approximation.

## Quantization floor

If the UI/state scale has resolution \(q_j\),

\[
r_j^{eff}=\max(r_j,q_j).
\]

A channel is never claimed to resolve below its actual encoding precision.

## Repeat-order drift

Repeatability also fails if the second member of a pair systematically differs from the first.

For signed discrepancies \(d_k\), R4.10 applies an exact two-sided sign test:

\[
H_0:P(d>0)=1/2.
\]

A significant sign imbalance at the frozen `alpha_drift` marks the metric `FAIL`.

This detects simple habituation/learning/order drift without fitting a temporal model.

## Gate

Metric \(j\) passes only if:
1. the finite-sample radius is identifiable;
2. no repeat-order drift is detected;
3. \(r_j^{eff}\le r_j^{max}\).

Every required metric must pass for every observer.

The common empirical resolution floor is:

\[
r_j^{common}=\max_i r_{ij}^{eff}.
\]

## Propagation into R4 equivalence

An equivalence margin finer than the measured repeatability floor is forbidden:

\[
\epsilon_j < r_j^{common}
\quad\Rightarrow\quad
\boxed{INVALID}.
\]

This does **not** say that a mean causal effect smaller than one-trial repeatability can never
be detected: repeated randomized trials may estimate a mean more precisely. It only forbids
claiming operational equivalence at a resolution finer than the measurement channel without
introducing and validating an explicit measurement-error model.

## Dynamic range

R4.10 also reports:

\[
\frac{\text{anchor response dynamic range}}{r_j^{eff}}.
\]

This is descriptive in R4.10 and not a hidden acceptance threshold. Rank/informativeness is
still tested independently in R4.7.

## Scope

R4.10 does not validate:
- the ontology of `focus`, `noise`, etc.;
- latent consciousness coordinates;
- physiological mechanisms;
- external-signal hypotheses.

It validates only whether the frozen observed coordinates are repeatable enough to support
the declared operational resolution.
