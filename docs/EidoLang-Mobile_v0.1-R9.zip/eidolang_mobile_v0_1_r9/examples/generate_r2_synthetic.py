"""Generate deterministic synthetic corpora used to sanity-check R2 discovery."""
from pathlib import Path
import json

SHAPES={
    'A':[(0.10,0.85),(0.50,0.15),(0.90,0.85)],
    'B':[(0.15,0.10),(0.15,0.90),(0.85,0.90)],
    'C':[(0.10,0.50),(0.50,0.50),(0.90,0.50)],
    'D':[(0.10,0.10),(0.50,0.90),(0.90,0.10)],
}

def raw_for(shapes):
    out=[]; t=0
    for name in shapes:
        pts=SHAPES[name]
        out += [
            {'type':'START','t_us':t,'pointer_id':0,'x':pts[0][0],'y':pts[0][1]},
            {'type':'MOVE','t_us':t+100000,'pointer_id':0,'x':pts[1][0],'y':pts[1][1]},
            {'type':'END','t_us':t+200000,'pointer_id':0,'x':pts[2][0],'y':pts[2][1]},
        ]
        t += 350000
    return out

def session(sid,shapes,delta):
    return {
        'session_id':sid,'protocol_version':'0.1-R2','mode':'TRANSFORM','recommendation_mode':'NONE',
        'started_at':'','raw_events':raw_for(shapes),
        'state_observations':[
            {'t_us':0,'metrics':{'focus':0.0,'noise':0.0}},
            {'t_us':10_000_000,'metrics':{'focus':delta,'noise':-delta}},
        ],
        'target_state':{'focus':1.0,'noise':-1.0}
    }

def write_group(root,name,items):
    d=root/name; d.mkdir(parents=True,exist_ok=True)
    for x in items:
        (d/f"{x['session_id']}.json").write_text(json.dumps(x,indent=2),encoding='utf-8')

if __name__=='__main__':
    root=Path(__file__).with_name('r2_synthetic')
    alphabet=[]
    for i in range(18): alphabet.append(session(f'A{i:02d}',['A'],0.8))
    for i in range(18): alphabet.append(session(f'B{i:02d}',['B'],0.8))
    for i in range(18): alphabet.append(session(f'C{i:02d}',['C'],-0.8))
    grammar=[]
    for i in range(30): grammar.append(session(f'pos{i:02d}',['A','C'],0.9))
    for i in range(30): grammar.append(session(f'neg{i:02d}',['D','C'],-0.9))
    write_group(root,'alphabet',alphabet); write_group(root,'grammar',grammar)
    print(root)
