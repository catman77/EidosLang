# R9 checkpoint

Status: IMPLEMENTED / SYNTHETIC ADEQUACY + FORCED-RESIDUAL CONTROLS

New gate:
- exact raw intervention-program identity;
- whole-current-grammar incidence address;
- complete raw causal disposition registry;
- complete substitution registry for every causal-PASS same-address pair;
- collision and unrepresented witnesses;
- explicit future-grammar separation obligations;
- R9 gate blocks R8/R7/R5 unless all confirmation observers PASS.

No new grammar feature is admitted in R9.

Expected controls:
1. Existing R8 synthetic source: PASS (nine supported raw programs, each represented by a
   distinct current grammar address).
2. Quantization collision: INADEQUATE with one same-address causal collision witness.
3. Causal raw program omitted by OperatorMiner: INADEQUATE / UNREPRESENTED.
4. Missing mandatory same-address pair disposition: INVALID.
5. Mandatory pair UNRESOLVED: UNRESOLVED.
