# EidoLang-Mobile v0.1-R2 checkpoint

## Implemented

- deterministic train/holdout split by session id;
- `AlphabetInducer`: effect-equivalence quotient over raw stroke signatures;
- holdout non-inferiority merge gate;
- exclusive-support identifiability gate for candidate substitutions;
- predictive-vs-global-baseline symbol admission;
- `EffectGrammarInducer`: context-vs-suffix semantic grammar;
- deterministic label-permutation negative controls;
- `LanguageDiscovery` end-to-end pipeline;
- CLI `discover` command;
- R2 tests and synthetic measured controls.

## Measured positive controls

### Alphabet benchmark

Synthetic corpus: 54 sessions. Two geometrically distinct strokes were assigned the same state-transition law;
a third stroke had the opposite law.

Measured:

```text
symbols                         2
observed holdout gain           21.5488
max of 16 permuted-label gains   2.469244602549109
negative-control gate            PASS
```

The positive symbol contains two distinct raw shape signatures while preserving the same transition effect.

### Grammar benchmark

Synthetic corpus: 60 sessions. The same terminal stroke/relation was preceded by one of two different first
symbols, and the first symbol determined the session transition.

Measured:

```text
rules                           4
observed holdout gain           48.768
max of 16 permuted-label gains   8.768933868674715
negative-control gate            PASS
```

The discovered rules beat their own suffix baseline on holdout.

## New no-go discovered in R2

If token A is always observed together with token B, session-level outcomes cannot identify whether A and B are
substitutable. Equal effects are then compatible with arbitrary causal roles. Therefore R2 forbids `A ~ B` unless
both train and holdout contain evidence from:

```text
A without B
B without A
```

This is the `exclusive-support` gate.

## Epistemic status

R2 establishes out-of-sample predictive structure only. Because `StateObservation` is currently measured at the
session level, R2 does **not** infer that an individual stroke causes the transition. A causal operator requires a
later replay/intervention layer.

## Next forced stage: R3

R3 should not add more primitives. It should close the causal gap:

1. intermediate state probes inside a session;
2. replay of discovered macro-operators;
3. matched null/sham trajectories preserving motor effort and duration;
4. counterbalanced operator order;
5. operator-specific transition model versus replay controls;
6. only then: `MacroName = operator-equivalence class` on independent replay trials.

A secondary R3 branch can begin the multimodal latent bridge only after the operator replay gate is available,
otherwise the LLM may manufacture apparent language structure that has not been shown to transform state.
