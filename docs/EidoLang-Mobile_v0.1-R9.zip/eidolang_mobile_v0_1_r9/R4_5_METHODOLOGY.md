# R4.5 — Topological Motif Discovery

## Цель

R4 доказал причинную взаимозаменяемость операторов **внутри заданного наблюдателя/домена**.
Следующая проблема — перенос представления между наблюдателями. Иллюстрации исходной статьи
дают прямой контрпример к требованию геометрической идентичности: разные авторы разворачивают
один и тот же предмет в сильно различающиеся изображения.

R4.5 не объявляет топологию «смыслом». Он проверяет более слабое утверждение:

```text
может ли топологический quotient переносить уже сертифицированный causal class
лучше, чем текущая геометрическая сигнатура?
```

## Necessity ladder

### T0 — минимальный топологический quotient

```text
T0 = (beta0, beta1, Euler characteristic)
```

Это первая допустимая абстракция, поскольку она устраняет метрическую форму, но сохраняет
связность и циклы.

### Counterexample T0

Две замкнутые фигуры могут иметь одинаковые `(beta0,beta1)` как при вложении, так и при
пространственном разделении. Следовательно T0 не сохраняет отношение организации.

### T1 — relational topology

Добавляются только отношения, необходимые данным контрпримером:

- attachment к границам поля;
- spanning components;
- число замкнутых strokes;
- containment graph;
- глубина вложенности;
- пересечения замкнутых strokes;
- disjoint closed pairs.

T1 не содержит семантических ярлыков форм.

### Counterexample T1

Одинаковый конечный комплекс может быть построен в разном порядке. Если язык процессуален,
финальная топология недостаточна.

### T2 — temporal topology

Для каждого префикса физических strokes строится T1 snapshot:

```text
K1 -> K2 -> ... -> Kn
```

и сохраняются события рождения/слияния компонент, рождения/исчезновения циклов,
возникновения containment/intersection/boundary-spanning отношений.

R4.5 пока использует additive stroke-prefix filtration. Полноценная zigzag persistence станет
необходимой только после введения локального erase/delete события в raw protocol.

## Digital topology convention

Raster T0 использует согласованную пару:

```text
foreground connectivity = 8
background connectivity = 4
```

чтобы диагональный контакт не создавал цифровой парадокс связности. Параметры входят в
`TopologyConfig` и являются частью версии протокола.

## Cross-observer gate

Класс `causal_class` **не выводится TDA-модулем**. Он должен приходить извне из R4
causal/substitution certificates.

Оценка выполняется leave-one-observer-out:

```text
train observers != held-out observer
predict causal class of held-out eidogram
```

Сравниваются:

```text
Geometry  : текущая sequence of exact technical tokens
T0        : Betti/Euler
T1        : final relational topology
T2        : T1 + temporal topological event program
```

Topological quotient допускается как новый representation layer только если:

```text
Accuracy(T2) - Accuracy(Geometry) >= declared minimum gain
```

и реальный T2 превосходит deterministic label-destruction controls.

## Что R4.5 НЕ доказывает

- что один topology motif имеет один смысл;
- что topology причиняет изменение состояния;
- что иллюстрации статьи сами по себе статистически доказывают общий язык;
- что Betti numbers достаточны;
- что topology универсальна между людьми.

Она лишь вводит проверяемый quotient-кандидат между индивидуальной геометрией и R5 transport.
