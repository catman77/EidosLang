# R3 checkpoint

## Implemented

- replay/control arm types;
- replay templates from real session trajectories;
- low-level motor profiles;
- outcome-blind matched-control selection;
- balanced pre-registered assignment;
- intermediate state probes;
- design validation;
- exact randomization inference;
- no approximate fallback when exact enumeration exceeds configured cap;
- multi-metric causal certificate;
- synthetic positive and null controls;
- probe-schedule mismatch negative test;
- non-randomized-trial negative test.

## Measured positive control

Synthetic 16-trial replay experiment, 8/8 balanced arms:

```text
focus:
  operator mean delta = +0.453
  control mean delta  = +0.020
  ATE                 = +0.433
  exact allocations   = 12,870
  exact p             = 7.77000777000777e-05

noise:
  operator mean delta = -0.453
  control mean delta  = -0.020
  ATE                 = -0.433
  exact p             = 7.77000777000777e-05

certificate = PASS
```

Intermediate focus contrast:

```text
phase 1: +0.141
phase 2: +0.307
```

The null synthetic control does not certify.

## New no-go

`causal(w1)` and `causal(w2)` do not imply `w1 ≡ w2`.
Causal `MacroName` therefore remains closed until direct substitution equivalence is tested.

## Next forced gate: R4

Randomized substitution equivalence:

```text
same pre-state domain
w1 vs w2
pre-registered equivalence margin
endpoint + trajectory/side-effect comparison
```

Only then can several physical realizations be collapsed into one causal Name.
