# R4.8 — Real Corpus Acquisition Gate

## Цель

R4.8 не ищет новый признак. Он закрывает возможность постфактум выбрать:
- fit/holdout anchors;
- состояние/метрики;
- версию топологического представления;
- subset причинных классов;
- cross-observer evaluation policy;
- удобные сессии после просмотра результата.

До прохождения R4.8 реальные данные не лицензируют R5.

## Двухфазная фиксация

### Phase A — AcquisitionManifest

До первой сессии фиксируются:

- `study_id`;
- физические anchor-протоколы;
- число повторов;
- state proxy coordinates;
- число fit anchors;
- `split_seed`;
- exclusion rules;
- topology representation/version;
- transport family;
- causal label policy;
- cross-observer policy.

Манифест канонизируется и получает:

\[
H_P = SHA256(CanonicalJSON(P)).
\]

Коллектор хранит только public view, где отсутствует принадлежность anchors к fit/holdout.

### Deterministic hidden split

Для anchor \(a\):

\[
r(a)=SHA256(seed || a).
\]

Anchors сортируются по `r(a)`. Первые `n_fit` становятся fit, остальные holdout.
Следовательно split нельзя переопределить после данных без изменения `protocol_hash`.

### Deterministic per-observer schedule

Порядок anchor trials для observer \(i\):

\[
r_i(a,k)=SHA256(H_P || observer_i || a || repeat_k).
\]

Это устраняет ручной выбор порядка во время сбора.

## Session admission

Anchor session принимается только если одновременно:

- `study_id` совпадает;
- `protocol_hash` совпадает;
- observer совпадает;
- anchor объявлен;
- schedule index/repeat совпадает;
- recommendation mode соответствует протоколу;
- target отсутствует, если он запрещён;
- pre/post state имеют **ровно** замороженные metric keys;
- post следует после pre.

Failure не удаляется молча: он должен либо остаться raw session, либо попасть в frozen exclusion list с причиной.

## Tamper-evident ledger

Каждая сессия получает:

\[
h_s=SHA256(session)
\]

и chain entry:

\[
h_n=SHA256(n, h_s, h_{n-1}, H_P).
\]

После завершения acquisition последний hash является `data_root`.

Изменение любой предыдущей сессии ломает цепь.

### Ограничение

Локальный hash-chain доказывает **внутреннюю неизменность после известного commit**, но сам по себе не доказывает время создания. Для независимого доказательства времени `protocol_hash`/`freeze_hash` должен быть опубликован во внешнем timestamped/append-only канале. R4.8 хранит `external_commit_ref`, но не выдумывает такой канал.

## Phase B — DataFreezeCertificate

До cross-observer evaluation фиксируются:

- `data_root`;
- длина ledger;
- enrolled observers;
- все exclusions и причины.

Получается:

\[
H_D=SHA256(DataFreezeCertificate).
\]

## Phase C — EvaluationManifest

После within-observer R4, но **до** cross-observer topology/effect analysis, фиксируются:

- frozen dataset hash;
- deterministic fit/holdout split;
- T3 extractor version;
- все causal classes, прошедшие R4 на cutoff;
- included causal classes;
- evaluator version.

Если policy = `ALL_R4_PASSING_AT_CUTOFF`, то

\[
Included = Eligible
\]

обязательно. Cherry-picking causal labels запрещён.

## Real-data admission theorem

R5 разрешён только если существуют три согласованных объекта:

\[
AcquisitionManifest
\rightarrow
DataFreezeCertificate
\rightarrow
EvaluationManifest
\]

и все cross-references/hash gates проходят.

Это не доказывает эффект. Это доказывает только, что следующий тест не определяется результатом, который он должен оценивать.

## Что R4.8 НЕ делает

- не назначает anchor semantics;
- не предлагает фармакологические/дыхательные воздействия;
- не объявляет self-report истинным пространством сознания;
- не подтверждает T3;
- не подтверждает causal MacroName;
- не создаёт общий язык.

Он только лицензирует честное получение данных для этих вопросов.
