# R7 checkpoint

Status: IMPLEMENTED / SYNTHETIC BLINDED-SELECTION DRY RUN

Primary R5 metrics remain sealed during class instantiation:
- `focus`
- `noise`

Selector metrics are mechanically derived as the complement in the frozen state schema:
- `activation`
- `clarity`
- `imagery`
- `valence`

## New no-go discovered during R7

The full 6D R4.7 similarity transform cannot in general be projected to the selector subspace:
an orthogonal rotation may mix primary and selector coordinates.

A direct projection attempt in the synthetic full-space transport produced selector holdout
RMSE around 0.24–0.30 against the frozen 0.02 margin and failed.

Therefore R7 requires a separate selector-only R4.7 calibration `Psi_i`, fitted and validated
using only the four selector coordinates. In the final synthetic positive control:

- discovery selector alignment: PASS for all 6 observers;
- confirmation selector alignment: PASS for all 6 observers;
- every non-reference exact anchor-permutation p = 1/720 = 0.0013888889.

No primary coordinate enters that alignment.

## Frozen instantiation rule

- prototype method: `DISCOVERY_ALIGNED_MEAN`;
- cost envelope: maximum discovery leave-one-observer-out correct assignment cost;
- distance: R4.10-normalized Euclidean;
- ambiguity threshold: exactly one R4.10 resolution unit;
- discovery rule may freeze only if every LOO wrong-minus-correct assignment gap is >= 1;
- selection: `EXACT_INJECTIVE_MIN_COST_V1`.

## Confirmation positive control

Each confirmation observer has 3 eligible R4 MacroNames:
- true H0 realization;
- true H1 realization;
- one distractor.

Total candidates: 18.
Blind selector chooses exactly 12 true MacroNames and rejects all 6 distractors.

For every confirmation observer:
- instantiation status: PASS;
- best assignment cost approximately numerical zero;
- second-best cost approximately 52.4404 repeatability-normalized units;
- assignment gap approximately 52.4404 > 1.

Only after the instantiation certificate is produced are primary R5 objects unsealed.

Primary confirmation R5 remains:
- S = 0.7508845597283931;
- exact conventions = 32;
- p = 1/32 = 0.03125;
- PASS.

Final:
- R6: PASS;
- R7: PASS;
- R7 certificate id: `r7:caa79bf6b9832c33`;
- R7 certificate hash: `c792127798add8ac3a3c172dc4a789c0d16824fb56ea997e962ca1e9ab853def`.

Negative controls:
- primary metric inserted into selector record -> INVALID;
- selector/primary causal-certificate reuse -> rejected before R5;
- ambiguous candidate profiles -> AMBIGUOUS/NO_MATCH;
- supplied primary MacroName set differing from blind selection -> rejected;
- distractor MacroNames are not silently selected.

Full regression suite: 99 tests, PASS.

Epistemic status:
synthetic/software validation only; no real cross-observer invariant is claimed.
