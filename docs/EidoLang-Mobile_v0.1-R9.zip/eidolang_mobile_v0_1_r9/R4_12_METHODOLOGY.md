# R4.12 — Executable Preregistration / Protocol Compiler

## 1. Necessity

R4.8–R4.11 froze individual stages, but the system still allowed a human to instantiate
older modules with mutually inconsistent parameters.

A confirmatory experiment therefore needs one root object:

\[
M=\texttt{MasterStudyManifest}
\]

and a deterministic compiler:

\[
C(M)=
(
P_{R3},P_{R4},P_{R4.7},P_{R4.8},P_{R4.9},P_{R4.10},P_{R4.11}
).
\]

No confirmatory parameter is manually re-entered after compilation.

The root hash is:

\[
H_M=SHA256(CanonicalJSON(M)).
\]

All child manifests/policies and their hashes are included in one `runtime_lock_hash`.

---

## 2. Cross-stage contradiction discovered

The previous standalone R4.11 example contained:

\[
N_{R3,operators}=2
\]

and simultaneously an R4 MacroName of:

\[
3\text{ distinct operator realizations}.
\]

For a binary R5, however, at least two distinct causal classes are needed.

If each cross-observer class is represented by an R4 MacroName containing three
distinct causal realizations, then the confirmatory dependency is:

\[
N_{R3,operators}
\ge
N_{classes}\times N_{realizations/class}
=
2\times3
=
6.
\]

R4.12 therefore compiles six R3 operator hypotheses per observer.

This is not a new heuristic. It follows from the already frozen object graph:

\[
R3\ operator
\rightarrow
R4\ MacroName
\rightarrow
R5\ binary\ class.
\]

---

## 3. Multiplicity correction propagates backwards

With:
- 2 causal classes;
- 3 realizations/class;
- 2 primary endpoint metrics,

R3 has:

\[
6\times2=12
\]

confirmatory claims.

Therefore:

\[
\alpha_{R3}^{local}
=
{0.05\over12}
=
0.004166\overline6.
\]

The compiler—not the caller—sets `CausalAnalyzer.alpha`.

At 10 balanced trials/operator:

\[
{10\choose5}=252,
\qquad
p_{min}=1/252=0.00396825,
\]

so exact resolution is barely sufficient.

---

For R4, each class requires:

\[
{3\choose2}=3
\]

pair certificates.

For two classes:

\[
P_{total}=6.
\]

Therefore each pair receives:

\[
\alpha_{pair}
=
{0.05\over6}
=
0.008333\overline3.
\]

Inside each pair there are:
- 2 endpoints;
- 2 trajectory metrics × 2 phases,

hence six checks:

\[
\alpha_{boundary}
=
{0.0083333\over6}
=
0.00138889.
\]

At 6 trials/arm:

\[
{12\choose6}=924,
\qquad
1/924=0.00108225,
\]

so the exact test remains feasible.

This corrects the earlier pair-alpha \(0.0166667\), which accounted for one MacroName
but not for both R5 causal classes.

---

## 4. Compiler outputs

`ProtocolCompiler` deterministically emits:

- `AcquisitionManifest` for alignment anchors;
- deterministic fit/holdout split;
- `ReliabilityManifest`;
- all R4.9 `AnchorExecutionPlan`s;
- `CompiledR3Policy`;
- `CompiledR4Policy`;
- R4.7 `AlignmentConfig`;
- corrected R4.11 `FeasibilityReport`;
- session budget;
- child hashes;
- `runtime_lock_hash`.

Changing any root field changes the root hash and the lock.

---

## 5. Real vs dry-run anchors

R4.12 does not invent real experimental anchors.

`MasterAnchorSpec` is explicit input.

`mode=REAL` rejects anchors marked `synthetic_only` and obvious placeholder instructions.

The shipped default corpus is therefore:

\[
\boxed{DRY\_RUN}
\]

and cannot be mistaken for a real preregistration.

This preserves the project rule that new experimental content is not silently introduced
as a hand-crafted semantic ontology.

---

## 6. Confirmatory runtime

Legacy constructors remain available for:
- unit tests;
- exploratory analysis;
- backward compatibility.

But confirmatory evidence must be created through:

\[
\texttt{ConfirmatoryRuntime(bundle)}.
\]

It provides only compiler-derived:
- `CausalAnalyzer`;
- `SubstitutionPolicy`;
- `CrossObserverEffectAligner`.

A manually instantiated analyzer with, for example:

\[
\alpha=0.05
\]

is rejected against the compiled lock.

Every confirmatory evidence item can be wrapped in an envelope containing:

\[
(H_M,H_{runtime},H_{bundle}).
\]

Thus provenance becomes machine-checkable.

---

## 7. Corrected conservative session lower bound

The previous R4.11 number 282 counted only:
- alignment;
- marginal repeatability.

R4.12 propagates the full binary-class dependency.

Per observer:

### Alignment
\[
6\ fit+3\ holdout=9.
\]

### Reliability
\[
19\ pairs\times2=38.
\]

### R3
\[
6\ operators\times10=60.
\]

### R4
Two classes, each with 3 pair certificates:

\[
2\times {3\choose2}\times12
=
72.
\]

Therefore:

\[
9+38+60+72=179
\]

confirmatory sessions/observer before discovery.

For six observers:

\[
\boxed{179\times6=1074}.
\]

This still excludes:
- free discovery sessions;
- failed retained sessions;
- any extra trials required for power.

It is therefore a **combinatorial lower bound**, not a recommended final sample size.

---

## 8. End-to-end dry run

R4.12 includes one compiled synthetic dry run that uses the *same locked policies* for:

- compilation / feasibility;
- runtime tamper rejection;
- six R3 causal realizations;
- two R4 three-realization all-pairs MacroNames;
- 6D R4.7 observer alignment;
- R4.10 repeatability and R4-margin compatibility;
- R4.9 execution fidelity;
- R4.11 exact arithmetic.

A PASS here proves software compatibility of the chain only.

It is not experimental evidence.
