# R7 — Prospective Class Instantiation / Blinded Matching

## 1. Remaining selection leak

R6 separates discovery and confirmation observers, but confirmation can still leak if it:

1. discovers several local R4 MacroNames;
2. computes T3/effect transport for all subsets;
3. retains the pair producing the best R5.

Then the exact R5 p-value again omits class-selection cost.

R7 therefore requires that confirmation classes be chosen **before the primary R5 data are opened**.

---

## 2. A selector cannot use either half of R5

The primary R5 statistic is built from:

\[
T3
\quad\text{and}\quad
M_P=\{\text{primary effect metrics}\}.
\]

Therefore a matching rule based on T3 would preselect the topological answer, while a rule
based on \(M_P\) would preselect the causal-effect answer.

Both are forbidden.

The existing frozen state vector already contains more dimensions than \(M_P\). R7 uses:

\[
M_S=M_{\rm state}\setminus M_P.
\]

Hence:

\[
\boxed{M_S\cap M_P=\varnothing}.
\]

For the current compiled schema:

\[
M_P=\{\text{focus},\text{noise}\},
\]

\[
M_S=
\{\text{activation},\text{valence},\text{clarity},\text{imagery}\}.
\]

No new sensor or hand-crafted semantic feature is introduced.

---

## 3. Independent selector trials

Each candidate confirmation MacroName has independent selector-effect estimates:

\[
z_{ik}\in M_S.
\]

Their certificate refs must be disjoint from the R3 causal certificate refs used by primary R5.

The blind instantiator never receives:
- T3 realization sessions;
- primary effect coordinates;
- R5 statistic.

Its input type exposes only:

\[
(observer,\ MacroName,\ selector\_effects,\ selector\_certificate\_refs).
\]

This is a structural blindness guarantee, not an instruction to an analyst.

---

## 4. Selector alignment must itself be blinded

A subtle no-go appears here. The full R4.7 transform

\[
\Phi_i:\mathbb R^6\to\mathbb R^6
\]

is an arbitrary zero-origin similarity and may rotate primary and selector coordinates into
one another. Therefore, in general,

\[
P_S\Phi_i(x)
\]

cannot be computed from the selector projection \(P_Sx\) alone. Using the full vector to
apply \(\Phi_i\) would reopen the sealed primary coordinates.

Hence R7 does **not** project the primary R4.7 transform. It fits a second, independently
validated alignment only on the selector subspace:

\[
\Psi_i:M_S\to M_S.
\]

It uses the same frozen anchor identities/split, but the aligner receives only selector
coordinates. It must independently pass:

- rank identifiability in \(M_S\);
- holdout RMSE;
- exact anchor-permutation test.

If selector-only alignment fails, R7 is blocked. There is no fallback to the full \(\Phi_i\).

This is not a new sensor channel; it is a separate calibration of a disjoint projection of
the already frozen observation vector.

---

## 5. Discovery-frozen selector prototypes

Discovery is allowed to formulate the hypothesis.

For each frozen class \(H_c\), after selector-only alignment \(\Psi_i\):

\[
\mu_c
=
{1\over |O_D|}
\sum_{i\in O_D}
\bar z_{ic}.
\]

These are frozen as `SelectorPrototype`s.

Distances use only R4.10 resolution floors:

\[
d(z,\mu_c)
=
\sqrt{
\sum_{m\in M_S}
\left(
{z_m-\mu_{c,m}\over r_m^{common}}
\right)^2
}.
\]

No metric is learned in confirmation.

---

## 6. Acceptance radius and ambiguity scale

R7 does not invent a convenient confirmation cutoff.

For every discovery observer \(i\), prototypes are rebuilt leaving \(i\) out.

Let:

\[
C_i^{correct}
\]

be the total selector cost of the known discovery class correspondence, and

\[
C_i^{wrong}
\]

the swapped correspondence.

The discovery envelope fixes the admissible total cost:

\[
C_{\max}
=
\max_i C_i^{correct}.
\]

The ambiguity threshold is **not** taken from the magnitude of discovery separation; doing so
would make an unusually easy discovery corpus arbitrarily strict for confirmation.

Because every selector coordinate is already divided by its R4.10 repeatability radius,
one unit has an operational meaning: one measured resolution unit. R7 therefore freezes

\[
G_{\min}=1.
\]

and permits freezing only if every discovery leave-one-out wrong assignment satisfies

\[
C_i^{wrong}-C_i^{correct}\ge 1.
\]

Thus the selector must be identifiable in discovery at at least one independently measured
resolution unit, while confirmation is not required to reproduce the full numerical discovery gap.

---

## 7. Prospective confirmation assignment

Suppose observer \(j\) has eligible R4 MacroNames:

\[
M_1,\ldots,M_q.
\]

R7 enumerates every injective assignment of the two frozen classes into distinct candidates:

\[
f:\{H_0,H_1\}\hookrightarrow\{M_1,\ldots,M_q\}.
\]

For each:

\[
C(f)=
d(M_{f(H_0)},\mu_0)
+
d(M_{f(H_1)},\mu_1).
\]

Let best and second-best costs be:

\[
C_1\le C_2.
\]

PASS requires both:

\[
C_1\le C_{\max}
\]

and

\[
C_2-C_1\ge G_{\min}.
\]

Otherwise:

\[
\boxed{NO\_MATCH}
\]

or:

\[
\boxed{AMBIGUOUS}.
\]

No fallback to "take the closest pair anyway" exists.

---

## 8. Confirmation R5 is opened only after class selection

The instantiation certificate contains only selected MacroName IDs:

\[
(observer,H_c,MacroName).
\]

Only then does R7 open the primary confirmation objects and require:

\[
SelectedMacroNames
=
SuppliedR5MacroNames.
\]

It additionally requires:

\[
SelectorCertRefs
\cap
PrimaryR3CertRefs
=
\varnothing.
\]

Any mismatch is `INVALID`.

Thus the data flow is:

\[
\boxed{
Discovery
\to
FrozenInstantiationRule
\to
SelectorOnlyConfirmation
\to
InstantiationCertificate
\to
UnsealPrimaryR5
\to
R6/R5.
}
\]

---

## 9. Interpretation

R7 PASS means:

> the discovery-defined classes were prospectively instantiated on each independent
> confirmation observer using information disjoint from the primary T3/effect statistic,
> and the resulting frozen class set independently passed R6/R5.

This closes the confirmation class-subset selection channel.

It still does not imply that the frozen state coordinates are a universal ontology of meaning.
