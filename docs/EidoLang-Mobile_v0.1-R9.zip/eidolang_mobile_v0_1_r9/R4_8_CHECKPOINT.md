# R4.8 checkpoint

Status: IMPLEMENTED / SYNTHETIC INTEGRITY TESTS ONLY

Implemented:
- canonical JSON + SHA-256 protocol commitment;
- deterministic anchor fit/holdout split;
- public collection manifest without split labels;
- deterministic per-observer anchor schedule;
- exact session admission gate;
- tamper-evident acquisition ledger;
- dataset freeze certificate;
- second-stage evaluation manifest;
- prohibition on post-hoc causal-label subsets;
- frozen T3/effect-alignment/cross-observer policies.

Epistemic status:
- no real participant corpus is included;
- no physiological/psychological effect is claimed;
- local hashes are not trusted timestamps without external commitment;
- R5 remains blocked until a real frozen corpus exists.
