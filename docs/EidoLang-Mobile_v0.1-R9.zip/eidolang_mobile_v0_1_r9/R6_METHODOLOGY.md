# R6 — Discovery / Confirmation Separation

## 1. Necessity

R5 exactness is conditional on the tested transport hypothesis already being fixed.

If the same observers are used both to discover the two causal classes/T3 motif and to evaluate the final exact R5 statistic, then the reported R5 p-value does not include the selection cost of choosing the object being tested.

Therefore:

\[
p_{R5}\text{ exact}\mid H\text{ fixed}
\]

does not imply:

\[
p_{R5}\text{ exact after data-dependent discovery of }H.
\]

R6 closes this leak by requiring physically disjoint observer cohorts.

## 2. Frozen cohort split

Before outcomes:

\[
O=O_D\sqcup O_C,
\qquad O_D\cap O_C=\varnothing.
\]

Membership is derived only from:

\[
rank(i)=SHA256(H_{root}\Vert seed\Vert observer_i).
\]

No manual reassignment is permitted after data exist.

R6 v1 requires at least six confirmation observers because the frozen binary R5 exact null has:

\[
2^{6-1}=32,
\]

hence:

\[
p_{min}=1/32=0.03125<0.05.
\]

## 3. Discovery may discover; confirmation may only test

The discovery cohort may run the whole ladder:

\[
R1\to R2\to R3\to R4\to R4.5\to R4.6\to R5.
\]

Its output is not the final confirmatory evidence. It freezes a `FrozenTransportHypothesis` containing only:

- binary causal-class count;
- realizations per class;
- T3 representation and extractor version;
- R5 primary statistic version;
- primary effect metric set;
- exhaustive frozen class-selection rule;
- discovery evidence references.

The only admitted discovery selection rule in R6 v1 is:

```text
ALL_DISCOVERY_CLASSES_PASSING_FROZEN_R4_CUTOFF
```

rather than selecting the visually best pair after inspection.

## 4. What is allowed to cross the boundary

Only the hashed hypothesis specification crosses from discovery to confirmation.

The following may not cross:

- raw discovery topology sessions;
- discovery R3 causal certificates;
- discovery R4 substitution certificates;
- discovery MacroName objects;
- discovery observer IDs as confirmation identities;
- discovery-fitted confirmation alignment transforms.

Confirmation must instantiate fresh local causal classes from fresh data.

## 5. Leakage audit

R6 returns `INVALID` if any of the following occur:

\[
O_D\cap O_C\ne\varnothing,
\]

\[
Sessions_D\cap Sessions_C\ne\varnothing,
\]

\[
R3Refs_D\cap R3Refs_C\ne\varnothing,
\]

\[
R4Refs_D\cap R4Refs_C\ne\varnothing,
\]

\[
MacroNames_D\cap MacroNames_C\ne\varnothing.
\]

This is stronger than labelling one file "holdout" while allowing evidence-object reuse.

## 6. Frozen confirmation package

Before the confirmation R5 result is opened, R6 freezes:

\[
P_C=(
H_{split},H_{hypothesis},O_C,R5Config_C,
DataFreeze_C,Alignment_C,Reliability_C,ClassRefs_C,RuntimeLock
).
\]

`R5Config_C` must agree with discovery on:

- class count;
- realizations/class;
- T3;
- topology extractor;
- primary statistic;
- effect metric set.

Only the observer identities/reference observer are cohort-specific.

## 7. Final certificate

If the leakage audit and package validation pass, R6 runs R5 only on confirmation data:

\[
R5_C=T3_C\leftrightarrow \Phi_C(Effect_C).
\]

The final object is:

```text
R6ConfirmationCertificate
```

containing both:

- `LeakageAudit`;
- independent confirmation `R5TransportCertificate`.

R6 PASS requires both to pass.

## 8. Interpretation

R6 PASS means:

> a transport hypothesis frozen on one observer cohort independently predicts the same T3/effect correspondence in a disjoint observer cohort under the exact R5 null.

It does not establish a metaphysical universal language or an external meaning ontology. It establishes out-of-discovery-sample operational transport.
