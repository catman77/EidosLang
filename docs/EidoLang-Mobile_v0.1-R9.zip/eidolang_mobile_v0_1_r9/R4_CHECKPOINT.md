# R4 checkpoint

Status: implementation complete; synthetic positive/negative controls and inherited R1-R3 tests must pass before release.

## New objects

- `CertifiedOperatorRef`
- `DomainSpec`
- `SubstitutionTrial`
- `SubstitutionPolicy`
- `EquivalenceEstimate`
- `SubstitutionCertificate`
- `CausalMacroName`
- `CausalSubstitutionAnalyzer`
- `CausalMacroNameBuilder`

## New hard gates

1. Both candidate operators already passed R3 independently.
2. Same declared domain and probe schedule.
3. Every pre-state lies inside `DomainSpec`.
4. Assignment must be reproducible from trial IDs + strata + seed.
5. Minimum support in both arms of every stratum.
6. Equivalence margins are pre-registered and positive.
7. Exact boundary randomization tests; cap overflow -> `UNRESOLVED`.
8. Bonferroni familywise control across endpoint + trajectory claims.
9. Every endpoint and every probe-phase trajectory check must pass.
10. MacroName formation is all-pairs clique, never transitive closure.

## Remaining wall after R4

A passed `CausalMacroName` is still an equivalence class only at the observer/measurement resolution chosen by the protocol.
It does not identify internal mechanism and it does not show that a Name transfers across persons.

The next necessity question is therefore cross-observer transport:

```text
Does a causal Name learned for observer O1 induce the same operator class for O2,
possibly through different physical/eidographic realizations?
```

That is the natural R5 gate, but it should not be attempted until R4 is validated on real repeated-session data.
