# R6 checkpoint

Status: IMPLEMENTED / SYNTHETIC TWO-COHORT DRY RUN

Core objects:
- `R6SplitManifest`
- `FrozenTransportHypothesis`
- `ConfirmationPackage`
- `LeakageAudit`
- `R6ConfirmationCertificate`

Measured synthetic split:
- total observer identities: 12
- discovery: 6
- confirmation: 6
- split policy: `HASH_RANK_DISJOINT`
- observer overlap: 0
- topology-session overlap: 0
- R3-certificate-ref overlap: 0
- R4-substitution-ref overlap: 0
- MacroName-object overlap: 0

Discovery R5:
- statistic: 0.7508845597283931
- exact conventions: 32
- exact p: 0.03125
- status: PASS

Frozen hypothesis:
- causal classes: 2
- realizations/class: 3
- topology: T3 / `multilayer-topology-v1`
- statistic: `pairing-orientation-product-v1`
- effect metrics: (`focus`, `noise`)
- selection rule: `ALL_DISCOVERY_CLASSES_PASSING_FROZEN_R4_CUTOFF`

Independent confirmation R5:
- statistic: 0.7508845597283931
- exact conventions: 32
- exact p: 0.03125
- status: PASS

Leakage audit: PASS
R6 certificate: PASS

Negative controls covered by tests:
- confirmation cohort < 6 -> invalid manifest;
- reused topology session -> leakage FAIL;
- reused R3 certificate ref -> leakage FAIL;
- reused discovery MacroName object -> leakage FAIL;
- changed post-freeze R5 primary statistic -> R6 INVALID.

Epistemic boundary:
The two cohorts in the dry run are independent identity/evidence objects generated from the
same synthetic six-profile population mechanism. This validates software separation and
exact-test plumbing only. It is not evidence of cross-human transport.
