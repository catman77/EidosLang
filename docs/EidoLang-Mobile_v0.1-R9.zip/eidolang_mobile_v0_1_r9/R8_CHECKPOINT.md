# R8 checkpoint

Status: IMPLEMENTED / SYNTHETIC RAW-LEDGER CLOSURE

Per confirmation observer in the positive control:

- frozen raw candidate sessions: 27;
- deterministic OperatorMiner candidates: 9;
- R3 dispositions required/registered: 9/9;
- R3 PASS in frozen domain/probe: 9;
- mandatory R4 pair dispositions: C(9,2) = 36;
- registered R4 pair dispositions: 36;
- q=3 subsets exhaustively tested: C(9,3) = 84;
- eligible all-PASS MacroNames: 3;
- R7 selector candidates supplied: exactly the same 3.

Across 6 confirmation observers:

- 162 frozen raw candidate sessions;
- 54 mined R3 operator candidates;
- 216 mandatory R4 pair dispositions;
- 504 three-operator cliques explicitly checked;
- 18 closed MacroName candidates;
- 18/18 supplied to blind R7 selector.

Negative gates:

- missing R3 disposition -> INVALID;
- missing mandatory R4 pair -> INVALID;
- source-session mutation after freeze -> INVALID;
- clique space beyond exact cap -> UNRESOLVED;
- omitted R7 candidate -> INVALID and R5 is not run;
- extra R7 candidate -> INVALID.

Scope boundary:
R8 proves completeness relative to the frozen candidate grammar and policies. It does not prove grammar adequacy/completeness with respect to all possible latent operator effects.

Measured end-to-end synthetic result:

- candidate-set audit: PASS;
- R7 blind instantiation: PASS;
- R6 independent confirmation: PASS;
- R5 exact statistic: 0.7508845597283931;
- R5 exact p-value: 1/32 = 0.03125;
- R8 certificate: `r8:7efa1cdec1cad48a`;
- R8 certificate SHA-256 object hash: `c0b2b0fe7da5d47a59e0c0228ee057662d203fd3b0d7e2f8538178134fe89ee9`.
