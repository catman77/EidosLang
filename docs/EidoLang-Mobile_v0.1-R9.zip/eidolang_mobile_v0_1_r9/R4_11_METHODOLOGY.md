# R4.11 — Finite-Sample Feasibility Gate

## 0. Что именно доказывает R4.11

R4.11 **не вычисляет power**.

Без модели распределения и размера эффекта невозможно заранее гарантировать, что эксперимент
обнаружит существующий эффект.

Вместо этого R4.11 проверяет более слабое, но абсолютно необходимое условие:

> допускает ли конечное exact-пространство теста p-value, достаточно малый для
> заранее фиксированного локального alpha?

Если

\[
p_{\min}>\alpha_{\rm local},
\]

то `PASS` арифметически невозможен даже при максимально благоприятных данных.

Такой протокол блокируется до acquisition.

---

## 1. R3 causal replay

Для \(n\) trials, \(n_A\) из которых назначены operator-arm:

\[
N_{\rm alloc}={n\choose n_A}.
\]

Для one-sided exact randomization test:

\[
p_{\min}\ge {1\over N_{\rm alloc}}.
\]

Если тесты заранее заявлены для \(K\) operators и \(M\) endpoint metrics, R4.11
использует Bonferroni family:

\[
\alpha_{R3}^{local}
=
{\alpha_{R3}^{FWER}\over KM}.
\]

Это также исправляет важную неоднозначность старого R3: `CausalAnalyzer.alpha` должен
трактоваться как **уже локальный** alpha.

Для even balanced two-sided randomization complement symmetry даёт консервативный floor:

\[
p_{\min}\ge {2\over {n\choose n/2}}.
\]

---

## 2. R4 causal substitution

Для MacroName из \(q\) operators необходимо:

\[
P={q\choose2}
\]

pairwise substitution certificates.

Внутри одной пары число заранее заявленных checks:

\[
C
=
S
\left(
M_E + M_T\,N_{\rm phase}
\right),
\]

где:
- \(S\) — strata;
- \(M_E\) — endpoint metrics;
- \(M_T\) — trajectory metrics.

Поэтому:

\[
\alpha_{\rm pair}
=
{\alpha_{R4}^{FWER}\over P},
\]

а существующий `CausalSubstitutionAnalyzer` затем использует:

\[
\alpha_{\rm boundary}
=
{\alpha_{\rm pair}\over C}.
\]

Каждый TOST boundary является one-sided exact randomization test, значит для \(m\) trials
в каждой arm:

\[
p_{\min}\ge {1\over {2m\choose m}}.
\]

R4.11 одновременно требует:

\[
{2m\choose m}\le Cap_{\rm exact}.
\]

Таким образом обнаруживается узкое допустимое окно: слишком мало trials не разрешают alpha,
слишком много могут превысить enumeration cap.

---

## 3. R4.7 cross-observer coordinate alignment

При \(k\) fit anchors exact permutation space:

\[
N_{\rm perm}=k!.
\]

Для \(O\) observers и одного reference:

\[
\alpha_i
=
{\alpha_{R4.7}^{FWER}\over O-1}.
\]

Необходимо:

\[
{1\over k!}\le \alpha_i,
\qquad
k!\le Cap,
\qquad
k\ge d,
\]

где \(d\) — размерность state coordinates.

Это даёт одновременно lower bound по статистической разрешимости и rank-identifiability.

---

## 4. R4.10 repeatability

Текущий R4.10 имеет **marginal** finite-sample semantics для одной
observer/metric координаты.

Для error level \(\alpha\):

\[
n_{\rm pair}^{min}
=
\left\lceil{1\over\alpha}\right\rceil-1.
\]

При \(\alpha=0.05\):

\[
n_{\rm pair}^{min}=19.
\]

R4.11 дополнительно показывает цену более сильного утверждения.

Если потребовать Bonferroni-simultaneous 95% guarantee сразу для \(O\times d\) каналов:

\[
\alpha_{\rm channel}
=
{0.05\over Od}.
\]

При \(O=d=6\):

\[
\alpha_{\rm channel}
=
0.001388\ldots
\]

и требуется:

\[
n_{\rm pair}^{min}=719.
\]

Следовательно прежние 19 pairs нельзя молча интерпретировать как одновременную
95%-гарантию для всех 36 каналов.

R4.11 не меняет семантику R4.10 постфактум: она остаётся marginal, а stronger simultaneous
claim показывается отдельно.

---

## 5. Planned R5 exact observer-convention null

R4.5/R4.6 использовали ограниченный набор destructive controls. Это полезный engineering
control, но **не exact p-value**.

Для первого confirmatory R5 с двумя causal classes фиксируется более строгий null:
каждый observer может независимо использовать одну из двух label conventions.

Глобальный одновременный swap не меняет отношения и факторизуется. Поэтому при \(O\)
observers:

\[
N_{\rm convention}=2^{O-1}.
\]

Для одного primary T3 transport hypothesis:

\[
p_{\min}
=
2^{-(O-1)}.
\]

Отсюда:

- \(O=5\): \(p_{\min}=1/16=0.0625\) — `PASS` при 0.05 невозможен;
- \(O=6\): \(p_{\min}=1/32=0.03125\) — впервые возможно.

Таким образом шесть observers возникают не как эвристическое круглое число, а как
минимальная exact-разрешимость первого бинарного cross-observer test.

Если primary hypotheses больше одного, alpha делится заранее, и минимум observers растёт.

---

## 6. Что означает PASS R4.11

`PASS` означает только:

\[
\boxed{
\text{каждый preregistered exact gate имеет достаточно тонкое конечное p-разрешение}
}
\]

и не превышает свой enumeration cap.

`PASS` **не означает**:
- наличие эффекта;
- достаточную statistical power;
- правильность T3;
- существование общего языка;
- достаточность effect size.

---

## 7. Первый рассчитанный корпус

В default design:

- observers: 6;
- state dimension: 6;
- R4.7 fit anchors: минимум 6;
- holdout anchors: 3;
- marginal R4.10 repeatability: 19 disjoint pairs = 38 sessions/observer.

Если не переиспользовать anchors между calibration и alignment:

\[
38+6+3=47
\]

anchor sessions на observer, то есть:

\[
47\times6=282
\]

anchor sessions до R3/R4.

Это консервативная нижняя граница. В неё не входят:
- free EidoLang discovery sessions;
- R3 replay;
- R4 substitution trials.

Переиспользование данных не допускается просто ради экономии; для него нужен отдельный
validity argument.
