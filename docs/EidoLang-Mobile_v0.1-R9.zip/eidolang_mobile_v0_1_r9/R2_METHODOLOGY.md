# R2 methodology — language discovery without semantic leakage

## Goal

Вывести персональный алфавит и грамматику из корпуса эйдографических сессий так, чтобы ни форма,
ни цвет, ни название символа не имели заданной человеком семантики.

## Status hierarchy

1. **Raw token** — каноническая shape signature. Это ещё не буква.
2. **AlphabetSymbol** — effect-equivalence class, прошедший holdout gate.
3. **EffectGrammarRule** — контекстная последовательность, предсказывающая transition лучше suffix.
4. **MacroName** — следующий уровень; требует операторной эквивалентности на независимых replay trials.

## Why holdout merge instead of geometric clustering

Геометрическая близость не доказывает функциональной эквивалентности. R2 разрешает quotient только
по критерию сохранения transition semantics на невиденных сессиях.

For clusters C1,C2:

```text
L_sep = holdout loss using separate train means
L_merge = holdout loss using pooled train mean
merge iff L_merge <= L_sep
```

После merge кластер принимается как символ только если:

```text
L_symbol < L_global_baseline
```

Никакой epsilon-tolerance для смысла не вводится.

### Exclusive-support identifiability gate

Если A всегда встречается вместе с B, равенство их session-level effects ничего не говорит о
взаимозаменяемости. Поэтому merge A~B разрешён только при наличии в train и holdout обеих
контрфактуально информативных областей: `A without B` и `B without A`. При их отсутствии
эквивалентность помечается как неидентифицируемая и quotient не строится.

## Grammar criterion

Для pattern p=(x1,...,xn), n>=2, baseline — suffix s=(x2,...,xn).

```text
L_rule(p) < L_suffix(s)
```

на holdout. Поэтому правило утверждает только то, что добавление левого контекста несёт
дополнительную информацию о полном state transition.

## Negative controls

Label permutation сохраняет:
- stroke sequences;
- state-delta marginal distribution;
- session count;
- split.

Она разрушает только linkage `session structure -> state transition`.

Observed pipeline проходит gate, если:

```text
Gain_observed > max(Gain_control_i)
```

для заранее зафиксированного control budget.

## What R2 does NOT prove

R2 не доказывает:
- причинность stroke -> state;
- универсальный язык между людьми;
- внешнее воздействие на мир;
- соответствие LLM latent space пространству смыслов;
- мистическую природу найденных состояний.

Он доказывает только существование или отсутствие out-of-sample predictive structure в персональном
корпусе при выбранном observation protocol.
