# R4.11 checkpoint

Status: IMPLEMENTED / COMBINATORIAL FEASIBILITY ONLY

Default preregistered design result:

- R3:
  - 2 operator hypotheses × 2 endpoint metrics;
  - local alpha = 0.0125;
  - minimum balanced trials/operator = 10;
  - C(10,5)=252;
  - best-case one-sided exact p-floor = 1/252 = 0.003968...

- R4:
  - 3 operators -> 3 all-pairs certificates;
  - 2 endpoint metrics + 2 trajectory metrics × 2 phases = 6 checks/pair;
  - pair alpha = 0.05/3;
  - boundary alpha = 0.05/(3×6) = 0.002777...
  - minimum 6 trials/arm/stratum;
  - C(12,6)=924;
  - p-floor = 1/924 = 0.001082...

- R4.7:
  - 6 observers -> adjusted alpha = 0.01;
  - state dimension = 6 forces >=6 fit anchors;
  - 6! = 720;
  - p-floor = 1/720 = 0.001388...
  - exact cap satisfied.

- R4.10:
  - marginal 95% repeatability requires 19 disjoint pairs;
  - 6 observers × 6 metrics simultaneous Bonferroni 95% claim would require 719 pairs.
  - Therefore R4.10 remains explicitly marginal unless its theory is changed.

- planned R5:
  - binary observer-wise label-convention exact null;
  - 5 observers: p-floor=0.0625 -> IMPOSSIBLE at alpha=.05;
  - 6 observers: p-floor=0.03125 -> FEASIBLE.

Conservative anchor acquisition lower bound without reuse:
- 47 anchor sessions / observer;
- 282 anchor sessions for 6 observers.

This is an arithmetic resolution result, not a power analysis.
