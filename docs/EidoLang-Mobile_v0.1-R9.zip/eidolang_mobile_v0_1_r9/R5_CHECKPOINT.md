# R5 checkpoint

Status: IMPLEMENTED / COMPILED SYNTHETIC EXACT TEST

Primary statistic:
`pairing-orientation-product-v1`

Measured positive control:
- observers: 6
- causal classes / observer: 2
- causal realizations / class: 3
- observer pairs: 15
- exact observer-wise convention quotient: 32
- observed statistic: 0.750884559728
- exact p-value: 0.03125000
- exact p-floor: 0.03125000
- alpha: 0.05000000
- status: PASS

The observed statistic is the unique maximum in the 32-element null space.

Negative controls covered by tests:
- changing local class names leaves statistic and p-value invariant;
- swapping topology/effect pairing for one observer makes the primary test fail;
- unpassed R4 MacroName -> INVALID;
- exact cap below 32 -> UNRESOLVED.

Cross-stage defect discovered by R5:
R4.12 synthetic alignment generation still contained a hard-coded `inner_noise`
coordinate while the compiled master schema used `noise`.
Earlier stages could pass because R4.7 and R4.10 each validated their own internally
consistent coordinate set. R5 was the first stage requiring literal composition:

    R4.7 transform -> R3 causal effect -> R4.10 reliability coordinates.

The source was corrected: alignment generation now takes metric keys only from the
compiled AcquisitionManifest.

Epistemic status:
This is a software/synthetic positive control. It is not evidence that real observers
share an eidographic/topological invariant.
