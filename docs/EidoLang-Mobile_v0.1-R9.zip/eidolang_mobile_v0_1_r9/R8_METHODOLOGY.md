# R8 — Candidate-Universe Closure / Exhaustive Enumeration Certificate

## 1. Necessity

R7 closes post-hoc selection **inside a supplied candidate set**. It does not prove that the supplied set contains every local R4 MacroName that passed the frozen gate.

If an analyst can omit one inconvenient candidate before blind matching, then the best-vs-second assignment gap can be increased without touching R7 itself.

Therefore the required statement is not

\[
Candidates_{R7}\subseteq Eligible_{R4},
\]

but

\[
\boxed{Candidates_{R7}=Eligible_{R4}}.
\]

R8 turns that equality into an executable certificate.

---

## 2. Closure starts at the frozen event ledger

For each confirmation observer R8 receives a frozen event-sourced candidate-discovery ledger:

\[
L_i=(S_1,\ldots,S_n).
\]

Every session is content-hashed by the inherited R4.8 `AcquisitionLedger`. A `DataFreezeCertificate` binds:

- ledger root;
- ledger length;
- exclusions;
- observer identity.

R8 requires the supplied session dictionary to equal the complete ledger session-ID set. It does not accept a manually selected subset.

The actual source for candidate mining is exactly:

\[
L_i\setminus Exclusions_{freeze}.
\]

Mutation of any earlier raw session breaks ledger verification and makes closure `INVALID`.

---

## 3. Frozen deterministic operator grammar

The first map is the existing R1 operator miner:

\[
G_{op}=\texttt{OperatorMiner}(min\_support,max\_ngram,version).
\]

R8 reruns it from the frozen raw sessions:

\[
O_i=G_{op}(L_i).
\]

No externally supplied operator list is trusted.

Every mined operator has a canonical object hash:

\[
h(o)=SHA256(o).
\]

The R3 registry must contain **exactly one** disposition for every mined operator and no extra operator:

\[
Keys(R3Registry)=O_i.
\]

Allowed dispositions are:

\[
PASS,FAIL,UNRESOLVED,INVALID.
\]

Thus an R3 candidate cannot disappear because it failed or was inconvenient.

---

## 4. Complete R4 pair universe

Fix the already preregistered R7/R5 operational domain and probe schedule:

\[
(D,P).
\]

Let

\[
V_i=\{o\in O_i:\ R3(o)=PASS,\ domain(o)=D,\ probe(o)=P\}.
\]

Every unordered pair is mandatory:

\[
E_i^{required}={V_i\choose2}.
\]

R8 requires:

\[
Keys(R4Registry)=E_i^{required}.
\]

Each pair record is also checked against:

- the exact R3 causal-certificate IDs of both endpoints;
- frozen domain;
- frozen probe schedule;
- frozen substitution-policy hash;
- frozen substitution protocol version.

Missing and extra pair records are both `INVALID`.

A failed R4 pair stays in the registry as `FAIL`; it is not deleted.

---

## 5. Exact MacroName enumeration

For frozen MacroName cardinality \(q\), R8 enumerates every subset

\[
Q\in {V_i\choose q}.
\]

If

\[
{ |V_i| \choose q}>Cap,
\]

R8 returns

\[
\boxed{UNRESOLVED}
\]

rather than sampling cliques.

A subset is eligible iff every one of its

\[
{q\choose2}
\]

pair dispositions is `PASS` under the same frozen R4 policy.

Every eligible clique is then reconstructed through the inherited `CausalMacroNameBuilder`; R8 does not introduce a second naming rule.

The output is:

\[
U_i=\{MacroName(Q):Q\text{ is an all-PASS }q\text{-clique}\}.
\]

and a candidate-set root:

\[
H_{U_i}=SHA256(U_i).
\]

---

## 6. Exact R7 candidate-set audit

Before R7 runs, R8 compares the closed universe to the blinded selector input:

\[
Expected_i=\{name(M):M\in U_i\},
\]

\[
Supplied_i=\{candidate.macro\_name\_id\}.
\]

PASS requires literal equality for every confirmation observer:

\[
\boxed{Expected_i=Supplied_i}.
\]

Therefore all of the following are fatal:

- omitted eligible MacroName;
- extra non-enumerated MacroName;
- duplicate candidate;
- missing observer universe certificate;
- any universe certificate not `PASS`.

If closure fails, R8 does not run R7 or R5 at all.

---

## 7. Synthetic measured closure

The positive control freezes 27 raw candidate sessions per observer:

\[
9\text{ distinct physical stroke forms}\times3\text{ repeats}.
\]

With frozen

```text
min_support = 3
max_ngram   = 1
```

`OperatorMiner` recovers exactly:

\[
9
\]

operators for each confirmation observer.

All nine have R3 `PASS`, hence the complete R4 pair universe contains:

\[
{9\choose2}=36
\]

pair dispositions.

For \(q=3\), R8 tests every:

\[
{9\choose3}=84
\]

possible clique.

The synthetic R4 graph contains exactly three all-PASS triangles, so:

\[
\boxed{|U_i|=3}.
\]

They are the two true frozen-class candidates plus one real R4-passed distractor. R7 receives all three and prospectively selects the two appropriate classes.

---

## 8. What the closure theorem does **not** say

R8 proves extensional completeness only relative to the frozen tuple

\[
(DataFreeze,OperatorMinerConfig,R3Gate,D,P,R4Policy,q).
\]

It does **not** prove that `OperatorMiner`'s grammar can express every psychologically or semantically relevant transformation.

Formally:

\[
\boxed{
R8:\quad Candidates_{R7}=Eligible_{frozen\ grammar}
}
\]

not

\[
Candidates_{R7}=\text{all possible meaningful human operators}.
\]

That distinction is the next remaining boundary after R8.
