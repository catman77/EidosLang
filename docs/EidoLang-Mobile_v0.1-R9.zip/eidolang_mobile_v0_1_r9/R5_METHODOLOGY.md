# R5 — Cross-Observer Topological-Causal Transport

## 1. Confirmatory question

R5 tests one frozen proposition:

> Do the two independently certified causal classes of different observers admit the
> same **binary correspondence** in T3 topology and in R4.7-aligned causal-effect space?

It does not ask whether pictures look similar.

For observer \(i\), let the two local R4 MacroNames be:

\[
C_{i0},C_{i1}.
\]

Their local IDs are arbitrary.

Each class contains exactly three R3-certified/R4-substitution-equivalent realizations,
as compiled by R4.12.

---

## 2. Class-level T3 distance

For every realization we use the already frozen R4.6 representation:

\[
T3=(v,\mathcal C,\mathcal M),
\]

where:
- \(v\) is `t3_vector`;
- \(\mathcal C\) is the anonymous color-layer multiset;
- \(\mathcal M\) is the media/topological-coupling multiset.

The realization distance is exactly the R4.6 metric:

\[
d_{T3}
=
0.55\,d_v
+
0.25\,d_{\mathcal C}
+
0.20\,d_{\mathcal M}.
\]

R5 fits no new representation weights.

A MacroName is an unordered all-pairs causal clique. Therefore the distance between two
three-realization MacroNames is:

\[
D_T(A,B)
=
\min_{\pi\in S_3}
{1\over3}
\sum_{k=1}^3
d_{T3}(A_k,B_{\pi(k)}).
\]

All realizations must be used. None may be selected or dropped post hoc.

---

## 3. Class-level causal-effect distance

Each of the three R3 operators supplies its preregistered causal effect vector.

For every non-reference observer the complete vector is first mapped by the already-passed
R4.7 similarity transform:

\[
y=\Phi_i(\Delta o_i).
\]

Only afterwards is it projected to the compiler-frozen primary endpoints.

The class effect is the symmetric mean of all three causal realizations:

\[
\bar y(C)
=
{1\over3}\sum_k \Phi_i(y_k).
\]

Distance is normalized only by the R4.10 common repeatability floor:

\[
D_E(A,B)
=
\sqrt{
\sum_{m\in M_{primary}}
\left(
{\bar y_m(A)-\bar y_m(B)\over r_m^{common}}
\right)^2
}.
\]

No learned metric is introduced.

---

## 4. The binary correspondence orientation

For observers \(i,j\), two bijections exist.

Same orientation:

\[
T_s
=
D_T(C_{i0},C_{j0})
+
D_T(C_{i1},C_{j1}).
\]

Cross orientation:

\[
T_c
=
D_T(C_{i0},C_{j1})
+
D_T(C_{i1},C_{j0}).
\]

Define the normalized topological orientation:

\[
A_{ij}
=
{T_c-T_s\over T_c+T_s}.
\]

Likewise in effect space:

\[
B_{ij}
=
{E_c-E_s\over E_c+E_s}.
\]

Both lie in \([-1,1]\).

If a local observer's class IDs are swapped, both \(A_{ij}\) and \(B_{ij}\) change sign.
Therefore their product is invariant:

\[
A_{ij}B_{ij}
\]

does not depend on naming the local classes.

The primary statistic is:

\[
\boxed{
S
=
{1\over {O\choose2}}
\sum_{i<j}A_{ij}B_{ij}.
}
\]

No classification threshold is needed.

---

## 5. Exact observer-wise convention null

Under the null that T3 correspondence and aligned causal-effect correspondence have no
stable cross-observer relation, the two effect classes may be swapped relative to topology
independently for each observer.

Let:

\[
s_i\in\{-1,+1\}.
\]

Then:

\[
B_{ij}\mapsto s_i s_j B_{ij}.
\]

Hence:

\[
S(s)
=
{1\over {O\choose2}}
\sum_{i<j}
A_{ij}s_i s_jB_{ij}.
\]

A simultaneous global reversal \(s_i\mapsto-s_i\) leaves every product \(s_is_j\) unchanged.
Therefore the exact null quotient contains:

\[
\boxed{2^{O-1}}
\]

distinct conventions.

For six observers:

\[
2^5=32.
\]

R5 enumerates all 32; there are no sampled controls.

The one-sided exact p-value is:

\[
p
=
{\#\{s:S(s)\ge S_{obs}\}\over 32}.
\]

Thus:

\[
p_{min}=1/32=0.03125.
\]

This is the exact combinatorial result anticipated by R4.11.

---

## 6. Prerequisite gates

R5 returns `INVALID` unless:

- R4.7 alignment is PASS for exactly the compiled observer set;
- R4.10 repeatability is PASS;
- every class is an R4-passed MacroName;
- exactly three topology realizations/class are supplied;
- exactly three R3 causal effect records/class are supplied;
- exactly three R4 pair-certificate refs/class are supplied;
- no topology realization session is reused;
- the representation is T3.

If the exact convention count exceeds the compiler cap:

\[
\boxed{UNRESOLVED}.
\]

---

## 7. Interpretation

`PASS` means only:

> within the frozen binary causal classes, the correspondence preferred by multilayer T3
> topology agrees across observers with the correspondence preferred by independently
> aligned causal effects more strongly than allowed by the exact observer-wise
> convention null.

It does not prove:
- a universal visual symbol;
- a universal semantic ontology;
- direct access to an external meaning realm;
- external-world causal control.

It is the first confirmatory evidence object for a cross-observer operational invariant.
