# R4.12 checkpoint

Status: IMPLEMENTED / FULL COMPILED DRY RUN

Cross-stage correction:
- binary R5 classes: 2;
- R4 realizations/class: 3;
- therefore R3 operators/observer: 6, not 2.

Corrected multiplicity:
- R3 claims: 6 operators × 2 endpoints = 12;
- R3 local alpha = 0.05/12 = 0.0041666667;
- minimum R3 trials/operator remains 10 because 1/C(10,5)=0.003968254.

- R4 pair families: 2 classes × C(3,2) = 6;
- R4 pair alpha = 0.05/6 = 0.0083333333;
- 6 checks/pair -> boundary alpha = 0.0013888889;
- minimum remains 6 trials/arm because 1/C(12,6)=0.001082251.

Corrected conservative session lower bound:
- alignment: 9 / observer;
- reliability: 38 / observer;
- R3: 60 / observer;
- R4: 72 / observer;
- total confirmatory before discovery: 179 / observer;
- 6 observers: 1074 sessions.

Dry-run requirement:
all confirmatory modules are instantiated by the compiler lock; a manually changed
CausalAnalyzer alpha is rejected.
