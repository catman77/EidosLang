# R4.9 checkpoint

Status: IMPLEMENTED / SYNTHETIC FIDELITY TESTS ONLY

Implemented:
- frozen AnchorExecutionPlan;
- plan SHA-256 binding;
- frozen DeviceCapabilityProfile;
- per-step actual execution timing;
- capability checks;
- duplicate/missing/undeclared-step rejection;
- start/duration tolerance gates;
- DIGITAL_EXECUTION vs PHYSICAL_OUTPUT scopes;
- external physical calibration reference;
- whole-corpus fidelity gate.

Critical no-go:
DIGITAL_EXECUTION does not certify acoustic SPL, luminance, haptic acceleration, or other absolute physical output. PHYSICAL_OUTPUT requires external calibration.

R5 remains blocked until both R4.8 data-freeze and R4.9 fidelity gates pass on a real corpus.
