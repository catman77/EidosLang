# EidoLang-Mobile v0.1-R4.6 — Multilayer Topological Motif Discovery

## 1. Причина введения R4.6

R4.5 показал, что топология формы может переносить операторный класс лучше геометрии, но
простая бинарная форма теряет часть структуры эйдограммы. В исходной статье цвет, форма и
композиция рассматриваются как различные эйдо-среды, а смысл финального изображения зависит
от отношений элементов и истории его построения.

На смартфоне эти каналы наблюдаемы непосредственно в raw event stream. Поэтому новый объект
не постулируется: он вынужден уже существующей измерительной моделью.

R4.6 не утверждает, что мультимедийная топология является «смыслом». Он проверяет более слабое
утверждение:

```text
может ли quotient, сохраняющий topology + relations between measured layers,
переносить R4-certified causal classes лучше одноканальной T2-топологии?
```

## 2. Объект

Для сессии Γ строится мультислойный объект

```text
M(Γ) = (K_form, {K_color^c}, K_audio, K_haptic, I)
```

где:

- `K_form` — R4.5 T2 topology полной траектории;
- `K_color^c` — topology частей траектории, реально выполненных в color-state `c`;
- `K_audio`, `K_haptic` — комплексы временных интервалов соответствующих media events;
- `I` — измеренные cross-layer incidence relations.

`COLOR`, `AUDIO`, `HAPTIC` уже являются RawEvent типами R1; R4.6 не вводит скрытый сенсорный
канал.

## 3. Color runs

Нельзя предполагать, что один START..END stroke имеет один цвет. Если COLOR меняется внутри
stroke, raw trajectory автоматически делится на `ColorRun` в момент явного COLOR event.

Тем самым:

```text
raw pointer trajectory + explicit renderer state -> color-layer trajectories
```

без геометрического порога и без семантической классификации цвета.

## 4. Palette-renaming quotient

Для cross-observer transport фактические названия цветов по умолчанию не считаются общими
семантическими атомами. Поэтому `anonymous_color_layers=True` факторизует произвольное
переименование палитры.

Сохраняется:

- сколько существует слоёв;
- topology каждого слоя;
- какие элементы принадлежат одному/разным слоям;
- отношения слоёв в containment structure;

но не утверждение `#ff0000 == конкретный смысл`.

Исходные labeled color tokens при этом не удаляются и остаются доступными для будущего отдельного
теста цветовой семантики.

## 5. Temporal media topology

AUDIO/HAPTIC event задаёт закрытый временной интервал из `t_us` и явного `duration_ms/us`.
Если duration отсутствует, event остаётся точечным.

Для каждого канала вычисляются:

- число episodes;
- `β0` объединения интервалов на временной прямой;
- число pairwise overlaps;
- максимальная concurrency.

Это описание не использует содержание аудио или субъективную интерпретацию вибрации.

## 6. Media ↔ form incidence

Media episode связывается с physical stroke только если их временные интервалы пересекаются.
Затем связь маркируется **топологическим событием формы**, которое произвёл этот stroke:

```text
AUDIO/HAPTIC | dB0+
AUDIO/HAPTIC | dB1+
AUDIO/HAPTIC | contain+
AUDIO/HAPTIC | newContains
...
```

Таким образом одинаковый haptic pulse, совпавший с созданием новой компоненты, отличен от того же
pulse, совпавшего с замыканием цикла. Никакого временного окна близости не вводится.

## 7. Cross-color containment motif

R4.6 обнаружил дополнительный no-go.

Недостаточно хранить:

```text
number of color layers
+ topology multiset of layers
+ number of cross-color containment edges
```

Две иерархии могут совпадать по всем этим числам и отличаться расположением отношения
«одинаковый/другой слой» вдоль containment poset.

Поэтому строится Hasse reduction containment relation для closed color runs, а на каждой
root-to-leaf chain сохраняется только equality pattern слоёв:

```text
ABAC, ABCB, AABA, ...
```

Actual palette labels удаляются first-occurrence normalization. Это topology of layer equality,
а не семантика цвета.

## 8. T3

`T3 = MultilayerTopologyDescriptor` содержит:

```text
T2(form)
+ anonymous color-layer topology multiset
+ color-layer equality patterns on containment chains
+ cross-color relations
+ temporal topology of audio/haptic
+ media↔form topological incidence
```

Feature vector фиксированной размерности используется для deterministic nearest-neighbour
baseline; полные multisets/signatures хранятся отдельно и не сворачиваются необратимо.

## 9. Necessity counterexamples

### N46.1 Form topology collision

Две сессии имеют одинаковый T2 формы и одинаковые nested shapes, но в одной два nested элемента
лежат в двух visual layers, а в другой — в одном.

```text
T2(A) = T2(B)
T3(A) != T3(B)
```

Следовательно T2 недостаточен для multilayer language.

### N46.2 Media coupling collision

Форма, цвет и один haptic pulse одинаковы. В первой сессии pulse перекрывает stroke, создающий
новую компоненту; во второй — stroke, замыкающий цикл.

```text
T2(A) = T2(B)
HAPTIC|dB0+ != HAPTIC|dB1+
```

Следовательно media content без incidence к процессу формы недостаточен.

### N46.3 Aggregate-layer collision

Две nested multilayer structures совпадают по:

- T2;
- числу color layers;
- multiset per-layer topology;
- числу color switches;
- aggregate cross-color containment count.

Но equality pattern на containment chains различен. Поэтому aggregate multilayer statistics
недостаточны; требуется сохранять структуру incidence poset.

## 10. Cross-observer gate

Causal labels не выводятся TDA и должны приходить из R4 certificates.

Leave-one-observer-out сравнивает:

```text
Geometry
T2 (form topology)
T3 (multilayer topology)
```

R4.6 representation принимается только если:

```text
accuracy(T3) - accuracy(T2) >= min_gain
and
accuracy(T3) > max destructive label-control accuracy
```

Negative control нарушает observer↔causal-class alignment, сохраняя сами рисунки и representations.

## 11. Что R4.6 не доказывает

R4.6 не доказывает:

- универсальность цветовой семантики;
- причинность media channels;
- что topology является смыслом;
- что causal class переносится между реальными людьми;
- что мультимодальная LLM latent space изоморфно пространству эйдограмм.

Он создаёт только необходимый representation layer для таких проверок.

## 12. Следующий gate

После R4.6 остаётся принципиальная неоднозначность:

```text
palette-renaming invariant topology
vs
actual metric/color/audio content
```

Если реальные causal classes не разделяются T3, следующая сущность может вводиться только из
конкретного counterexample. Кандидаты заранее не считаются обязательными. В частности, actual hue,
audio frequency или latent embedding нельзя добавлять лишь потому, что они доступны смартфону.
