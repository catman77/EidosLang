# Android eidogram messenger roadmap after R16

## R14 / R14.1 — Eidogram editor — COMPLETE AT SOURCE LEVEL
113-glyph editor, exact selection, grouping, deterministic canonical documents.

## R15 — Identity + encrypted/signed message envelope — COMPLETE
Root/device identities, encrypted canonical eidograms, immutable signed message DAG nodes.

## R16 — Torrent Archive Model — COMPLETE
- immutable conversation segments;
- deterministic manifest and segment ID;
- BitTorrent-v2 file tree/Merkle metadata;
- v2 infohash and magnet;
- signed per-device BEP44 mutable conversation head;
- fixed archive/torrent/DHT golden vectors.

## R17 — Android P2P / Torrent Engine — NEXT
- native torrent engine boundary;
- load/create R16 `.torrent` metadata;
- DHT bootstrap and peer discovery;
- download/verify/seed immutable conversation segments;
- BEP44 head get/put and periodic republish;
- bind network results back through R16 verification before repository admission;
- storage quotas and explicit pinning;
- WorkManager periodic sync plus user-visible continuous-seeding mode;
- network integration tests on two peers.

## R18 — Messenger UX + local repository
- contacts/public identity bundle import;
- conversations;
- persistent message DAG;
- sender sequence/replay enforcement;
- compose/send/receive;
- synchronization state and conflict display.

## R19 — Archive / Recovery
- local archive index;
- pin/unpin;
- archive browser;
- full conversation restore after deleting local database.

## R20 — Multi-device
- root-authorized additional devices;
- archive publisher certificates per device;
- device revocation;
- concurrent publisher heads;
- deterministic DAG merge.

## R20.1 — Forward-secrecy session layer
- ratcheted per-contact secrets;
- historical key erasure;
- migrate message key distribution away from static RSA recipient boxes.

## R21 — Security / Fuzzing
- bencode/JSON parser fuzzing;
- malicious torrent paths and Merkle metadata;
- poisoned swarm content;
- forged/stale BEP44 heads;
- replay and rollback;
- JNI/native boundary fuzzing.

## R22 — Android 1.0 acceptance
Two Android devices with no application server can compose eidograms, exchange encrypted
signed messages, publish/fetch torrent-backed archive segments through DHT/swarm transport,
converge on the same message DAG, and restore the history from P2P storage.
