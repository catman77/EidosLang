plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.compose.compiler)
}

android {
    namespace = "org.eidolang.app"
    compileSdk = 37

    defaultConfig {
        applicationId = "org.eidolang.app"
        minSdk = 26
        targetSdk = 37
        versionCode = 1
        versionName = "0.1-R22"
        // Two-device enrollment is driven by tools/two-device-enrollment.sh, not by this suite.
        testInstrumentationRunnerArguments["notAnnotation"] =
            "org.eidolang.app.TwoDeviceOnly,org.eidolang.app.NativeSessionHeavy"
    }

    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation(project(":feature-editor"))
    implementation(project(":core-model"))
    implementation(project(":core-crypto"))
    implementation(project(":core-message"))
    implementation(project(":core-multidevice"))
    implementation(project(":core-session"))
    implementation(project(":core-vault"))
    implementation(project(":core-hardening"))
    implementation(project(":core-archive"))
    implementation(project(":core-transport"))
    implementation(project(":feature-sync"))
    implementation(project(":feature-messenger"))
    implementation(project(":feature-onboarding"))
    implementation(project(":feature-viewer"))
    implementation(project(":core-repository"))
    implementation(project(":feature-archive"))
    implementation(project(":core-recovery"))
    implementation(project(":transport-libtorrent4j"))
    val composeBom = platform(libs.androidx.compose.bom)
    implementation(composeBom)
    androidTestImplementation(composeBom)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.ui.tooling.preview)
    debugImplementation(libs.androidx.compose.ui.tooling)
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    androidTestImplementation(project(":core-admission"))
    androidTestImplementation(project(":core-canonical"))
    // Prebuilt libtorrent 2.1.0 Android binding, test-only: it backs the R17 on-device transport
    // admission and is deliberately NOT a dependency of the shipped app.
    androidTestImplementation("org.libtorrent4j:libtorrent4j:2.1.0-35")
    androidTestImplementation("org.libtorrent4j:libtorrent4j-android-arm64:2.1.0-35")
    androidTestImplementation("org.libtorrent4j:libtorrent4j-android-x86_64:2.1.0-35")
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}
