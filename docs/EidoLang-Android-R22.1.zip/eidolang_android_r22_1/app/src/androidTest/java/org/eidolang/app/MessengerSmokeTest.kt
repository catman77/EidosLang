package org.eidolang.app

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Rule
import org.junit.Test

class MessengerSmokeTest {
    @get:Rule
    val rule = createAndroidComposeRule<MainActivity>()

    private fun enterPrimaryHomeIfNeeded() {
        val firstRun = rule.onAllNodesWithText("Создать основной профиль")
            .fetchSemanticsNodes().isNotEmpty()
        if (firstRun) {
            rule.onNodeWithText("Создать основной профиль").performClick()
            rule.waitUntil(timeoutMillis = 15_000) {
                rule.onAllNodesWithText("Эйдограммы").fetchSemanticsNodes().isNotEmpty()
            }
        }
    }

    @Test
    fun r22PrimaryHomeAndAdmissionNavigationAreVisible() {
        enterPrimaryHomeIfNeeded()
        rule.onNodeWithText("Эйдограммы").assertExists()
        rule.onNodeWithText("Архив").assertExists()
        rule.onNodeWithText("Устройства").assertExists()
        rule.onNodeWithText("Диагностика").assertExists()

        rule.onNodeWithText("Диагностика").performClick()
        rule.onNodeWithText("Android admission").assertExists()
        rule.onNodeWithText("Запустить admission probe").assertExists()
    }

    @Test
    fun secureArchiveRecoveryControlsAreVisible() {
        enterPrimaryHomeIfNeeded()
        rule.onNodeWithText("Архив").performClick()
        rule.onNodeWithText("Forward-secure history vault").assertExists()
        rule.onNodeWithText("Secure export").assertExists()
        rule.onAllNodesWithText("Recovery backup").onFirst().assertExists()
        rule.onNodeWithText("Secure restore").assertExists()
        rule.onNodeWithText("Мигрировать R19 → secure vault").assertExists()
    }
}
