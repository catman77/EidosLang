# EidoLang-Mobile v0.1-R4.7

R4.7 adds the missing **cross-observer effect-coordinate alignment gate**. It does not add a new eido representation. Before T3 motifs can be compared across real subjects, observer-specific state-effect coordinates must be empirically transported into a common chart using preregistered shared anchors and unseen holdout anchors.

See `R4_7_METHODOLOGY.md` and `R4_7_CHECKPOINT.md`.

---

# EidoLang-Mobile v0.1-R1


## R4.5: Topological Motif Discovery

R4.5 inserts a representation gate before cross-observer transport. It does **not** assume that
shared meaning has a shared shape. Instead it tests three nested quotients:

```text
T0 = Betti/Euler
T1 = T0 + boundary/containment/intersection topology
T2 = T1 + temporal topological event program
```

A topology layer is admissible only if it predicts already-certified causal classes on held-out
observers better than the current geometric token representation and beats label-destruction controls.
See `R4_5_METHODOLOGY.md` and `EXAMPLE_R45_REPORT.json`.

Минимальное детерминированное ядро для исследования эйдографического языка как языка **операторов состояния**, а не словаря заранее назначенных символов.

## Инварианты R1

1. Raw-first/event-sourced: первичен поток `RawEvent`; финальное изображение — производное представление.
2. Никакой заданной семантики форм: в ядре нет правил вроде «круг = покой».
3. Сегмент = физический stroke: R1 не вводит эвристическую субсегментацию.
4. Токены структурные: форма кодируется канонической геометрической сигнатурой; отношения — числовыми дескрипторами.
5. Операторы открываются по эффекту: `EidoOperator` — повторяющийся n-граммный паттерн, связанный с наблюдаемым переходом состояния.
6. Evidence-carrying: сохраняются support, evidence и counterexamples.
7. Recommender не рисует за пользователя: он возвращает ссылку на прототип следующего структурного действия.
8. Все derived-артефакты версионируются; raw-данные неизменяемы.

## Pipeline

```text
smartphone pointer/media events
        -> RawEvent stream (append-only)
        -> StrokeSegmenter v1
        -> shape signatures + relation descriptors
        -> token trajectory
        -> OperatorMiner
        -> EidoOperator + evidence + counterexamples
        -> DeterministicRecommender
        -> next-action prototype reference
```

Состояние субъекта хранится независимо:

```text
latent state m_t --unknown--> StateObservation o_t = proxy(m_t)
```

Никакая шкала состояния не считается фундаментальной.

## Запуск

```bash
python -m pip install -e .
python -m unittest discover -s tests -v
```

CLI:

```bash
eidolang analyze examples/sample_session.json
```

## Gate R1

R1 считается содержательно успешным только если на корпусе появляются паттерны `w`, для которых наблюдаемый переход состояния воспроизводимо отличается от baseline и сохраняется на отложенных сессиях.

# R2 — персональный алфавит и эффект-грамматика

R2 добавляет автоматический discovery-проход, который **не присваивает значения формам вручную**.

## Alphabet gate

Исходные stroke signatures рассматриваются как технические токены. Два токена допускается
слить в один `AlphabetSymbol` только если pooled effect predictor на holdout не хуже, чем два
раздельных predictors. Символ сохраняется только если его predictor на holdout лучше глобального
baseline состояния.

```text
raw stroke tokens
   -> train effect estimates
   -> deterministic agglomerative merge
   -> holdout non-inferiority gate
   -> predictive-vs-global-baseline gate
   -> AlphabetSymbol
```

## Grammar gate

После factorization stroke token -> alphabet symbol сессия кодируется как:

```text
A:symbol, R:relation, A:symbol, R:relation, ...
```

Паттерн порядка >=2 становится `EffectGrammarRule`, только если на holdout его transition predictor
строго лучше predictor-а собственного suffix. Это проверяет наличие **контекстного эффекта**, а не
просто частоты последовательности.

## Negative controls

И alphabet, и grammar повторно строятся на детерминированных permutations `session -> state_delta`,
которые сохраняют распределение эффектов, но разрушают связь формы с переходом состояния.
Discovery gate проходит только если реальный holdout gain выше максимального gain предзаданных
controls.

Это сильный, намеренно консервативный gate; `negative_controls` — вычислительный budget протокола,
а не семантический порог.

## Важное ограничение R2

State delta пока относится к сессии целиком. Поэтому найденная буква/грамматическое правило означает
`predictive association with session transition`, а не доказанную причинность отдельного штриха.
Чтобы перейти к причинному оператору, следующая версия должна вводить промежуточные state probes или
рандомизированное/контрбалансированное воспроизведение уже найденных macro-operators.

---

# R3: causal replay

R2 patterns are predictive only. R3 adds randomized replay against an outcome-blind matched motor control.

Core API:

```python
from eidolang import (
    ReplayTemplateBuilder, MatchedControlBuilder,
    balanced_random_assignment, CausalAnalyzer
)
```

Synthetic validation:

```bash
eidolang r3-synthetic --n 16 --seed 731
```

See:
- `R3_METHODOLOGY.md`
- `R3_REPLAY_PROTOCOL.md`
- `R3_CHECKPOINT.md`
- `EXAMPLE_R3_REPORT.json`

R3 deliberately does not promote two efficacious operators to one causal `MacroName`; that requires randomized substitution equivalence in R4.

---

# R4: Causal Substitution Calculus

R4 does not discover more shapes. It tests whether two already-causal R3 operators are actually substitutable.

```text
R3: do(w1) -> target, do(w2) -> target
R4: do(w1) ≃ do(w2) within pre-registered margins and trajectory resolution
```

`CausalMacroName` is formed only from an all-pairs clique of passed substitution certificates. Approximate equivalence is not assumed transitive.
See `R4_METHODOLOGY.md` and `R4_CHECKPOINT.md`.

---

# R4.6 — Multilayer Topological Motifs

R4.6 extends R4.5 from a binary/form topology to the channels that are already explicitly measured
by the smartphone event stream:

```text
FORM + COLOR + AUDIO + HAPTIC
```

It does **not** assign meanings to colors, tones or haptic patterns. Instead it asks whether their
layer topology and their incidence with the topological construction process preserve an externally
certified causal class better than T2 form topology alone.

Commands:

```bash
eidolang multilayer session.json
eidolang r46-synthetic
```

Measured synthetic positive control:

```text
Geometry  0.50
T2        0.50
T3        1.00
negative-control max T3 = 0.833333
PASS
```

See `R4_6_METHODOLOGY.md` and `R4_6_CHECKPOINT.md`.

## R4.8 — Real Corpus Acquisition Gate

Добавлены preregistration hash, deterministic hidden anchor split, per-observer schedule, session admission, tamper-evident ledger, dataset freeze и second-stage evaluation lock. R5 запрещён до появления реального frozen corpus.
