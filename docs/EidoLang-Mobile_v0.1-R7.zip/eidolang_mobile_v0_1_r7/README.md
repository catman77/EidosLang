# EidoLang-Mobile v0.1-R4.7

R4.7 adds the missing **cross-observer effect-coordinate alignment gate**. It does not add a new eido representation. Before T3 motifs can be compared across real subjects, observer-specific state-effect coordinates must be empirically transported into a common chart using preregistered shared anchors and unseen holdout anchors.

See `R4_7_METHODOLOGY.md` and `R4_7_CHECKPOINT.md`.

---

# EidoLang-Mobile v0.1-R1


## R4.5: Topological Motif Discovery

R4.5 inserts a representation gate before cross-observer transport. It does **not** assume that
shared meaning has a shared shape. Instead it tests three nested quotients:

```text
T0 = Betti/Euler
T1 = T0 + boundary/containment/intersection topology
T2 = T1 + temporal topological event program
```

A topology layer is admissible only if it predicts already-certified causal classes on held-out
observers better than the current geometric token representation and beats label-destruction controls.
See `R4_5_METHODOLOGY.md` and `EXAMPLE_R45_REPORT.json`.

Минимальное детерминированное ядро для исследования эйдографического языка как языка **операторов состояния**, а не словаря заранее назначенных символов.

## Инварианты R1

1. Raw-first/event-sourced: первичен поток `RawEvent`; финальное изображение — производное представление.
2. Никакой заданной семантики форм: в ядре нет правил вроде «круг = покой».
3. Сегмент = физический stroke: R1 не вводит эвристическую субсегментацию.
4. Токены структурные: форма кодируется канонической геометрической сигнатурой; отношения — числовыми дескрипторами.
5. Операторы открываются по эффекту: `EidoOperator` — повторяющийся n-граммный паттерн, связанный с наблюдаемым переходом состояния.
6. Evidence-carrying: сохраняются support, evidence и counterexamples.
7. Recommender не рисует за пользователя: он возвращает ссылку на прототип следующего структурного действия.
8. Все derived-артефакты версионируются; raw-данные неизменяемы.

## Pipeline

```text
smartphone pointer/media events
        -> RawEvent stream (append-only)
        -> StrokeSegmenter v1
        -> shape signatures + relation descriptors
        -> token trajectory
        -> OperatorMiner
        -> EidoOperator + evidence + counterexamples
        -> DeterministicRecommender
        -> next-action prototype reference
```

Состояние субъекта хранится независимо:

```text
latent state m_t --unknown--> StateObservation o_t = proxy(m_t)
```

Никакая шкала состояния не считается фундаментальной.

## Запуск

```bash
python -m pip install -e .
python -m unittest discover -s tests -v
```

CLI:

```bash
eidolang analyze examples/sample_session.json
```

## Gate R1

R1 считается содержательно успешным только если на корпусе появляются паттерны `w`, для которых наблюдаемый переход состояния воспроизводимо отличается от baseline и сохраняется на отложенных сессиях.

# R2 — персональный алфавит и эффект-грамматика

R2 добавляет автоматический discovery-проход, который **не присваивает значения формам вручную**.

## Alphabet gate

Исходные stroke signatures рассматриваются как технические токены. Два токена допускается
слить в один `AlphabetSymbol` только если pooled effect predictor на holdout не хуже, чем два
раздельных predictors. Символ сохраняется только если его predictor на holdout лучше глобального
baseline состояния.

```text
raw stroke tokens
   -> train effect estimates
   -> deterministic agglomerative merge
   -> holdout non-inferiority gate
   -> predictive-vs-global-baseline gate
   -> AlphabetSymbol
```

## Grammar gate

После factorization stroke token -> alphabet symbol сессия кодируется как:

```text
A:symbol, R:relation, A:symbol, R:relation, ...
```

Паттерн порядка >=2 становится `EffectGrammarRule`, только если на holdout его transition predictor
строго лучше predictor-а собственного suffix. Это проверяет наличие **контекстного эффекта**, а не
просто частоты последовательности.

## Negative controls

И alphabet, и grammar повторно строятся на детерминированных permutations `session -> state_delta`,
которые сохраняют распределение эффектов, но разрушают связь формы с переходом состояния.
Discovery gate проходит только если реальный holdout gain выше максимального gain предзаданных
controls.

Это сильный, намеренно консервативный gate; `negative_controls` — вычислительный budget протокола,
а не семантический порог.

## Важное ограничение R2

State delta пока относится к сессии целиком. Поэтому найденная буква/грамматическое правило означает
`predictive association with session transition`, а не доказанную причинность отдельного штриха.
Чтобы перейти к причинному оператору, следующая версия должна вводить промежуточные state probes или
рандомизированное/контрбалансированное воспроизведение уже найденных macro-operators.

---

# R3: causal replay

R2 patterns are predictive only. R3 adds randomized replay against an outcome-blind matched motor control.

Core API:

```python
from eidolang import (
    ReplayTemplateBuilder, MatchedControlBuilder,
    balanced_random_assignment, CausalAnalyzer
)
```

Synthetic validation:

```bash
eidolang r3-synthetic --n 16 --seed 731
```

See:
- `R3_METHODOLOGY.md`
- `R3_REPLAY_PROTOCOL.md`
- `R3_CHECKPOINT.md`
- `EXAMPLE_R3_REPORT.json`

R3 deliberately does not promote two efficacious operators to one causal `MacroName`; that requires randomized substitution equivalence in R4.

---

# R4: Causal Substitution Calculus

R4 does not discover more shapes. It tests whether two already-causal R3 operators are actually substitutable.

```text
R3: do(w1) -> target, do(w2) -> target
R4: do(w1) ≃ do(w2) within pre-registered margins and trajectory resolution
```

`CausalMacroName` is formed only from an all-pairs clique of passed substitution certificates. Approximate equivalence is not assumed transitive.
See `R4_METHODOLOGY.md` and `R4_CHECKPOINT.md`.

---

# R4.6 — Multilayer Topological Motifs

R4.6 extends R4.5 from a binary/form topology to the channels that are already explicitly measured
by the smartphone event stream:

```text
FORM + COLOR + AUDIO + HAPTIC
```

It does **not** assign meanings to colors, tones or haptic patterns. Instead it asks whether their
layer topology and their incidence with the topological construction process preserve an externally
certified causal class better than T2 form topology alone.

Commands:

```bash
eidolang multilayer session.json
eidolang r46-synthetic
```

Measured synthetic positive control:

```text
Geometry  0.50
T2        0.50
T3        1.00
negative-control max T3 = 0.833333
PASS
```

See `R4_6_METHODOLOGY.md` and `R4_6_CHECKPOINT.md`.

## R4.8 — Real Corpus Acquisition Gate

Добавлены preregistration hash, deterministic hidden anchor split, per-observer schedule, session admission, tamper-evident ledger, dataset freeze и second-stage evaluation lock. R5 запрещён до появления реального frozen corpus.

## R4.9 — Protocol Fidelity / Instrument Calibration Gate

Добавлены frozen execution plans, device capability profile, actual execution traces, per-step fidelity certificates и явное различие:

`DIGITAL_EXECUTION != PHYSICAL_OUTPUT`.

Абсолютная физическая эквивалентность audio/haptic/visual stimulus допускается только с внешним calibration reference.

## R4.10 — Observer-State Measurement Reliability Gate

R4.10 calibrates the repeatability of the full `anchor -> observed state delta` channel.

It adds:
- frozen repeatability manifest;
- disjoint repeat pairing;
- finite-sample repeatability radii;
- quantization floors;
- exact order-drift test;
- common cross-observer resolution floor;
- a hard gate forbidding R4 equivalence margins below measured resolution.

No decomposition into "true state noise" vs "self-report noise" is claimed without a
separate model.

## R4.11 — Finite-Sample Feasibility Gate

Before real acquisition, R4.11 checks exact-test arithmetic resolution:
`p_floor <= preregistered local alpha <= familywise budget`, while respecting exact enumeration caps.

It also exposes an important semantic boundary:
R4.10's 19-pair 95% radius is marginal per observer/metric. A simultaneous Bonferroni
95% claim over 6 observers × 6 metrics would require 719 disjoint pairs under the current
method and is therefore not silently claimed.

The planned first confirmatory binary cross-observer R5 test needs at least 6 observers:
5 gives exact p-floor 1/16=0.0625; 6 gives 1/32=0.03125.

## R4.12 — Executable Preregistration / Protocol Compiler

A single `MasterStudyManifest` now compiles all confirmatory settings and a runtime lock.

Important correction discovered by dependency compilation:

```text
2 R5 causal classes
× 3 R4 realizations/class
= 6 distinct R3 causal operators / observer
```

Therefore the old standalone design with two R3 operator hypotheses was not cross-stage complete.

The corrected conservative pre-discovery confirmatory lower bound is 179 sessions/observer,
or 1074 sessions for six observers, before free discovery and before any extra power-driven trials.

Use:

```bash
PYTHONPATH=src python tools/r412_compile.py \
  examples/r412_master_manifest.dryrun.json \
  --out compiled_protocol
```

`mode=REAL` rejects synthetic/placeholder anchor specifications.

## R5 — Cross-Observer Topological-Causal Transport

The first confirmatory cross-observer test is now implemented.

Primary statistic:
- full R4.6 T3 distance between complete three-realization MacroNames;
- R4.7-aligned causal effect distance normalized by R4.10 repeatability floors;
- per-observer-pair SAME-vs-CROSS orientation agreement.

For 6 observers the exact null contains all `2^(6-1)=32` observer-wise pairing
conventions. No sampled negative controls enter the primary p-value.

## R6 — Discovery / Confirmation Separation

R5 is now wrapped in an independent two-cohort protocol. Discovery may identify and freeze the binary T3/effect transport hypothesis; confirmation must use disjoint observers, sessions, R3 certificates, R4 substitution certificates, and fresh local MacroNames.

The only object permitted to cross the boundary is the hashed `FrozenTransportHypothesis`. Final PASS requires both a zero-leakage audit and an exact confirmation-cohort R5 PASS.

## R7 — Prospective Class Instantiation / Blinded Matching

Confirmation MacroNames are now selected before primary R5 is opened.

The selector is mechanically derived as:

```text
selector metrics = frozen StateObservation metrics - primary R5 effect metrics
```

and uses independent selector-effect certificates only. T3 and the primary effect endpoints
are structurally unavailable to the matching object.

Discovery freezes prototypes and leave-one-observer-out acceptance/ambiguity envelopes.
Confirmation enumerates all injective mappings into eligible local R4 MacroNames and may
return PASS, NO_MATCH, AMBIGUOUS, or INVALID. There is no post-hoc fallback.


### R7 selector-alignment correction

The selector does not reuse/project the full R4.7 transform. A full-space rotation can mix
sealed primary and selector coordinates, so projection would violate blindness and need not
remain a similarity. R7 therefore requires a separately fitted and holdout-validated
selector-only alignment `Psi_i`. Failure of this gate returns INVALID; there is no fallback.
