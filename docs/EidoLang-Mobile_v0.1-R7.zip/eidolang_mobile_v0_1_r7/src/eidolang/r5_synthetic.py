from __future__ import annotations

import copy
import numpy as np

from .r412_dryrun import dryrun_master, _alignment_observations, _reliability_observations
from .protocol_compiler import ProtocolCompiler, ConfirmatoryRuntime
from .reliability import reliability_gate
from .r46_synthetic import make_cross_observer_examples
from .cross_observer_transport import R5CausalClassObservation


def _clone_session(s,new_id):
    x=copy.deepcopy(s)
    x.session_id=new_id
    return x


def _inverse_map(canonical:dict[str,float], transform):
    if transform is None:
        return dict(canonical)
    keys=transform.metric_keys
    y=np.array([canonical[k] for k in keys],dtype=float)
    r=np.array(transform.rotation,dtype=float)
    x=(y/transform.scale)@r.T
    return {k:float(v) for k,v in zip(keys,x)}


def make_r5_dryrun_inputs(bundle, alignment_report):
    base=make_cross_observer_examples()
    # Map R4.6's observer-specific geometric realizations to compiler observers.
    sess={}
    for e in base:
        oi=int(e.observer_id.split(":")[-1])
        cls="C0" if "split-layers" in e.causal_class else "C1"
        sess[(f"O{oi}",cls)]=e.session

    trs={alignment_report.reference_observer:None}
    for r in alignment_report.results:
        if r.status=="PASS":
            trs[r.observer_id]=r.transform

    keys=next(iter([r.transform.metric_keys for r in alignment_report.results if r.transform is not None]))
    canon0={
        "activation":.10,"valence":.12,"clarity":.18,
        "noise":-.42,"imagery":.08,"focus":.52
    }
    canon1={
        "activation":-.08,"valence":-.03,"clarity":-.10,
        "noise":.31,"imagery":-.06,"focus":-.24
    }
    observations=[]
    for oi,o in enumerate(bundle.r5.observer_ids):
        for ci,base_effect in enumerate((canon0,canon1)):
            true_cls=f"C{ci}"
            # Deliberately reverse lexical local ordering for alternating observers.
            local_id=("A" if ci==(oi%2) else "B")
            src=sess[(o,true_cls)]
            rs=tuple(_clone_session(src,f"{o}:{true_cls}:real:{k}") for k in range(bundle.r5.realizations_per_class))
            eff=[]
            for k in range(bundle.r5.realizations_per_class):
                c=dict(base_effect)
                # small deterministic member variation in common coordinates
                c["focus"] += (k-1)*.004
                c["noise"]  -= (k-1)*.003
                eff.append(_inverse_map(c,trs[o]))
            observations.append(R5CausalClassObservation(
                observer_id=o,
                local_class_id=local_id,
                macro_name_id=f"{o}:macro:{true_cls}",
                macro_name_passed=True,
                realization_sessions=rs,
                operator_effects=tuple(eff),
                operator_causal_certificate_refs=tuple(f"{o}:{true_cls}:causal:{k}" for k in range(3)),
                substitution_certificate_refs=tuple(f"{o}:{true_cls}:subst:{k}" for k in range(3)),
            ))
    return observations


def run_r5_dryrun():
    master=dryrun_master()
    bundle=ProtocolCompiler().compile(master)
    runtime=ConfirmatoryRuntime(bundle)
    alignment=runtime.effect_aligner().align(_alignment_observations(bundle),master.reference_observer_id)
    reliability=reliability_gate(bundle.reliability,_reliability_observations(master,bundle))
    observations=make_r5_dryrun_inputs(bundle,alignment)
    cert=runtime.r5_analyzer(alignment,reliability).certify(observations)
    return master,bundle,alignment,reliability,observations,cert
