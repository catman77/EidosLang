# Android eidogram messenger roadmap after R19

## R14 / R14.1 — Eidogram editor — COMPLETE AT SOURCE LEVEL
Frozen 113-glyph editor, grouping, exact hit testing, canonical drafts/import/export.

## R15 — Identity + encrypted/signed message envelope — COMPLETE
Root/device identity, device certificates, conversation IDs, encrypted signed immutable
message DAG nodes.

## R16 — Torrent archive format — COMPLETE
Immutable segments, BitTorrent-v2 mapping and signed mutable conversation heads.

## R17 — Transport interface / admission — COMPLETE AT SOURCE LEVEL
Transport-neutral admission gate and native libtorrent scaffold. Real network execution stays
deferred until the application layers are finished.

## R18 — Messenger UX + Local Repository — COMPLETE AT SOURCE LEVEL
Contacts, conversations, persistent encrypted-envelope repository, deterministic DAG timeline,
editor-to-send flow and manual file exchange.

## R19 — Archive / Recovery — COMPLETE AT SOURCE LEVEL
- incremental local R16 segment creation;
- segment index and pin/unpin;
- archive browser;
- canonical complete recovery package;
- contacts/conversations with no messages preserved in package metadata;
- destructive same-device recovery;
- segment-only cryptographic recovery;
- deterministic overlap/duplicate handling;
- transaction-style preflight before mutation.

## R20 — Multi-device — NEXT
- root-authorized second/subsequent device certificates;
- explicit device roster per user;
- device authorization/revocation records;
- contact import with multiple certified devices;
- outgoing message recipient boxes for all active devices;
- local user's own active devices as recipients;
- concurrent message heads from multiple local devices;
- deterministic DAG convergence;
- archive/package semantics across devices;
- migration path from R19 same-device recovery limitation.

## R20.1 — Forward-secrecy session layer
- evaluate/introduce ratcheted per-contact/session secrets;
- historical-key erasure;
- stop relying on static RSA recipient keys for historical confidentiality;
- keep `EidogramDocumentV1` unchanged.

## R21 — Security / Fuzzing / local hardening
- database/draft/archive at-rest protection;
- malformed canonical objects;
- certificate/revocation attacks;
- replay/equivocation corpus;
- archive poisoning and overlap adversarial cases;
- parser/JNI fuzzing.

## R22 — Android product completion
- settings/profile UX;
- notifications;
- archive controls/policies;
- Android build/install/device admission;
- finally connect and admit the real R17 BitTorrent/DHT backend.

Final acceptance remains two ordinary Android phones exchanging, archiving and recovering
encrypted eidogram conversations without an application server.
