pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "EidoLangAndroid"
include(
    ":app",
    ":core-model",
    ":core-canonical",
    ":core-render",
    ":core-crypto",
    ":core-message",
    ":core-archive",
    ":core-transport",
    ":core-repository",
    ":core-recovery",
    ":feature-sync",
    ":native-torrent",
    ":feature-library",
    ":feature-editor",
    ":feature-viewer",
    ":feature-messenger",
    ":feature-archive",
)
