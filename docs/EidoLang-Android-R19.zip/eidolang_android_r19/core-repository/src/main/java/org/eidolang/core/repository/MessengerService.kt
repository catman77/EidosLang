package org.eidolang.core.repository

import org.eidolang.core.canonical.EidogramCanonical
import org.eidolang.core.crypto.*
import org.eidolang.core.message.*
import org.eidolang.core.model.EidogramDocumentV1
import java.security.SecureRandom
import java.util.PriorityQueue

data class ContactSummary(
    val userId: String,
    val alias: String,
    val deviceCount: Int,
)

data class ConversationSummary(
    val conversationId: String,
    val title: String,
    val participantUserIds: List<String>,
    val messageCount: Int,
    val headMessageIds: List<String>,
    val latestCreatedAtMs: Long?,
)

data class TimelineItem(
    val messageId: String,
    val senderUserId: String,
    val senderDeviceId: String,
    val senderSeq: Int,
    val createdAtMs: Long,
    val parentMessageIds: List<String>,
    val outgoing: Boolean,
    val localState: MessageLocalState,
    val document: EidogramDocumentV1,
)

class LocalMessengerService(
    private val repository: MessengerRepository,
    val localIdentity: DevicePrivateCrypto,
    private val random: SecureRandom = SecureRandom(),
) {
    fun exportLocalIdentityCanonical(): String =
        IdentityCanonical.publicBundleJson(PublicIdentityBundleV1(localIdentity.user, localIdentity.certificate))

    fun importContact(bundleCanonicalJson: String, alias: String? = null, importedAtMs: Long): ContactSummary {
        require(importedAtMs >= 0)
        val bundle = IdentityParser.parsePublicBundleCanonical(bundleCanonicalJson)
        require(bundle.user.userId != localIdentity.user.userId) { "Local identity is not a contact" }
        val effectiveAlias = alias?.trim()?.takeIf { it.isNotEmpty() } ?: bundle.user.userId.take(12)
        repository.putContact(
            ContactDeviceRecord(
                bundle.user.userId,
                bundle.device.deviceId,
                effectiveAlias,
                bundleCanonicalJson,
                importedAtMs,
            )
        )
        return contactSummaries().first { it.userId == bundle.user.userId }
    }

    fun contactSummaries(): List<ContactSummary> =
        repository.contactDevices()
            .groupBy { it.userId }
            .values
            .map { rows ->
                ContactSummary(rows.first().userId, rows.minBy { it.importedAtMs }.alias, rows.size)
            }
            .sortedWith(compareBy<ContactSummary> { it.alias }.thenBy { it.userId })

    fun createConversation(
        remoteUserIds: Collection<String>,
        seed: ByteArray = JcaCrypto.randomBytes(16, random),
        title: String? = null,
        createdAtMs: Long,
    ): ConversationDescriptorV1 {
        require(createdAtMs >= 0)
        val remote = remoteUserIds.toSortedSet()
        require(remote.isNotEmpty()) { "At least one remote participant is required" }
        val contacts = repository.contactDevices().groupBy { it.userId }
        remote.forEach { require(it in contacts) { "Unknown contact user $it" } }
        val descriptor = ConversationFactory.fromSeed(seed, remote + localIdentity.user.userId)
        val effectiveTitle = title?.trim()?.takeIf { it.isNotEmpty() }
            ?: remote.map { uid -> contacts.getValue(uid).first().alias }.joinToString(", ")
        repository.putConversation(
            ConversationRecord(
                descriptor.conversationId,
                ConversationCanonical.descriptorJson(descriptor),
                effectiveTitle,
                createdAtMs,
            )
        )
        return descriptor
    }

    fun importConversation(descriptorCanonicalJson: String, title: String? = null, createdAtMs: Long): ConversationDescriptorV1 {
        val descriptor = ConversationParser.parseCanonical(descriptorCanonicalJson)
        require(localIdentity.user.userId in descriptor.participantUserIds) { "Local user is not a participant" }
        val contacts = repository.contactDevices().groupBy { it.userId }
        descriptor.participantUserIds.filter { it != localIdentity.user.userId }.forEach {
            require(it in contacts) { "Missing contact identity for participant $it" }
        }
        val effectiveTitle = title?.trim()?.takeIf { it.isNotEmpty() }
            ?: descriptor.participantUserIds.filter { it != localIdentity.user.userId }
                .joinToString(", ") { contacts.getValue(it).first().alias }
        repository.putConversation(
            ConversationRecord(descriptor.conversationId, descriptorCanonicalJson, effectiveTitle, createdAtMs)
        )
        return descriptor
    }

    fun conversationDescriptor(conversationId: String): ConversationDescriptorV1 =
        repository.conversations().firstOrNull { it.conversationId == conversationId }
            ?.let { ConversationParser.parseCanonical(it.descriptorCanonicalJson) }
            ?: error("Unknown conversation $conversationId")

    fun conversationDescriptorCanonical(conversationId: String): String =
        repository.conversations().firstOrNull { it.conversationId == conversationId }?.descriptorCanonicalJson
            ?: error("Unknown conversation $conversationId")

    fun send(
        conversationId: String,
        document: EidogramDocumentV1,
        createdAtMs: Long,
    ): EidogramMessageV1 {
        val conversation = conversationDescriptor(conversationId)
        val recipients = recipientDevices(conversation)
        val seq = nextSenderSeq(conversationId, localIdentity.certificate.deviceId)
        val parents = currentHeads(conversationId)
        val message = MessageCrypto.seal(
            document = document,
            conversation = conversation,
            sender = localIdentity,
            recipients = recipients,
            senderSeq = seq,
            createdAtMs = createdAtMs,
            parentMessageIds = parents,
            random = random,
        )
        // Admission of our own envelope through the same cryptographic boundary.
        val opened = MessageCrypto.open(message, localIdentity.user, localIdentity.certificate, localIdentity, conversation)
        require(EidogramCanonical.contentHash(opened) == EidogramCanonical.contentHash(document))
        storeVerified(message, MessageDirection.OUTGOING, MessageLocalState.READY_FOR_ARCHIVE, createdAtMs)
        return message
    }

    fun admitIncoming(
        envelopeCanonicalJson: String,
        storedAtMs: Long,
        expectedConversationId: String? = null,
    ): InsertMessageResult {
        val message = MessageParser.parseCanonical(envelopeCanonicalJson)
        if (expectedConversationId != null) {
            require(message.body.aad.conversationId == expectedConversationId) { "Message belongs to another conversation" }
        }
        val conversation = conversationDescriptor(message.body.aad.conversationId)
        require(message.body.aad.senderUserId in conversation.participantUserIds)
        val senderBundle = senderBundle(message.body.aad.senderUserId, message.body.aad.senderDeviceId)
        require(MessageCrypto.verify(message, senderBundle.user, senderBundle.device, conversation)) { "Incoming signature/authentication failure" }

        // Strong local admission: the message must actually be decryptable by this local device
        // and must contain a canonical production EidogramDocumentV1.
        MessageCrypto.open(message, senderBundle.user, senderBundle.device, localIdentity, conversation)

        val duplicate = repository.messages(message.body.aad.conversationId).firstOrNull { it.messageId == message.messageId }
        if (duplicate != null) {
            val old = MessageParser.parseCanonical(duplicate.envelopeCanonicalJson)
            require(MessageCanonical.bodyJson(old.body) == MessageCanonical.bodyJson(message.body)) {
                "Same message_id with different message body"
            }
            return InsertMessageResult.Duplicate
        }

        validateGraphInsertion(message)
        return storeVerified(message, MessageDirection.INCOMING, MessageLocalState.ACCEPTED, storedAtMs)
    }

    fun messageCanonical(messageId: String): String =
        repository.conversations().asSequence()
            .flatMap { repository.messages(it.conversationId).asSequence() }
            .firstOrNull { it.messageId == messageId }?.envelopeCanonicalJson
            ?: error("Unknown message $messageId")

    fun latestOutgoingCanonical(conversationId: String): String? =
        repository.messages(conversationId)
            .filter { it.direction == MessageDirection.OUTGOING }
            .maxWithOrNull(compareBy<StoredMessageRecord> { it.createdAtMs }.thenBy { it.senderSeq }.thenBy { it.messageId })
            ?.envelopeCanonicalJson

    fun currentHeads(conversationId: String): List<String> {
        val records = repository.messages(conversationId)
        val ids = records.mapTo(linkedSetOf()) { it.messageId }
        val consumed = records.flatMap { it.parentMessageIds }.filterTo(linkedSetOf()) { it in ids }
        return (ids - consumed).sorted()
    }

    fun timeline(conversationId: String): List<TimelineItem> {
        val conversation = conversationDescriptor(conversationId)
        val records = topological(repository.messages(conversationId))
        return records.map { r ->
            val message = MessageParser.parseCanonical(r.envelopeCanonicalJson)
            val sender = senderBundle(message.body.aad.senderUserId, message.body.aad.senderDeviceId)
            val document = MessageCrypto.open(message, sender.user, sender.device, localIdentity, conversation)
            TimelineItem(
                r.messageId, r.senderUserId, r.senderDeviceId, r.senderSeq,
                r.createdAtMs, r.parentMessageIds,
                outgoing = r.direction == MessageDirection.OUTGOING,
                localState = r.localState,
                document = document,
            )
        }
    }

    fun conversationSummaries(): List<ConversationSummary> =
        repository.conversations().map { r ->
            val d = ConversationParser.parseCanonical(r.descriptorCanonicalJson)
            val msgs = repository.messages(r.conversationId)
            ConversationSummary(
                r.conversationId,
                r.title,
                d.participantUserIds,
                msgs.size,
                currentHeads(r.conversationId),
                msgs.maxOfOrNull { it.createdAtMs },
            )
        }.sortedWith(compareByDescending<ConversationSummary> { it.latestCreatedAtMs ?: Long.MIN_VALUE }
            .thenByDescending { it.conversationId })

    private fun recipientDevices(conversation: ConversationDescriptorV1): List<RecipientPublicDeviceV1> {
        val remoteUsers = conversation.participantUserIds.filter { it != localIdentity.user.userId }.toSet()
        return repository.contactDevices()
            .filter { it.userId in remoteUsers }
            .map { IdentityParser.parsePublicBundleCanonical(it.bundleCanonicalJson) }
            .map { MessageCrypto.recipient(it.device) }
    }

    private fun senderBundle(userId: String, deviceId: String): PublicIdentityBundleV1 {
        if (userId == localIdentity.user.userId && deviceId == localIdentity.certificate.deviceId) {
            return PublicIdentityBundleV1(localIdentity.user, localIdentity.certificate)
        }
        return repository.contactDevices()
            .firstOrNull { it.userId == userId && it.deviceId == deviceId }
            ?.let { IdentityParser.parsePublicBundleCanonical(it.bundleCanonicalJson) }
            ?: error("Unknown sender device $userId/$deviceId")
    }

    private fun nextSenderSeq(conversationId: String, deviceId: String): Int =
        (repository.messages(conversationId)
            .filter { it.senderDeviceId == deviceId }
            .maxOfOrNull { it.senderSeq } ?: -1) + 1

    private fun storeVerified(
        message: EidogramMessageV1,
        direction: MessageDirection,
        state: MessageLocalState,
        storedAtMs: Long,
    ): InsertMessageResult {
        val canonical = MessageCanonical.envelopeJson(message)
        return repository.insertMessage(
            StoredMessageRecord(
                message.messageId,
                message.body.aad.conversationId,
                message.body.aad.senderUserId,
                message.body.aad.senderDeviceId,
                message.body.aad.senderSeq,
                message.body.aad.createdAtMs,
                message.body.aad.parentMessageIds,
                canonical,
                direction,
                state,
                storedAtMs,
            )
        )
    }

    private fun validateGraphInsertion(message: EidogramMessageV1) {
        require(message.messageId !in message.body.aad.parentMessageIds) { "Self-parent message" }
        val existing = repository.messages(message.body.aad.conversationId)
        val candidate = existing + StoredMessageRecord(
            message.messageId,
            message.body.aad.conversationId,
            message.body.aad.senderUserId,
            message.body.aad.senderDeviceId,
            message.body.aad.senderSeq,
            message.body.aad.createdAtMs,
            message.body.aad.parentMessageIds,
            MessageCanonical.envelopeJson(message),
            MessageDirection.INCOMING,
            MessageLocalState.ACCEPTED,
            0,
        )
        // This also detects a cycle that becomes visible only when a formerly missing parent arrives.
        topological(candidate)
    }

    private fun topological(records: List<StoredMessageRecord>): List<StoredMessageRecord> {
        if (records.isEmpty()) return emptyList()
        val byId = records.associateBy { it.messageId }
        require(byId.size == records.size)
        val children = byId.keys.associateWith { mutableListOf<String>() }
        val indegree = byId.keys.associateWith { 0 }.toMutableMap()
        records.forEach { child ->
            child.parentMessageIds.filter { it in byId }.forEach { parent ->
                children.getValue(parent).add(child.messageId)
                indegree[child.messageId] = indegree.getValue(child.messageId) + 1
            }
        }
        val cmp = compareBy<String>(
            { byId.getValue(it).createdAtMs },
            { byId.getValue(it).senderUserId },
            { byId.getValue(it).senderSeq },
            { it },
        )
        val ready = PriorityQueue(cmp)
        indegree.filterValues { it == 0 }.keys.forEach(ready::add)
        val out = mutableListOf<StoredMessageRecord>()
        while (ready.isNotEmpty()) {
            val id = ready.remove()
            out += byId.getValue(id)
            children.getValue(id).sorted().forEach { child ->
                val n = indegree.getValue(child) - 1
                indegree[child] = n
                if (n == 0) ready.add(child)
            }
        }
        require(out.size == records.size) { "Message DAG contains a cycle" }
        return out
    }
}
