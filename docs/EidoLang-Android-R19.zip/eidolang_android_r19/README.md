# EidoLang Android R18

Android eidogram messenger source tree.

## Frozen eidographic content
- `EidoGlyphCatalogV1`: 113 glyphs
- glyph catalog hash: `da2d3b72ff8d41abb8c293ce1deca44e99cb1d1a696e9834997395c6f6218005`
- production grammar hash: `d5afb09e6ecdcff8a4b2c9758af83f215059d1b5bc4ad32da3fb8dd191b69b19`

## Current stack
- R14/R14.1: canonical eidogram editor
- R15: root/device identities and encrypted signed message envelopes
- R16: immutable torrent archive format and mutable heads
- R17: transport abstraction/admission and native torrent scaffold
- **R18: local messenger repository and UX**

## R18 modules
- `core-repository` — contacts, conversations, encrypted message DAG, SQLite adapter
- `feature-viewer` — read-only eidogram renderer
- `feature-messenger` — contacts/conversations/timeline/composer flows

`app` now starts `EidoMessengerApp`, not the standalone editor.

## Manual no-network interoperability
R18 can be exercised on two devices by exporting/importing the exact public identity, conversation descriptor and encrypted message envelope files. See `R18_MANUAL_EXCHANGE.md`.

## Validation
Pure Kotlin/JCA/archive regressions on the final R18 tree total 49 PASS lines. Android SDK/emulator execution is not claimed. See `R18_CHECKPOINT.md` and `R18_VALIDATION.md`.

## Build pins inherited from R14
- compileSdk / targetSdk: 37
- AGP: 9.3.0
- Gradle target: 9.5.0
- Kotlin / Compose compiler plugin: 2.3.21
- Compose BOM: 2026.06.00
- minSdk: 26
- Java target: 17

## R19 — Archive / Recovery

R19 adds incremental R16 segment creation from the local messenger repository, persistent
archive indexing/pinning, a complete canonical recovery package, an archive browser, and
same-device destructive recovery. Private keys are not exported. See `R19_METHODOLOGY.md` and
`R19_RECOVERY_PROTOCOL.md`.
