# EidoLang-Mobile v0.1-R13.1

This package freezes **EidoGlyphCatalogV1** and updates the roadmap from generic geometric primitives to a finite glyph inventory for the Android eidogram messenger.

Artifacts:
- `EIDO_GLYPH_CATALOG_V1.json` — canonical glyph catalog.
- `EIDO_GLYPH_CATALOG_V1.md` — human-readable spec.
- `EXAMPLE_EIDOGRAM_DOCUMENT_V1.json` — example document using glyph IDs.
- `ANDROID_PROJECT_STRUCTURE_V1.md` — concrete Android project/module structure.
- `ANDROID_TORRENT_MESSENGER_ROADMAP.md` — updated roadmap.
- `R13_1_METHODOLOGY.md` / `R13_1_CHECKPOINT.md` — methodology + checkpoint.
