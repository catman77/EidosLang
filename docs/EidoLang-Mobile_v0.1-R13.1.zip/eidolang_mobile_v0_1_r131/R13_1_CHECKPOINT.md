# R13.1 checkpoint — Glyph Catalog Binding

Status: FROZEN

Core decision:
- Generic `ShapeLibraryV1` is replaced by finite `EidoGlyphCatalogV1`.
- Every editable element in the Android eidogram editor is a `glyph_id` from the frozen catalog.

Frozen families:
1. colored_circle = 30 glyphs
2. black_dot = 3 glyphs
3. black_stick = 72 glyphs
4. black_outline = 8 glyphs

Total:
- 113 base glyphs

Design constraints:
- no arbitrary RGB
- no freehand drawing in the wire/content layer
- no bitmap glyphs
- no float geometry
- Android renderer must be byte/hash-conformant with the Python reference catalog
