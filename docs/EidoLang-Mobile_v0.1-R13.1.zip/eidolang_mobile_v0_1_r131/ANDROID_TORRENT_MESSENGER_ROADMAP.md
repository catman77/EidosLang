# Updated roadmap to Android eidogram messenger

## Current status
- R12 fixed production grammar lineage.
- R13 fixed document format.
- R13.1 freezes the finite base glyph inventory.

## Roadmap

### R14 — Android Editor MVP
Deliverables:
- Kotlin/Compose Android project scaffold
- frozen `EidoGlyphCatalogV1` bundled in assets
- glyph picker grouped by family
- canvas editor using fixed-point coordinates internally
- add/move/rotate/scale/group/reorder/delete
- undo/redo with deterministic action log
- Kotlin conformance tests against Python golden vectors

### R15 — Message Envelope & Identity
- user identity keys
- `EidogramMessageV1`
- signatures
- encrypted conversation items
- conversation heads and receipts

### R16 — Archive / Torrent data model
- immutable `ConversationSegment`
- manifest format
- mapping from message/content hashes to segment members
- mutable head pointer for latest conversation state

### R17 — Torrent sync engine on Android
- native/JNI torrent integration
- DHT discovery
- verification, seeding, storage quotas, sync scheduling

### R18 — Messenger UX
- contacts
- conversation list
- send/receive eidograms
- archive browser and pinned content

### R19 — Recovery and archive browser
- restore history from torrent archive
- search by hash/date/conversation
- local cache management

### R20 — Multi-device and merge
- device subkeys
- deterministic merge of concurrent histories
- revocation

### R21 — Security and hostile-network audit
- malformed documents
- forged heads
- stale DHT pointers
- oversized segments
- replay and duplication

### R22 — Android 1.0
Two Android devices can create, exchange, archive, and recover eidogram conversations without an application server.
