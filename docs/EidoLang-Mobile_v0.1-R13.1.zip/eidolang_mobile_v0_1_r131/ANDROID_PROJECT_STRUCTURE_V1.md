# Android project structure v1

## Root modules
- `app/` — Android application shell
- `core-model/` — immutable content/domain models (`EidogramDocumentV1`, `GlyphCatalog`, `PaletteV1`)
- `core-canonical/` — canonical JSON, hashing, fixed-point utilities
- `core-render/` — glyph rendering primitives for Compose canvas
- `feature-editor/` — eidogram editor UI and action/reducer logic
- `feature-viewer/` — read-only eidogram viewer
- `feature-library/` — glyph picker / palette browser
- `feature-messages/` — later message-envelope layer
- `feature-torrent/` — later torrent/archive sync layer
- `androidTest-goldens/` — conformance tests against R13 golden vectors

## Editor architecture

### Domain object
\[
EditorState = (Document, Selection, Tool, UndoStack, RedoStack)
\]

### Tools
- select/move
- rotate
- scale
- reorder z
- group/ungroup
- add glyph from catalog
- delete glyph

### Non-goals for MVP
- freehand drawing
- arbitrary color picker
- arbitrary polygon authoring
- image attachment as eidogram base element
