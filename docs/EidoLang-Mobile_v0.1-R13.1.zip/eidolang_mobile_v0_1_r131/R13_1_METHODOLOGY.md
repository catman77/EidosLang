# R13.1 methodology — finite eidographic base vocabulary

## Goal
Freeze the exact base vocabulary for the Android eidogram messenger so that the editor, document format, and future transport/archive layers all target the same finite set of glyphs.

## Principle
The user should compose eidograms from **ready-made canonical glyphs**, not from unconstrained graphics primitives.

Therefore the message object is not:
- arbitrary SVG,
- freehand raster/vector drawing,
- unbounded shape generation.

It is:

\[
oxed{
GlyphInstance = (glyph\_id, position, scale, rotation, z\_index, group\_id)
}
\]

where `glyph_id` must belong to `EidoGlyphCatalogV1`.

## Families
### 1. Colored circles
- 10 colors: 7 rainbow + white + gray + black
- 3 sizes: s, m, l
- total: 30

### 2. Black dots
- 3 sizes
- total: 3

### 3. Black sticks
- 8 poses: 0,45,90,135,180,225,270,315 degrees
- 3 lengths
- 3 thicknesses
- total: 72

### 4. Black outlines
- triangle
- square
- rectangle
- diamond
- circle
- ellipse
- cross
- plus
- total: 8

## Total vocabulary
\[
30 + 3 + 72 + 8 = oxed{113}
\]

## Serialization consequence
R13 document instances should reference glyphs by ID. The editor may still allow placement, scaling, rotation, grouping, and z-ordering, but it must not silently create new base glyph types.
