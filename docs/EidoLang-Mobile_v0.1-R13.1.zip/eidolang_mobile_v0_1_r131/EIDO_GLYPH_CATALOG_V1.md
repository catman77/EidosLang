# EidoGlyphCatalogV1

Catalog hash: `3585215ae8fc695f4258a9dc3c08484f9e536674c71ac7ed85175203e0fc7860`

## Summary

| Family | Count | Notes |
|---|---:|---|
| colored_circle | 30 | 10 colors × 3 sizes |
| black_dot | 3 | 3 sizes |
| black_stick | 72 | 8 poses × 3 lengths × 3 thicknesses |
| black_outline | 8 | outline-only black contour primitives |
| **Total** | **113** | |

## PaletteV1

| Index | Name | Hex |
|---:|---|---|
| 0 | red | `#E53935` |
| 1 | orange | `#FB8C00` |
| 2 | yellow | `#FDD835` |
| 3 | green | `#43A047` |
| 4 | cyan | `#00ACC1` |
| 5 | blue | `#1E88E5` |
| 6 | violet | `#8E24AA` |
| 7 | white | `#FFFFFF` |
| 8 | gray | `#9E9E9E` |
| 9 | black | `#000000` |

## Circle sizes

| Token | Diameter (fp) |
|---|---:|
| s | 60000 |
| m | 90000 |
| l | 135000 |

## Dot sizes

| Token | Diameter (fp) |
|---|---:|
| s | 24000 |
| m | 36000 |
| l | 54000 |

## Stick parameters

- Poses: pose000, pose045, pose090, pose135, pose180, pose225, pose270, pose315
- Lengths: s, m, l
- Thicknesses: thin, normal, thick

## Outline shapes

- `triangle`
- `square`
- `rectangle`
- `diamond`
- `circle`
- `ellipse`
- `cross`
- `plus`

## Example glyph IDs

- `circle.red.s`
- `circle.violet.l`
- `dot.black.m`
- `stick.black.pose045.m.normal`
- `outline.triangle`
- `outline.plus`
