# Roadmap — Android eidogram messenger with BitTorrent archive

## Product target

The final product is a native Android messenger in which the primary message payload is an eidogram, not text.

The MVP editor uses only ready-made geometric primitives and a fixed versioned color palette. The palette has no built-in semantic labels. Freehand drawing is not required for MVP.

The canonical transport and archive are decentralized and content-addressed through the BitTorrent/DHT stack. A central application server is not required for message history.

## Frozen architectural constraints inherited from R12

Every `EidogramDocument`, message event and torrent archive manifest must carry:

- `production_grammar_spec_hash`;
- `production_grammar_binding_hash`;
- product schema version.

A document created under another grammar is still viewable as historical content, but cannot be silently reinterpreted as current production grammar.

## R13 — Eidogram Document Format v1

Deliverable: deterministic, portable document model independent of Android UI.

`EidogramDocumentV1` should contain:

- normalized canvas coordinates;
- ordered scene graph;
- primitive IDs and stable UUIDs;
- primitive kind;
- transform: position, scale, rotation;
- fill/stroke palette entries;
- z-order and grouping;
- overlap/enclosure relations derivable from geometry;
- complete edit/action history, because construction order is part of the current eidographic model;
- production grammar hashes;
- canonical serialization and content hash.

Initial primitive vocabulary:

- point/dot;
- line/segment;
- triangle;
- square/rectangle;
- circle/ellipse.

The format should allow later addition of new primitives by schema version, but MVP does not need freehand paths.

`PaletteV1` is fixed and versioned. Users choose entries; arbitrary RGB creation is disabled in MVP. The exact palette is a product-level UI vocabulary, not a claim that colors have universal semantic meanings.

Exit gate: the same document serialized on Python reference code and Android produces the same canonical content hash.

## R14 — Android editor core

Native Android implementation in Kotlin with Jetpack Compose.

Screens:

- eidogram canvas;
- primitive palette;
- color palette;
- layer/order controls;
- transform handles;
- undo/redo through the action log;
- preview/send.

The Android renderer is a view of `EidogramDocumentV1`; UI state is not the source of truth.

Exit gate: create/edit/save/reopen produces byte-identical canonical document content.

## R15 — Identity, conversation and cryptographic envelope

Introduce device/user identity and signed conversation events.

Objects:

- `IdentityKey`;
- `ConversationId`;
- `ConversationEvent`;
- `EidogramMessage`;
- `ReceiptEvent`;
- `ConversationHead`.

Every event forms an append-only hash chain or DAG and includes the previous accepted head(s).

Because torrent swarms and DHT are public discovery mechanisms, message payloads must be encrypted before publication. Torrent pieces contain ciphertext, not plaintext eidograms. Signature/authentication and encryption-key management are separate from the scientific meaning layer.

Exit gate: two local test identities exchange encrypted/signed eidogram events and independently reconstruct the same conversation state.

## R16 — Torrent archive format

Canonical immutable archive unit: `ConversationSegment`.

A segment batches multiple encrypted message events rather than creating one torrent per tiny message. This reduces torrent metadata and swarm overhead.

Recommended protocol structure:

- BitTorrent v2 torrent metadata for immutable segments;
- DHT peer discovery;
- a signed mutable DHT head containing the newest segment/manifest pointer and monotonically increasing sequence;
- every segment references its predecessor, so the entire archive is verifiable from the current head.

The mutable DHT object should be small and contain only identifiers/hash pointers, not the actual conversation history.

Exit gate: delete all local history on device B, retain only conversation identity/head information, then reconstruct the full encrypted archive from torrents and verify every event hash.

## R17 — Torrent sync engine on Android

Native torrent engine integrated through Android NDK/JNI or another production-quality native bridge.

Responsibilities:

- magnet/metainfo handling;
- DHT bootstrap;
- peer discovery;
- torrent v2 verification;
- seeding downloaded conversation segments;
- signed mutable-head publication/lookup;
- storage quotas;
- retry/backoff;
- Wi-Fi/mobile-data policy;
- battery-aware synchronization.

Android background constraints mean synchronization must be split into:

- short/persistent sync jobs for ordinary background operation;
- explicitly user-visible long-running seeding mode when continuous operation is requested.

Exit gate: two Android devices with no application server can exchange and recover conversation segments over the public or test DHT/torrent network.

## R18 — Messenger UX

Screens:

- identities/contacts;
- conversation list;
- conversation timeline;
- eidogram viewer;
- eidogram reply/edit-copy;
- editor;
- sync/seeding status;
- archive status.

Timeline items display eidograms directly, with optional metadata below them. Text can later be added as an auxiliary channel, but the primary message object remains the eidogram.

Exit gate: ordinary end-to-end use requires no developer tools.

## R19 — Decentralized archive browser

Add:

- local full-text/metadata index where applicable;
- search by date/contact/document hash;
- visual gallery of eidograms;
- pin/unpin archive segments;
- export/import magnet identifiers;
- deterministic recovery from identity keys + conversation heads;
- optional long-term seed policy.

No central cloud backup is required for canonical history.

## R20 — Multi-device and conflict semantics

A single identity may have multiple devices. Concurrent publications therefore require deterministic merge semantics rather than last-write-wins data loss.

Implement:

- device subkeys;
- multi-head conversation DAG;
- deterministic merge order for display;
- revocation/key rotation;
- replay protection;
- duplicate suppression.

Exit gate: two devices belonging to the same user can send concurrently while offline and later converge to the same archive state.

## R21 — Security and hostile-network audit

Threat model must include:

- malicious DHT records;
- stale/replayed mutable heads;
- poisoned torrents;
- metadata leakage;
- malicious peers;
- corrupted local DB;
- key loss/revocation;
- denial-of-service through huge archives or candidate magnets.

Hard limits and verification are part of the wire format, not UI heuristics.

Exit gate: adversarial corpus + fuzz/property tests + deterministic recovery tests.

## R22 — Android MVP / 1.0

MVP definition:

1. create identity;
2. exchange/add contact information;
3. open conversation;
4. compose eidogram from fixed geometric primitives and fixed palette;
5. send it;
6. second Android device receives it through torrent/DHT transport;
7. reply with another eidogram;
8. both devices show the same signed timeline;
9. conversation history can be deleted locally and restored from the torrent archive;
10. every document/message/archive object carries the R12 production grammar lineage.

## Implementation order

The critical path is:

`R12 root binding -> R13 document format -> R14 editor -> R15 signed/encrypted event log -> R16 torrent archive -> R17 Android torrent sync -> R18 messenger UX -> R19 archive browser -> R20 multi-device -> R21 security audit -> R22 1.0`.

The research grammar should not be expanded merely to make the app prettier. Product primitives/palette are UI/document vocabulary; scientific grammar changes still require the R9 -> R10 -> R11 -> R12 admission loop.
