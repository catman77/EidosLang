package org.eidolang.app

import androidx.compose.ui.test.assertExists
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import org.junit.Rule
import org.junit.Test

class MessengerSmokeTest {
    @get:Rule
    val rule = createAndroidComposeRule<MainActivity>()

    @Test
    fun messengerHomeAndContactsNavigationAreVisible() {
        rule.onNodeWithText("Эйдограммы").assertExists()
        rule.onNodeWithText("Архив").assertExists()
        rule.onNodeWithText("Импорт диалога").assertExists()
        rule.onNodeWithText("Контакты").assertExists().performClick()
        rule.onNodeWithText("Мой контакт").assertExists()
        rule.onNodeWithText("Импорт").assertExists()
    }

    @Test
    fun archiveNavigationIsVisible() {
        rule.onNodeWithText("Архив").assertExists().performClick()
        rule.onNodeWithText("Архивировать").assertExists()
        rule.onNodeWithText("Импорт").assertExists()
    }
}
