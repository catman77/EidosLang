# Android eidogram messenger roadmap after R20.1

## R14–R20 — COMPLETE AT SOURCE/PROTOCOL CORE LEVEL
Editor, identities, encrypted message DAG, archive format, local repository, recovery and
multi-device convergence remain regression-protected.

## R20.1 — Forward-Secrecy Session Layer — COMPLETE AT CORE LEVEL
- signed asynchronous P-256 prekey bundles;
- one-time prekeys;
- P-256 ECDH + HKDF-SHA256 root KDF;
- per-message symmetric chain keys;
- recurring DH ratchet;
- out-of-order skipped-key store;
- consumed key erasure;
- transactional AEAD receive;
- encrypted Android session/prekey secret persistence;
- outer session wrapping of canonical R15/R20 message envelopes;
- fixed golden + independent Python cross-check.

## R20.2 — Forward-Secure History Vault / Archive Migration — NEXT

Necessity is proved by `R20_1_ARCHIVE_NO_GO.md`.

Required:
- independent history/recovery key domain;
- local decrypted-history vault encrypted independently of active ratchet state;
- explicit recovery-key threat model;
- archive objects that do not expose inner long-term-RSA-decryptable R15 envelopes;
- migration from R16/R19 legacy archive objects;
- multi-device history-vault key distribution/revocation;
- destructive recovery after old session keys have been erased;
- proof that active ratchet-state compromise alone cannot decrypt archived history.

## R21 — Security / fuzzing / local hardening
- formal/adversarial ratchet state tests;
- malicious prekey bundles;
- packet/header substitution;
- skipped-key DoS corpus;
- state rollback/corruption;
- vault compromise boundaries;
- parser/JNI fuzzing.

## R22 — Product completion
- secondary-device onboarding UX;
- prekey publication/refresh UX/background jobs;
- settings/profile/device management;
- notifications;
- Android build/install/device admission;
- real R17 BitTorrent/DHT integration only after application/protocol layers are complete.
