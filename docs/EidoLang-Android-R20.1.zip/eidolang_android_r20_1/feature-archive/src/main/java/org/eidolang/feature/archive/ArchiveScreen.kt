package org.eidolang.feature.archive

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.eidolang.core.recovery.ArchiveCoordinator
import org.eidolang.core.recovery.ArchiveConversationResult
import org.eidolang.core.repository.LocalMessengerService

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArchiveScreen(
    archive: ArchiveCoordinator,
    messenger: LocalMessengerService,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var revision by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf<String?>(null) }
    val summaries = remember(revision) { archive.summaries() }
    val titles = remember(revision) { messenger.conversationSummaries().associate { it.conversationId to it.title } }

    fun refresh() { revision++ }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            runCatching {
                archive.archiveAll(System.currentTimeMillis())
                val canonical = archive.exportPackageCanonical()
                context.contentResolver.openOutputStream(uri)!!.use { out ->
                    out.write(canonical.toByteArray(Charsets.UTF_8))
                }
            }.onSuccess { status = "Архив экспортирован" }
                .onFailure { status = "Ошибка экспорта архива: ${it.message}" }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            runCatching {
                val canonical = context.contentResolver.openInputStream(uri)!!
                    .bufferedReader(Charsets.UTF_8).use { it.readText() }
                archive.importAndRestorePackage(canonical, System.currentTimeMillis())
            }.onSuccess {
                status = "Восстановлено: ${it.uniqueMessageCount} сообщений, ${it.segmentCount} сегментов"
                refresh()
            }.onFailure { status = "Архив отклонён: ${it.message}" }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Архив") },
                navigationIcon = { TextButton(onClick = onBack) { Text("←") } },
                actions = {
                    TextButton(onClick = {
                        runCatching { archive.archiveAll(System.currentTimeMillis()) }
                            .onSuccess { created ->
                                status = if (created.isEmpty()) "Новых сообщений для архива нет" else "Создано сегментов: ${created.size}"
                                refresh()
                            }
                            .onFailure { status = "Ошибка архивации: ${it.message}" }
                    }) { Text("Архивировать") }
                    TextButton(onClick = { exportLauncher.launch("eidolang-archive.json") }, enabled = summaries.isNotEmpty()) {
                        Text("Экспорт")
                    }
                    TextButton(onClick = { importLauncher.launch(arrayOf("application/json")) }) { Text("Импорт") }
                }
            )
        },
        modifier = modifier,
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            status?.let {
                Text(
                    it,
                    Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (summaries.isEmpty()) {
                Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
                    Text("Архивных сегментов пока нет.")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {
                        runCatching { archive.archiveAll(System.currentTimeMillis()) }
                            .onSuccess { refresh(); status = "Создано сегментов: ${it.size}" }
                            .onFailure { status = "Ошибка архивации: ${it.message}" }
                    }) { Text("Архивировать локальную историю") }
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(summaries, key = { it.segmentId }) { s ->
                        ListItem(
                            headlineContent = { Text(titles[s.conversationId] ?: s.conversationId.take(12)) },
                            supportingContent = {
                                Text(
                                    "${s.messageCount} сообщ. · ${s.segmentId.take(12)}…\n" +
                                        "v2 ${s.torrentInfoHashV2.take(12)}… · ${s.byteLength} байт"
                                )
                            },
                            trailingContent = {
                                FilterChip(
                                    selected = s.pinned,
                                    onClick = {
                                        runCatching { archive.setPinned(s.segmentId, !s.pinned) }
                                            .onSuccess { refresh() }
                                            .onFailure { status = "Ошибка pin: ${it.message}" }
                                    },
                                    label = { Text(if (s.pinned) "Pinned" else "Pin") },
                                )
                            },
                        )
                        HorizontalDivider()
                    }
                    item {
                        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = {
                                runCatching { archive.restoreFromStoredSegments(System.currentTimeMillis()) }
                                    .onSuccess {
                                        status = "Проверено/восстановлено: ${it.uniqueMessageCount} сообщений"
                                        refresh()
                                    }
                                    .onFailure { status = "Восстановление отклонено: ${it.message}" }
                            }) { Text("Проверить и восстановить") }
                        }
                    }
                }
            }
        }
    }
}
