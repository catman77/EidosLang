package org.eidolang.core.repository

data class ContactDeviceRecord(
    val userId: String,
    val deviceId: String,
    val alias: String,
    val bundleCanonicalJson: String,
    val importedAtMs: Long,
)


data class OwnDeviceRecord(
    val userId: String,
    val deviceId: String,
    val bundleCanonicalJson: String,
    val importedAtMs: Long,
)

data class DeviceRosterRecord(
    val userId: String,
    val epoch: Int,
    val rosterId: String,
    val rosterCanonicalJson: String,
    val importedAtMs: Long,
)

data class MessageKeyGrantRecord(
    val messageId: String,
    val targetEncryptionKeyId: String,
    val grantCanonicalJson: String,
    val storedAtMs: Long,
)

data class ConversationRecord(
    val conversationId: String,
    val descriptorCanonicalJson: String,
    val title: String,
    val createdAtMs: Long,
)

enum class MessageDirection { OUTGOING, INCOMING }
enum class MessageLocalState { READY_FOR_ARCHIVE, ACCEPTED, ARCHIVED }

data class StoredMessageRecord(
    val messageId: String,
    val conversationId: String,
    val senderUserId: String,
    val senderDeviceId: String,
    val senderSeq: Int,
    val createdAtMs: Long,
    val parentMessageIds: List<String>,
    val envelopeCanonicalJson: String,
    val direction: MessageDirection,
    val localState: MessageLocalState,
    val storedAtMs: Long,
)

sealed interface InsertMessageResult {
    data object Inserted : InsertMessageResult
    data object Duplicate : InsertMessageResult
}

interface MessengerRepository {
    fun putContact(record: ContactDeviceRecord)
    fun contactDevices(): List<ContactDeviceRecord>

    fun putOwnDevice(record: OwnDeviceRecord)
    fun ownDevices(): List<OwnDeviceRecord>

    fun putDeviceRoster(record: DeviceRosterRecord)
    fun deviceRosters(): List<DeviceRosterRecord>

    fun putKeyGrant(record: MessageKeyGrantRecord)
    fun keyGrants(messageId: String? = null): List<MessageKeyGrantRecord>

    fun putConversation(record: ConversationRecord)
    fun conversations(): List<ConversationRecord>

    fun insertMessage(record: StoredMessageRecord): InsertMessageResult
    fun messages(conversationId: String): List<StoredMessageRecord>
}
