# Android eidogram messenger roadmap after R20.2

## R14–R20.2 — protocol/core stack complete through forward-secure recovery

The product now has:
- deterministic eidogram editor/document format;
- user/device identity;
- encrypted/signed immutable message DAG;
- multi-device authorization/revocation;
- asynchronous forward-session ratchet;
- local messenger repository/timeline;
- legacy torrent/archive formats;
- destructive recovery;
- independent forward-secure history-vault archive and legacy migration.

## R20.2 — History Vault — COMPLETE AT CORE LEVEL

The R20.1 no-go is resolved with an independent recovery secret domain.

After verified migration and deletion of legacy R16/R19 copies:

\[
Compromise(CurrentSessionState) \not\Rightarrow HistoricalArchivePlaintext.
\]

A new authorized device can destructively recover the same message DAG and documents without
the old R15 RSA key or R20 historical message-key grants.

## R21 — Security / Fuzzing / Local Hardening — NEXT

Required work is now driven by measured/proved obligations rather than new product features:

1. recovery-secret handling:
   - passphrase/offline/QR wrapping;
   - no raw-secret default export;
   - confirmation and loss warnings;
   - recovery-secret compromise/rotation procedure;
2. vault adversarial corpus:
   - epoch rollback/fork;
   - package downgrade;
   - entry/header substitution;
   - cross-vault ciphertext substitution;
   - device-grant substitution;
   - malicious roster combinations;
   - truncated/missing-parent DAG;
3. ratchet hardening:
   - skipped-key DoS bounds;
   - state rollback/corruption;
   - prekey/session cross-domain substitution;
4. local at-rest protection:
   - repository metadata and drafts;
   - vault temporary plaintext lifetime;
   - backup/export temporary files;
5. migration cutover:
   - verify-new-archive-before-delete workflow;
   - explicit detection/listing of locally retained legacy archives;
6. parser/native fuzzing.

## R22 — Product completion

- first-run identity and secondary-device onboarding;
- recovery-secret backup/unlock UX;
- device/revocation management UI;
- prekey refresh jobs;
- notifications/settings;
- archive policy UI;
- Android build/install/device admission;
- finally connect the already isolated R17 BitTorrent/DHT transport adapter.
