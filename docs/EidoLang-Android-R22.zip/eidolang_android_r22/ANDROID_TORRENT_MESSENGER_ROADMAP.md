# Android eidogram messenger roadmap after R22

## R14–R21 — protocol/core complete

Completed source/core layers:
- deterministic eidogram documents/editor;
- user/device identity;
- encrypted/signed immutable message DAG;
- archive/torrent object format;
- local messenger/repository;
- multi-device authorization/revocation;
- forward-session ratchet;
- independent history-vault recovery;
- legacy migration/cutover;
- recovery backup and rollback hardening.

## R22 — product source integration complete

Added:
- first-launch primary/secondary onboarding;
- device enrollment/authorization/revocation UI;
- secure-vault/recovery UI;
- explicit fresh-restore freshness warning;
- encrypted recovery backup/code UX;
- verified legacy cutover workflow;
- SQLite v3 alias/title field protection;
- Android runtime diagnostics;
- Android platform-backup/cleartext hardening.

Pure/product validation: 180 executed PASS lines including the complete prior regression.

## R22.1 — Android device admission — NEXT

No new protocol design should occur unless an actual Android counterexample forces it.

Required:

1. provide Android SDK + pinned Gradle wrapper/runtime;
2. `:app:assembleDebug`;
3. `:app:connectedDebugAndroidTest`;
4. install on a clean primary device/emulator;
5. run Diagnostics → `ADMISSION PASS`;
6. exercise first-run secondary enrollment between two Android installs;
7. exercise SQLite v2→v3 migration on a populated legacy database;
8. export/restore secure vault with recovery backup/code;
9. verify fresh restore displays `FRESHNESS UNPROVEN`;
10. verify device revocation and fresh vault epoch;
11. verify legacy cutover rejects the exact retired R19 artifact.

## Final network admission

Real R17 BitTorrent/DHT execution remains intentionally last and separate.

After local two-device Android admission succeeds, connect the transport adapter and require:

\[
TwoAndroidDevices
\land SameMessageDAG
\land ForwardSession
\land RecoverableHistoryVault
\land VerifiedCutover
\land NoApplicationServer.
\]
