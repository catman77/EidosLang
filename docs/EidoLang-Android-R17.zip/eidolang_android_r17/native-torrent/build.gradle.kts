plugins { alias(libs.plugins.android.library); alias(libs.plugins.kotlin.android) }
android { namespace="org.eidolang.native.torrent"; compileSdk=37; defaultConfig { minSdk=26 }
    compileOptions { sourceCompatibility=JavaVersion.VERSION_17; targetCompatibility=JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget="17" }
}
dependencies { implementation(project(":core-transport")); implementation(project(":core-archive")) }
