package org.eidolang.core.archive

import org.eidolang.core.canonical.CanonicalJson
import org.eidolang.core.crypto.*
import java.security.*

/** Binds a BEP44 Ed25519 public key to an already authorized R15 device identity. */
data class ArchivePublisherCertificateV1(
    val userId: String,
    val deviceId: String,
    val dhtPublicKeyRawB64: String,
    val publisherKeyId: String,
    val deviceSignatureB64: String,
)

object Ed25519Raw {
    // SubjectPublicKeyInfo prefix for Ed25519: 302a300506032b6570032100
    private val X509_PREFIX = byteArrayOf(0x30,0x2a,0x30,0x05,0x06,0x03,0x2b,0x65,0x70,0x03,0x21,0x00)
    fun raw(publicKey: PublicKey): ByteArray {
        val e = publicKey.encoded
        require(e.size == X509_PREFIX.size + 32 && e.copyOfRange(0, X509_PREFIX.size).contentEquals(X509_PREFIX)) { "unexpected Ed25519 X509 encoding" }
        return e.copyOfRange(X509_PREFIX.size, e.size)
    }
    fun publicKey(raw: ByteArray): PublicKey {
        require(raw.size == 32)
        return KeyFactory.getInstance("Ed25519").generatePublic(java.security.spec.X509EncodedKeySpec(X509_PREFIX + raw))
    }
}

object ArchivePublisherCanonical {
    fun bodyJson(userId: String, deviceId: String, dhtPublicKeyRawB64: String): String = CanonicalJson.obj(mapOf(
        "algorithm" to CanonicalJson.string("ED25519_BEP44"),
        "device_id" to CanonicalJson.string(deviceId),
        "dht_public_key_raw_b64" to CanonicalJson.string(dhtPublicKeyRawB64),
        "publisher_certificate_type" to CanonicalJson.string("ArchivePublisherCertificateV1"),
        "publisher_certificate_version" to CanonicalJson.string("1.0.0"),
        "user_id" to CanonicalJson.string(userId),
    ))

    fun certificateJson(c: ArchivePublisherCertificateV1): String = CanonicalJson.obj(mapOf(
        "body" to bodyJson(c.userId, c.deviceId, c.dhtPublicKeyRawB64),
        "device_signature_b64" to CanonicalJson.string(c.deviceSignatureB64),
        "publisher_key_id" to CanonicalJson.string(c.publisherKeyId),
    ))
}

class JcaArchivePublisher private constructor(
    val keyPair: KeyPair,
    val certificate: ArchivePublisherCertificateV1,
) {
    fun signBep44(bytes: ByteArray): ByteArray = Signature.getInstance("Ed25519").run {
        initSign(keyPair.private); update(bytes); sign()
    }

    companion object {
        fun create(identity: JvmPrivateIdentity): JcaArchivePublisher {
            val kp = KeyPairGenerator.getInstance("Ed25519").generateKeyPair()
            val raw = Ed25519Raw.raw(kp.public)
            val rawB64 = B64Url.encode(raw)
            val body = ArchivePublisherCanonical.bodyJson(identity.user.userId, identity.certificate.deviceId, rawB64)
            val keyId = "dht:" + HexSha256.of(raw)
            val sig = identity.signMessage(body.toByteArray(Charsets.UTF_8))
            return JcaArchivePublisher(kp, ArchivePublisherCertificateV1(
                identity.user.userId, identity.certificate.deviceId, rawB64, keyId, B64Url.encode(sig)
            ))
        }
    }
}

object ArchivePublisherVerifier {
    fun verify(cert: ArchivePublisherCertificateV1, identity: PublicIdentityBundleV1): Boolean {
        if (!IdentityVerifier.verifyBundle(identity)) return false
        if (cert.userId != identity.user.userId || cert.deviceId != identity.device.deviceId) return false
        val raw = runCatching { B64Url.decode(cert.dhtPublicKeyRawB64) }.getOrNull() ?: return false
        if (raw.size != 32 || cert.publisherKeyId != "dht:" + HexSha256.of(raw)) return false
        val body = ArchivePublisherCanonical.bodyJson(cert.userId, cert.deviceId, cert.dhtPublicKeyRawB64)
        return runCatching {
            JcaCrypto.verify(
                PublicKeyCodec.ec(identity.device.body.signingPublicKeyB64),
                body.toByteArray(Charsets.UTF_8),
                B64Url.decode(cert.deviceSignatureB64),
            )
        }.getOrDefault(false)
    }
}
