package org.eidolang.feature.editor

import android.content.Context
import org.eidolang.core.canonical.EidogramCanonical
import org.eidolang.core.canonical.EidogramParser
import org.eidolang.core.model.EditorDraft
import org.eidolang.core.model.EditorDraftFactory

object DraftStore {
    private const val FILE_NAME = "eidogram-draft-v1.json"

    fun load(context: Context): Result<EditorDraft> = runCatching {
        val f = context.filesDir.resolve(FILE_NAME)
        if (!f.exists()) return@runCatching EditorDraft()
        EditorDraftFactory.fromDocument(EidogramParser.parseCanonical(f.readText(Charsets.UTF_8)))
    }

    fun save(context: Context, draft: EditorDraft): Result<Unit> = runCatching {
        val f = context.filesDir.resolve(FILE_NAME)
        val tmp = context.filesDir.resolve("$FILE_NAME.tmp")
        tmp.writeText(EidogramCanonical.documentJson(draft.document), Charsets.UTF_8)
        if (!tmp.renameTo(f)) {
            f.writeText(tmp.readText(Charsets.UTF_8), Charsets.UTF_8)
            tmp.delete()
        }
    }

    fun clear(context: Context) {
        context.filesDir.resolve(FILE_NAME).delete()
        context.filesDir.resolve("$FILE_NAME.tmp").delete()
    }
}
