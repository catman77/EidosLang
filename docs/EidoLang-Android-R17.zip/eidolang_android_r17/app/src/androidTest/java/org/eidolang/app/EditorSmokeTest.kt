package org.eidolang.app

import androidx.compose.ui.test.assertExists
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import org.junit.Rule
import org.junit.Test

class EditorSmokeTest {
    @get:Rule
    val rule = createAndroidComposeRule<MainActivity>()

    @Test
    fun editorCanvasAndCoreActionsAreVisible() {
        rule.onNodeWithText("Эйдограмма").assertExists()
        rule.onNodeWithText("Новая").assertExists()
        rule.onNodeWithText("Открыть").assertExists()
        rule.onNodeWithText("Экспорт").assertExists()
        rule.onNodeWithTag("eidogramCanvas").assertExists()
    }
}
