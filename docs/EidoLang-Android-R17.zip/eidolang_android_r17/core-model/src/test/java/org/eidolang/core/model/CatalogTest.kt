package org.eidolang.core.model

import org.junit.Assert.*
import org.junit.Test

class CatalogTest {
    @Test fun catalogHasExactly113UniqueGlyphs() {
        assertEquals(113,EidoGlyphCatalogV1.glyphs.size)
        assertEquals(113,EidoGlyphCatalogV1.glyphs.map{it.glyphId}.toSet().size)
        assertEquals(30,EidoGlyphCatalogV1.family(GlyphFamily.COLORED_CIRCLE).size)
        assertEquals(3,EidoGlyphCatalogV1.family(GlyphFamily.BLACK_DOT).size)
        assertEquals(72,EidoGlyphCatalogV1.family(GlyphFamily.BLACK_STICK).size)
        assertEquals(8,EidoGlyphCatalogV1.family(GlyphFamily.BLACK_OUTLINE).size)
    }
    @Test fun editorUndoRedo() {
        var d=EditorDraft()
        d=EditorReducer.reduce(d,EditorCommand.AddGlyph("circle.red.m"))
        d=EditorReducer.reduce(d,EditorCommand.TranslateSelected(10_000,20_000))
        assertEquals(510_000,d.snapshot.instances.single().transform.cxFp)
        d=EditorReducer.reduce(d,EditorCommand.Undo)
        assertEquals(500_000,d.snapshot.instances.single().transform.cxFp)
        d=EditorReducer.reduce(d,EditorCommand.Redo)
        assertEquals(510_000,d.snapshot.instances.single().transform.cxFp)
    }
}
