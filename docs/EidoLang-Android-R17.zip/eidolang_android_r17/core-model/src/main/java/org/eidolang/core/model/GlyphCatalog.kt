package org.eidolang.core.model

enum class GlyphFamily { COLORED_CIRCLE, BLACK_DOT, BLACK_STICK, BLACK_OUTLINE }

data class PaletteEntry(val index: Int, val name: String, val hexSrgb: String)

sealed interface GlyphRenderSpec {
    data class FilledCircle(val diameterFp: Int, val paletteIndex: Int) : GlyphRenderSpec
    data class Capsule(
        val lengthFp: Int,
        val thicknessFp: Int,
        val baseOrientationMdeg: Int,
        val paletteIndex: Int,
    ) : GlyphRenderSpec
    data class BlackOutline(
        val shape: String,
        val bboxWFp: Int,
        val bboxHFp: Int,
        val strokeWidthFp: Int,
        val paletteIndex: Int,
    ) : GlyphRenderSpec
}

data class GlyphDefinition(
    val glyphId: String,
    val family: GlyphFamily,
    val render: GlyphRenderSpec,
)

object EidoGlyphCatalogV1 {
    val palette = listOf(
        PaletteEntry(0, "red", "#E53935"),
        PaletteEntry(1, "orange", "#FB8C00"),
        PaletteEntry(2, "yellow", "#FDD835"),
        PaletteEntry(3, "green", "#43A047"),
        PaletteEntry(4, "cyan", "#00ACC1"),
        PaletteEntry(5, "blue", "#1E88E5"),
        PaletteEntry(6, "violet", "#8E24AA"),
        PaletteEntry(7, "white", "#FFFFFF"),
        PaletteEntry(8, "gray", "#9E9E9E"),
        PaletteEntry(9, "black", "#000000"),
    )

    private val circleDiameters = linkedMapOf("s" to 60_000, "m" to 90_000, "l" to 135_000)
    private val dotDiameters = linkedMapOf("s" to 24_000, "m" to 36_000, "l" to 54_000)
    private val stickLengths = linkedMapOf("s" to 90_000, "m" to 135_000, "l" to 202_500)
    private val stickThickness = linkedMapOf("thin" to 9_000, "normal" to 15_000, "thick" to 24_000)
    private val poses = listOf(0, 45, 90, 135, 180, 225, 270, 315)
    private val outline = linkedMapOf(
        "triangle" to (160_000 to 160_000),
        "square" to (150_000 to 150_000),
        "rectangle" to (180_000 to 120_000),
        "diamond" to (150_000 to 150_000),
        "circle" to (150_000 to 150_000),
        "ellipse" to (180_000 to 120_000),
        "cross" to (150_000 to 150_000),
        "plus" to (150_000 to 150_000),
    )

    val glyphs: List<GlyphDefinition> = buildList {
        palette.forEach { color ->
            circleDiameters.forEach { (size, diameter) ->
                add(GlyphDefinition(
                    "circle.${color.name}.$size",
                    GlyphFamily.COLORED_CIRCLE,
                    GlyphRenderSpec.FilledCircle(diameter, color.index),
                ))
            }
        }
        dotDiameters.forEach { (size, diameter) ->
            add(GlyphDefinition(
                "dot.black.$size",
                GlyphFamily.BLACK_DOT,
                GlyphRenderSpec.FilledCircle(diameter, 9),
            ))
        }
        poses.forEach { angle ->
            val pose = "pose" + angle.toString().padStart(3, '0')
            stickLengths.forEach { (lengthName, length) ->
                stickThickness.forEach { (thicknessName, thickness) ->
                    add(GlyphDefinition(
                        "stick.black.$pose.$lengthName.$thicknessName",
                        GlyphFamily.BLACK_STICK,
                        GlyphRenderSpec.Capsule(length, thickness, angle * 1000, 9),
                    ))
                }
            }
        }
        outline.forEach { (shape, dims) ->
            add(GlyphDefinition(
                "outline.$shape",
                GlyphFamily.BLACK_OUTLINE,
                GlyphRenderSpec.BlackOutline(shape, dims.first, dims.second, 9_000, 9),
            ))
        }
    }

    private val byId = glyphs.associateBy { it.glyphId }
    fun requireGlyph(id: String): GlyphDefinition = requireNotNull(byId[id]) { "Unknown glyph_id: $id" }
    fun family(family: GlyphFamily): List<GlyphDefinition> = glyphs.filter { it.family == family }
}
