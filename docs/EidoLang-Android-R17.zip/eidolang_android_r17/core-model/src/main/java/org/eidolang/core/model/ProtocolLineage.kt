package org.eidolang.core.model

object ProtocolLineage {
    const val MASTER_MANIFEST_HASH = "4667dcd42dec6e14aed1311525488370d141758ca8795aeb2ddfe8aecde57fd3"
    const val PRODUCTION_GRAMMAR_HASH = "d5afb09e6ecdcff8a4b2c9758af83f215059d1b5bc4ad32da3fb8dd191b69b19"
    const val PRODUCTION_BINDING_HASH = "130eed81541292dfc8ccfd48ba01a28c374cd8fa96285c51fb3ea978d530944a"
    const val GLYPH_CATALOG_ID = "EidoGlyphCatalogV1"
    const val GLYPH_CATALOG_HASH = "da2d3b72ff8d41abb8c293ce1deca44e99cb1d1a696e9834997395c6f6218005"
    const val DOCUMENT_TYPE = "EidogramDocumentV1"
    const val DOCUMENT_VERSION = "1.1.0"
    const val FIXED_POINT_ONE = 1_000_000
    const val CANVAS_W_FP = 1_000_000
    const val CANVAS_H_FP = 1_000_000
}
