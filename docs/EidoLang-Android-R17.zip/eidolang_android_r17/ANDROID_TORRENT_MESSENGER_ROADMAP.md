# Roadmap after R17

## R17 — transport source / reference admission — COMPLETE
Transport contract, mandatory R16 admission, WorkManager policy and pinned libtorrent JNI scaffold.

## R17.1 — native Android network admission — ENVIRONMENTAL GATE
Build/run libtorrent 2.1.1 with Android NDK; real two-node v2 swarm + BEP44 DHT tests.

## R18 — local repository + messenger UX
Contacts, conversation repository, replay/sequence enforcement, compose/send/receive and sync state.

## R19 — archive recovery
Pin/unpin, archive browser, restore after local database loss.

## R20 — multi-device
Additional device authorization, revocation and DAG-head merge.

## R20.1 — forward secrecy
Ratcheted session layer replacing static historical RSA key-box exposure.

## R21 — security/fuzzing
Parsers, crypto envelopes, DHT, torrent files and JNI/native fuzzing.

## R22 — Android 1.0
Two physical Android devices exchange encrypted signed eidograms without an application server and recover the signed history from BitTorrent/DHT.
