package org.eidolang.feature.editor

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import org.eidolang.core.model.*
import org.eidolang.core.render.drawGlyph
import org.eidolang.feature.library.GlyphPicker
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EidoEditorScreen(modifier:Modifier=Modifier) {
    var draft by remember { mutableStateOf(EditorDraft()) }
    val snapshot=draft.snapshot

    Scaffold(
        topBar={ TopAppBar(title={Text("Эйдограмма")},actions={
            TextButton(onClick={draft={ EditorReducer.reduce(draft,EditorCommand.Undo) }},enabled=draft.undo.isNotEmpty()){Text("↶")}
            TextButton(onClick={draft={ EditorReducer.reduce(draft,EditorCommand.Redo) }},enabled=draft.redo.isNotEmpty()){Text("↷")}
        }) },
        bottomBar={ Surface(shadowElevation=6.dp){ GlyphPicker(onGlyph={id->draft=EditorReducer.reduce(draft,EditorCommand.AddGlyph(id))}) } },
        modifier=modifier,
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            EditorToolbar(
                hasSelection=draft.selectedIds.isNotEmpty(),
                multi=draft.selectedIds.size>=2,
                on={cmd->draft=EditorReducer.reduce(draft,cmd)},
            )
            Canvas(
                Modifier.weight(1f).fillMaxWidth().background(androidx.compose.ui.graphics.Color(0xFFF3F3F3))
                    .pointerInput(snapshot,draft.selectedIds) {
                        detectTapGestures { p ->
                            val id=hitTest(snapshot,p,size.width.toFloat(),size.height.toFloat())
                            draft=EditorReducer.reduce(draft,EditorCommand.Select(id?.let(::setOf) ?: emptySet()))
                        }
                    }
                    .pointerInput(snapshot,draft.selectedIds) {
                        detectTransformGestures { _,pan,zoom,rotation ->
                            if(draft.selectedIds.isNotEmpty()) {
                                if(abs(pan.x)>0.1f || abs(pan.y)>0.1f) {
                                    val dx=(pan.x/size.width*1_000_000f).toInt(); val dy=(pan.y/size.height*1_000_000f).toInt()
                                    draft=EditorReducer.reduce(draft,EditorCommand.TranslateSelected(dx,dy))
                                }
                                if(abs(zoom-1f)>0.01f) draft=EditorReducer.reduce(draft,EditorCommand.ScaleSelected((zoom*1_000_000f).toInt()))
                                if(abs(rotation)>0.5f) draft=EditorReducer.reduce(draft,EditorCommand.RotateSelected((rotation*1000f).toInt()))
                            }
                        }
                    }
            ) {
                snapshot.instances.forEach { drawGlyph(it,selected=it.instanceId in draft.selectedIds) }
            }
        }
    }
}

@Composable
private fun EditorToolbar(hasSelection:Boolean,multi:Boolean,on:(EditorCommand)->Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal=8.dp,vertical=4.dp),horizontalArrangement=Arrangement.spacedBy(4.dp)) {
        AssistChip(onClick={on(EditorCommand.RotateSelected(-45_000))},label={Text("−45°")},enabled=hasSelection)
        AssistChip(onClick={on(EditorCommand.RotateSelected(45_000))},label={Text("+45°")},enabled=hasSelection)
        AssistChip(onClick={on(EditorCommand.SendBackward)},label={Text("↓ слой")},enabled=hasSelection)
        AssistChip(onClick={on(EditorCommand.BringForward)},label={Text("↑ слой")},enabled=hasSelection)
        AssistChip(onClick={on(EditorCommand.DeleteSelected)},label={Text("Удалить")},enabled=hasSelection)
    }
}

private fun hitTest(s:EidogramSnapshot,p:Offset,w:Float,h:Float):String? {
    val x=(p.x/w*1_000_000f).toInt(); val y=(p.y/h*1_000_000f).toInt()
    return s.instances.asReversed().minByOrNull { i ->
        val dx=i.transform.cxFp-x; val dy=i.transform.cyFp-y; dx.toLong()*dx+dy.toLong()*dy
    }?.takeIf { i ->
        val dx=i.transform.cxFp-x; val dy=i.transform.cyFp-y; dx.toLong()*dx+dy.toLong()*dy < 80_000L*80_000L
    }?.instanceId
}
