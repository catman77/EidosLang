# Android eidogram messenger roadmap after R14

## R14 — Android Editor MVP Scaffold — CURRENT
Finite 113-glyph catalog, Compose renderer/picker/editor, canonical document model, golden vectors.

## R14.1 — Editor Completion
- robust hit-testing by actual glyph bounds
- multi-select UI
- group/ungroup UI
- snap/grid optional presentation aid (not wire semantics)
- draft persistence
- export/import canonical EidogramDocumentV1
- Android instrumentation golden tests

## R15 — Identity + Message Envelope
- Ed25519 identity/device keys
- ConversationId
- signed immutable EidogramMessageV1
- encrypted message payload containing canonical eidogram bytes
- reply/reference graph

## R16 — Torrent Archive Model
- immutable ConversationSegment bundles
- segment manifest and content hashes
- torrent-v2 content addressing
- signed mutable conversation head

## R17 — Android P2P/Torrent Engine
- native torrent core via NDK/JNI
- DHT peer/content discovery
- downloading, validation and seeding
- WorkManager/background policy and explicit continuous-seeding mode

## R18 — Messenger UX
- contacts
- conversation list
- eidogram timeline
- compose/send/receive flow
- sync state

## R19 — Archive/Recovery
- local index
- pin/unpin
- archive browser
- restore a conversation after deleting the local database

## R20 — Multi-device
- device subkeys
- concurrent conversation heads
- deterministic DAG merge
- revocation/replay protection

## R21 — Security/Fuzzing
- malformed canonical JSON
- malicious glyph/document dimensions
- poisoned torrents
- forged/stale DHT heads
- oversized archives
- parser and JNI fuzzing

## R22 — Android 1.0 acceptance
Two ordinary Android devices, with no application server, can create identities, compose eidograms from the frozen glyph set, exchange them, converge on the same signed timeline, seed/archive the history, and recover it from the torrent network.
