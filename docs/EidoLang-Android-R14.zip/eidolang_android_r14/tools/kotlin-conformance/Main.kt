package org.eidolang.tools

import org.eidolang.core.model.*
import org.eidolang.core.canonical.*

private fun add(seq:Int,id:String,glyph:String,cx:Int=500_000,cy:Int=500_000,z:Int=0,scale:Int=1_000_000,rot:Int=0) =
    EidogramAction.Add(seq,id,glyph,FixedTransform(cx,cy,scale,scale,rot),z)

private fun check(name:String,d:EidogramDocumentV1,content:String,snapshot:String) {
    val c=EidogramCanonical.contentHash(d)
    val s=EidogramCanonical.snapshotHash(d)
    check(c==content) { "$name content hash mismatch: $c != $content" }
    check(s==snapshot) { "$name snapshot hash mismatch: $s != $snapshot" }
    println("PASS $name content=$c snapshot=$s")
}

fun main() {
    check(EidoGlyphCatalogV1.glyphs.size == 113)
    check(EidoGlyphCatalogV1.glyphs.map { it.glyphId }.toSet().size == 113)
    check(ProtocolLineage.GLYPH_CATALOG_HASH.length == 64)

    check("00_empty", EidogramDocumentV1(emptyList()), GoldenExpected._00_EMPTY_CONTENT, GoldenExpected._00_EMPTY_SNAPSHOT)
    check("01_red_circle", EidogramDocumentV1(listOf(add(0,"g000001","circle.red.m"))), GoldenExpected._01_RED_CIRCLE_CONTENT, GoldenExpected._01_RED_CIRCLE_SNAPSHOT)
    check("02_stick_dot_outline", EidogramDocumentV1(listOf(
        add(0,"g000001","stick.black.pose045.m.normal",350_000,500_000,0),
        add(1,"g000002","dot.black.s",500_000,500_000,1),
        add(2,"g000003","outline.triangle",680_000,500_000,2),
    )), GoldenExpected._02_STICK_DOT_OUTLINE_CONTENT, GoldenExpected._02_STICK_DOT_OUTLINE_SNAPSHOT)
    check("03_red_circle_direct", EidogramDocumentV1(listOf(add(0,"g000001","circle.red.m"))), GoldenExpected._03_RED_CIRCLE_DIRECT_CONTENT, GoldenExpected._03_RED_CIRCLE_DIRECT_SNAPSHOT)
    check("04_red_circle_via_blue", EidogramDocumentV1(listOf(
        add(0,"g000001","circle.blue.m"),
        EidogramAction.SetGlyph(1,"g000001","circle.red.m"),
    )), GoldenExpected._04_RED_CIRCLE_VIA_BLUE_CONTENT, GoldenExpected._04_RED_CIRCLE_VIA_BLUE_SNAPSHOT)
    check("05_group_transform", EidogramDocumentV1(listOf(
        add(0,"g000001","circle.violet.s",350_000,420_000,0),
        add(1,"g000002","stick.black.pose090.l.thick",560_000,530_000,1),
        EidogramAction.Group(2,"grp000001",listOf("g000001","g000002")),
        EidogramAction.SetTransform(3,"g000002",FixedTransform(600_000,530_000,1_200_000,1_200_000,45_000)),
    )), GoldenExpected._05_GROUP_TRANSFORM_CONTENT, GoldenExpected._05_GROUP_TRANSFORM_SNAPSHOT)

    val direct=EidogramDocumentV1(listOf(add(0,"g000001","circle.red.m")))
    val via=EidogramDocumentV1(listOf(add(0,"g000001","circle.blue.m"),EidogramAction.SetGlyph(1,"g000001","circle.red.m")))
    check(EidogramCanonical.snapshotHash(direct)==EidogramCanonical.snapshotHash(via))
    check(EidogramCanonical.contentHash(direct)!=EidogramCanonical.contentHash(via))

    var e=EditorDraft()
    e=EditorReducer.reduce(e,EditorCommand.AddGlyph("circle.red.m"))
    e=EditorReducer.reduce(e,EditorCommand.TranslateSelected(10_000,-20_000))
    val moved=e.snapshot.instances.single().transform
    check(moved.cxFp==510_000 && moved.cyFp==480_000)
    e=EditorReducer.reduce(e,EditorCommand.Undo)
    check(e.snapshot.instances.single().transform.cxFp==500_000)
    e=EditorReducer.reduce(e,EditorCommand.Redo)
    check(e.snapshot.instances.single().transform.cxFp==510_000)
    println("PASS editor reducer undo/redo")
    println("ALL R14 PURE-KOTLIN CONFORMANCE CHECKS PASS")
}
