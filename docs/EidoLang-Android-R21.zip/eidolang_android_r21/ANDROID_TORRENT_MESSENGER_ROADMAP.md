# Android eidogram messenger roadmap after R21

## R14–R21

Protocol/core layers now cover:

- eidogram authoring;
- immutable message identity/DAG;
- identity and multi-device authorization;
- encrypted message envelopes;
- asynchronous forward session;
- local repository/timeline;
- archive/recovery;
- independent history-vault recovery domain;
- legacy migration;
- recovery-secret backup;
- local rollback protection;
- adversarial/fuzz hardening;
- encrypted local drafts.

## R22 — Product completion / Android admission — NEXT

R22 should no longer invent core cryptographic structures unless a device/runtime counterexample forces one.

Required admission work:

1. build/install on actual Android toolchain;
2. AndroidKeyStore runtime validation for:
   - primary/secondary identity keys;
   - R20.1 session/prekey state;
   - R20.2 vault recovery secret;
   - R21 local drafts/rollback anchors;
3. first-run identity and secondary-device onboarding UX;
4. recovery backup UX:
   - encrypted backup file;
   - separate QR/offline recovery code;
   - explicit warning that losing both loses destructive recovery;
5. fresh-device restore UX must display `FRESHNESS UNPROVEN` until compared with another trusted checkpoint/device;
6. device/revocation and prekey-refresh UI/background work;
7. remaining SQLite metadata-at-rest decision and migration;
8. verified `migrate → recover → compare → retire legacy` workflow;
9. notifications/settings/archive browser finalization;
10. only then connect the real R17 BitTorrent/DHT backend and run two-device end-to-end admission.

Final product acceptance:

\[
TwoAndroidDevices
\land NoApplicationServer
\land SameMessageDAG
\land ForwardSession
\land RecoverableHistoryVault
\land VerifiedLegacyCutover
\]
