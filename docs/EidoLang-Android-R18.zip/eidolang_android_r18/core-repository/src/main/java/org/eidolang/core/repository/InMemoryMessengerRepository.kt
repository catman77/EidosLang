package org.eidolang.core.repository

class InMemoryMessengerRepository : MessengerRepository {
    private val contacts = linkedMapOf<Pair<String,String>, ContactDeviceRecord>()
    private val conversations = linkedMapOf<String, ConversationRecord>()
    private val messages = linkedMapOf<String, StoredMessageRecord>()
    private val seqIndex = linkedMapOf<Triple<String,String,Int>, String>()

    override fun putContact(record: ContactDeviceRecord) {
        val key = record.userId to record.deviceId
        // user_id/device_id identify the certified key body. The ECDSA root signature is proof
        // material and may be re-issued with different bytes for the same body. Validation is
        // performed by LocalMessengerService before storage.
        contacts[key] = record
    }

    override fun contactDevices(): List<ContactDeviceRecord> =
        contacts.values.sortedWith(compareBy<ContactDeviceRecord> { it.alias }.thenBy { it.userId }.thenBy { it.deviceId })

    override fun putConversation(record: ConversationRecord) {
        val old = conversations[record.conversationId]
        if (old != null) {
            require(old.descriptorCanonicalJson == record.descriptorCanonicalJson) {
                "Conflicting conversation descriptor"
            }
        }
        conversations[record.conversationId] = record
    }

    override fun conversations(): List<ConversationRecord> =
        conversations.values.sortedWith(compareByDescending<ConversationRecord> { it.createdAtMs }.thenBy { it.conversationId })

    override fun insertMessage(record: StoredMessageRecord): InsertMessageResult {
        val existing = messages[record.messageId]
        if (existing != null) {
            require(existing.envelopeCanonicalJson == record.envelopeCanonicalJson) {
                "Same message_id with different canonical bytes"
            }
            return InsertMessageResult.Duplicate
        }
        val seqKey = Triple(record.conversationId, record.senderDeviceId, record.senderSeq)
        val oldId = seqIndex[seqKey]
        require(oldId == null) {
            "Sender sequence equivocation: $seqKey already belongs to $oldId"
        }
        messages[record.messageId] = record
        seqIndex[seqKey] = record.messageId
        return InsertMessageResult.Inserted
    }

    override fun messages(conversationId: String): List<StoredMessageRecord> =
        messages.values.filter { it.conversationId == conversationId }
}
