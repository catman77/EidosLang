package org.eidolang.core.repository

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class AndroidSqliteMessengerRepository(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION),
    MessengerRepository {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE contacts(
                user_id TEXT NOT NULL,
                device_id TEXT NOT NULL,
                alias TEXT NOT NULL,
                bundle_json TEXT NOT NULL,
                imported_at_ms INTEGER NOT NULL,
                PRIMARY KEY(user_id, device_id)
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE conversations(
                conversation_id TEXT PRIMARY KEY,
                descriptor_json TEXT NOT NULL,
                title TEXT NOT NULL,
                created_at_ms INTEGER NOT NULL
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE messages(
                message_id TEXT PRIMARY KEY,
                conversation_id TEXT NOT NULL,
                sender_user_id TEXT NOT NULL,
                sender_device_id TEXT NOT NULL,
                sender_seq INTEGER NOT NULL,
                created_at_ms INTEGER NOT NULL,
                parent_ids TEXT NOT NULL,
                envelope_json TEXT NOT NULL,
                direction TEXT NOT NULL,
                local_state TEXT NOT NULL,
                stored_at_ms INTEGER NOT NULL,
                UNIQUE(conversation_id, sender_device_id, sender_seq)
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX idx_messages_conversation ON messages(conversation_id)")
        db.execSQL("CREATE INDEX idx_contacts_user ON contacts(user_id)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        error("No DB migrations defined yet: $oldVersion -> $newVersion")
    }

    override fun putContact(record: ContactDeviceRecord) {
        writableDatabase.beginTransaction()
        try {
            val v = ContentValues().apply {
                put("user_id", record.userId)
                put("device_id", record.deviceId)
                put("alias", record.alias)
                put("bundle_json", record.bundleCanonicalJson)
                put("imported_at_ms", record.importedAtMs)
            }
            writableDatabase.insertWithOnConflict("contacts", null, v, SQLiteDatabase.CONFLICT_REPLACE)
            writableDatabase.setTransactionSuccessful()
        } finally {
            writableDatabase.endTransaction()
        }
    }

    override fun contactDevices(): List<ContactDeviceRecord> {
        val out = mutableListOf<ContactDeviceRecord>()
        readableDatabase.rawQuery("""
            SELECT user_id,device_id,alias,bundle_json,imported_at_ms
            FROM contacts
            ORDER BY alias,user_id,device_id
        """.trimIndent(), null).use { c ->
            while (c.moveToNext()) {
                out += ContactDeviceRecord(
                    c.getString(0), c.getString(1), c.getString(2),
                    c.getString(3), c.getLong(4)
                )
            }
        }
        return out
    }

    override fun putConversation(record: ConversationRecord) {
        writableDatabase.beginTransaction()
        try {
            val existing = queryOne(
                "SELECT descriptor_json FROM conversations WHERE conversation_id=?",
                arrayOf(record.conversationId)
            ) { it.getString(0) }
            if (existing != null) {
                require(existing == record.descriptorCanonicalJson) { "Conflicting conversation descriptor" }
            }
            val v = ContentValues().apply {
                put("conversation_id", record.conversationId)
                put("descriptor_json", record.descriptorCanonicalJson)
                put("title", record.title)
                put("created_at_ms", record.createdAtMs)
            }
            writableDatabase.insertWithOnConflict("conversations", null, v, SQLiteDatabase.CONFLICT_REPLACE)
            writableDatabase.setTransactionSuccessful()
        } finally {
            writableDatabase.endTransaction()
        }
    }

    override fun conversations(): List<ConversationRecord> {
        val out = mutableListOf<ConversationRecord>()
        readableDatabase.rawQuery("""
            SELECT conversation_id,descriptor_json,title,created_at_ms
            FROM conversations
            ORDER BY created_at_ms DESC, conversation_id
        """.trimIndent(), null).use { c ->
            while (c.moveToNext()) {
                out += ConversationRecord(c.getString(0), c.getString(1), c.getString(2), c.getLong(3))
            }
        }
        return out
    }

    override fun insertMessage(record: StoredMessageRecord): InsertMessageResult {
        writableDatabase.beginTransaction()
        try {
            val byId = queryOne(
                "SELECT envelope_json FROM messages WHERE message_id=?",
                arrayOf(record.messageId)
            ) { it.getString(0) }
            if (byId != null) {
                require(byId == record.envelopeCanonicalJson) {
                    "Same message_id with different canonical bytes"
                }
                writableDatabase.setTransactionSuccessful()
                return InsertMessageResult.Duplicate
            }

            val bySeq = queryOne(
                "SELECT message_id FROM messages WHERE conversation_id=? AND sender_device_id=? AND sender_seq=?",
                arrayOf(record.conversationId, record.senderDeviceId, record.senderSeq.toString())
            ) { it.getString(0) }
            require(bySeq == null) {
                "Sender sequence equivocation: (${record.conversationId},${record.senderDeviceId},${record.senderSeq}) already belongs to $bySeq"
            }

            val v = ContentValues().apply {
                put("message_id", record.messageId)
                put("conversation_id", record.conversationId)
                put("sender_user_id", record.senderUserId)
                put("sender_device_id", record.senderDeviceId)
                put("sender_seq", record.senderSeq)
                put("created_at_ms", record.createdAtMs)
                put("parent_ids", record.parentMessageIds.joinToString(","))
                put("envelope_json", record.envelopeCanonicalJson)
                put("direction", record.direction.name)
                put("local_state", record.localState.name)
                put("stored_at_ms", record.storedAtMs)
            }
            require(writableDatabase.insertOrThrow("messages", null, v) != -1L)
            writableDatabase.setTransactionSuccessful()
            return InsertMessageResult.Inserted
        } finally {
            writableDatabase.endTransaction()
        }
    }

    override fun messages(conversationId: String): List<StoredMessageRecord> {
        val out = mutableListOf<StoredMessageRecord>()
        readableDatabase.rawQuery("""
            SELECT message_id,conversation_id,sender_user_id,sender_device_id,sender_seq,
                   created_at_ms,parent_ids,envelope_json,direction,local_state,stored_at_ms
            FROM messages
            WHERE conversation_id=?
        """.trimIndent(), arrayOf(conversationId)).use { c ->
            while (c.moveToNext()) {
                out += StoredMessageRecord(
                    messageId = c.getString(0),
                    conversationId = c.getString(1),
                    senderUserId = c.getString(2),
                    senderDeviceId = c.getString(3),
                    senderSeq = c.getInt(4),
                    createdAtMs = c.getLong(5),
                    parentMessageIds = c.getString(6).takeIf { it.isNotEmpty() }?.split(",") ?: emptyList(),
                    envelopeCanonicalJson = c.getString(7),
                    direction = MessageDirection.valueOf(c.getString(8)),
                    localState = MessageLocalState.valueOf(c.getString(9)),
                    storedAtMs = c.getLong(10),
                )
            }
        }
        return out
    }

    private fun <T> queryOne(sql: String, args: Array<String>, mapper: (android.database.Cursor) -> T): T? =
        readableDatabase.rawQuery(sql, args).use { c -> if (c.moveToFirst()) mapper(c) else null }

    companion object {
        private const val DB_NAME = "eidolang-messenger-r18.db"
        private const val DB_VERSION = 1
    }
}
