package org.eidolang.feature.messenger

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.eidolang.core.crypto.AndroidKeystoreIdentityStore
import org.eidolang.core.repository.*
import org.eidolang.feature.editor.EidoEditorScreen
import org.eidolang.feature.viewer.EidogramViewer

private sealed interface Screen {
    data object Conversations : Screen
    data object Contacts : Screen
    data class Conversation(val id: String) : Screen
    data class Compose(val id: String) : Screen
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EidoMessengerApp(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val identity = remember { AndroidKeystoreIdentityStore(context).ensure() }
    val repo = remember { AndroidSqliteMessengerRepository(context) }
    val service = remember { LocalMessengerService(repo, identity) }

    var screen: Screen by remember { mutableStateOf(Screen.Conversations) }
    var refresh by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf<String?>(null) }

    fun touch() { refresh++ }

    when (val s = screen) {
        Screen.Conversations -> ConversationListScreen(
            service = service,
            refresh = refresh,
            status = status,
            onContacts = { screen = Screen.Contacts },
            onOpen = { screen = Screen.Conversation(it) },
            onChanged = { touch() },
            onStatus = { status = it },
        )

        Screen.Contacts -> ContactsScreen(
            service = service,
            refresh = refresh,
            onBack = { screen = Screen.Conversations },
            onChanged = { touch() },
            onOpenConversation = { screen = Screen.Conversation(it) },
            onStatus = { status = it },
        )

        is Screen.Conversation -> ConversationScreen(
            service = service,
            conversationId = s.id,
            refresh = refresh,
            onBack = { screen = Screen.Conversations },
            onCompose = { screen = Screen.Compose(s.id) },
            onChanged = { touch() },
            onStatus = { status = it },
        )

        is Screen.Compose -> EidoEditorScreen(
            modifier = modifier,
            draftKey = "conversation:${s.id}",
            onSend = { doc ->
                service.send(s.id, doc, System.currentTimeMillis())
                touch()
                true
            },
            onClose = { screen = Screen.Conversation(s.id) },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConversationListScreen(
    service: LocalMessengerService,
    refresh: Int,
    status: String?,
    onContacts: () -> Unit,
    onOpen: (String) -> Unit,
    onChanged: () -> Unit,
    onStatus: (String?) -> Unit,
) {
    val context = LocalContext.current
    val summaries = remember(refresh) { service.conversationSummaries() }
    val importConversation = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)!!
                    .bufferedReader(Charsets.UTF_8).use { it.readText() }
                    .let { service.importConversation(it, createdAtMs = System.currentTimeMillis()) }
            }.onSuccess {
                onChanged()
                onStatus("Диалог импортирован")
            }.onFailure { onStatus("Импорт диалога отклонён: ${it.message}") }
        }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Эйдограммы") },
                actions = {
                    TextButton(onClick = { importConversation.launch(arrayOf("application/json")) }) { Text("Импорт диалога") }
                    TextButton(onClick = onContacts) { Text("Контакты") }
                },
            )
        },
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            status?.let {
                Text(
                    it,
                    Modifier.padding(12.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (summaries.isEmpty()) {
                Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
                    Text("Диалогов пока нет.")
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = onContacts) { Text("Добавить контакт") }
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(summaries, key = { it.conversationId }) { c ->
                        ListItem(
                            headlineContent = { Text(c.title) },
                            supportingContent = {
                                Text(
                                    when {
                                        c.messageCount == 0 -> "Сообщений нет"
                                        c.headMessageIds.size > 1 -> "${c.messageCount} сообщений · ${c.headMessageIds.size} ветви"
                                        else -> "${c.messageCount} сообщений"
                                    }
                                )
                            },
                            modifier = Modifier.clickable { onOpen(c.conversationId) },
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ContactsScreen(
    service: LocalMessengerService,
    refresh: Int,
    onBack: () -> Unit,
    onChanged: () -> Unit,
    onOpenConversation: (String) -> Unit,
    onStatus: (String?) -> Unit,
) {
    val context = LocalContext.current
    val contacts = remember(refresh) { service.contactSummaries() }

    val importContact = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)!!
                    .bufferedReader(Charsets.UTF_8).use { it.readText() }
                    .let { service.importContact(it, importedAtMs = System.currentTimeMillis()) }
            }.onSuccess {
                onChanged()
                onStatus("Контакт ${it.alias} импортирован")
            }.onFailure { onStatus("Импорт контакта отклонён: ${it.message}") }
        }
    }

    val exportMe = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)!!.use {
                    it.write(service.exportLocalIdentityCanonical().toByteArray(Charsets.UTF_8))
                }
            }.onSuccess { onStatus("Публичный контакт экспортирован") }
             .onFailure { onStatus("Ошибка экспорта: ${it.message}") }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Контакты") },
                navigationIcon = { TextButton(onClick = onBack) { Text("←") } },
                actions = {
                    TextButton(onClick = {
                        exportMe.launch("eidolang-contact-${service.localIdentity.user.userId.take(12)}.json")
                    }) { Text("Мой контакт") }
                    TextButton(onClick = { importContact.launch(arrayOf("application/json")) }) { Text("Импорт") }
                },
            )
        }
    ) { padding ->
        if (contacts.isEmpty()) {
            Column(Modifier.padding(padding).fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
                Text("Импортируйте публичный identity bundle другого пользователя.")
                Spacer(Modifier.height(12.dp))
                Button(onClick = { importContact.launch(arrayOf("application/json")) }) { Text("Импорт контакта") }
            }
        } else {
            LazyColumn(Modifier.padding(padding).fillMaxSize()) {
                items(contacts, key = { it.userId }) { c ->
                    ListItem(
                        headlineContent = { Text(c.alias) },
                        supportingContent = { Text("${c.deviceCount} устройство · ${c.userId.take(16)}…") },
                        trailingContent = {
                            TextButton(onClick = {
                                runCatching {
                                    service.createConversation(
                                        remoteUserIds = listOf(c.userId),
                                        createdAtMs = System.currentTimeMillis(),
                                    )
                                }.onSuccess {
                                    onChanged()
                                    onOpenConversation(it.conversationId)
                                }.onFailure { onStatus("Не удалось создать диалог: ${it.message}") }
                            }) { Text("Диалог") }
                        },
                    )
                    HorizontalDivider()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConversationScreen(
    service: LocalMessengerService,
    conversationId: String,
    refresh: Int,
    onBack: () -> Unit,
    onCompose: () -> Unit,
    onChanged: () -> Unit,
    onStatus: (String?) -> Unit,
) {
    val context = LocalContext.current
    val summary = remember(refresh, conversationId) {
        service.conversationSummaries().first { it.conversationId == conversationId }
    }
    val timeline = remember(refresh, conversationId) { service.timeline(conversationId) }

    val exportConversation = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)!!.use {
                    it.write(service.conversationDescriptorCanonical(conversationId).toByteArray(Charsets.UTF_8))
                }
            }.onSuccess { onStatus("Описание диалога экспортировано") }
             .onFailure { onStatus("Ошибка экспорта диалога: ${it.message}") }
        }
    }

    val importMessage = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)!!
                    .bufferedReader(Charsets.UTF_8).use { it.readText() }
                    .let { service.admitIncoming(it, System.currentTimeMillis(), conversationId) }
            }.onSuccess {
                onChanged()
                onStatus(if (it == InsertMessageResult.Duplicate) "Сообщение уже было получено" else "Сообщение принято")
            }.onFailure { onStatus("Сообщение отклонено: ${it.message}") }
        }
    }

    val exportMessage = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val raw = service.latestOutgoingCanonical(conversationId)
            if (raw == null) {
                onStatus("Нет исходящего сообщения для экспорта")
            } else {
                runCatching {
                    context.contentResolver.openOutputStream(uri)!!.use {
                        it.write(raw.toByteArray(Charsets.UTF_8))
                    }
                }.onSuccess { onStatus("Исходящее сообщение экспортировано") }
                 .onFailure { onStatus("Ошибка экспорта сообщения: ${it.message}") }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(summary.title) },
                navigationIcon = { TextButton(onClick = onBack) { Text("←") } },
                actions = {
                    TextButton(onClick = {
                        exportConversation.launch("conversation-${conversationId.take(12)}.json")
                    }) { Text("Диалог") }
                    TextButton(onClick = { importMessage.launch(arrayOf("application/json")) }) { Text("Импорт") }
                    TextButton(onClick = {
                        exportMessage.launch("eidolang-message-${System.currentTimeMillis()}.json")
                    }) { Text("Экспорт") }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onCompose) { Text("+") }
        },
    ) { padding ->
        if (timeline.isEmpty()) {
            Column(Modifier.padding(padding).fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
                Text("В этом диалоге пока нет эйдограмм.")
                Spacer(Modifier.height(12.dp))
                Button(onClick = onCompose) { Text("Создать эйдограмму") }
            }
        } else {
            LazyColumn(
                Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(timeline, key = { it.messageId }) { item ->
                    MessageCard(item)
                }
                item { Spacer(Modifier.height(72.dp)) }
            }
        }
    }
}

@Composable
private fun MessageCard(item: TimelineItem) {
    val alignment = if (item.outgoing) Arrangement.End else Arrangement.Start
    Row(Modifier.fillMaxWidth(), horizontalArrangement = alignment) {
        ElevatedCard(Modifier.widthIn(max = 300.dp)) {
            Column(Modifier.padding(8.dp)) {
                EidogramViewer(
                    document = item.document,
                    modifier = Modifier.fillMaxWidth().aspectRatio(1f),
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    if (item.outgoing) "Вы · #${item.senderSeq}" else "${item.senderUserId.take(10)}… · #${item.senderSeq}",
                    style = MaterialTheme.typography.labelSmall,
                )
                if (item.parentMessageIds.size > 1) {
                    Text("${item.parentMessageIds.size} родительские ветви", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}
