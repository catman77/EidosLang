# Android eidogram messenger roadmap after R18

## R14 / R14.1 — Eidogram editor — COMPLETE AT SOURCE LEVEL
Frozen 113-glyph editor, grouping, exact hit testing, canonical drafts/import/export.

## R15 — Identity + encrypted/signed message envelope — COMPLETE
Root/device identity, device certificates, conversation IDs, encrypted signed immutable
message DAG nodes.

## R16 — Torrent archive format — COMPLETE
Immutable segments, BitTorrent-v2 mapping and signed mutable conversation heads.

## R17 — Transport interface / admission — COMPLETE AT SOURCE LEVEL
Transport-neutral admission gate and native libtorrent scaffold. Real network execution is
deferred and is no longer a blocker for product development.

## R18 — Messenger UX + Local Repository — COMPLETE AT SOURCE LEVEL
- contacts;
- conversation list;
- persistent encrypted message repository;
- deterministic DAG timeline;
- replay/sequence enforcement;
- editor -> send flow;
- manual identity/conversation/message import/export;
- eidogram timeline rendering.

## R19 — Archive / Recovery — NEXT
- build R16 conversation segments directly from locally committed R18 messages;
- persist segment/index metadata;
- archive browser;
- pin/unpin state;
- export/import complete archive package;
- delete local message DB and reconstruct it from verified R16 segments;
- deterministic duplicate/overlap handling across segments.

## R20 — Multi-device
- root-authorized additional device certificates;
- device revocation state;
- import multiple devices per contact;
- concurrent conversation heads;
- deterministic DAG merge between local devices.

## R20.1 — Forward-secrecy session layer
- ratcheted session secrets;
- historical-key erasure;
- migration away from static historical RSA key boxes while retaining EidogramDocumentV1.

## R21 — Security / Fuzzing / local hardening
- database and draft at-rest protection;
- malformed canonical objects;
- key/certificate attacks;
- replay/equivocation corpus;
- archive poisoning;
- parser and JNI fuzzing.

## R22 — Android product completion
- settings/profile/contact UX polish;
- notifications;
- archive controls;
- installation/build admission on Android devices;
- finally connect and admit the real R17 BitTorrent/DHT backend.

Final acceptance remains two ordinary Android phones exchanging and recovering encrypted
eidogram conversations without an application server. Real network execution is deferred,
not deleted from that final acceptance criterion.
