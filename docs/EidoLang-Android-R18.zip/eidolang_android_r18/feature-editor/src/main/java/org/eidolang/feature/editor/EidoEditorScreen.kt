package org.eidolang.feature.editor

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import org.eidolang.core.canonical.EidogramCanonical
import org.eidolang.core.canonical.EidogramParser
import org.eidolang.core.model.*
import org.eidolang.core.render.drawGlyph
import org.eidolang.feature.library.GlyphPicker
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EidoEditorScreen(
    modifier: Modifier = Modifier,
    draftKey: String = "standalone",
    onSend: ((EidogramDocumentV1) -> Boolean)? = null,
    onClose: (() -> Unit)? = null,
) {
    val context = LocalContext.current
    var draft by remember(draftKey) {
        mutableStateOf(DraftStore.load(context, draftKey).getOrElse { EditorDraft() })
    }
    var multiSelect by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<String?>(null) }

    val snapshot = draft.snapshot

    fun setDraft(next: EditorDraft, persist: Boolean = true) {
        draft = next
        if (persist) {
            DraftStore.save(context, next, draftKey).onFailure {
                status = "Ошибка сохранения черновика: ${it.message}"
            }
        }
    }

    fun command(c: EditorCommand) = setDraft(EditorReducer.reduce(draft, c))

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json"),
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)!!.use {
                    it.write(EidogramCanonical.documentJson(draft.document).toByteArray(Charsets.UTF_8))
                }
            }.onSuccess {
                status = "Эйдограмма экспортирована"
            }.onFailure {
                status = "Ошибка экспорта: ${it.message}"
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)!!
                    .bufferedReader(Charsets.UTF_8).use { it.readText() }
                    .let(EidogramParser::parseCanonical)
                    .let(EditorDraftFactory::fromDocument)
            }.onSuccess {
                setDraft(it)
                multiSelect = false
                status = "Эйдограмма импортирована"
            }.onFailure {
                status = "Импорт отклонён: ${it.message}"
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (onSend == null) "Эйдограмма" else "Новое сообщение") },
                navigationIcon = {
                    if (onClose != null) {
                        TextButton(onClick = onClose) { Text("←") }
                    }
                },
                actions = {
                    if (onSend != null) {
                        TextButton(
                            onClick = {
                                if (snapshot.instances.isEmpty()) {
                                    status = "Пустую эйдограмму отправить нельзя"
                                } else {
                                    runCatching { onSend(draft.document) }
                                        .onSuccess { accepted ->
                                            if (accepted) {
                                                DraftStore.clear(context, draftKey)
                                                draft = EditorDraft()
                                                status = "Сообщение сохранено"
                                                onClose?.invoke()
                                            } else status = "Сообщение не принято"
                                        }
                                        .onFailure { status = "Ошибка отправки: ${it.message}" }
                                }
                            },
                            enabled = snapshot.instances.isNotEmpty(),
                        ) { Text("Отправить") }
                    }
                    TextButton(onClick = {
                        DraftStore.clear(context, draftKey)
                        setDraft(EditorDraft())
                        multiSelect = false
                        status = "Новая эйдограмма"
                    }) { Text("Новая") }
                    TextButton(onClick = { importLauncher.launch(arrayOf("application/json")) }) { Text("Открыть") }
                    TextButton(onClick = {
                        val h = EidogramCanonical.contentHash(draft.document).take(12)
                        exportLauncher.launch("eidogram-$h.json")
                    }) { Text("Экспорт") }
                    TextButton(onClick = { command(EditorCommand.Undo) }, enabled = draft.undo.isNotEmpty()) { Text("↶") }
                    TextButton(onClick = { command(EditorCommand.Redo) }, enabled = draft.redo.isNotEmpty()) { Text("↷") }
                },
            )
        },
        bottomBar = {
            Surface(shadowElevation = 6.dp) {
                GlyphPicker(onGlyph = { id -> command(EditorCommand.AddGlyph(id)) })
            }
        },
        modifier = modifier,
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            EditorToolbar(
                selectedCount = draft.selectedIds.size,
                multiSelect = multiSelect,
                canUngroup = snapshot.instances.any { it.instanceId in draft.selectedIds && it.groupId != null },
                onToggleMulti = {
                    multiSelect = !multiSelect
                    if (!multiSelect && draft.selectedIds.size > 1) command(EditorCommand.Select(emptySet()))
                },
                on = ::command,
            )
            status?.let {
                Text(
                    it,
                    Modifier.padding(horizontal = 12.dp, vertical = 3.dp),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Canvas(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .testTag("eidogramCanvas")
                    .background(Color(0xFFF3F3F3))
                    .pointerInput(snapshot, draft.selectedIds, multiSelect) {
                        detectTapGestures(
                            onTap = { p ->
                                val x = (p.x / size.width * ProtocolLineage.CANVAS_W_FP).toInt()
                                val y = (p.y / size.height * ProtocolLineage.CANVAS_H_FP).toInt()
                                val id = EidogramHitTest.hitTest(snapshot, x, y)
                                val selection =
                                    if (multiSelect) EditorSelection.toggle(snapshot, draft.selectedIds, id)
                                    else EditorSelection.single(snapshot, id)
                                command(EditorCommand.Select(selection))
                            },
                            onLongPress = { p ->
                                val x = (p.x / size.width * ProtocolLineage.CANVAS_W_FP).toInt()
                                val y = (p.y / size.height * ProtocolLineage.CANVAS_H_FP).toInt()
                                val id = EidogramHitTest.hitTest(snapshot, x, y)
                                if (id != null) {
                                    multiSelect = true
                                    command(EditorCommand.Select(EditorSelection.toggle(snapshot, draft.selectedIds, id)))
                                }
                            },
                        )
                    }
                    .pointerInput(snapshot, draft.selectedIds) {
                        detectTransformGestures { _, pan, zoom, rotation ->
                            if (draft.selectedIds.isNotEmpty()) {
                                if (abs(pan.x) > 0.1f || abs(pan.y) > 0.1f) {
                                    command(EditorCommand.TranslateSelected(
                                        (pan.x / size.width * ProtocolLineage.CANVAS_W_FP).toInt(),
                                        (pan.y / size.height * ProtocolLineage.CANVAS_H_FP).toInt(),
                                    ))
                                }
                                if (abs(zoom - 1f) > 0.01f) {
                                    command(EditorCommand.ScaleSelected((zoom * ProtocolLineage.FIXED_POINT_ONE).toInt()))
                                }
                                if (abs(rotation) > 0.5f) {
                                    command(EditorCommand.RotateSelected((rotation * 1000f).toInt()))
                                }
                            }
                        }
                    },
            ) {
                snapshot.instances.forEach { drawGlyph(it, selected = it.instanceId in draft.selectedIds) }
            }
        }
    }
}

@Composable
private fun EditorToolbar(
    selectedCount: Int,
    multiSelect: Boolean,
    canUngroup: Boolean,
    onToggleMulti: () -> Unit,
    on: (EditorCommand) -> Unit,
) {
    val hasSelection = selectedCount > 0
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        FilterChip(
            selected = multiSelect,
            onClick = onToggleMulti,
            label = { Text(if (selectedCount == 0) "Выбор" else "Выбрано $selectedCount") },
        )
        AssistChip(onClick = { on(EditorCommand.GroupSelected) }, label = { Text("Группа") }, enabled = selectedCount >= 2)
        AssistChip(onClick = { on(EditorCommand.UngroupSelected) }, label = { Text("Разгрупп.") }, enabled = canUngroup)
        AssistChip(onClick = { on(EditorCommand.RotateSelected(-45_000)) }, label = { Text("−45°") }, enabled = hasSelection)
        AssistChip(onClick = { on(EditorCommand.RotateSelected(45_000)) }, label = { Text("+45°") }, enabled = hasSelection)
        AssistChip(onClick = { on(EditorCommand.SendBackward) }, label = { Text("↓") }, enabled = hasSelection)
        AssistChip(onClick = { on(EditorCommand.BringForward) }, label = { Text("↑") }, enabled = hasSelection)
        AssistChip(onClick = { on(EditorCommand.DeleteSelected) }, label = { Text("Удалить") }, enabled = hasSelection)
    }
}
