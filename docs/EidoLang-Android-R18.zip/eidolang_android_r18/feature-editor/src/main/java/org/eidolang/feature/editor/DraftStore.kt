package org.eidolang.feature.editor

import android.content.Context
import org.eidolang.core.canonical.EidogramCanonical
import org.eidolang.core.canonical.EidogramParser
import org.eidolang.core.model.EditorDraft
import org.eidolang.core.model.EditorDraftFactory
import java.security.MessageDigest

object DraftStore {
    private fun fileName(key: String): String {
        val h = MessageDigest.getInstance("SHA-256")
            .digest(key.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
            .take(20)
        return "eidogram-draft-$h.json"
    }

    fun load(context: Context, key: String = "standalone"): Result<EditorDraft> = runCatching {
        val f = context.filesDir.resolve(fileName(key))
        if (!f.exists()) return@runCatching EditorDraft()
        EditorDraftFactory.fromDocument(EidogramParser.parseCanonical(f.readText(Charsets.UTF_8)))
    }

    fun save(context: Context, draft: EditorDraft, key: String = "standalone"): Result<Unit> = runCatching {
        val name = fileName(key)
        val f = context.filesDir.resolve(name)
        val tmp = context.filesDir.resolve("$name.tmp")
        tmp.writeText(EidogramCanonical.documentJson(draft.document), Charsets.UTF_8)
        if (!tmp.renameTo(f)) {
            f.writeText(tmp.readText(Charsets.UTF_8), Charsets.UTF_8)
            tmp.delete()
        }
    }

    fun clear(context: Context, key: String = "standalone") {
        val name = fileName(key)
        context.filesDir.resolve(name).delete()
        context.filesDir.resolve("$name.tmp").delete()
    }
}
